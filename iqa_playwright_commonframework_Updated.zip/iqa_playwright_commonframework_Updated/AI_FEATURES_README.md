# AI Add-on for iqa_playwright_commonframework — FULL AUTO + AUTO-FIX

Scenario in → files written directly into your real repo → pytest runs
automatically → **if it fails, AI fixes the likely file and retries
automatically (up to 3 attempts)**. `base_page.py` is never touched — it
is only read as reference, and it is never a candidate for auto-fix
either (it's your stable core file; only the AI-generated locators/page/
test files get auto-fixed).

## 0. Install (one time)

```bash
pip install google-generativeai playwright openpyxl --break-system-packages
playwright install chromium
```

Set your AI key:

```bash
set AI_BACKEND=gemini
set GEMINI_API_KEY=your_key_here
```

## 1. Copy into your real framework folder

```
src/common/utilities/ai_backend.py    -> same path in your repo
scripts/generate_scenario.py          -> same path in your repo
scripts/run_scenario.py               -> same path in your repo
reference/*.py                        -> new folder `reference/` in repo root
```

## 2. Run it — only place you type anything

```bash
python scripts/run_scenario.py
```

Answers the same 5 questions as before (repo path, bank, module,
scenario, URL).

## 3. What happens automatically

1. Live URL inspected for real selectors (if given).
2. AI generates locators + page class + test file + test data.
3. Files written directly into `src/banks/<bank>/locators/...`,
   `src/common/pages/<module>/...`, `src/testcase/<module>/...`,
   `src/banks/<bank>/testdata/<Module>.xlsx`.
4. `pytest -k <module>` runs.
5. **If it fails:** the failure output + the most likely broken file
   (chosen by keyword — "selector"/"timeout" → locators/page file,
   "excel"/"sheet"/"keyerror" → test file) are sent to the AI, which
   returns a corrected version of THAT ONE FILE. It's written back and
   pytest runs again.
6. This repeats up to **3 total attempts**. Each attempt's result prints
   live so you can watch what changed.
7. Final result: PASSED, or "could not fix automatically — here's where
   to look by hand."

## Example output

```
Running pytest with AI auto-fix enabled (up to 3 attempts)...

Running: pytest -k brand  (attempt 1/3)
FAILED - TimeoutError: locator '#TODO-verify-add-button' not found
FAILED. Asking AI to fix the likely file and retrying...
AI updated: src/banks/wio/locators/brand_locators.py

Running: pytest -k brand  (attempt 2/3)
PASSED on attempt 2.

Done - scenario ran successfully end-to-end.
```

## Why base_page.py is excluded from auto-fix

Auto-fix only ever rewrites the files THIS TOOL generated
(locators/page/test for the new module) — never `base_page.py`. That
file is shared by your whole framework; if a failure looks like it's
base_page's fault, auto-fix will say "could not determine a confident
fix" rather than touch it, and you should look at it yourself.

## Safety notes

- This writes and rewrites files directly in your repo automatically.
  **Always start on a clean `git status`** so a bad auto-fix attempt can
  be reverted with `git checkout -- <file>`.
- After a successful auto-fix run, open the final file versions once
  before committing — an AI fix that makes the test pass isn't
  automatically the *right* fix (e.g. it could loosen an assertion
  instead of fixing the real selector). Review before `git commit`.
- Never paste real credentials/passwords/internal URLs anywhere — only
  page HTML structure, your scenario text, and pytest's own output text
  are sent to the AI.
- If AI can't find a confident fix after attempt 1, it stops immediately
  rather than guessing repeatedly — you'll see "AI could not determine a
  confident fix" and the exact pytest output to debug manually.
