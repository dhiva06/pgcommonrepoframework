"""
verify_autoheal.py - End-to-end verification of the AI auto-heal pipeline.

What it does:
1. Launches a headless Chromium browser.
2. Navigates to the bundled demo_site/demobank_login.html.
3. Calls BasePage.fill_by_locator with a DELIBERATELY broken selector
   that won't match the real element id (we use the wrong id).
4. The action method's except block fires:
     a. Heuristic LocatorAutoHeal cannot find the broken selector either
     b. Gemini-heal is invoked
     c. Gemini reads the live DOM, finds the right element id
     d. Playwright validates the proposed selector
     e. SelectorUpdater writes the new selector back to a sandbox file
5. We assert the heal was successful and the log entry was created.

Usage:  python verify_autoheal.py
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

# Ensure project root is on the path
sys.path.insert(0, ".")

from playwright.sync_api import sync_playwright

from src.common.base.base_page import BasePage


# A class that pretends to be a locator namespace; the registry should
# be auto-populated from all bank files at session start, so the heal
# can resolve the source even without us registering manually.
class FakeLocator:
    def __init__(self, value: str) -> None:
        self._value = value

    def __str__(self) -> str:
        return self._value


def main() -> int:
    demo_path = (Path("demo_site").resolve() / "demobank_login.html").as_uri()
    print(f"[1/6] Demo page: {demo_path}")

    # 1. Build a sandbox copy of a real locator file so the bank-scope
    #    gate is satisfied and we can safely persist into it.
    src = Path("src/banks/pinelabs/locators/login_locators.py")
    sandbox_dir = Path("src/banks/pinelabs/locators/.verify_sandbox")
    sandbox_dir.mkdir(exist_ok=True)
    sandbox_file = sandbox_dir / "login_locators.py"
    shutil.copy2(src, sandbox_file)
    print(f"[2/6] Sandbox copy: {sandbox_file}")

    # 2. Register a deliberately broken selector in the global registry
    #    pointing at the sandbox file.
    from src.common.autoheal.selector_registry import GLOBAL_REGISTRY

    BROKEN = "#adminuserId_FAKE_BROKEN_VALUE"
    REAL = "#adminuserId"
    GLOBAL_REGISTRY.register(
        outer_class="PinelabsLoginLocators",
        inner_class="Admin",
        attr_name="username_field",
        selector=BROKEN,
        file_path=sandbox_file,
    )
    print(f"[3/6] Registered broken selector: {BROKEN!r}")

    # 3. Start Playwright and navigate to the demo page
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context()
        page = context.new_page()
        page.goto(demo_path)
        print(f"[4/6] Page loaded, title: {page.title()!r}")

        # 4. Instantiate BasePage and call fill_by_locator with the broken
        #    selector. The except block should:
        #       a. try heuristic (fails)
        #       b. call _gemini_heal
        #       c. Gemini reads DOM, proposes a fix
        #       d. Playwright validates the fix
        #       e. SelectorUpdater writes the new value to the sandbox file
        base = BasePage(page, module_name="VerifyAutoHeal")
        print(f"[5/6] BasePage created (heal_engine={base._get_heal_engine() is not None})")

        # Trigger the heal flow
        try:
            base.fill_by_locator(
                locator=BROKEN,
                text="demobankuser",
                description="Demobank user id",
                timeout=5000,  # Short timeout so the test is fast
            )
        except Exception as e:
            print(f"     Note: action raised: {type(e).__name__}: {e}")
        else:
            print("     Action returned True without raising - check the heal flow")

        browser.close()

    # 5. Verify the sandbox file was updated with the new selector
    print("[6/6] Verifying sandbox file was updated...")
    updater_text = sandbox_file.read_text(encoding="utf-8")
    if REAL in updater_text:
        # The new selector should be inside the file now
        if BROKEN in updater_text:
            # Could be that the BROKEN selector is now still present elsewhere
            # but the REAL selector should also be there
            pass
        print(f"     PASS: Real selector {REAL!r} now in file")
    else:
        print(f"     FAIL: Real selector {REAL!r} not found in file")
        print("     File contents:")
        for i, line in enumerate(updater_text.splitlines(), 1):
            print(f"       {i:3d}: {line}")
        return 1

    # 6. Check heal_history.jsonl has an entry
    log_path = Path("reports/autoheal_log.jsonl")
    if log_path.exists():
        lines = [l for l in log_path.read_text(encoding="utf-8").splitlines() if l.strip()]
        if lines:
            last = lines[-1]
            print(f"     PASS: heal_history.jsonl has {len(lines)} entry/entries")
            print(f"     Last entry: {last[:200]}")
        else:
            print("     FAIL: heal_history.jsonl is empty")
            return 1
    else:
        print("     FAIL: reports/autoheal_log.jsonl does not exist")
        return 1

    # Cleanup
    sandbox_file.unlink()
    sandbox_dir.rmdir()

    print("\n[SUCCESS] Auto-heal pipeline is working end-to-end!")
    return 0


if __name__ == "__main__":
    # Use the virtualenv Python so dependencies are available
    import subprocess, sys
    venv_python = Path(__file__).parent / ".venv" / "Scripts" / "python.exe"
    if venv_python.exists() and Path(sys.executable).resolve() != venv_python.resolve():
        result = subprocess.run([str(venv_python), __file__] + sys.argv[1:])
        sys.exit(result.returncode)

    # Also inject test-name context so heal_history.jsonl gets a proper name
    try:
        from src.common.autoheal.heal_action_helpers import set_current_test_name
        set_current_test_name("verify_autoheal::test_gemini_heal")
    except Exception:
        pass

    try:
        sys.exit(main())
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"\n[ERROR] {type(e).__name__}: {e}")
        sys.exit(1)
