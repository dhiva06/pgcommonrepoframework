
import pytest
from src.common.base.base_page import BasePage
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.Externalconnection import ExternalConnectionPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil

        
BANK_NAME=ConfigManager.get("bank")       
_rows_AddConnection = ExcelUtil.get_sheet("ExternalConnection", "AddConnection")
_rows_EditConnection = ExcelUtil.get_sheet("ExternalConnection", "EditConnection")
_rows_deleteConnection = ExcelUtil.get_sheet("ExternalConnection", "DeleteConnection")
_rows_NegativeCases = ExcelUtil.get_sheet("ExternalConnection", "NegativeCases")
_rows_NegativeCases2 = ExcelUtil.get_sheet("ExternalConnection", "NegativeCases2")


# ============================================================================================

_rows_AddSetupRountingPlan = ExcelUtil.get_sheet("ExternalConnection", "AddSetupRountingPlan")
_rows_NegativeSetupRountingPlan=ExcelUtil.get_sheet("ExternalConnection", "NegativeSetupRountingPlan")
_rows_NegativeSetupRountingPlan1=ExcelUtil.get_sheet("ExternalConnection", "NegativeSetupRountingPlan1")
_rows_DeleteSetupRountingPlan=ExcelUtil.get_sheet("ExternalConnection", "DeleteSetupRountingPlan")
_rows_EditSetupRountingPlan=ExcelUtil.get_sheet("ExternalConnection", "EditSetupRountingPlan")








 
 
@pytest.mark.sanity
@pytest.mark.regression
class TestExternalConnectionModule:
 
    @pytest.mark.parametrize(
        "data",
        _rows_AddConnection,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_AddConnection]
    )
    def test_external_connection_add(self, page, data):
        # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        base_page = BasePage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)
 
        connection_page = ExternalConnectionPage(page)
        connection_page.navigate_to_external_connection(BANK_NAME)
        connection_page.add_external_connection(BANK_NAME,data)
        connection_page.click_save_button(BANK_NAME,data)
        # page.pause()
        # page.wait_for_timeout(5000000)
        
        
        
        # ===================================EDIT===============================
        
    @pytest.mark.sanity

    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_EditConnection,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_EditConnection]
            )
    def test_external_connection_edit(self, page, data):
               
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
            # login_page.assert_dashboard_visible(BANK_NAME)
        connection_page = ExternalConnectionPage(page)
        connection_page.navigate_to_external_connection(BANK_NAME)
        connection_page.edit_external_connection(BANK_NAME, data)
        connection_page.click_save_button(BANK_NAME,data)
               
                
                
    # ========================DELETE====================================
    
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_deleteConnection,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_deleteConnection]
            )
    def test_external_connection_delete(self, page, data):
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)

        connection_page = ExternalConnectionPage(page)
        connection_page.navigate_to_external_connection(BANK_NAME)
        connection_page.delete_connection(BANK_NAME, data)
            
            
            
    # ================Negative cases================================================
    
    
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeCases,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_NegativeCases]

    )
    def test_external_connection_NegativeCases(self, page, data):
        # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
            # login_page.assert_dashboard_visible(BANK_NAME)
 
        connection_page = ExternalConnectionPage(page)
        connection_page.navigate_to_external_connection(BANK_NAME)
        connection_page.add_external_connection_NegativeCases(BANK_NAME,data)
            
            
    # ================Negative cases================================================
        
        
        
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeCases2,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_NegativeCases2]
        )
    def test_external_connection_NegativeCases2(self, page, data):
            # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
                # login_page.assert_dashboard_visible(BANK_NAME)
     
        connection_page = ExternalConnectionPage(page)
        connection_page.navigate_to_external_connection(BANK_NAME)
        connection_page.add_external_connection(BANK_NAME,data)
        connection_page.click_save_button2(BANK_NAME,data)
                
                
                
# ===========================================================================================================
# ===========================================================================================================


            
    @pytest.mark.parametrize(
        "data",
        _rows_AddSetupRountingPlan,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_AddSetupRountingPlan]
         )
    def test_Rounting_plan_add(self, page, data):
             # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
             # login_page.assert_dashboard_visible(BANK_NAME)
      
        connection_page = ExternalConnectionPage(page)  
        connection_page.navigate_to_setuproutingplan(BANK_NAME)
        page.wait_for_timeout(5000)
        connection_page.click_add_button(BANK_NAME)
        connection_page._add_rounting_plan(BANK_NAME, data)
             
             
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeSetupRountingPlan,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_NegativeSetupRountingPlan]
             )
    def test_Rounting_plan_NegativeCases(self, page, data):
                 # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
                 # login_page.assert_dashboard_visible(BANK_NAME)
          
        connection_page = ExternalConnectionPage(page)  
        connection_page.navigate_to_setuproutingplan(BANK_NAME)
        page.wait_for_timeout(5000)
        connection_page.click_add_button(BANK_NAME)
        connection_page._add_rounting_plan_Negative(BANK_NAME, data)
                 
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeSetupRountingPlan1,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_NegativeSetupRountingPlan1]
                 )
    def test_Rounting_plan_NegativeCases2(self, page, data):
                     # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
                     # login_page.assert_dashboard_visible(BANK_NAME)
              
        connection_page = ExternalConnectionPage(page)  
        connection_page.navigate_to_setuproutingplan(BANK_NAME)
        page.wait_for_timeout(5000)
        connection_page.click_add_button(BANK_NAME)
        connection_page._add_rounting_plan_Negative1(BANK_NAME, data)
          

    @pytest.mark.parametrize(
        "data",
        _rows_EditSetupRountingPlan,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_EditSetupRountingPlan]
    )
    def test_setuproutingplan_edit(self, page, data):
        """Verify the edit functionality of Setup routing plan."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        connection_page = ExternalConnectionPage(page)  
        connection_page.navigate_to_setuproutingplan(BANK_NAME)
        page.wait_for_timeout(5000)
        connection_page.editing_routing_plan(BANK_NAME,data)
   

    @pytest.mark.parametrize(
        "data",
        _rows_DeleteSetupRountingPlan,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_DeleteSetupRountingPlan]
    )
    def test_setuproutingplan_delete(self, page, data):
        """Verify the delete functionality of Setup routing plan."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)
        
        
        connection_page = ExternalConnectionPage(page)  
        connection_page.navigate_to_setuproutingplan(BANK_NAME)
        page.wait_for_timeout(5000)
        connection_page.edit_routing_plan(BANK_NAME,data)
        page.wait_for_timeout(5000)
        connection_page.delete_routing_plan(BANK_NAME,data)
        
        
       
        
       

  
        
    
        
        
        
        
        
        
        
    
 
