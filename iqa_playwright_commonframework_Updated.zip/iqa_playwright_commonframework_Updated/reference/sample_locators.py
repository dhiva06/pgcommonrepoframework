class CurrencyLocators:
    # Navigation
    menu_configuration = "(//span[contains(text(),'Configuration')])[1]"
    menu_currency = "//span[text()='Currency']"
 
    # Currency list page
    add_button = "//input[@value='Add']"
 
    # Add Currency form
    currency_code_input = "//input[@name='currCode']"
    currency_description_input = "//input[@name='currDesc']"
    minor_digits_input = "//input[@name='minorDigits']"
    currency_symbol_input = "//input[@name='currSymbol']"
    save_button = "//input[@value='Save']"
    Successmsg = "//div[@id='msgcodediv']"
    message_container = "//div[contains(@class, 'alert')]"
    add_currency_page_title = "//h1[text()='Add Currency']"
 
    # Currency list page for View/Edit/ChangeStatus
    # Dynamic row locator template (to be formatted with currency_code)
    row_template = "//tr[.//*[contains(normalize-space(),'{currency_code}')]]"
    view_button = row_template + "//a[contains(normalize-space(),'View')]"
    edit_button = row_template + "//a[text()='Edit']"
    checkbox = row_template + "//div[contains(@class,'prettycheckbox')]//a"
    change_status_button = "//input[@value='Change Status']"
    page_2 = "//a[contains(@onclick,'curnPage') and normalize-space()='2']"
 
    pagination_links = "//a[contains(@class,'pageNumber')]"
 
    # View Currency page
    view_currency_code = "//span[@data-testid='view-currency-code']"
    view_currency_description = "//span[@data-testid='view-currency-description']"
    view_minor_digits = "//span[@data-testid='view-minor-digits']"
    view_currency_symbol = "//span[@data-testid='view-currency-symbol']"
    view_status = "//span[@data-testid='view-status']"
    back_button = "//input[@value='Back']"
    view_page_header = "//h4[contains(text(),'View Currency')]"
 
    # assertion locators for negative scenarios
    CurrencyCodeAsZero = "//label[text()='Should not contain zero']"
    CurrencyCodeAlreacyExist = "//div[contains(text(),'Currency already exist')]"
    CurrencyCodewithspecialchar = "//label[contains(text(),'Should be numeric')]"
    CurrencyCodewithAlphabets = "//label[contains(text(),'Should be numeric')]"
    CurrencyCodewithAlphanumeric = "//label[contains(text(),'Should be numeric')]"
    CurrencyCodeEmpty = "//label[contains(text(),'Enter a value')]"
    validation_message = (
        "//label[@class='must' and contains(normalize-space(),'{message}')]"
    )
    CurrencyCodeValidation = "//label[@id='Labelcurrcode']"
    CurrencyDescriptionValidation = "//label[@id='LabelcurrDesc']"
    MinorDigitsValidation = "//label[@id='LabelminorDigits']"
    CurrencySymbolValidation = "//label[@id='Labelcurrsymbol']"