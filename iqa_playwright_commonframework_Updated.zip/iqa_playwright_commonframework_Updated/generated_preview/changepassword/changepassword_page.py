"""Page-object class for the Change Password module."""

from src.common.base.base_page import BasePage
from src.banks.wio.locators.changepassword_locators import ChangepasswordLocators as WioChangepasswordLocators


class ChangepasswordPage(BasePage):
    """Encapsulates all actions for the My Accounts > Change Password flow."""

    def __init__(self, page, module_name: str = "Changepassword") -> None:
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "wio": (self._changepassword_standard, WioChangepasswordLocators),
        }

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def navigate_to_changepassword(self, bank: str) -> None:
        """Click through My Accounts > Change Password."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_myaccounts, "My Accounts menu")
        self.click_by_locator(loc.menu_changepassword, "Change Password submenu")

    # ------------------------------------------------------------------
    # Add / Change Password
    # ------------------------------------------------------------------

    def fill_changepassword_form(self, bank: str, data: dict) -> None:
        """Delegate field-filling to the bank-specific helper."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _changepassword_standard(self, loc, data: dict) -> None:
        """Standard three-field change-password form used by Wio."""
        self.fill_by_locator(
            loc.current_password_input,
            data["Old Password"],
            "Old Password",
        )
        self.fill_by_locator(
            loc.new_password_input,
            data["New Password"],
            "New Password",
        )
        self.fill_by_locator(
            loc.confirm_password_input,
            data["Confirm New Password"],
            "Confirm New Password",
        )

    def click_save_button(self, bank: str) -> None:
        """Submit the Change Password form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save / Submit button")

    def click_cancel_button(self, bank: str) -> None:
        """Click the Cancel button to reset the Change Password form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.cancel_button, "Cancel button")

    def assert_changepassword_message(self, bank: str, expected_message: str) -> None:
        """Assert the feedback message shown after form submission."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            self.locator(loc.message_container),
            expected_message,
            "Change Password response message",
        )

    def execute_add_changepassword(self, bank: str, data: dict) -> None:
        """Navigate to Change Password, fill all fields, save, assert result, then cancel to reset."""
        self.navigate_to_changepassword(bank)
        self.fill_changepassword_form(bank, data)
        self.click_save_button(bank)
        self.assert_changepassword_message(bank, data["ExpectedMessage"])
        self.click_cancel_button(bank)

    # ------------------------------------------------------------------
    # View  (display the Change Password page; no record-grid involved)
    # ------------------------------------------------------------------

    def assert_changepassword_form_visible(self, bank: str) -> None:
        """Assert the Change Password form fields are visible (View check)."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(
            self.locator(loc.current_password_input),
            "Current Password field",
        )
        self.assert_visible(
            self.locator(loc.new_password_input),
            "New Password field",
        )
        self.assert_visible(
            self.locator(loc.confirm_password_input),
            "Confirm Password field",
        )

    # ------------------------------------------------------------------
    # Edit  (re-use the same form; just re-fill and re-submit)
    # ------------------------------------------------------------------

    def fill_edit_changepassword_form(self, bank: str, data: dict) -> None:
        """Fill the change-password form with updated values (Edit flow)."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    # ------------------------------------------------------------------
    # Change Status
    # NOTE: Change Password is a transactional form, not a record with a
    # status toggle.  The ChangeStatus action here is interpreted as
    # verifying the form is accessible (active/enabled state) and checking
    # the expected message from the test data.
    # Update this method once the real application's behaviour is known.
    # ------------------------------------------------------------------

    def assert_form_accessible(self, bank: str, expected_message: str) -> None:
        """Assert the Change Password form is accessible / enabled."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(
            self.locator(loc.save_button),
            "Save button (form accessible)",
        )
        self.assert_text(
            self.locator(loc.message_container),
            expected_message,
            "Change Password status message",
        )

    # ------------------------------------------------------------------
    # SetChangePassword
    # ------------------------------------------------------------------

    def fill_setchangepassword_form(self, bank: str, data: dict) -> None:
        """Fill the set-change-password form fields (Old, New, Confirm New)."""
        _, loc = self._dispatch[bank.lower()]
        self._setchangepassword_standard(loc, data)

    def _setchangepassword_standard(self, loc, data: dict) -> None:
        """Standard three-field set-change-password form used by Wio."""
        self.fill_by_locator(
            loc.current_password_input,
            data["Old Password"],
            "Old Password",
        )
        self.fill_by_locator(
            loc.new_password_input,
            data["New Password"],
            "New Password",
        )
        self.fill_by_locator(
            loc.confirm_password_input,
            data["Confirm New Password"],
            "Confirm New Password",
        )

    def assert_setchangepassword_message(self, bank: str, expected_message: str) -> None:
        """Assert the feedback message shown after set-change-password form submission."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            self.locator(loc.message_container),
            expected_message,
            "Set Change Password response message",
        )

    def execute_setchangepassword_changepassword(self, bank: str, data: dict) -> None:
        """Navigate to Change Password, fill fields, save, and assert result."""
        self.navigate_to_changepassword(bank)
        self.fill_setchangepassword_form(bank, data)
        self.click_save_button(bank)
        self.assert_setchangepassword_message(bank, data["ExpectedMessage"])
