"""Locators for the Change Password module - Wio bank portal."""


class ChangepasswordLocators:
    """XPath locators for My Accounts > Change Password."""

    # Navigation
    menu_myaccounts = "//span[contains(text(),'My\u00a0Accounts\u00a0\u00a0')]"
    menu_changepassword = "//span[contains(text(),'Change\u00a0Password')]"

    # Form fields
    current_password_input = "//input[@name='currentPassword' or @id='currentPassword' or @placeholder='Current Password']"
    new_password_input = "//input[@name='newPassword' or @id='newPassword' or @placeholder='New Password']"
    confirm_password_input = "//input[@name='confirmPassword' or @id='confirmPassword' or @placeholder='Confirm Password']"

    # Buttons
    save_button = "//input[@value='Submit' or @value='Save' or @type='submit']"
    cancel_button = "//input[@value='Cancel' or @type='reset'] | //button[contains(text(),'Cancel')]"

    # Messages / feedback
    message_container = "//div[contains(@class,'success') or contains(@class,'error') or contains(@class,'message') or contains(@class,'alert')]"

    # TODO: replace every locator above (except menu_myaccounts and
    # menu_changepassword, which were verified live) with the real XPath
    # once the live Change Password page has been inspected in browser DevTools.
