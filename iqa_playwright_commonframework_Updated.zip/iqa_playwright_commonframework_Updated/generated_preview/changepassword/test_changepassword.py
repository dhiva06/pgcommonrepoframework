"""Tests for the Change Password module - My Accounts > Change Password."""

import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.changepassword.changepassword_page import ChangepasswordPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_add_rows = ExcelUtil.get_sheet("Changepassword", "Add")
_view_rows = ExcelUtil.get_sheet("Changepassword", "View")
_edit_rows = ExcelUtil.get_sheet("Changepassword", "Edit")
_changestatus_rows = ExcelUtil.get_sheet("Changepassword", "Changestatus")
_setchangepassword_rows = ExcelUtil.get_sheet("Changepassword", "Setchangepassword")


@pytest.mark.sanity
@pytest.mark.regression
class TestChangepasswordModule:
    """Covers Add, View, Edit, ChangeStatus, and SetChangePassword flows for Change Password."""

    # ------------------------------------------------------------------
    # Add
    # ------------------------------------------------------------------

    @pytest.mark.parametrize(
        "data",
        _add_rows,
        ids=[
            f'{r["ScenarioID"]} - {r["TestcaseID"]} - {r["Description"]}'
            for r in _add_rows
        ],
    )
    def test_changepassword_add(self, page, data):
        """Verify all password validation rules by filling Old Password, New Password, and Confirm New Password, then saving and asserting the result."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        cp_page = ChangepasswordPage(page)
        cp_page.execute_add_changepassword(BANK_NAME, data)

    # ------------------------------------------------------------------
    # View
    # ------------------------------------------------------------------

    @pytest.mark.parametrize(
        "data",
        _view_rows,
        ids=[
            f'{r["ScenarioID"]} - {r["TestcaseID"]} - {r["Description"]}'
            for r in _view_rows
        ],
    )
    def test_changepassword_view(self, page, data):
        """Verify that the Change Password form is visible and all fields are displayed."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        cp_page = ChangepasswordPage(page)
        cp_page.navigate_to_changepassword(BANK_NAME)
        cp_page.assert_changepassword_form_visible(BANK_NAME)

    # ------------------------------------------------------------------
    # Edit
    # ------------------------------------------------------------------

    @pytest.mark.parametrize(
        "data",
        _edit_rows,
        ids=[
            f'{r["ScenarioID"]} - {r["TestcaseID"]} - {r["Description"]}'
            for r in _edit_rows
        ],
    )
    def test_changepassword_edit(self, page, data):
        """Verify that the user can update their password using the Change Password form."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        cp_page = ChangepasswordPage(page)
        cp_page.navigate_to_changepassword(BANK_NAME)
        cp_page.fill_edit_changepassword_form(BANK_NAME, data)
        cp_page.click_save_button(BANK_NAME)
        cp_page.assert_changepassword_message(BANK_NAME, data["ExpectedMessage"])

    # ------------------------------------------------------------------
    # ChangeStatus
    # ------------------------------------------------------------------

    @pytest.mark.parametrize(
        "data",
        _changestatus_rows,
        ids=[
            f'{r["ScenarioID"]} - {r["TestcaseID"]} - {r["Description"]}'
            for r in _changestatus_rows
        ],
    )
    def test_changepassword_changestatus(self, page, data):
        """Verify that the Change Password form is accessible (status check)."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        cp_page = ChangepasswordPage(page)
        cp_page.navigate_to_changepassword(BANK_NAME)
        cp_page.assert_form_accessible(BANK_NAME, data["ExpectedMessage"])

    # ------------------------------------------------------------------
    # SetChangePassword
    # ------------------------------------------------------------------

    @pytest.mark.parametrize(
        "data",
        _setchangepassword_rows,
        ids=[
            f'{r["ScenarioID"]} - {r["TestcaseID"]} - {r["Description"]}'
            for r in _setchangepassword_rows
        ],
    )
    def test_changepassword_setchangepassword(self, page, data):
        """Verify all password validation rules on the Change Password form."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        cp_page = ChangepasswordPage(page)
        cp_page.navigate_to_changepassword(BANK_NAME)
        cp_page.fill_setchangepassword_form(BANK_NAME, data)
        cp_page.click_save_button(BANK_NAME)
        cp_page.assert_setchangepassword_message(BANK_NAME, data["ExpectedMessage"])
