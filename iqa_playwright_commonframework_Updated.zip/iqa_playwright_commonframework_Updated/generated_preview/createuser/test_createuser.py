"""Createuser module automation tests."""

import pytest
from src.common.pages.authentication.admin_login_page import AdminLoginPage
from src.common.pages.createuser.createuser_page import CreateuserPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows = ExcelUtil.get_sheet("Createuser", "Createuser")


@pytest.mark.sanity
@pytest.mark.regression
class TestCreateuserModule:
    """Tests covering end-to-end user creation workflow in the Admin Portal."""

    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows]
    )
    def test_createuser(self, page, data):
        """Verify user creation functionality with positive and validation data."""
        login_page = AdminLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        createuser_page = CreateuserPage(page)
        createuser_page.execute_createuser(data)
