from src.common.base.base_page import BasePage
from src.banks.wio.locators.createuser_locators import CreateuserLocators


class CreateuserPage(BasePage):
    """Page object class for Create User functionality in WIO Admin Portal."""

    def __init__(self, page, module_name="Createuser"):
        super().__init__(page, module_name=module_name)

    def execute_createuser(self, data: dict) -> None:
        """Executes the complete Create User scenario end-to-end."""
        self.hover_by_getbytext("My Accounts", "My Accounts menu")
        self.click_by_locator(CreateuserLocators.menu_create_user, "Create User sub-menu")
        self.click_by_locator(CreateuserLocators.add_button, "Add button")

        self.fill_by_locator(CreateuserLocators.username_field, data.get("User Name"), "User Name")
        self.fill_by_locator(CreateuserLocators.user_id_field, data.get("User ID"), "User ID")
        self.fill_by_locator(CreateuserLocators.description_field, data.get("Description Field"), "Description")

        user_role = data.get("User Role")
        if user_role:
            try:
                self.select_custom_dropdown("cuSel-0", user_role)
            except Exception:
                self.fill_by_locator(CreateuserLocators.user_role_dropdown, user_role, "User Role")

        self.fill_by_locator(CreateuserLocators.email_field, data.get("E-mail ID"), "E-mail ID")
        self.fill_by_locator(CreateuserLocators.mobile_field, data.get("Mobile Number"), "Mobile Number")

        start_time = data.get("Work Start Time", "00:00")
        if start_time and ":" in start_time:
            start_hr, start_min = start_time.split(":")
            try:
                self.select_custom_dropdown("cuSel-1", start_hr)
                self.select_custom_dropdown("cuSel-2", start_min)
            except Exception:
                pass

        end_time = data.get("Work End Time", "23:59")
        if end_time and ":" in end_time:
            end_hr, end_min = end_time.split(":")
            try:
                self.select_custom_dropdown("cuSel-3", end_hr)
                self.select_custom_dropdown("cuSel-4", end_min)
            except Exception:
                pass

        if data.get("Enable User Expiry") == "Yes":
            self.click_by_locator(CreateuserLocators.enable_user_expiry_yes, "Enable User Expiry Yes")
        else:
            self.click_by_locator(CreateuserLocators.enable_user_expiry_no, "Enable User Expiry No")

        if data.get("Block User") == "Yes":
            self.click_by_locator(CreateuserLocators.block_user_yes, "Block User Yes")
        else:
            self.click_by_locator(CreateuserLocators.block_user_no, "Block User No")

        self.click_by_locator(CreateuserLocators.save_button, "Save button")

        if data.get("ExpectedMessage"):
            self.assert_text(self.locator(CreateuserLocators.message_label), data["ExpectedMessage"], "Status message")

        self.click_by_locator(CreateuserLocators.logout_button, "Logout button")
