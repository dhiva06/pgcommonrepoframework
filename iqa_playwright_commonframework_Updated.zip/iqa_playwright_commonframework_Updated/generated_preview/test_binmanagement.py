"""
BIN Management module tests.
"""
import pytest
from src.common.fixtures.browser_fixtures import page
from src.common.pages.binmanagement.binmanagement_page import BinmanagementPage
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


@pytest.mark.ecentric
@pytest.mark.sanity
class TestBinmanagementModule:
    """BIN Management Add, View, Edit, and Delete flows."""

    @pytest.fixture(autouse=True)
    def setup(self, page):
        """Setup test fixtures."""
        self.page = page
        self.bank = ConfigManager.get("bank")

    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        ExcelUtil.get_sheet("Binmanagement", "Add"),
        ids=lambda x: f"{x['ScenarioID']}-{x['TestcaseID']}-{x['Description']}"
    )
    def test_binmanagement_add(self, data):
        """Add a new BIN with all required fields and verify it appears in the listing with correct status."""
        RuntimeData.resolve(data, "Binmanagement", self.bank)
        
        login_page = BankLoginPage(self.page)
        login_page.login(self.bank)
        login_page.assert_dashboard_visible(self.bank)
        
        bin_page = BinmanagementPage(self.page)
        bin_page.navigate_to_binmanagement(self.bank)
        bin_page.click_add_button(self.bank)
        bin_page.fill_binmanagement_form(self.bank, data)
        bin_page.click_send_for_approval_button(self.bank)
        
        # Extract the generated BIN for use in subsequent tests
        generated_bin = data["BIN"]
        bin_page.assert_bin_in_listing(self.bank, generated_bin, "New", "Approval pending")
        
        # Store for View/Edit/Delete to reuse
        RuntimeData.store(self.bank, "Binmanagement", "BIN", generated_bin)

    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        ExcelUtil.get_sheet("Binmanagement", "View"),
        ids=lambda x: f"{x['ScenarioID']}-{x['TestcaseID']}-{x['Description']}"
    )
    def test_binmanagement_view(self, data):
        """View a BIN and verify all fields match what was entered during Add."""
        RuntimeData.resolve(data, "Binmanagement", self.bank)
        
        login_page = BankLoginPage(self.page)
        login_page.login(self.bank)
        login_page.assert_dashboard_visible(self.bank)
        
        bin_page = BinmanagementPage(self.page)
        bin_page.navigate_to_binmanagement(self.bank)
        bin_page.search_and_open_bin(self.bank, data["BIN"])
        bin_page.assert_bin_details(self.bank, data)

    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        ExcelUtil.get_sheet("Binmanagement", "Edit"),
        ids=lambda x: f"{x['ScenarioID']}-{x['TestcaseID']}-{x['Description']}"
    )
    def test_binmanagement_edit(self, data):
        """Edit a BIN by changing Card type and Country, verify request history and updated fields."""
        RuntimeData.resolve(data, "Binmanagement", self.bank)
        
        login_page = BankLoginPage(self.page)
        login_page.login(self.bank)
        login_page.assert_dashboard_visible(self.bank)
        
        bin_page = BinmanagementPage(self.page)
        bin_page.navigate_to_binmanagement(self.bank)
        bin_page.click_expand_icon_and_edit(self.bank, data["BIN"])
        bin_page.update_binmanagement_form(self.bank, data)
        bin_page.click_edit_send_for_approval(self.bank)
        
        bin_page.assert_edit_request_history(self.bank, "Edit", "Approval pending")
        bin_page.navigate_to_binmanagement(self.bank)
        bin_page.search_and_open_bin(self.bank, data["BIN"])
        bin_page.assert_edit_fields_updated(self.bank, data)

    @pytest.mark.order(3)
    @pytest.mark.parametrize(
        "data",
        ExcelUtil.get_sheet("Binmanagement", "Delete"),
        ids=lambda x: f"{x['ScenarioID']}-{x['TestcaseID']}-{x['Description']}"
    )
    def test_binmanagement_delete(self, data):
        """Delete a BIN and verify the request history shows DELETE with Approval pending status."""
        RuntimeData.resolve(data, "Binmanagement", self.bank)
        
        login_page = BankLoginPage(self.page)
        login_page.login(self.bank)
        login_page.assert_dashboard_visible(self.bank)
        
        bin_page = BinmanagementPage(self.page)
        bin_page.navigate_to_binmanagement(self.bank)
        bin_page.click_delete_icon(self.bank, data["BIN"])
        bin_page.confirm_delete_dialog(self.bank)
        bin_page.assert_delete_request_history(self.bank, "DELETE", "Approval pending")
