from src.common.base.base_page import BasePage
from src.banks.wio.locators.brandtype_locators import BrandtypeLocators as WioBrandtypeLocators


class BrandtypePage(BasePage):
    def __init__(self, page, module_name="Brandtype"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "wio": (self._add_standard, WioBrandtypeLocators),
        }

    def navigate_to_brandtype(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.hover_by_getbytext(loc.menu_configuration, "Configuration menu")
        self.click_by_locator(loc.menu_brandtype, "Brand Type submenu")

    def click_add_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_brandtype_form(self, bank: str, data: dict) -> None:
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        self.fill_by_locator(loc.brand_type_name_input, data["Brand Type Name"], "Brand Type Name")
        self.fill_by_locator(loc.description_input, data["Description Value"], "Description")

    def click_save_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_brandtype_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(loc.message_container, expected_message, "Response Message")

    def click_logout_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.logout_button, "Logout button")
