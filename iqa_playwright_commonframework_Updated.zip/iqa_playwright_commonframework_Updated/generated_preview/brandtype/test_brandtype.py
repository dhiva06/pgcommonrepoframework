"""Tests for Brandtype module functionality."""

import pytest
from src.common.pages.authentication.admin_login_page import AdminLoginPage
from src.common.pages.brandtype.brandtype_page import BrandtypePage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows = ExcelUtil.get_sheet("Brandtype", "Add")


@pytest.mark.sanity
@pytest.mark.regression
class TestBrandtypeModule:
    """Test cases for Brandtype module addition flow."""

    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows]
    )
    def test_execute_add_brandtype(self, page, data):
        """Verify adding a brand type with various data combinations."""
        login_page = AdminLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        brandtype_page = BrandtypePage(page)
        brandtype_page.navigate_to_brandtype(BANK_NAME)
        brandtype_page.click_add_button(BANK_NAME)
        brandtype_page.fill_brandtype_form(BANK_NAME, data)
        brandtype_page.click_save_button(BANK_NAME)
        brandtype_page.assert_brandtype_message(BANK_NAME, data["ExpectedMessage"])
        brandtype_page.click_logout_button(BANK_NAME)
