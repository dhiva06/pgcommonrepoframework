import pytest
from src.common.pages.authentication.merchant_login_page import MerchantLoginPage
from src.common.pages.merchant.self_configuration_api_page import SelfConfigurationApiPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows = ExcelUtil.get_sheet("self_configuration_api", "API")

@pytest.mark.sanity
@pytest.mark.regression
class TestselfconfigAPI:
    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows]
    )
    def test_self_config_API(self, page, data):
        testcase = data["TestcaseID"]
        """Verify the add functionality of User Role across banks"""
        # Step 1: Login via AdminLoginPage
        login_page = MerchantLoginPage(page)
        login_page.login(BANK_NAME)
        test= SelfConfigurationApiPage(page)
        test.navigate_to_api_key(BANK_NAME, data)
        test.assert_api_key_dashboard_page(BANK_NAME)
        if testcase=="TC_API_KEY_004 to TC_006, and TC-10,TC-11, TC-13,TC-15 to TC-19,TC,24,TC_036 to TC-039, TC-45,TC-46,TC-47,TC-48":
            test.add_api_key_ecentric(BANK_NAME, data)
            # test.verify_api_key_generation_success_popup(BANK_NAME,data)
            test.verify_Navigation_to_generate_api_page(BANK_NAME, data)
            test.verify_key_id(BANK_NAME, data)
            test.verify_key_secret(BANK_NAME, data)
            downloaded_file=test.download_api_key(BANK_NAME, data)
            print(downloaded_file)
            test.verify_date_creation_based_on_key_expiry_type(BANK_NAME, data)
            test.verify_expiry_based_on_key_expiry_type(BANK_NAME, data)
        elif testcase=="TC_API_KEY_012,TC-014 and TC_042 to TC_44":
            test.verify_default_key_expiry_preview_page(BANK_NAME,data)
        elif testcase=="TC_API_KEY_21 and TC_API_KEY_025":
            test.verify_new_api_key_added(BANK_NAME, data)
        elif testcase=="TC_API_KEY_022":
            test.verify_self_configuration_tabs(BANK_NAME, data)
        elif testcase=="TC_API_KEY_027 and TC_API_KEY_028":
            test.verify_date_creation_format(BANK_NAME, data)
        elif testcase=="TC_API_KEY_029":
            test.verify_channel_value(BANK_NAME, data)
        elif testcase=="TC_API_KEY_030 and TC_API_KEY_031":
            test.verify_expiry_date(BANK_NAME, data)
        elif testcase=="TC_API_KEY_041":
            test.verify_My_Account(BANK_NAME, data)
        #--------change the key expiry in bank portal in instituition in terminal
        #  based on that configure in excel Automatic key renewal in Instituition as "yes" or "no"
        #  then run the script
        elif testcase=="TC_API_KEY_053 and TC_054":
            test.verify_auto_populated_expiry_date(BANK_NAME, data)

        #---------pass the inactive terminalid from excel in terminalid coloumn
        elif testcase=="TC_API_KEY_009":
            test.verify_inactive_terminal_not_displayed(BANK_NAME, data)
        elif testcase=="TC_API_KEY_032 to TC_API_KEY_035":
            test.verify_delete_api_key(BANK_NAME, data)
        

        

        
            
