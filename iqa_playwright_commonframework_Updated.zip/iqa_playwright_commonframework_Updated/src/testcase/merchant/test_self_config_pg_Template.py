"""selfconfiguration: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Selfconfiguration.xlsx
"""
import pytest
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.pages.authentication.merchant_login_page import MerchantLoginPage
from src.common.pages.merchant.self_config_Pg_Template_page import SelfconfigurationPage


BANK_NAME = ConfigManager.get("bank")
_rows = ExcelUtil.get_sheet("Selfconfiguration_Pg_template", "Testcase")


# ==================================================================
# TESTS
# ==================================================================
class TestSelfconfigurationModule:

    # ==================================EDIT==================================

    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_selfconfiguration_Pg_template(self, page, data):
        bank = ConfigManager.get("bank")
        login_page = MerchantLoginPage(page)
        login_page.login(bank)
        selfconfig_page = SelfconfigurationPage(page)
        selfconfig_page.navigate_to_pg_template(bank, data)
        selfconfig_page.assert_pg_template_dashboard_page(bank, data)
        if data["TestcaseID"] == "TC_PG_TEMPLATE_006":
            selfconfig_page.verify_push_live_pg_template(bank, data)
        elif data["TestcaseID"] == "TC_PG_TEMPLATE_007":
            selfconfig_page.verify_back_to_edit_pg_template(bank, data)
        elif data["TestcaseID"] == "TC_PG_TEMPLATE_008":
            selfconfig_page.verify_upload_and_edit_logo(bank, data)
        elif data["TestcaseID"] in ("TC_PG_TEMPLATE_014", "TC_PG_TEMPLATE_015"):
            selfconfig_page.verify_invalid_logo_upload(bank, data)
        elif data["TestcaseID"] == "TC_PG_TEMPLATE_016":
            selfconfig_page.verify_select_color(bank, data)
        elif data["TestcaseID"] == "TC_PG_TEMPLATE_018 to TC_PG_TEMPLATE_019":
            selfconfig_page.verify_language_dropdown(bank, data)
        elif data["TestcaseID"] == "TC_PG_TEMPLATE_021 to TC_PG_TEMPLATE_022":
            selfconfig_page.verify_template_dropdown(bank, data)
        elif data["TestcaseID"] in ("TC_PG_TEMPLATE_023", "TC_PG_TEMPLATE_024", "TC_PG_TEMPLATE_025", "TC_PG_TEMPLATE_026", "TC_PG_TEMPLATE_027", "TC_PG_TEMPLATE_028", "TC_PG_TEMPLATE_029", "TC_PG_TEMPLATE_030", "TC_PG_TEMPLATE_031", "TC_PG_TEMPLATE_032", "TC_PG_TEMPLATE_033", "TC_PG_TEMPLATE_034", "TC_PG_TEMPLATE_035", "TC_PG_TEMPLATE_036"):
            selfconfig_page.verify_preview_page(bank, data)

   