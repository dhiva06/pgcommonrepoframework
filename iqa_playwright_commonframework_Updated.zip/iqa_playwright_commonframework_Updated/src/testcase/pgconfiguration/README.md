# Pgconfiguration module

## Add

Not applicable. The PG Configuration module has no create/Add flow — it only configures existing records (e.g., updating settings, logos, or app icons tied to a pre-existing entry). No `execute_add_pgconfiguration` method exists for this module.

Supported actions instead: Update, AddLogo, DeleteLogo, AddAppIcon, DeleteAppIcon — documented separately.
