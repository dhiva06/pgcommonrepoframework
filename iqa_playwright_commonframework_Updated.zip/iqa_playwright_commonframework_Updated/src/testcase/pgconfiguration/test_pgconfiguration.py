import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.pgconfiguration.pgconfiguration_page import PgconfigurationPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows_update = ExcelUtil.get_sheet("Pgconfiguration", "Update")
_rows_addlogo = ExcelUtil.get_sheet("Pgconfiguration", "Addlogo")
_rows_deletelogo = ExcelUtil.get_sheet("Pgconfiguration", "Deletelogo")
_rows_addappicon = ExcelUtil.get_sheet("Pgconfiguration", "Addappicon")
_rows_deleteappicon = ExcelUtil.get_sheet("Pgconfiguration", "Deleteappicon")

@pytest.mark.sanity
@pytest.mark.regression
@pytest.mark.ecentric
class TestPgconfigurationModule:
    @pytest.mark.parametrize(
        "data",
        _rows_update,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_update]
    )
    def test_pgconfiguration_update(self, page, data):
        """Verify the update functionality of PG configuration"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        pgconfig_page = PgconfigurationPage(page)
        pgconfig_page.execute_update_pgconfiguration(BANK_NAME, data)

    @pytest.mark.parametrize(
        "data",
        _rows_addlogo,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_addlogo]
    )
    def test_pgconfiguration_addlogo(self, page, data):
        """Verify the add logo functionality of PG configuration"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        pgconfig_page = PgconfigurationPage(page)
        pgconfig_page.execute_addlogo_pgconfiguration(BANK_NAME, data)

    @pytest.mark.parametrize(
        "data",
        _rows_deletelogo,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_deletelogo]
    )
    def test_pgconfiguration_deletelogo(self, page, data):
        """Verify the delete logo functionality of PG configuration"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        pgconfig_page = PgconfigurationPage(page)
        pgconfig_page.execute_deletelogo_pgconfiguration(BANK_NAME, data)

    @pytest.mark.parametrize(
        "data",
        _rows_addappicon,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_addappicon]
    )
    def test_pgconfiguration_addappicon(self, page, data):
        """Verify the add app icon functionality of PG configuration"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        pgconfig_page = PgconfigurationPage(page)
        pgconfig_page.execute_addappicon_pgconfiguration(BANK_NAME, data)

    @pytest.mark.parametrize(
        "data",
        _rows_deleteappicon,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_deleteappicon]
    )
    def test_pgconfiguration_deleteappicon(self, page, data):
        """Verify the delete app icon functionality of PG configuration"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        pgconfig_page = PgconfigurationPage(page)
        pgconfig_page.execute_deleteappicon_pgconfiguration(BANK_NAME, data)
