import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.reports.transaction_summary_reports_page import TransactionsummaryreportsPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows = ExcelUtil.get_sheet("Reports", "Transaction_summary_reports")

# @pytest.mark.sanity
# @pytest.mark.regression
class TestTransactionSummaryReport:
    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows]
    )
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    def test_transaction_detail_reports(self, page, data):
        testcase = data["TestcaseID"]
        """Verify the add functionality of User Role across banks"""
        # Step 1: Login via AdminLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        test=TransactionsummaryreportsPage(page)
        test.navigate_to_transaction_summary_reports(BANK_NAME)
        test.Transaction_detail_dashboard_summary(BANK_NAME, data)
        test.Bank_test_execution(BANK_NAME, data)
        
        

        

        
            
