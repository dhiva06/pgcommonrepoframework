# Goconnect module

## Add

Adds a new GoConnect connection with specified product, network, and connection parameters.
**Bank:** Ecentric

- Verifies Add connection page displays with correct breadcrumb, Product network segmentation section, and Connection details section
- Creates connection with PG product, MASTERCARD network, client mode, echo enabled (7s frequency, 8 retries), and IP/port configuration; validates success message and redirect to listing
- Searches for newly created connection and confirms it appears in listing with correct product, network, mode, and STOPPED status
