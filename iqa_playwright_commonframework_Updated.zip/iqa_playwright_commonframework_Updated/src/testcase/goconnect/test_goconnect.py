"""goconnect: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Goconnect.xlsx
"""
import pytest
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.goconnect.goconnect_page import GoconnectPage, GoconnectPageNegative


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Goconnect", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Goconnect", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("Goconnect", "Add")
_rows_Edit = ExcelUtil.get_sheet("Goconnect", "Edit")
_rows_Delete = ExcelUtil.get_sheet("Goconnect", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestGoconnectModule:

    # ==================================ADD==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d['ScenarioID']}-{d['TestcaseID']}-{d['Description']}"
    )
    def test_goconnect_add(self, page, data):
        """Verify adding a new GoConnect connection with all required details."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "goconnect", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        goconnect_page = GoconnectPage(page)
        goconnect_page.navigate_to_goconnect(bank_name)
        goconnect_page.click_add_button(bank_name)
        goconnect_page.fill_product_network_segmentation(bank_name, data)
        goconnect_page.fill_connection_details(bank_name, data)
        goconnect_page.click_save_button(bank_name)
        goconnect_page.assert_add_success_message(bank_name, data["ExpectedMessage"])
        goconnect_page.assert_goconnect_listing_displayed(bank_name)
        goconnect_page.search_connection(bank_name, data["Connection name"])
        goconnect_page.assert_listing_shows_connection(
            bank_name,
            data["Connection name"],
            data["Product"],
            data["Network"],
            data["Connection mode"],
            "STOPPED"
        )


    # ==================================EDIT==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d['ScenarioID']}-{d['TestcaseID']}-{d['Description']}"
    )
    def test_goconnect_edit(self, page, data):
        """Verify editing an existing GoConnect connection and verifying updated values."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "goconnect", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        goconnect_page = GoconnectPage(page)
        goconnect_page.navigate_to_goconnect_edit(bank_name)
        goconnect_page.search_and_open_connection_summary(bank_name, data["Connection name"])
        goconnect_page.assert_connection_summary_page_displayed(
            bank_name,
            data["Connection name"],
            data["Product"],
            data["Network"],
            data["Connection mode"],
            data["Login required"],
            data["Auto login flag"],
            data["Echo required"],
            data["Echo frequency"],
            data["Echo retry attempts"],
            data["IP address"],
            data["Port"],
            "STOPPED"
        )
        goconnect_page.click_edit_icon(bank_name)
        goconnect_page.assert_edit_page_prepopulated(
            bank_name,
            data["Connection name"],
            data["Product"],
            data["Network"],
            data["Echo frequency"],
            data["Echo retry attempts"],
            data["IP address"],
            data["Port"]
        )
        goconnect_page.update_connection_details(bank_name, data)
        goconnect_page.click_update_button(bank_name)
        goconnect_page.assert_edit_success_message(bank_name, data["ExpectedMessage"])
        goconnect_page.verify_updated_values_in_summary(
            bank_name,
            data["Connection name"],
            data["Echo frequency"],
            data["Echo retry attempts"],
            data["IP address"],
            data["Port"]
        )


    # ==================================DELETE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(3)
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d['ScenarioID']}-{d['TestcaseID']}-{d['Description']}"
    )
    def test_goconnect_delete(self, page, data):
        """Verify deleting a GoConnect connection and confirming removal from listing."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "goconnect", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        goconnect_page = GoconnectPage(page)
        goconnect_page.navigate_to_goconnect_delete(bank_name)
        goconnect_page.search_and_open_connection_for_delete(bank_name, data["Connection name"])
        goconnect_page.assert_listing_shows_one_connection(bank_name, data["Connection name"], "STOPPED")
        goconnect_page.click_delete_button(bank_name)
        goconnect_page.assert_delete_confirmation_dialog_displayed(bank_name)
        goconnect_page.click_delete_confirmation_yes(bank_name)
        goconnect_page.assert_delete_success_message(bank_name, data["ExpectedMessage"])
        goconnect_page.verify_connection_not_found_after_delete(bank_name, data["Connection name"])


    # ==================================NEGATIVE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d['ScenarioID']}-{d['TestcaseID']}-{d['Description']}"
    )
    def test_add_goconnect_negative(self, page, data):
        """Verify negative scenarios for adding a GoConnect connection."""
        data = RuntimeData.resolve(data, "goconnect", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        goconnect_page = GoconnectPageNegative(page)
        goconnect_page.navigate_to_goconnect(BANK_NAME)
        goconnect_page.add_goconnect_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d['ScenarioID']}-{d['TestcaseID']}-{d['Description']}"
    )
    def test_edit_goconnect_negative(self, page, data):
        """Verify negative scenarios for editing a GoConnect connection."""
        data = RuntimeData.resolve(data, "goconnect", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        goconnect_page = GoconnectPageNegative(page)
        goconnect_page.navigate_to_goconnect_edit(BANK_NAME)
        goconnect_page.edit_goconnect_negative(BANK_NAME, data)
