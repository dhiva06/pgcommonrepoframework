# Serviceintegration module

## Edit Service Integration

Modifies service integration configuration settings for an existing integration record.

Verified for: **Ecentric**

- Positive case: successfully updates integration settings and confirms changes persist
- Negative case: rejects invalid configuration values with appropriate error messaging
- Negative case: prevents submission when required fields are left empty

## Add

Adds a new service integration configuration to the system.

Verified for: **Ecentric**

- Validates successful creation with valid integration parameters (name, service type, credentials)
- Rejects duplicate service names with appropriate error messaging
- Confirms required fields are enforced and form submission fails when omitted
