"""serviceintegration: negative tests for validation errors, invalid state transitions, and missing prerequisites.

Test data lives in src/banks/ecentric/testdata/Serviceintegration.xlsx (Negative sheet)
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.serviceintegration.serviceintegration_page import ServiceintegrationPageNegative
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Serviceintegration", "Negative")


@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestServiceintegrationNegativeModule:
    """Test suite for Service integration configuration - negative scenarios covering validation errors, invalid states, and missing prerequisites."""

    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_serviceintegration_negative(self, page, data):
        """Execute negative test scenarios for Service integration.
        
        Test covers: invalid state transitions, missing prerequisites, conflicting options, 
        and validation errors across tokenization, services, and payment method sections.
        """
        data = RuntimeData.resolve(data, "serviceintegration", BANK_NAME)
        bank = ConfigManager.get("bank")

        # Login
        login_page = BankLoginPage(page)
        login_page.login(bank)
        login_page.assert_dashboard_visible(bank)

        # Navigate to Service integration
        negative_page = ServiceintegrationPageNegative(page)
        negative_page.navigate_to_serviceintegration(bank)

        # Execute negative action based on NegativeType
        negative_type = data.get("NegativeType", "").strip()

        if negative_type == "COFT_InvalidState":
            negative_page.select_coft_enable_without_channel_support_negative(bank, data)
        elif negative_type == "AlternatePayments_InvalidState":
            negative_page.select_alternate_payments_without_prerequisites_negative(bank, data)
        elif negative_type == "OffUsSupport_InvalidState":
            negative_page.disable_off_us_support_without_prerequisites_negative(bank, data)
        elif negative_type == "SaveWithoutRequiredSelections":
            negative_page.save_without_required_selections_negative(bank, data)
        elif negative_type == "ConflictingTokenizationOptions":
            negative_page.toggle_conflicting_tokenization_options_negative(bank, data)
        elif negative_type == "ConflictingServicesOptions":
            negative_page.toggle_conflicting_services_options_negative(bank, data)
        elif negative_type == "ConflictingPaymentMethodOptions":
            negative_page.toggle_conflicting_payment_method_options_negative(bank, data)
        else:
            # Default fallback based on description
            if "COFT" in data.get("Description", ""):
                negative_page.select_coft_enable_without_channel_support_negative(bank, data)
            elif "Alternate" in data.get("Description", ""):
                negative_page.select_alternate_payments_without_prerequisites_negative(bank, data)
            elif "Off Us" in data.get("Description", ""):
                negative_page.disable_off_us_support_without_prerequisites_negative(bank, data)
            elif "Conflicting" in data.get("Description", ""):
                negative_page.toggle_conflicting_tokenization_options_negative(bank, data)
            elif "Save" in data.get("Description", ""):
                negative_page.save_without_required_selections_negative(bank, data)
            else:
                negative_page.save_without_required_selections_negative(bank, data)
