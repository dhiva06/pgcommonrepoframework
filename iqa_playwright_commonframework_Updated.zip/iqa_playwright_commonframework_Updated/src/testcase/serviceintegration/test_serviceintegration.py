"""serviceintegration: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Serviceintegration.xlsx
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.serviceintegration.serviceintegration_page import ServiceintegrationPage, ServiceintegrationPageNegative
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Serviceintegration", "Editserviceintegration")
_rows_Editserviceintegration = ExcelUtil.get_sheet("Serviceintegration", "Editserviceintegration")


class TestServiceintegrationModule:
    """Test suite for Service integration configuration - edit workflow and negative scenarios."""

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Editserviceintegration,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_serviceintegration_editserviceintegration(self, page, data):
        """Verify Service integration configuration edit workflow - verify initial settings, modify toggle states, save, and verify persistence after reload."""
        data = RuntimeData.resolve(data, "serviceintegration", BANK_NAME)
        bank = ConfigManager.get("bank")

        # Login
        login_page = BankLoginPage(page)
        login_page.login(bank)
        login_page.assert_dashboard_visible(bank)

        # Navigate to Service integration
        serviceintegration_page = ServiceintegrationPage(page)
        serviceintegration_page.navigate_to_serviceintegration(bank)

        # Verify Channel support section initial state
        serviceintegration_page.verify_channel_support_initial_state(bank)

        # Verify Services section initial state
        serviceintegration_page.verify_services_initial_state(bank)

        # Verify Tokenization section initial state
        serviceintegration_page.verify_tokenization_initial_state(bank)

        # Select Enable for COFT or Faster checkout
        serviceintegration_page.select_coft_enable(bank)

        # Assert COFT Enable is selected
        serviceintegration_page.assert_coft_enable_selected(bank)

        # Verify Alternate payments initial state
        serviceintegration_page.verify_alternate_payments_initial_state(bank)

        # Select Enable for Alternate payments
        serviceintegration_page.select_alternate_payments_enable(bank)

        # Assert Alternate payments Enable is selected
        serviceintegration_page.assert_alternate_payments_enable_selected(bank)

        # Verify Off Us support initial state (Enable)
        serviceintegration_page.verify_off_us_support_initial_state(bank)

        # Select Disable for Off Us support
        serviceintegration_page.select_off_us_support_disable(bank)

        # Assert Off Us support Disable is selected
        serviceintegration_page.assert_off_us_support_disable_selected(bank)

        # Select Enable for Off Us support again
        serviceintegration_page.select_off_us_support_enable(bank)

        # Verify Authentication service provider chips
        serviceintegration_page.verify_authentication_provider_chips(bank)

        # Verify payment method type and transaction type
        serviceintegration_page.verify_payment_method_and_transaction_type(bank)

        # Click Save button
        serviceintegration_page.click_save_button(bank)

        # Assert success message is displayed
        serviceintegration_page.assert_success_message_displayed(bank, data["ExpectedMessage"])

        # Reload Service integration page
        serviceintegration_page.navigate_to_serviceintegration(bank)

        # Verify COFT or Faster checkout is set to Enable after reload
        serviceintegration_page.verify_saved_state_coft_enable(bank)

        # Verify Alternate payments is set to Enable after reload
        serviceintegration_page.verify_saved_state_alternate_payments_enable(bank)

        # Verify Off Us support is set to Enable after reload
        serviceintegration_page.verify_saved_state_off_us_support_enable(bank)

        # Verify Channel support section after reload
        serviceintegration_page.verify_saved_channel_support_state(bank)

        # Verify Services section after reload
        serviceintegration_page.verify_saved_services_state(bank)

        # Verify Authentication service provider after reload
        serviceintegration_page.verify_saved_authentication_provider_state(bank)

        # Verify payment method type and transaction type after reload
        serviceintegration_page.verify_saved_payment_and_transaction_state(bank)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_serviceintegration_negative(self, page, data):
        """Execute negative test scenarios for Service integration. Test covers: invalid state transitions, missing prerequisites, conflicting options, validation errors."""
        data = RuntimeData.resolve(data, "serviceintegration", BANK_NAME)

        # Login
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        # Navigate to Service integration
        negative_page = ServiceintegrationPageNegative(page)
        negative_page.navigate_to_serviceintegration(BANK_NAME)

        # Execute negative action based on NegativeType
        negative_type = data.get("NegativeType", "").strip()

        if negative_type == "COFT_InvalidState":
            negative_page.select_coft_invalid_state_negative(BANK_NAME, data)
        elif negative_type == "AlternatePayments_InvalidState":
            negative_page.select_alternate_payments_invalid_state_negative(BANK_NAME, data)
        elif negative_type == "OffUsSupport_MissingPrerequisite":
            negative_page.select_off_us_support_disable_without_prerequisite_negative(BANK_NAME, data)
        elif negative_type == "SaveWithoutRequiredSelections":
            negative_page.click_save_without_required_selections_negative(BANK_NAME, data)
        elif negative_type == "ConflictingRadioOptions":
            negative_page.toggle_conflicting_radio_options_negative(BANK_NAME, data)
        else:
            if "COFT" in data.get("Description", ""):
                negative_page.select_coft_invalid_state_negative(BANK_NAME, data)
            elif "Alternate" in data.get("Description", ""):
                negative_page.select_alternate_payments_invalid_state_negative(BANK_NAME, data)
            elif "Off Us" in data.get("Description", ""):
                negative_page.select_off_us_support_disable_without_prerequisite_negative(BANK_NAME, data)
            elif "Conflicting" in data.get("Description", ""):
                negative_page.toggle_conflicting_radio_options_negative(BANK_NAME, data)
            else:
                negative_page.click_save_without_required_selections_negative(BANK_NAME, data)
