"""selfconfiguration: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Selfconfiguration.xlsx
"""
import pytest
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.Bank_transaction_search_and_view.transaction_search_and_view_page import TransactionSearchViewPage


BANK_NAME = ConfigManager.get("bank")
_rows = ExcelUtil.get_sheet("TransactionSearchandView", "Testcase")


# ==================================================================
# TESTS
# ==================================================================
class TestSelfconfigurationModule:

    # ==================================EDIT==================================

    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_selfconfiguration_Pg_template(self, page, data):
        bank = ConfigManager.get("bank")
        login_page = BankLoginPage(page)
        login_page.login(bank)
        transaction_search_view_page = TransactionSearchViewPage(page)
        transaction_search_view_page.navigate_to_transactions_menue(bank, data)
        if data["TestcaseID"] == "TC-BTRX-001 to TC-BTRX-002":
            transaction_search_view_page.assert_Transactions_dashboard_page(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-004", "TC-BTRX-011", "TC-BTRX-012", "TC-BTRX-013", "TC-BTRX-014", "TC-BTRX-015", "TC-BTRX-016"):
            transaction_search_view_page.verify_transactions_filters_and_grid_data(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-005", "TC-BTRX-006", "TC-BTRX-007", "TC-BTRX-008"):
            transaction_search_view_page.verify_transactions_search_and_grid_values(bank, data)
        if data["TestcaseID"] == "TC-BTRX-009":
            transaction_search_view_page.verify_default_transaction_date(bank, data)
        if data["TestcaseID"] == "TC-BTRX-010":
            transaction_search_view_page.verify_custom_date_range(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-017", "TC-BTRX-018", "TC-BTRX-019"):
            transaction_search_view_page.verify_refund_reversal_Icon(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-021", "TC-BTRX-022", "TC-BTRX-023", "TC-BTRX-024"):
            transaction_search_view_page.verify_Refund_tab_filters_and_grid_data(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-025", "TC-BTRX-026"):
            transaction_search_view_page.verify_Refund_tab_search_and_grid_values(bank, data)
        if data["TestcaseID"] == "TC-BTRX-027":
            transaction_search_view_page.verify_Refund_tab_default_transaction_date(bank, data)
        if data["TestcaseID"] == "TC-BTRX-028":
            transaction_search_view_page.verify_Refund_tab_custom_date_range(bank, data)
        if data["TestcaseID"] in ("TC-BTRX-029", "TC-BTRX-030"):
            transaction_search_view_page.verify_column_customization(bank, data)


        