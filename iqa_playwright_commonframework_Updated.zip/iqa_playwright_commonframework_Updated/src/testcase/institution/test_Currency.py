import pytest
import random
import string
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.institution.Currency_page import CurrencyPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows_add = ExcelUtil.get_sheet("Currency", "Add")
_rows_view = ExcelUtil.get_sheet("Currency", "View")
_rows_edit = ExcelUtil.get_sheet("Currency", "Edit")
_rows_changestatus = ExcelUtil.get_sheet("Currency", "ChangeStatus")
_rows_NegativeCases = ExcelUtil.get_sheet("Currency", "NegativeCases")


def generate_currency_code():
    """Generate a random 3-digit currency code."""
    return ''.join(random.choices(string.digits, k=3))

@pytest.mark.oab
@pytest.mark.sanity
@pytest.mark.regression
class TestCurrencyModule:
    @pytest.mark.parametrize(
        "data",
        _rows_add,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_add]
    )
    def test_currency_add(self, page, data):
        """Verify the add functionality of Currency with randomly generated code."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        currency_page = CurrencyPage(page)
        currency_page.navigate_to_currency(BANK_NAME)
        currency_page.click_add_button(BANK_NAME)
        
        # Generate random currency code at runtime
        generated_code = generate_currency_code()
        
        # Prepare data with generated code
        form_data = {
            "Currency Code": generated_code,
            "Currency Description": data["Currency Description"],
            "Minor Digits": data["Minor Digits"],
            "Currency Symbol": data["Currency Symbol"],
        }
        
        currency_page.fill_currency_form(BANK_NAME, form_data)
        currency_page.click_save_button(BANK_NAME)
        currency_page.assert_currency_message(BANK_NAME, data["ExpectedMessage"])
        
        # Store generated code for subsequent actions
        page.context.generated_currency_code = generated_code
        
        
# # ============================VIEW====================================


    @pytest.mark.parametrize(
        "data",
        _rows_view,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_view]
    )
    def test_currency_view(self, page, data):
        """Verify the view functionality of Currency."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)
 
        currency_page = CurrencyPage(page)
        currency_page.navigate_to_currency(BANK_NAME)
 
        currency_code = str(data["Currency Code"])
        currency_page.find_and_view_row(BANK_NAME, currency_code)  
        currency_page.assert_currency_message_view_CC(BANK_NAME,str(data["ExpectedMessage"]))
        currency_page.click_back_button(BANK_NAME)
        
        
# =====================EDIT=============================
         

    @pytest.mark.parametrize(
        "data",
        _rows_edit,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_edit]
    )
    def test_currency_edit(self, page, data):
        """Verify the edit functionality of Currency."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        currency_page = CurrencyPage(page)
        currency_page.navigate_to_currency(BANK_NAME)
        currency_code = str(data["Currency Code"])
        currency_page.find_and_edit_row(BANK_NAME, currency_code,data)
        currency_page.click_save_button(BANK_NAME)
        currency_page.assert_currency_message_Edit(BANK_NAME,str(data["ExpectedMessage"])) 
        
        
        
# ========================CHANGE STATUS====================================

    @pytest.mark.parametrize(
        "data",
        _rows_changestatus,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_changestatus]
    )
    def test_currency_changestatus(self, page, data):
        """Verify the change status functionality of Currency."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        currency_page = CurrencyPage(page)
        currency_page.navigate_to_currency(BANK_NAME)
        
        # Use the currency code from data
        currency_code = data["Currency Code"]
        currency_page.find_and_check_row(BANK_NAME, currency_code)
        currency_page.click_change_status_button(BANK_NAME)
        currency_page.assert_currency_message_Edit(BANK_NAME,str(data["ExpectedMessage"]))
        
        
        
# =======================================NEGATIVE CASES==========================================



    @pytest.mark.parametrize(
        "data",
        _rows_NegativeCases,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_NegativeCases]
    )
    def test_currency_Negative_Cases(self, page, data):
        """Verify the add functionality of Currency with randomly generated code."""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        currency_page = CurrencyPage(page)
        currency_page.navigate_to_currency(BANK_NAME)
        currency_page.click_add_button(BANK_NAME)
        
        
        # Prepare data with generated code
        form_data = {
            "Currency Code": data["Currency Code"],
            "Currency Description": data["Currency Description"],
            "Minor Digits": data["Minor Digits"],
            "Currency Symbol": data["Currency Symbol"],
            "ExpectedMessage": data["ExpectedMessage"]
            
        }
        
        currency_page.fill_currency_form(BANK_NAME, form_data)
        currency_page.click__Negative_save_button(BANK_NAME,data)
   

   
    
        
        
        
        
        