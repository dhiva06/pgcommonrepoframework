import pytest
from src.common.fixtures.browser_fixtures import page
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.risk_validations.Negative_IP_page import NegativeIPPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager
from src.common.base.base_page import BasePage

BANK_NAME = ConfigManager.get("bank")

_Add_IpBlock = ExcelUtil.get_sheet("RiskValidations", "IpBlock")
_Add_MutlipleIpBlock = ExcelUtil.get_sheet("RiskValidations", "NegativeIpMultiple")
_Negative_IpBlock = ExcelUtil.get_sheet("RiskValidations", "NegativeIp")
_Search_IpBlock = ExcelUtil.get_sheet("RiskValidations", "SearchIp")

@pytest.mark.oab
@pytest.mark.sanity
@pytest.mark.regression
class TestNegativeIP:
    @pytest.mark.parametrize(
        "data",
        _Add_IpBlock,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Add_IpBlock]
    )
    def test_negative_IP(self, page, data):
        """Verify the add functionality of Negative IP across banks"""
        login_page = BankLoginPage(page)
        base_page = BasePage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        # Step 2: Navigate and perform User Role actions
        card_page = NegativeIPPage(page)
        card_page.navigate_to_negative_IP(BANK_NAME)
        card_page.add_negative_IP(BANK_NAME,data)
        card_page.click_Add_save_button(BANK_NAME,data)
        card_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])
        
        
        
        # =======================MULTIPLE IP BLOCK ADD=========================
        
        
    @pytest.mark.parametrize(
    "data",
    _Add_MutlipleIpBlock,
    ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Add_MutlipleIpBlock]
    )
    def test_negative_IP(self, page, data):
        """Verify the add functionality of Negative IP across banks"""
        login_page = BankLoginPage(page)
        base_page = BasePage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        # Step 2: Navigate and perform User Role actions
        card_page = NegativeIPPage(page)
        card_page.navigate_to_negative_IP(BANK_NAME)
        card_page.add_multiple_negative_IP(BANK_NAME,data)
        card_page.click_Add_save_button(BANK_NAME,data)
        card_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])
        
        
        
        # ========================NEGATIVE TEST CASES=========================
        
        
        
        
        @pytest.mark.parametrize(
         "data",
         _Negative_IpBlock,
         ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Negative_IpBlock]
        )
        def test_negative_IP(self, page, data):
         """Verify the add functionality of Negative IP across banks"""
         login_page = BankLoginPage(page)
         base_page = BasePage(page)
         login_page.login(BANK_NAME)
         # login_page.assert_dashboard_visible(BANK_NAME)
 
         # Step 2: Navigate and perform User Role actions
         card_page = NegativeIPPage(page)
         card_page.navigate_to_negative_IP(BANK_NAME)
         card_page.add_negative_IP(BANK_NAME,data)
         card_page.click_Negative_save_button(BANK_NAME,data)
         
         
        #=========================SEARCH FUNCTIONALITY=========================
        
        
        @pytest.mark.parametrize(
            "data",
            _Search_IpBlock,
            ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Search_IpBlock]
            )
        def test_negative_IP(self, page, data):
            """Verify the add functionality of Negative IP across banks"""
            login_page = BankLoginPage(page)
            base_page = BasePage(page)
            login_page.login(BANK_NAME)
            # login_page.assert_dashboard_visible(BANK_NAME)
         
            # Step 2: Navigate and perform User Role actions
            card_page = NegativeIPPage(page)
            card_page.navigate_to_negative_IP(BANK_NAME)
            card_page.select_IP(BANK_NAME, data)    
            
            
            # FOR SEARCH NEGATIVE IP IT CLICK SEARCH BUTTON BUT IT DOESNOT FILTER BUT MANUALLY IT GET FILTER
        
        