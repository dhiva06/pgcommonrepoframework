import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.risk_validations.Negative_Card_Page import NegativeCardPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager
from src.common.base.base_page import BasePage

BANK_NAME = ConfigManager.get("bank")

_Add = ExcelUtil.get_sheet("RiskValidations", "NegativeCard")
_AddMultiple = ExcelUtil.get_sheet("RiskValidations", "NegativeCardMultiple")
_NegativeCardScenarios = ExcelUtil.get_sheet("RiskValidations", "NegCard")
_UploadCard = ExcelUtil.get_sheet("RiskValidations", "NegativeCardUpload")
_Search_NegativeCard = ExcelUtil.get_sheet("RiskValidations", "SearchNegativeCard")


@pytest.mark.oab
@pytest.mark.sanity
@pytest.mark.regression
class TestNegativeCard:
    @pytest.mark.parametrize(
        "data",
        _Add,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Add]
        # - {data["Description"]}
    )
    def test_Addnegative_card(self, page, data):
        """Verify the add functionality of Negative Card across banks"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        # Step 2: Navigate and perform User Role actions
        card_page = NegativeCardPage(page)
        card_page.navigate_to_negative_card(BANK_NAME)
        card_page.add_negative_card(BANK_NAME,data)
        card_page.click_Add_save_button(BANK_NAME)
        card_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])
        
        # ============================MULTIPLE NEGATIVE CARD ADD=========================
        
    @pytest.mark.parametrize(
             "data",
             _AddMultiple,
             ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _AddMultiple]
             # - {data["Description"]}
         )
    def test_Mutiplenegative_card(self, page, data):
             """Verify the add functionality of Negative Card across banks"""
             login_page = BankLoginPage(page)
             login_page.login(BANK_NAME)
             # login_page.assert_dashboard_visible(BANK_NAME)
     
             # Step 2: Navigate and perform User Role actions
             card_page = NegativeCardPage(page)
             card_page.navigate_to_negative_card(BANK_NAME)
             card_page.add_Mutiple_card(BANK_NAME,data)
             card_page.click_Add_save_button(BANK_NAME)
             card_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])   
             
             
            #  ==============NEGATIVE CASES FOR CARD BLOCK=========================
            
            
    @pytest.mark.parametrize(
                "data",
                _NegativeCardScenarios,
                ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _NegativeCardScenarios]
                # - {data["Description"]}
            )
    def test_Negnegative_card(self, page, data):
                """Verify the add functionality of Negative Card across banks"""
                login_page = BankLoginPage(page)
                login_page.login(BANK_NAME)
                # login_page.assert_dashboard_visible(BANK_NAME)
        
                # Step 2: Navigate and perform User Role actions
                card_page = NegativeCardPage(page)
                card_page.navigate_to_negative_card(BANK_NAME)
                card_page.add_negative_card(BANK_NAME,data)
                card_page.click_NegativeCard_save_button(BANK_NAME,data)
        
        
        # ======================UPLOAD FILE TEST CASES=========================
        
    @pytest.mark.parametrize(
                    "data",
                    _UploadCard,
                    ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _UploadCard]
                    # - {data["Description"]}
                )
    def test_Uploadnegative_card(self, page, data):
                    """Verify the add functionality of Negative Card across banks"""
                    login_page = BankLoginPage(page)
                    login_page.login(BANK_NAME)
                    # login_page.assert_dashboard_visible(BANK_NAME)
            
                    # Step 2: Navigate and perform User Role actions
                    card_page = NegativeCardPage(page)
                    card_page.navigate_to_negative_card(BANK_NAME)
                    # card_page.view_sample_format(BANK_NAME,data)
                    card_page.click_upload_button(BANK_NAME,data)
                    card_page.UploadAssert_message(BANK_NAME, data["ExpectedMessage"])
                    card_page.view_sample_format(BANK_NAME,data)
                    page.wait_for_timeout(1000)
        
        
        
     #=========================SEARCH FUNCTIONALITY=========================
            
            
    @pytest.mark.parametrize(
            "data",
            _Search_NegativeCard,
            ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Search_NegativeCard]
                )
    def test_SearchNegativeCard(self, page, data):
            """Verify the add functionality of Negative Card across banks"""
            login_page = BankLoginPage(page)
            base_page = BasePage(page)
            login_page.login(BANK_NAME)
            # login_page.assert_dashboard_visible(BANK_NAME)
             
            # Step 2: Navigate and perform User Role actions
            card_page = NegativeCardPage(page)
            card_page.navigate_to_negative_card(BANK_NAME)
            card_page.select_Card(BANK_NAME, data)   
            
                    
                    
                    
        
        
    
      