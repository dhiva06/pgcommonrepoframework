import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.risk_validations.Negative_Bin_page import NegativeBinPage
from src.common.pages.risk_validations.Negative_Card_Page import NegativeCardPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager
from src.common.base.base_page import BasePage

BANK_NAME = ConfigManager.get("bank")

_AddNegativeBin = ExcelUtil.get_sheet("RiskValidations", "NegativeBin")
_NegativeBin = ExcelUtil.get_sheet("RiskValidations", "NegBin")
_MultipleNegativeBin = ExcelUtil.get_sheet("RiskValidations", "MultipleBin")
_UploadNegativeBin = ExcelUtil.get_sheet("RiskValidations", "UploadBin")
_Search_NegativeBin = ExcelUtil.get_sheet("RiskValidations", "SearchBin")

@pytest.mark.oab
@pytest.mark.sanity
@pytest.mark.regression
class TestNegativeBin:
    @pytest.mark.parametrize(
        "data",
        _AddNegativeBin,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _AddNegativeBin]
        # - {data["Description"]}
    )
    def test_negative_bin(self, page, data):
        """Verify the add functionality of Negative Bin across banks"""
        login_page = BankLoginPage(page)
        base_page = BasePage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        # Step 2: Navigate and perform User Role actions
        card_page = NegativeBinPage(page)
        card_page.navigate_to_negative_Bin(BANK_NAME)
        card_page.add_negative_bin(BANK_NAME,data)
        card_page.click_save_button(BANK_NAME)
        card_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])
       
#    ====================NEGATIVE BIN ADD=========================
    
    @pytest.mark.parametrize(
            "data",
            _NegativeBin,
            ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _NegativeBin]
            # - {data["Description"]}
        )
    def test_neg_bin(self, page, data):
            """Verify the add functionality of Negative Bin across banks"""
            login_page = BankLoginPage(page)
            login_page.login(BANK_NAME)
            # login_page.assert_dashboard_visible(BANK_NAME)
    
            # Step 2: Navigate and perform User Role actions
            card_page = NegativeBinPage(page)
            card_page.navigate_to_negative_Bin(BANK_NAME)
            card_page.add_negative_bin(BANK_NAME,data)
            card_page.click_NegSave_button(BANK_NAME,data)
            
            
            
# =================MUTIPLE NEGATIVE BIN ADD=========================


    @pytest.mark.parametrize(
               "data",
               _MultipleNegativeBin,
               ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _MultipleNegativeBin]
           )
    def test_negMultiple_bin(self, page, data):
               """Verify the add functionality of Negative Bin across banks"""
               login_page = BankLoginPage(page)
               login_page.login(BANK_NAME)
               # login_page.assert_dashboard_visible(BANK_NAME)
       
               # Step 2: Navigate and perform User Role actions
               card_page = NegativeBinPage(page)
               card_page.navigate_to_negative_Bin(BANK_NAME)
               card_page.add_Mutiple_bin(BANK_NAME,data)
               card_page.click_save_button(BANK_NAME)
               card_page.AddAssert_message(BANK_NAME,data["ExpectedMessage"])     
    
    
    # =================UPLOAD BIN =========================
    
    
    @pytest.mark.parametrize(
        "data",
        _UploadNegativeBin,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _UploadNegativeBin]
                    )
    def test_Uploadnegative_bin(self, page, data):
        """Verify the add functionality of Negative Card across banks"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # Step 2: Navigate and perform actions
        card_page = NegativeBinPage(page)
        card_page.navigate_to_negative_Bin(BANK_NAME)
        # card_page.view_sample_format(BANK_NAME,data)
        card_page.click_upload_button(BANK_NAME,data)
        card_page.UploadAssert_message(BANK_NAME, data["ExpectedMessage"])
        card_page.view_sample_format(BANK_NAME,data)
        page.wait_for_timeout(1000)    
        
        
# =================SEARCH BIN =========================

    @pytest.mark.parametrize(
                "data",
                _Search_NegativeBin,
                ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]}- {data["Description"]} ' for data in _Search_NegativeBin]
                    )
    def test_SearchNegativeBin(self, page, data):
                """Verify the add functionality of Negative Bin across banks"""
                login_page = BankLoginPage(page)
                base_page = BasePage(page)
                login_page.login(BANK_NAME)
                # login_page.assert_dashboard_visible(BANK_NAME)
                 
                # Step 2: Navigate and perform User Role actions
                card_page = NegativeBinPage(page)
                card_page.navigate_to_negative_Bin(BANK_NAME)
                card_page.select_Bin(BANK_NAME, data)
                
                card_page.select_row_checkbox(BANK_NAME, data["search_text"])
                card_page.click_change_status_button(BANK_NAME)
                card_page.accept_status_change_alert(BANK_NAME)
                card_page.ChangeStatusAssert_message(BANK_NAME, data["ExpectedMessage1"])
                
                
        
        
    