# Menumanagement module

## Add

Adds a new menu entry via the Menu Management screen under User Administration, verified for **Ecentric**.

- Positive case: fills Product, Sub product/Portal, Menu code, Menu name, Menu description, Access URL, Parent menu, Menu type, Display sequence, API module, sets Status to Active, saves, and asserts the "saved successfully" confirmation message.
- Covers full navigation path: Administration → User administration → Menu management → Add new menu.
- Validates all dropdown selections and field inputs are correctly persisted before save confirmation.
