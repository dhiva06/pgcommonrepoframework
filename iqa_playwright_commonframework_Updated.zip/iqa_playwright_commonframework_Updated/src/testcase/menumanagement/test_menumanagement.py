"""Test suite for the Menu Management module."""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.menumanagement.menumanagement_page import MenumanagementPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_add_rows = ExcelUtil.get_sheet("Menumanagement", "Add")
_edit_rows = ExcelUtil.get_sheet("Menumanagement", "Edit")
_delete_rows = ExcelUtil.get_sheet("Menumanagement", "Delete")


@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestMenumanagementModule:
    """Covers Add, Edit and Delete flows for the Menu Management module."""

    @pytest.mark.parametrize(
        "data",
        _add_rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _add_rows]
    )
    def test_menumanagement_add(self, page, data):
        """Verify a new menu can be added with valid data and the success message is shown."""
        # TODO: if "User already logged in" appears, add a locator for it to
        # this bank's real login_locators.py and handle it inside
        # BankLoginPage.login() - not here in the test.
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        menu_page = MenumanagementPage(page)
        menu_page.navigate_to_menumanagement(BANK_NAME)
        menu_page.click_add_button(BANK_NAME)
        menu_page.fill_menumanagement_form(BANK_NAME, data)
        menu_page.click_active_status_radio(BANK_NAME)
        menu_page.click_save_button(BANK_NAME)
        menu_page.assert_menumanagement_message(BANK_NAME, data["ExpectedMessage"])

    @pytest.mark.parametrize(
        "data",
        _edit_rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _edit_rows]
    )
    def test_menumanagement_edit(self, page, data):
        """Verify an existing menu's name and description can be updated and the success message is shown."""
        # TODO: if "User already logged in" appears, add a locator for it to
        # this bank's real login_locators.py and handle it inside
        # BankLoginPage.login() - not here in the test.
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        menu_page = MenumanagementPage(page)
        menu_page.navigate_to_menumanagement(BANK_NAME)
        menu_page.select_product_and_sub_product_filters(BANK_NAME, data)
        menu_page.click_edit_icon(BANK_NAME, data["Menu Code"])
        menu_page.update_menumanagement_form(BANK_NAME, data)
        menu_page.click_update_button(BANK_NAME)
        menu_page.assert_menumanagement_message(BANK_NAME, data["ExpectedMessage"])

    @pytest.mark.parametrize(
        "data",
        _delete_rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _delete_rows]
    )
    def test_menumanagement_delete(self, page, data):
        """Verify an existing menu can be deleted and no longer appears in the list."""
        # TODO: if "User already logged in" appears, add a locator for it to
        # this bank's real login_locators.py and handle it inside
        # BankLoginPage.login() - not here in the test.
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        menu_page = MenumanagementPage(page)
        menu_page.navigate_to_menumanagement(BANK_NAME)
        menu_page.select_product_and_sub_product_filters(BANK_NAME, data)
        menu_page.click_delete_icon(BANK_NAME, data["Menu Code"])
        menu_page.confirm_delete(BANK_NAME)
        menu_page.assert_menu_removed(BANK_NAME, data["Menu Code"])
