"""userrolrmanagement: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Userrolemanagement.xlsx
"""
import pytest
from src.common.pages.userrolemanagement.userrolemanagement_page import UserrolemanagementPage, UserrolemanagementPageNegative
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Userrolemanagement", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Userrolemanagement", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("Userrolemanagement", "Add")
_rows_Edit = ExcelUtil.get_sheet("Userrolemanagement", "Edit")
_rows_Delete = ExcelUtil.get_sheet("Userrolemanagement", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestUserrolrmanagementModule:

    # ==================================ADD==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_userrolemanagement_add(self, page, data):
        """Verify user role can be created with all required fields and menu selections."""
        data = RuntimeData.resolve(data, "userrolemanagement", BANK_NAME)
        bank_name = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        user_role_page = UserrolemanagementPage(page)
        user_role_page.navigate_to_user_role_management(bank_name)
        user_role_page.click_add_button(bank_name)
        user_role_page.fill_user_role_form(bank_name, data)
        user_role_page.verify_product_and_sub_product(bank_name, data)
        user_role_page.verify_status_active_selected_by_default(bank_name)
        user_role_page.verify_menu_legend(bank_name)
        user_role_page.scroll_and_select_menus(bank_name, data)
        user_role_page.expand_first_selected_menu(bank_name, data)
        user_role_page.click_save_button(bank_name)
        user_role_page.assert_success_message(bank_name, data["ExpectedMessage"])
        user_role_page.search_user_role(bank_name, data["Role Name"])
        user_role_page.assert_role_in_listing(bank_name, data)
        user_role_page.assert_listing_total_count(bank_name, "1")


    # ==================================EDIT==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_userrolemanagement_edit(self, page, data):
        """Verify user role can be edited with updated description and menu selections."""
        data = RuntimeData.resolve(data, "userrolemanagement", BANK_NAME)
        bank_name = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        user_role_page = UserrolemanagementPage(page)
        user_role_page.navigate_to_user_role_management(bank_name)
        user_role_page.search_user_role(bank_name, data["Role Name"])
        user_role_page.assert_role_in_listing(bank_name, data)
        user_role_page.click_edit_button_for_role(bank_name, data["Role Name"])
        user_role_page.verify_edit_page_displays(bank_name, data)
        user_role_page.update_role_description(bank_name, data["Updated Role Description"])
        user_role_page.toggle_menu_selection(bank_name, data["Toggle Menu Name"])
        user_role_page.click_update_button(bank_name)
        user_role_page.assert_success_message(bank_name, data["ExpectedMessage"])
        user_role_page.search_user_role(bank_name, data["Role Name"])
        user_role_page.click_edit_button_for_role(bank_name, data["Role Name"])
        _, loc = user_role_page._dispatch["ecentric"]
        user_role_page.assert_text(
            user_role_page.locator(loc.role_description_input),
            data["Updated Role Description"],
            "Updated Role Description"
        )


    # ==================================DELETE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(3)
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_userrolemanagement_delete(self, page, data):
        """Verify user role can be deleted and is no longer searchable."""
        data = RuntimeData.resolve(data, "userrolemanagement", BANK_NAME)
        bank_name = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        user_role_page = UserrolemanagementPage(page)
        user_role_page.navigate_to_user_role_management(bank_name)
        user_role_page.search_user_role(bank_name, data["Role Name"])
        user_role_page.assert_role_in_listing(bank_name, data)
        user_role_page.click_delete_button_for_role(bank_name, data["Role Name"])
        user_role_page.verify_delete_confirmation_dialog(bank_name, data["Role Name"])
        user_role_page.confirm_delete_action(bank_name)
        user_role_page.assert_delete_success_message(bank_name, data["Role Name"], data["ExpectedMessage"])
        user_role_page.search_user_role(bank_name, data["Role Name"])
        user_role_page.verify_no_records_found(bank_name)


    # ==================================NEGATIVE==================================

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_add_userrolemanagement_negative(self, page, data):
        """Verify user role add rejects invalid input with appropriate error messages."""
        data = RuntimeData.resolve(data, "userrolrmanagement", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_role_page = UserrolemanagementPageNegative(page)
        user_role_page.navigate_to_user_role_management(BANK_NAME)
        user_role_page.add_user_role_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_edit_userrolrmanagement_negative(self, page, data):
        """Verify user role edit rejects invalid input with appropriate error messages."""
        data = RuntimeData.resolve(data, "userrolrmanagement", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_role_page = UserrolemanagementPageNegative(page)
        user_role_page.navigate_to_user_role_management(BANK_NAME)
        user_role_page.edit_user_role_negative(BANK_NAME, data)
