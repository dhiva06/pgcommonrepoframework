# Userrolrmanagement module

## Add

Adds a new user role with menu permissions in the User Role Management module.
**Bank:** Ecentric

- Verifies role creation form displays correct default values (Product: ACQUIRING PG, Sub-product: ACQUIRING PG BANK, Status: Active) and menu selection legend is visible
- Tests successful role creation with multiple menu selections and sub-menu expansion, confirming success message and return to listing page
- Validates created role appears in search results with correct Role name, Product portal, Status, and item count
