"""general: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/General.xlsx
"""
import pytest
from src.common.pages.general.general_page import GeneralPage, GeneralPageNegative
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("General", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("General", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("General", "Add")
_rows_Edit = ExcelUtil.get_sheet("General", "Edit")
_rows_Delete = ExcelUtil.get_sheet("General", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestGeneralModule:

    # ==================================ADD==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    def test_general_notification_add(self, page, data):
        """Add a new notification with Event, Mode, Template name and Content."""
        data = RuntimeData.resolve(data, "general", BANK_NAME)
        bank_name = ConfigManager.get("bank")
        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        general_page = GeneralPage(page)
        general_page.navigate_to_general(bank_name)
        general_page.click_add_button(bank_name)
        general_page.verify_add_notification_page_loaded(bank_name)

        general_page.fill_add_notification_form(bank_name, data)
        general_page.verify_character_counter(bank_name, data["Expected Counter"])
        general_page.verify_preview_content(bank_name, data["Content"])
        general_page.verify_save_button_enabled(bank_name)

        general_page.click_save_button(bank_name)
        general_page.assert_success_message(bank_name, data["ExpectedMessage"])

        general_page.search_notification(bank_name, data["Template name"])
        event_code = general_page.extract_event_code_from_row(bank_name, data["Template name"])
        assert event_code, "Event code should not be empty"


    # ==================================EDIT==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    def test_general_notification_edit(self, page, data):
        """Edit an existing notification's content and verify update."""
        data = RuntimeData.resolve(data, "general", BANK_NAME)
        bank_name = ConfigManager.get("bank")
        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        general_page = GeneralPage(page)
        general_page.navigate_to_general(bank_name)

        general_page.search_notification(bank_name, data["Event Code"])
        general_page.verify_search_result_single_row(
            bank_name,
            data["Event Code"],
            data["Event"],
            data["Notification Type"],
            data["Template name"]
        )

        general_page.click_edit_button(bank_name, data["Event Code"])
        general_page.verify_update_notification_page_loaded(bank_name)

        general_page.update_notification_content(bank_name, data)
        general_page.verify_preview_updated_content(bank_name, data["Updated Content"])

        general_page.click_update_button(bank_name)
        general_page.assert_success_message(bank_name, data["ExpectedMessage"])

        general_page.search_notification(bank_name, data["Event Code"])
        general_page.click_edit_button(bank_name, data["Event Code"])
        general_page.verify_preview_updated_content(bank_name, data["Updated Content"])


    # ==================================DELETE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    def test_general_notification_delete(self, page, data):
        """Delete a notification and verify it no longer exists."""
        data = RuntimeData.resolve(data, "general", BANK_NAME)
        bank_name = ConfigManager.get("bank")
        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        general_page = GeneralPage(page)
        general_page.navigate_to_general(bank_name)

        general_page.search_notification(bank_name, data["Event Code"])
        general_page.verify_search_result_single_row(
            bank_name,
            data["Event Code"],
            data["Event"],
            data["Notification Type"],
            data["Template name"]
        )

        general_page.click_delete_button(bank_name, data["Event Code"])
        general_page.verify_delete_confirmation_dialog(bank_name)
        general_page.confirm_delete(bank_name)
        general_page.assert_success_message(bank_name, data["ExpectedMessage"])

        general_page.search_notification(bank_name, data["Event Code"])
        general_page.verify_no_records_found(bank_name)


    # ==================================NEGATIVE==================================

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    def test_add_general_negative(self, page, data):
        """Add notification with invalid field values; verify error message."""
        data = RuntimeData.resolve(data, "general", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page = GeneralPageNegative(page)
        negative_page.navigate_to_general(BANK_NAME)
        negative_page.add_notification_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    def test_edit_general_negative(self, page, data):
        """Edit notification with invalid field values; verify error message."""
        data = RuntimeData.resolve(data, "general", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page = GeneralPageNegative(page)
        negative_page.navigate_to_general(BANK_NAME)
        negative_page.edit_notification_negative(BANK_NAME, data)
