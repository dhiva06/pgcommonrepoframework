# General module

## Add

Adds a new notification configuration for a specified event and notification mode.
**Bank(s):** Ecentric

- Verifies the Add notification form displays with all required fields (Event dropdown, Mode of notification radio buttons for SMS/Email, Template name, content textarea with 2000 character limit, and Preview panel) and Save button is disabled until valid data is entered
- Confirms that selecting an Event, choosing SMS mode, entering template name and content enables the Save button, updates character counter correctly, and displays preview in real-time
- Validates successful creation by confirming success message appears, user returns to Notification listing, newly created entry is searchable and displays correct Event/Mode/Template name with auto-generated Event code
