# Binmanagement module

## Add

Adds a new BIN record with randomly generated 6-digit BIN and 19-digit range values, submits for approval, and verifies approval workflow.

**Bank:** Ecentric

- **Positive case:** BIN successfully created with all required fields (Visa, Credit Card, Visa Classic, South Africa, ONUS, Dual Message, Active status), appears in listing as "New" with "Approval pending" status, and transitions to "Approved" after admin approval
- **Negative case:** Validates that randomly generated BIN and range values are unique and non-hardcoded; approval workflow correctly enforces status transitions
- **Data persistence:** Generated BIN number is stored and reused for subsequent related test scenarios (approval, edit, etc.)
