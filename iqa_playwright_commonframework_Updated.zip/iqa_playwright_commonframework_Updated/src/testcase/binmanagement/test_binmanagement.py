"""binmanagement: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Binmanagement.xlsx
"""
import pytest
from src.common.pages.binmanagement.binmanagement_page import BinmanagementPage, BinmanagementPageNegative
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Binmanagement", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Binmanagement", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("Binmanagement", "Add")
_rows_View = ExcelUtil.get_sheet("Binmanagement", "View")
_rows_Edit = ExcelUtil.get_sheet("Binmanagement", "Edit")
_rows_Delete = ExcelUtil.get_sheet("Binmanagement", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestBinmanagementModule:

    # ==================================ADD==================================
    
    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_binmanagement_add(self, page, data):
        """Add a new BIN and verify it appears in the listing with Request type 'New' and status 'Approval pending'."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        bank_name = ConfigManager.get("bank")
        bin_page = BinmanagementPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        bin_page.navigate_to_bin_management(bank_name)
        bin_page.click_add_button(bank_name)
        bin_page.fill_bin_form(bank_name, data)
        bin_page.click_send_for_approval_button(bank_name)

        # Store BIN value for subsequent tests
        bin_page.navigate_to_bin_management_approval(bank_name)
        bin_value = data.get("BIN", "")

        bin_page.search_for_bin(bank_name, bin_value)
        bin_page.click_bin_in_results(bank_name, bin_value)
        # bin_page.assert_bin_in_listing(bank_name, bin_value)
        bin_page.click_approve_button(bank_name)
        bin_page.confirm_approval(bank_name)

    # ==================================VIEW==================================
    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_View,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_binmanagement_view(self, page, data):
        """Search for BIN and verify details match the values entered during Add."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        bank_name = ConfigManager.get("bank")
        bin_page = BinmanagementPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        bin_page.navigate_to_bin_management(bank_name)
        bin_value = data.get("BIN", "")
        bin_page.search_for_bin(bank_name, bin_value)
        bin_page.click_expand_icons(bank_name, bin_value)
        # bin_page.click_bin_in_results(bank_name, bin_value)
        bin_page.assert_view_bin_details(bank_name, data)


    # ==================================EDIT==================================

    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_binmanagement_edit(self, page, data):
        """Edit BIN Card type and Country, then approve the edit request."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        bank_name = ConfigManager.get("bank")
        bin_page = BinmanagementPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        bin_page.navigate_to_bin_management(bank_name)
        bin_value = data.get("BIN", "")
        bin_page.search_for_bin(bank_name, bin_value)
        bin_page.click_bin_in_results(bank_name, bin_value)
        bin_page.click_edit_button(bank_name)
        bin_page.edit_bin_form(bank_name, data)
        bin_page.click_send_for_approval_button(bank_name)
        bin_page.assert_edit_in_request_history(bank_name)

        bin_page.navigate_to_bin_management_approval(bank_name)
        bin_page.search_bin_in_approval(bank_name, bin_value)
        bin_page.expand_request_details(bank_name)
        bin_page.click_approve_button(bank_name)
        bin_page.confirm_approval(bank_name)
        bin_page.assert_bin_approved(bank_name)


    # ==================================DELETE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.order(3)
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_binmanagement_delete(self, page, data):
        """Delete a BIN and verify the deletion request appears in Request history."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        bank_name = ConfigManager.get("bank")
        bin_page = BinmanagementPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        bin_page.navigate_to_bin_management(bank_name)
        bin_value = data.get("BIN", "")
        bin_page.search_for_bin(bank_name, bin_value)
        bin_page.click_bin_in_results(bank_name, bin_value)
        bin_page.click_delete_button(bank_name)
        bin_page.confirm_delete(bank_name)
        bin_page.assert_delete_success(bank_name, bin_value)


    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_add_binmanagement_negative(self, page, data):
        """Add BIN with invalid values and verify validation error message."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        negative_page = BinmanagementPageNegative(page)

        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page.navigate_to_bin_management(BANK_NAME)
        negative_page.add_bin_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d.get('ScenarioID', 'N/A')} - {d.get('TestcaseID', 'N/A')} - {d.get('Description', 'N/A')}"
    )
    def test_edit_binmanagement_negative(self, page, data):
        """Edit BIN with invalid values and verify validation error message."""
        data = RuntimeData.resolve(data, "binmanagement", BANK_NAME)
        login_page = BankLoginPage(page)
        negative_page = BinmanagementPageNegative(page)

        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page.navigate_to_bin_management(BANK_NAME)
        negative_page.edit_bin_negative(BANK_NAME, data)
