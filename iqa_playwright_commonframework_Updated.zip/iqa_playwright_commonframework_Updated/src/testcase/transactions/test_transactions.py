"""
Test module for transactions (Purchase and Authorization).
Drives tests via Excel test data sheets (Hosted_TXN and Hosted_AuthTXN).
"""
import pytest

from src.common.pages.transactions.transactions_page import TransactionsPage
from src.common.utilities.config_manager import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil

BANK_NAME = ConfigManager.get("bank")

# Load Purchase transaction test data
try:
    _purchase_rows = ExcelUtil.get_sheet("Transactions", "Hosted_TXN")
except Exception:
    _purchase_rows = []

_purchase_params = [
    pytest.param(
        data,
        id=f'{data.get("ScenarioID", "")} - {data.get("TestcaseID", "")} - {data.get("Description", "")}'
    )
    for data in _purchase_rows
]

# Load Auth transaction test data
try:
    _auth_rows = ExcelUtil.get_sheet("Transactions", "Hosted_AuthTXN")
except Exception:
    _auth_rows = []

_auth_params = [
    pytest.param(
        data,
        id=f'{data.get("ScenarioID", "")} - {data.get("TestcaseID", "")} - {data.get("Description", "")}'
    )
    for data in _auth_rows
]

# Load Negative Payment Page transaction test data
try:
    _negative_rows = ExcelUtil.get_sheet("Transactions", "Payment_Negative")
except Exception:
    _negative_rows = []

_negative_params = [
    pytest.param(
        data,
        id=f'{data.get("ScenarioID", "")} - {data.get("TestcaseID", "")} - {data.get("Description", "")}'
    )
    for data in _negative_rows
]

# Backward-compatibility aliases
_rows = _purchase_rows
_params = _purchase_params




class TestTransactions:

    @pytest.mark.wio
    @pytest.mark.neoleap
    @pytest.mark.ecentric
    @pytest.mark.fab
    @pytest.mark.oab
    @pytest.mark.pinelabs
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize("data", _purchase_params)
    def test_PurchaseTransaction(self, page, data):
        transactions_page = TransactionsPage(page)
        transactions_page.navigate_to_Transaction_url()
        transactions_page.PurchaseTransaction(BANK_NAME, data)
        payment_id = transactions_page.get_payment_id()
        transactions_page.handle_otp(data.get("otp"))
        transactions_page.SupportingTransaction(BANK_NAME, data, payment_id=payment_id)
        expected_status = data.get("ExpectedMessage") or "CAPTURED"
        transactions_page.assert_transactionstatus(BANK_NAME, expected_status)

    @pytest.mark.wio
    @pytest.mark.neoleap
    @pytest.mark.ecentric
    @pytest.mark.fab
    @pytest.mark.oab
    @pytest.mark.pinelabs
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize("data", _auth_params)
    def test_AuthTransaction(self, page, data):
        transactions_page = TransactionsPage(page)
        transactions_page.navigate_to_Transaction_url()
        transactions_page.AuthTransaction(BANK_NAME, data)
        payment_id = transactions_page.get_payment_id()
        transactions_page.handle_otp(data.get("otp"))
        transactions_page.SupportingTransaction(BANK_NAME, data, payment_id=payment_id)
        expected_status = data.get("ExpectedMessage") or "Approved"
        transactions_page.assert_transactionstatus(BANK_NAME, expected_status)

    @pytest.mark.wio
    @pytest.mark.neoleap
    @pytest.mark.ecentric
    @pytest.mark.fab
    @pytest.mark.oab
    @pytest.mark.pinelabs
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize("data", _negative_params)
    def test_Paymentpage_NegativeScenario(self, page, data):
        transactions_page = TransactionsPage(page)
        transactions_page.navigate_to_Transaction_url()
        transactions_page.PaymentpageNegative(BANK_NAME, data)
        expected = data.get("ExpectedMessage") or "Please enter valid"
        transactions_page.assert_page_contains(expected)

    
    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize("data", _purchase_params)
    def test_EcentricTransaction(self, page, data):
        """Verify Ecentric food cart purchase transaction."""
        if BANK_NAME.lower() != "ecentric":
            pytest.skip(f"Test is applicable only for Ecentric (current bank: '{BANK_NAME}')")
        transactions_page = TransactionsPage(page)
        transactions_page.navigate_to_Transaction_url()
        transactions_page.EcentricTransaction(BANK_NAME, data)
        transactions_page.EcentricSupportingTransaction(BANK_NAME, data)



