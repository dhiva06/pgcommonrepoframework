import pytest
from src.common.base.base_page import BasePage
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.generateresourcefile.generate_resource_file import GenerateResourceFilePage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil

        
BANK_NAME=ConfigManager.get("bank")       
_AddGenerateReosurce = ExcelUtil.get_sheet("ResourceFile", "ResourceFile")
_NegGenerateReosurce = ExcelUtil.get_sheet("ResourceFile", "NegativeFile")


@pytest.mark.oab
@pytest.mark.sanity
@pytest.mark.regression
class TestGenerateResourceFile:
 
    @pytest.mark.parametrize(
        "data",
        _AddGenerateReosurce,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _AddGenerateReosurce]
    )
    def test_generate_resource_file(self, page, data):
        print("INSIDE TEST METHOD")
        print(data)
        
        # Step 1: Login via BankLoginPage
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
 
        resourcefile_page = GenerateResourceFilePage(page)
        resourcefile_page.navigate_to_resource_file(BANK_NAME)
        resourcefile_page.generate_resource_file(BANK_NAME,data)
        resourcefile_page.click_generate_resource_file_button(BANK_NAME)
        resourcefile_page.AddAssert_message(BANK_NAME, data["ExpectedMessage"])
    
    @pytest.mark.parametrize(
            "data",
            _NegGenerateReosurce,
            ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _NegGenerateReosurce]
        )
    def test_Neggenerate_resource_file(self, page, data):
            print("INSIDE TEST METHOD")
            print(data)
            
            # Step 1: Login via BankLoginPage
            login_page = BankLoginPage(page)
            login_page.login(BANK_NAME)
     
            resourcefile_page = GenerateResourceFilePage(page)
            resourcefile_page.navigate_to_resource_file(BANK_NAME)
            resourcefile_page.click_generate_resource_file_Negbutton(BANK_NAME, data)



