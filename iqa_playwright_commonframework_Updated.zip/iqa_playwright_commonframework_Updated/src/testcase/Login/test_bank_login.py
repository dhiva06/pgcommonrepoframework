import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager
from src.banks.ecentric.locators.login_locators import EcentricLoginLocators

BANK_NAME = ConfigManager.get("bank")

class BankLoginModule:
    def __init__(self, page):
        self.page = page

    def bankportal(self) -> None:
        login_page = BankLoginPage(self.page)
        login_page.login(BANK_NAME)
        # self.assert_visible(self.locator(EcentricLoginLocators.logout_msg), "Ecentric Bank Logout message")
    def bankportal_logout(self) -> None:
            login_page = BankLoginPage(self.page)
            login_page.logout_ecentric(BANK_NAME)

    
        
