import pytest
from src.common.pages.authentication.admin_login_page import AdminLoginPage
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.quick_onboarding.quick_onboarding_page import QuickOnboardingPage
from src.common.utilities.config_manager import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil

BANK_NAME = ConfigManager.get("bank")

# _rows = ExcelUtil.get_sheet("QuickOnboarding", "QuickOnboarding")
# _params = [pytest.param(data,id=f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}') for data in _rows]

_all_rows = ExcelUtil.get_sheet("QuickOnboarding", "QuickOnboarding")
def filter_rows(scenario_id: str, run_config: str = "Y"):
    return [
        pytest.param(
            row,
            id=f'{row["ScenarioID"]} - {row["TestcaseID"]} - {row["Description"]}',
            marks=pytest.mark.skipif(
                run_config.upper() == "N",
                reason=f"Skipping {row['ScenarioID']} by config"
            )
        )
        for row in _all_rows
        if row.get("ScenarioID") == scenario_id
    ]
    
_params_add_quick_onboarding    = filter_rows("Successfull_onboarding_01", run_config="Y")
_params_landing_page_functionality = filter_rows("Landing_page_functionality_01", run_config="Y")
_params_quick_onboarding_negative = filter_rows("Quick_onboarding_negative_01", run_config="Y")

@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestQuickOnboarding:
    
    @pytest.mark.parametrize("data",_params_add_quick_onboarding)
    def test_quick_onboarding(self, page, data):
        login_page = BankLoginPage(page)
        quick_onboarding_page = QuickOnboardingPage(page)
        
        
        login_page.login(BANK_NAME)
        quick_onboarding_page.navigate_to_quick_onboarding(BANK_NAME, data)
        quick_onboarding_page.assert_cards_visible(BANK_NAME, data)
        quick_onboarding_page.add_quick_onboarding(BANK_NAME)
        quick_onboarding_page._quick_onboarding(BANK_NAME, data)

    @pytest.mark.parametrize("data",_params_landing_page_functionality)
    def test_landing_page_functionality(self, page, data):
        
        login_page = BankLoginPage(page)
        quick_onboarding_page = QuickOnboardingPage(page)
        
        login_page.login(BANK_NAME)
        quick_onboarding_page.navigate_to_quick_onboarding(BANK_NAME, data)
        quick_onboarding_page.verify_landing_page_functionality(BANK_NAME, data)
        
    @pytest.mark.parametrize("data",_params_quick_onboarding_negative)
    def test_quick_onboarding_negative(self, page, data):
        
        login_page = BankLoginPage(page)
        quick_onboarding_page = QuickOnboardingPage(page)
        
        login_page.login(BANK_NAME)
        quick_onboarding_page.navigate_to_quick_onboarding(BANK_NAME, data)
        quick_onboarding_page.add_quick_onboarding(BANK_NAME)
        quick_onboarding_page.add_quick_onboarding_negative(BANK_NAME, data)
        