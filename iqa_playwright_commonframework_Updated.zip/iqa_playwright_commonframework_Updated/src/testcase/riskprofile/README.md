# Riskprofile module

## Add

Creates a new risk profile with transaction limits and fraud detection rules across Terminal, User, and IP channels.

**Bank(s) verified:** Ecentric

- Validates successful creation of risk profile "TESTDSS" with ZAR currency, domestic-only settings, and multi-level transaction/refund limits (daily/weekly/monthly) across Terminal, User, and IP channels with appropriate blocking actions
- Confirms profile appears in listing with correct name, currency, and ACTIVE status after creation
- Verifies success message displays and user returns to Risk profiles list upon completion

