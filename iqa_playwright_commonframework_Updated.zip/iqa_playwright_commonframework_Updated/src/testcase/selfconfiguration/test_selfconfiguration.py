"""selfconfiguration: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Selfconfiguration.xlsx
"""
import pytest
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.pages.authentication.merchant_login_page import MerchantLoginPage
from src.common.pages.selfconfiguration.selfconfiguration_page import SelfconfigurationPage, SelfconfigurationPageNegative
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Selfconfiguration", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Selfconfiguration", "NegativeEdit")
_rows_Edit = ExcelUtil.get_sheet("Selfconfiguration", "Edit")


# ==================================================================
# TESTS
# ==================================================================
class TestSelfconfigurationModule:

    # ==================================EDIT==================================

    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_selfconfiguration_edit(self, page, data):
        """Verify the edit functionality of Self configuration PG Template settings."""
        # Login to merchant portal
        data = RuntimeData.resolve(data, "selfconfiguration", BANK_NAME)
        bank = ConfigManager.get("bank")
        login_page = MerchantLoginPage(page)
        login_page.login(bank)
        login_page.assert_dashboard_visible(bank)

        # Execute edit flow
        selfconfig_page = SelfconfigurationPage(page)
        selfconfig_page.execute_edit_selfconfiguration(bank, data)


    # ==================================NEGATIVE==================================

    @pytest.mark.ecentric
    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_selfconfiguration_add_negative(self, page, data):
        """Verify validation errors for Self configuration PG Template add with invalid data."""
        data = RuntimeData.resolve(data, "selfconfiguration", BANK_NAME)

        # Login to merchant portal
        login_page = MerchantLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        # Execute negative add flow
        selfconfig_page = SelfconfigurationPageNegative(page)
        selfconfig_page.execute_add_selfconfiguration_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.merchant
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda row: f"{row['ScenarioID']}-{row['TestcaseID']}-{row['Description']}"
    )
    def test_selfconfiguration_edit_negative(self, page, data):
        """Verify validation errors for Self configuration PG Template edit with invalid data."""
        data = RuntimeData.resolve(data, "selfconfiguration", BANK_NAME)

        # Login to merchant portal
        login_page = MerchantLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        # Execute negative edit flow
        selfconfig_page = SelfconfigurationPageNegative(page)
        selfconfig_page.execute_edit_selfconfiguration_negative(BANK_NAME, data)
