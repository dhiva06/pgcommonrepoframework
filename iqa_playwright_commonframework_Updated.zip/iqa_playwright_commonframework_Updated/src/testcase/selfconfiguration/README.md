# Selfconfiguration module

I understand. Since the selfconfiguration module has no Add/Create flow in the real application, I will not generate an Add action section. 

Please provide the EDIT scenario details (including the menu path and DOM scan information) so I can generate the appropriate documentation for that action instead.
