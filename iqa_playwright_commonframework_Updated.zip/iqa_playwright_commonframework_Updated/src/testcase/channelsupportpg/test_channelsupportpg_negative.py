"""
Module: channelsupportpg negative test cases
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.channelsupportpg.channelsupportpg_negative_page import ChannelsupportpgPageNegative
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Channelsupportpg", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Channelsupportpg", "Negative")


@pytest.mark.sanity
@pytest.mark.regression
@pytest.mark.ecentric
class TestChannelsupportpgNegativeModule:
    """Test class for Channel Support - PG configuration negative cases."""

    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda row: f"{row['ScenarioID']} - {row['TestcaseID']} - {row['Description']}",
    )
    def test_channelsupportpg_negative(self, page, data):
        """Verify negative validation scenarios for Channel Support - PG configuration."""
        # Resolve runtime data placeholders
        data = RuntimeData.resolve(data, "channelsupportpg", BANK_NAME)

        # Login
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        # Navigate to Channel Support - PG
        negative_page = ChannelsupportpgPageNegative(page)
        negative_page.navigate_to_channel_support_pg(BANK_NAME)
        negative_page.click_channel_support_pg_tile(BANK_NAME)
        negative_page.verify_stepper_steps(BANK_NAME)

        # Determine which step the negative test applies to based on description
        description = data.get("Description", "").lower()

        if "primary" in description or "api" in description or "hosted payment" in description or "card masking" in description or "gateway user" in description or "mpgs" in description or "cybersource" in description:
            # Step 1 Negative
            negative_page.fill_step1_primary_negative(BANK_NAME, data)
            negative_page.click_step1_continue_and_assert_error_negative(BANK_NAME, data)
        
        elif "terminal" in description or "merchant user" in description or "merchant url" in description or "international" in description or "refund" in description or "card capture" in description or "success/failure" in description or "page time out" in description or "automatic key expiry" in description or "expiry period" in description:
            # Step 1 first (positive) then Step 2 Negative
            negative_page.fill_step1_primary_negative(BANK_NAME, data)
            negative_page.click_step1_continue(BANK_NAME)
            negative_page.assert_step2_active(BANK_NAME)
            
            negative_page.fill_step2_terminal_configurations_negative(BANK_NAME, data)
            negative_page.click_step2_continue_and_assert_error_negative(BANK_NAME, data)
        
        elif "webstore" in description or "webhook" in description or "payment button" in description or "payment link" in description or "multiple terminal" in description or "maximum terminal" in description:
            # Step 1 and Step 2 positive, then Step 3 Negative
            negative_page.fill_step1_primary_negative(BANK_NAME, data)
            negative_page.click_step1_continue(BANK_NAME)
            negative_page.assert_step2_active(BANK_NAME)
            
            negative_page.fill_step2_terminal_configurations_negative(BANK_NAME, data)
            negative_page.click_step2_continue(BANK_NAME)
            negative_page.assert_step3_active(BANK_NAME)
            
            negative_page.fill_step3_merchant_services_negative(BANK_NAME, data)
            negative_page.click_step3_continue_and_assert_error_negative(BANK_NAME, data)


@pytest.mark.sanity
@pytest.mark.regression
@pytest.mark.ecentric
class TestChannelsupportpgNegativeEditModule:
    """Test class for Channel Support - PG configuration negative edit cases."""

    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda row: f"{row['ScenarioID']} - {row['TestcaseID']} - {row['Description']}",
    )
    def test_edit_channelsupportpg_negative(self, page, data):
        """Verify negative edit scenarios for Channel Support - PG configuration."""
        # Resolve runtime data placeholders
        data = RuntimeData.resolve(data, "channelsupportpg", BANK_NAME)

        # Login
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        # Navigate and edit
        negative_page = ChannelsupportpgPageNegative(page)
        negative_page.navigate_to_channel_support_pg(BANK_NAME)
        negative_page.click_channel_support_pg_tile(BANK_NAME)
        
        # Edit with negative data
        negative_page.edit_channel_support_pg_negative(BANK_NAME, data)
