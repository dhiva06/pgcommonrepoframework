# Channelsupportpg module

I cannot generate a section for the "add" action because, as noted in your scenario, the channelsupportpg module has no Add/create flow in the real application. Only the **edit** action applies to this module.

Please provide the edit scenario details so I can generate the appropriate documentation section for that action instead.
