"""
Module: channelsupportpg
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.banks.ecentric.locators.channelsupportpg_locators import ChannelsupportpgLocators
from src.common.pages.channelsupportpg.channelsupportpg_page import ChannelsupportpgPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestChannelsupportpgModule:
    """Test class for Channel Support - PG configuration edit flow."""

    @pytest.mark.parametrize(
        "data",
        ExcelUtil.get_sheet("Channelsupportpg", "Edit"),
        ids=lambda row: f"{row['ScenarioID']} - {row['TestcaseID']} - {row['Description']}",
    )
    def test_channelsupportpg_edit(self, page, data):
        """Verify the edit functionality of Channel Support - PG configuration with all three steps."""
        # Resolve runtime data placeholders
        data = RuntimeData.resolve(data, "channelsupportpg", 'ecentric')
        bank_name = ConfigManager.get("bank")

        # Login
        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        # Navigate to Channel Support - PG
        channel_support_page = ChannelsupportpgPage(page)
        channel_support_page.navigate_to_channel_support_pg(bank_name)
        channel_support_page.click_channel_support_pg_tile(bank_name)

        # Verify stepper shows 3 steps
        channel_support_page.verify_stepper_steps(bank_name)

        # Step 1: Primary
        channel_support_page.fill_step1_primary(bank_name, data)
        channel_support_page.click_step1_continue(bank_name)
        channel_support_page.assert_step1_success_message(bank_name, data["ExpectedMessage"])
        channel_support_page.assert_step2_active(bank_name)

        # Step 2: Terminal Configurations
        channel_support_page.fill_step2_terminal_configurations(bank_name, data)
        channel_support_page.click_step2_continue(bank_name)
        channel_support_page.assert_step2_success_message(bank_name, data["ExpectedMessage"])
        channel_support_page.assert_step3_active(bank_name)

        # Step 3: Merchant Services
        channel_support_page.fill_step3_merchant_services(bank_name, data)
        channel_support_page.click_step3_continue(bank_name)
        channel_support_page.assert_step3_success_message(bank_name, data["ExpectedMessage"])

        # Reopen Channel Support - PG and verify values are retained
        channel_support_page.reopen_channel_support_pg(bank_name)
        channel_support_page.assert_step1_values_retained(bank_name, data)
        channel_support_page.assert_step2_values_retained(bank_name, data)
        channel_support_page.assert_step3_values_retained(bank_name, data)
