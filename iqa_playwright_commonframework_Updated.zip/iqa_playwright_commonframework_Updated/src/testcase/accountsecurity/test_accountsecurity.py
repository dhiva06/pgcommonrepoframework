"""
User Account Security module tests.
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.accountsecurity.accountsecurity_page import AccountsecurityPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows_add = ExcelUtil.get_sheet("Accountsecurity", "Add")
_rows_search = ExcelUtil.get_sheet("Accountsecurity", "Search")

@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestAccountsecurityModule:
    @pytest.mark.parametrize(
        "data",
        _rows_add,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_add]
    )
    
    def test_accountsecurity_add(self, page, data):
        """Verify the add functionality of User Account Security policy"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        security_page = AccountsecurityPage(page)
        security_page.navigate_to_accountsecurity(BANK_NAME)
        security_page.click_add_button(BANK_NAME)
        security_page.fill_accountsecurity_form(BANK_NAME, data)
        security_page.click_save_button(BANK_NAME)
        security_page.assert_success_message(BANK_NAME, data["ExpectedMessage"])
    @pytest.mark.ecentric
    @pytest.mark.parametrize(
        "data",
        _rows_search,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_search]
    )
    def test_accountsecurity_search(self, page, data):
        """Verify the search functionality of User Account Security policy"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        security_page = AccountsecurityPage(page)
        security_page.navigate_to_accountsecurity(BANK_NAME)
        security_page.fill_search_policy_field(BANK_NAME, data["Search Policy Name"])
        security_page.select_created_on_dropdown(BANK_NAME, data["Created On"])
        security_page.click_search_button(BANK_NAME)
        security_page.assert_policy_row_displayed(BANK_NAME, data["Search Policy Name"])
