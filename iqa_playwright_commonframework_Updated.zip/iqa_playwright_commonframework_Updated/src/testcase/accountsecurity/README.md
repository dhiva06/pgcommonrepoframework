# Accountsecurity module

## Add

Creates a new account security policy with customized authentication and password requirements.

**Verified for:** Ecentric

- Validates successful policy creation with all security parameters (idle timeout, login attempts, password complexity rules)
- Confirms required fields are enforced and success message displays
- Verifies dropdown selections (Product, Portal, special characters) and radio button toggles (password reuse, force change) are properly saved
