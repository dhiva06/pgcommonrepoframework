"""useraccountsecurity: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Useraccountsecurity.xlsx
"""
import pytest
from src.common.pages.useraccountsecurity.useraccountsecurity_page import UseraccountsecurityPage
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData
from src.common.pages.useraccountsecurity.useraccountsecurity_page import UseraccountsecurityPageNegative


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Useraccountsecurity", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Useraccountsecurity", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("Useraccountsecurity", "Add")
_rows_View = ExcelUtil.get_sheet("Useraccountsecurity", "View")
_rows_Edit = ExcelUtil.get_sheet("Useraccountsecurity", "Edit")
_rows_Delete = ExcelUtil.get_sheet("Useraccountsecurity", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestUseraccountsecurityModule:

    # ==================================ADD==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(1)
    def test_useraccountsecurity_add(self, page, data):
        """Verify the ability to add a new user account security policy with all required configurations."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        policy_page = UseraccountsecurityPage(page)
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.click_add_button(bank_name)
        policy_page.fill_useraccountsecurity_form(bank_name, data)
        policy_page.click_save_button(bank_name)
        policy_page.assert_add_success_message(bank_name, data["ExpectedMessage"])


    # ==================================VIEW==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_View,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(2)
    def test_useraccountsecurity_view(self, page, data):
        """Verify the ability to search for and view a user account security policy with all saved configurations."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        policy_page = UseraccountsecurityPage(page)
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.search_and_verify_policy(bank_name, data)
        policy_page.click_policy_id_link(bank_name, data["Policy ID"])
        policy_page.assert_summary_page_visible(bank_name)
        policy_page.assert_view_policy_details(bank_name, data)
        policy_page.assert_view_primary_config(bank_name, data)
        policy_page.assert_view_password_policy(bank_name, data)


    # ==================================EDIT==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(2)
    def test_useraccountsecurity_edit(self, page, data):
        """Verify the ability to edit a user account security policy and update its configurations."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        policy_page = UseraccountsecurityPage(page)
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.search_and_verify_policy(bank_name, data)
        policy_page.click_policy_id_link(bank_name, data["Policy ID"])
        policy_page.click_edit_button(bank_name)
        policy_page.assert_edit_form_prefilled(bank_name, data)
        policy_page.fill_useraccountsecurity_form(bank_name, data)
        policy_page.click_update_button(bank_name)
        policy_page.assert_edit_success_message(bank_name, data["ExpectedMessage"])

        # Re-open and verify updated values
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.search_and_verify_policy(bank_name, data)
        policy_page.click_policy_id_link(bank_name, data["Policy ID"])
        policy_page.assert_updated_policy_details(bank_name, data)


    # ==================================DELETE==================================
    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(3)
    def test_useraccountsecurity_delete(self, page, data):
        """Verify the ability to delete a user account security policy and confirm it is removed from the listing."""
        bank_name = ConfigManager.get("bank")
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(bank_name)
        login_page.assert_dashboard_visible(bank_name)

        policy_page = UseraccountsecurityPage(page)
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.search_and_verify_policy(bank_name, data)
        policy_page.click_policy_id_link(bank_name, data["Policy ID"])
        policy_page.click_delete_button(bank_name)
        policy_page.assert_delete_confirmation_dialog(bank_name, data["Confirmation Message"])
        policy_page.confirm_delete(bank_name)
        policy_page.assert_delete_success_message(bank_name, data["ExpectedMessage"])

        # Verify policy no longer exists
        policy_page.navigate_to_useraccountsecurity(bank_name)
        policy_page.search_and_verify_policy(bank_name, data)
        policy_page.assert_no_records_found(bank_name)


    # ==================================NEGATIVE==================================

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.negative
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(1)
    def test_add_useraccountsecurity_negative(self, page, data):
        """
        Verify validation errors when adding a user account security policy with invalid field values.
        Each test case changes exactly one field to an invalid value and asserts the expected error.
        """
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        policy_page = UseraccountsecurityPageNegative(page)
        policy_page.navigate_to_useraccountsecurity(BANK_NAME)
        policy_page.add_useraccountsecurity_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.negative
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d['ScenarioID']} - {d['TestcaseID']} - {d['Description']}"
    )
    @pytest.mark.order(2)
    def test_edit_useraccountsecurity_negative(self, page, data):
        """
        Verify validation errors when editing a user account security policy with invalid field values.
        Each test case searches for a policy, opens it for edit, changes one field to an invalid value,
        and asserts the expected error.
        """
        data = RuntimeData.resolve(data, "useraccountsecurity", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        policy_page = UseraccountsecurityPageNegative(page)
        policy_page.navigate_to_useraccountsecurity(BANK_NAME)
        policy_page.edit_useraccountsecurity_negative(BANK_NAME, data)
