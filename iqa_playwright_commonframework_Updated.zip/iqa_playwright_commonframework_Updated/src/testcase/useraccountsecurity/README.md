# Useraccountsecurity module

## Add

Creates a new user account security policy with comprehensive session, password, and character restriction settings.

**Verified for:** Ecentric

- Positive case: Successfully creates policy "testd" with all primary configuration, password policy, character restrictions, and disallowed passwords; generates and stores Policy ID in format P#####
- Validates product/portal defaults ("ACQUIRING PG"), special character set chips (@, #, !), and all numeric constraints (session timeout, login attempts, inactive period, password length/complexity rules)
- Confirms success message appears, page navigates to listing, and search filters correctly to display only the newly created policy record
