import pytest
from src.common.fixtures.browser_fixtures import page
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.pg_information.pg_information_page import BankInformationPage
from src.banks.ecentric.locators.pg_information_locators import BankInformationLocators

from src.common.utilities.excel_utils import ExcelUtil
from src.testcase.Login.test_bank_login import BankLoginModule
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_all_rows = ExcelUtil.get_sheet("BankInformation", "BankInformationconfig")

loc = BankInformationLocators


# Utility: filter rows by ScenarioID
def filter_rows(scenario_id: str, run_config: str = "Y", require_expected: bool = True):
    rows = []
    for row in _all_rows:
        if row.get("ScenarioID") != scenario_id:
            continue
        if run_config.upper() == "N":
            continue
        if require_expected and row.get("ExpectedMessage") in (None, ""):
            continue
        rows.append(
            pytest.param(
                row,
                id=f'{row["ScenarioID"]} - {row["TestcaseID"]} - {row["Description"]}',
                marks=pytest.mark.skipif(
                    run_config.upper() == "N",
                    reason=f"Skipping {row['ScenarioID']} by config",
                ),
            )
        )
    return rows


# Scenario-specific row sets with inline run config (Y/N)
_params_pg_info = filter_rows("TS_PG_INFORMATION_001", run_config="N", require_expected=False)
_params_bankname = filter_rows("TS_PG_INFORMATION_002", run_config="N", require_expected=False)
_params_bankcode = filter_rows("TS_PG_INFORMATION_003", run_config="N", require_expected=False)
_params_contactpersonname = filter_rows("TS_PG_INFORMATION_004", run_config="N", require_expected=False)
_params_contactnumber = filter_rows("TS_PG_INFORMATION_005", run_config="N", require_expected=False)
_params_contactpersonemailid = filter_rows("TS_PG_INFORMATION_006", run_config="N", require_expected=False)
_params_helpdeskemailid = filter_rows("TS_PG_INFORMATION_007", run_config="N", require_expected=False)
_params_helpdeskmobilenumber = filter_rows("TS_PG_INFORMATION_008", run_config="N", require_expected=False)
_params_helpdesktollfreenumber = filter_rows("TS_PG_INFORMATION_009", run_config="N", require_expected=False)
_params_helpdesklandlinenumber = filter_rows("TS_PG_INFORMATION_010", run_config="N", require_expected=False)
_params_mobileoption = filter_rows("TS_PG_INFORMATION_011", run_config="N", require_expected=False)
_params_landlineoption = filter_rows("TS_PG_INFORMATION_012", run_config="N", require_expected=False)
_params_tollfreeoption = filter_rows("TS_PG_INFORMATION_013", run_config="N", require_expected=False)
_params_helpdeskadditionalnumber = filter_rows("TS_PG_INFORMATION_014", run_config="N", require_expected=False)
_params_helpdeskdeleteicon = filter_rows("TS_PG_INFORMATION_015", run_config="N", require_expected=False)
_params_contactaddress = filter_rows("TS_PG_INFORMATION_016", run_config="N", require_expected=False)
_params_postalcode = filter_rows("TS_PG_INFORMATION_017", run_config="N", require_expected=False)
_params_contactcountry = filter_rows("TS_PG_INFORMATION_018", run_config="N", require_expected=False)
_params_language = filter_rows("TS_PG_INFORMATION_019", run_config="N", require_expected=False)
_params_basecurrency = filter_rows("TS_PG_INFORMATION_020", run_config="N", require_expected=False)
_params_permittedcurrency = filter_rows("TS_PG_INFORMATION_021", run_config="N", require_expected=False)
_params_city = filter_rows("TS_PG_INFORMATION_022", run_config="N", require_expected=False)
_params_state = filter_rows("TS_PG_INFORMATION_023", run_config="N", require_expected=False)
_params_country = filter_rows("TS_PG_INFORMATION_024", run_config="Y", require_expected=False)
_params_savebutton = filter_rows("TS_PG_INFORMATION_025", run_config="N", require_expected=False)
_params_mandvalid = filter_rows("TS_PG_INFORMATION_026", run_config="N", require_expected=False)
_params_incorrectdatatype = filter_rows("TS_PG_INFORMATION_027", run_config="N", require_expected=False)
_params_incorrectdatalen = filter_rows("TS_PG_INFORMATION_028", run_config="N", require_expected=False)


@pytest.mark.sanity
@pytest.mark.regression
class TestBankInformationModule:
   
    @pytest.mark.parametrize("data", _params_pg_info)
    def test_bank_informationt_menu(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page, BANK_NAME)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.assert_element_visible(BANK_NAME, loc.BANK_TIME_ZONE_LABEL, "Asserting Time zone label")
        BankLoginModule(page).bankportal_logout()
    
    @pytest.mark.parametrize("data", _params_bankname)
    def test_pg_finame_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(BANK_NAME, loc.BANK_NAME, data["128_BANK_NAME"], "Fill 128 Digit Bank Name")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 128 digit Bank Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(
            BANK_NAME, loc.BANK_NAME, data["TENDIGIT_BANK_NAME"], "Fill Ten Digit Bank Name"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10 digit Bank Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(
            BANK_NAME, loc.BANK_NAME, data["MORETHAN_128_BANK_NAME"], "Fill More than 128 Character Bank Name"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_NAME_DATALENGTH_ERROR,
            data["BANK_NAME_DATALENGTH"],
            "Negative validation: Asserting Morethan 128 digit Bank Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(
            BANK_NAME,
            loc.BANK_NAME,
            data["LESSTHAN_THREEDIGIT_BANK_NAME"],
            "Fill Less than 3 Character Bank Name",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_NAME_DATALENGTH_ERROR,
            data["BANK_NAME_DATALENGTH"],
            "Negative validation: Asserting less than 3 digit Bank Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(
            BANK_NAME,
            loc.BANK_NAME,
            data["SPECIAL CHARACTERS_BANK_NAME"],
            "Fill Special Characters Bank Name",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANKNAME_SPECIAL_CHAR_ERROR_MESSAGE,
            data["BANK_NAME_SPECIAL_CHAR_ERROR_MESSAGE"],
            "Negative validation: Asserting Special Characters in Bank Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
   
    @pytest.mark.parametrize("data", _params_bankcode)
    def test_pg_fishortcode_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)

        bank_info.fill_bank_short_Code(
            BANK_NAME, loc.BANK_SHORT_CODE, data["THREEDIGIT_BANK_CODE"], "Fill 3 Bank Short code"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 3 digit Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME, loc.BANK_SHORT_CODE, data["64_DIGIT_BANK_CODE"], "Fill 64 Character Bank Short code"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 64 digit Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME,
            loc.BANK_SHORT_CODE,
            data["MORETHAN_64_BANK_CODE"],
            "Fill More than 64 Character Bank Short code",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_CODE_ERROR_MESSAGE,
            data["BANK_CODE_ERROR_MESSAGE"],
            "Negative validation: Asserting More than 64 digit Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME,
            loc.BANK_SHORT_CODE,
            data["LESSTHAN_THREEDIGIT_BANK_CODE"],
            "Fill Less than 3 Character Bank Short code",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_CODE_ERROR_MESSAGE,
            data["BANK_CODE_ERROR_MESSAGE"],
            "Negative validation: Asserting Less than 3 digit Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME,
            loc.BANK_SHORT_CODE,
            data["SPECIAL CHARACTERS_BANK_CODE"],
            "Fill Special Characters Bank Short code",
        )

        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE,
            data["BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE"],
            "Negative validation: Asserting Special Characters in Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME,
            loc.BANK_SHORT_CODE,
            data["THREEDIGIT_ALAPHANUMERIC_BANK_CODE"],
            "Fill 3 Character Alphanumeric Bank Short code",
        )

        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE,
            data["BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE"],
            "Negative validation: Asserting 3 Character Alphanumeric Bank Short code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

   
    @pytest.mark.parametrize("data", _params_contactpersonname)
    def test_pg_contact_person_name_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_name(
            BANK_NAME,
            loc.NAME,
            data["128_DIGIT_CONTACT_PERSON_NAME"],
            "Fill 128 Character Contact Person Name",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 128 Character Contact Person Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_name(
            BANK_NAME,
            loc.NAME,
            data["THREEDIGIT_CONTACT_PERSON_NAME"],
            "Fill 3 Character Contact Person Name",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 3 Character Contact Person Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_name(
            BANK_NAME,
            loc.NAME,
            data["MORETHAN_128_CONTACT_PERSON_NAME"],
            "Fill More than 128 Character Contact Person Name",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.CONTACT_PERSON_NAME_ERROR_MESSAGE,
            data["CONTACT_PERSON_NAME_DATALENGTH"],
            "Negative validation: Asserting More than 128 Character Contact Person Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_name(
            BANK_NAME,
            loc.NAME,
            data["LESSTHAN_THREEDIGIT_CONTACT_PERSON_NAME"],
            "Fill Less than 3 Character Contact Person Name",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.CONTACT_PERSON_NAME_ERROR_MESSAGE,
            data["CONTACT_PERSON_NAME_DATALENGTH"],
            "Negative validation: Asserting Less than 3 Character Contact Person Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_name(
            BANK_NAME,
            loc.NAME,
            data["SPECIAL_CHARACTERS_CONTACT_PERSON_NAME"],
            "Fill Special Characters Contact Person Name",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.PERSON_NAME_SPECIAL_CHAR_ERROR_MESSAGE,
            data["NAME_SPECIAL_CHAR_ERROR_MESSAGE"],
            "Negative validation: Asserting Special Characters in Contact Person Name PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

   
    @pytest.mark.parametrize("data", _params_contactnumber)
    def test_pg_contact_person_mobilenumber_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_mobile_number(
            BANK_NAME, loc.MOBILE_NUMBER, data["MOBILE_NUMBER"], "Fill 10-digit Contact Person Mobile Number"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10-digit Contact Person Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_mobile_number(
            BANK_NAME,
            loc.MOBILE_NUMBER,
            data["LESSTHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill Contact Person Mobile Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.MOBILE_NUMBER_DATALENGTH_ERROR,
            data["MOBILE_NUMBER_DATALENGTH"],
            "Negative validation: Asserting Less than 10-digit Contact Person Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_mobile_number(
            BANK_NAME,
            loc.MOBILE_NUMBER,
            data["MORETHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill Contact Person Mobile Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.MOBILE_MAX_MSG,
            data["MOBILE_MAX_MSG"],
            "Negative validation: Asserting More than 10-digit Contact Person Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_mobile_number(
            BANK_NAME,
            loc.MOBILE_NUMBER,
            data["SPECIAL_CHAR_MOBILE_NUMBER"],
            "Fill Contact Person Mobile Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.MOBILE_SPECIALCHAR_MSG,
            data["MOBILE_SPECIALCHAR_MSG"],
            "Negative validation: Asserting Special Characters in Contact Person Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

   
    @pytest.mark.parametrize("data", _params_contactpersonemailid)
    def test_pg_contact_person_email_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_email(
            BANK_NAME, loc.EMAIL, data["320_DIGIT_EMAIL"], "Fill 320 Character Contact Person Email"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 320 Character Contact Person Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_email(
            BANK_NAME, loc.EMAIL, data["TENDIGIT_EMAIL"], "Fill 10 Character Contact Person Email"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10 Character Contact Person Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_email(
            BANK_NAME,
            loc.EMAIL,
            data["MORETHAN_320_EMAIL"],
            "Fill More than 320 Character Contact Person Email",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.EMAIL_DATALENGTH_ERROR,
            data["EMAIL_DATALENGTH"],
            "Negative validation: Asserting More than 320 Character Contact Person Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_email(
            BANK_NAME,
            loc.EMAIL,
            data["LESSTHAN_TENDIGIT_EMAIL"],
            "Fill Less than 10 Character Contact Person Email",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.EMAIL_DATALENGTH_ERROR,
            data["EMAIL_DATALENGTH"],
            "Negative validation: Asserting Less than 10 Character Contact Person Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_contactperson_email(
            BANK_NAME, loc.EMAIL, data["INVALID_EMAIL"], "Fill Invalid Contact Person Email"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.EMAIL_INCORRECT_FORMAT_ERROR,
            data["EMAIL_INCORRECT_FORMAT"],
            "Negative validation: Asserting Invalid Contact Person Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

   
    @pytest.mark.parametrize("data", _params_helpdeskemailid)
    def test_help_desk_email_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["320_DIGIT_EMAIL"], "Fill 320-digit Help Desk Email"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 320-digit Help Desk Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["TENDIGIT_EMAIL"], "Fill 10-digit Help Desk Email"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10-digit Help Desk Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["MORETHAN_320_EMAIL"], "Fill 320-digit Help Desk Email"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_EMAIL_DATALENGTH_ERROR,
            data["HELPDESK_EMAIL_DATALENGTH_ERROR"],
            "Negative validation: Asserting 320-digit Help Desk Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["LESSTHAN_TENDIGIT_EMAIL"], "Fill 10-digit Help Desk Email"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_EMAIL_DATALENGTH_ERROR,
            data["HELPDESK_EMAIL_DATALENGTH_ERROR"],
            "Negative validation: Asserting 10-digit Help Desk Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["INVALID_EMAIL"], "Fill 10-digit Help Desk Email"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.EMAIL_INCORRECT_FORMAT_ERROR,
            data["EMAIL_INCORRECT_FORMAT"],
            "Positive validation: Asserting 10-digit Help Desk Email PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

   
    @pytest.mark.parametrize("data", _params_helpdeskmobilenumber)
    def test_help_desk_mobilenum_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_mobile_number_1(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_1,
            data["HELPDESK_MOBILE_NUMBER_1"],
            "Fill Help Desk Mobile Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10-digit Help Desk Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_mobile_number_1(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_1,
            data["LESSTHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill Less than 10 Character Help Desk Mobile Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_DATALENGTH_ERROR,
            data["HELP_DESK_MOBILE_NUMBER_DATALENGTH"],
            "Negative validation: Asserting less than 10-digit Help Desk Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_mobile_number_1(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_1,
            data["MORETHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill More than 10 Character Help Desk Mobile Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_MAX_MSG,
            data["HELPDESK_MOBILE_NUMBER_MAX_MSG"],
            "Negative validation: Asserting More than 10-digit Help Desk Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_mobile_number_1(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_1,
            data["SPECIAL_CHAR_MOBILE_NUMBER"],
            "Fill Special Characters Help Desk Mobile Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_MOBNUM_SPECIAL_MSG,
            data["HELPDESK_MOBNUM_SPECIAL_MSG"],
            "Positive validation: Asserting Special Characters Help Desk Mobile Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()


    @pytest.mark.parametrize("data", _params_helpdesktollfreenumber)
    def test_help_desk_tollfreenum_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["HELPDESK_TOLL_FREE_NUMBER_1"],
            "Fill 8 Digit Help Toll Free Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 8-digit Help Toll Free Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["HELPDESK_MOBILE_NUMBER_1"],
            "Fill 10 Character Help Toll Free Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10-digit Help Toll Free Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["LESSTHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill Less than 10 Character Help Toll Free Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_6DIGIT_ERROR,
            data["HELPDESK_TOLLFREE_NUM_6DIGITLENGTH_ERROR"],
            "Positive validation: Asserting 6-digit Help Toll Free Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["MORETHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill More than 10 Character Help Toll Free Number",
        )
        page.keyboard.press("Tab")
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_MAX_LENGTH_ERROR,
            data["HELPDESK_TOLL_FREE_NUMBER_MAX_MSG"],
            "Positive validation: Asserting More than 10-digit Help Toll Free Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["SPECIAL_CHAR_MOBILE_NUMBER"],
            "Fill Special Characters Help Toll Free Number",
        )
        page.keyboard.press("Tab")
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_MAX_MSG,
            data["HELPDESK_TOLLNUM_SPECIAL_MSG"],
            "Positive validation: Asserting Special Characters Help Toll Free Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
   
    @pytest.mark.parametrize("data", _params_helpdesklandlinenumber)
    def test_help_desk_landlinenum_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["HELPDESK_LANDLINE_NUMBER_1"],
            "Fill 8 Digit Help Land line Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 8-digit Help Land line Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["HELPDESK_MOBILE_NUMBER_1"],
            "Fill 10 Digit Help Land line Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 10-digit Help Land line Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["LESSTHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill Less than 10 Character Help Land line Number",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_LESSTHAN_ERROR_MSG,
            data["HELPDESK_LANDLINE_LESSTHAN_ERROR_MSG"],
            "Negative validation: Asserting Less than 10-digit Help Land line Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["MORETHAN_TENDIGIT_MOBILE_NUMBER"],
            "Fill More than 10 Character Help Land line Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_DATALENGTH_ERROR,
            data["HELPDESK_LANDLINE_NUM_DATALENGTH_ERROR"],
            "Negative validation: Asserting 10-digit Help Land line Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["SPECIAL_CHAR_TOLLFREE_NUMBER"],
            "Fill Special Characters Help Land line Number",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_SPECIAL_MSG,
            data["HELPDESK_lANDLINE_SPECIAL_MSG"],
            "Negative validation: Asserting Special Characters Help Land line Number PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_mobileoption)
    def test_help_desk_mobile_checkbox(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.get_mobile_checkbox_enabled(BANK_NAME, data, data)
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_landlineoption)
    def test_help_desk_landline_checkbox(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.get_landline_checkbox_enabled(
            BANK_NAME, data["HELPDESK_LANDLINE_SUC_MSG"], data["HELPDESK_LANDLINE_NUMBER_1"]
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_tollfreeoption)
    def test_help_desk_tollfree_checkbox(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.get_tollfree_checkbox_enabled(
            BANK_NAME, data["HELPDESK_TOLLFREE_SUC_MSG"], data["HELPDESK_TOLL_FREE_NUMBER_1"]
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_helpdeskadditionalnumber)
    def test_fill_Helpdesk_Additional_Numbers(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_MOBILE_NUMBER,
            loc.HELPDESK_MOBILE_NUMBER_2,
            data["HELPDESK_MOBILE_NUMBER_2"],
        )
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_LANDLINE_NUMBER,
            loc.HELPDESK_LANDLINE_NUMBER_2,
            data["HELPDESK_LANDLINE_NUMBER_2"],
        )
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_TOLL_FREE_NUMBER,
            loc.HELPDESK_TOLL_FREE_NUMBER_2,
            data["HELPDESK_TOLL_FREE_NUMBER_2"],
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Helpdesk AdditionalNumbersBank information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_helpdeskdeleteicon)
    def test_delete_Additional_Numbers(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_MOBILE_NUMBER,
            loc.HELPDESK_MOBILE_NUMBER_2,
            data["HELPDESK_MOBILE_NUMBER_2"],
        )
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_LANDLINE_NUMBER,
            loc.HELPDESK_LANDLINE_NUMBER_2,
            data["HELPDESK_LANDLINE_NUMBER_2"],
        )
        bank_info.fill_Helpdesk_Additional_Numbers(
            BANK_NAME,
            loc.ADDITIONAL_TOLL_FREE_NUMBER,
            loc.HELPDESK_TOLL_FREE_NUMBER_2,
            data["HELPDESK_TOLL_FREE_NUMBER_2"],
        )
        bank_info.click_delete_icon(BANK_NAME)
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Helpdesk AdditionalNumbers PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_contactaddress)
    def test_contact_address_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_building_name(
            BANK_NAME, loc.BUILDING_NAME, data["64_DIGIT-BUILDING_NAME"], "Fill 64 Character Address Details"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 64-character Address Details PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)

        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_building_name(
            BANK_NAME, loc.BUILDING_NAME, data["4_DIGIT-BUILDING_NAME"], "Fill 4 Character Address Details"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 4-character Address Details PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_building_name(
            BANK_NAME,
            loc.BUILDING_NAME,
            data["MORETHAN_64_DIGIT_BUILDING_NAME"],
            "Fill More than 64 Character Address Details",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BUILDING_NAME_DATALENGTH_ERROR,
            data["BUILDING_NAME_DATALENGTH_ERROR"],
            "Negative validation: Asserting More than 64-character Address Details PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_building_name(
            BANK_NAME,
            loc.BUILDING_NAME,
            data["LESSTHAN_4_DIGIT_BUILDING_NAME"],
            "Fill Less than 4 Character Address Details",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BUILDING_NAME_DATALENGTH_ERROR,
            data["BUILDING_NAME_DATALENGTH_ERROR"],
            "Negative validation: Asserting Less than 4-character Address Details PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_postalcode)
    def test_contact_postalcode_details(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_postalcode(BANK_NAME, loc.PINCODE, data["4_DIGIT_PINCODE"], "Fill 4 Digit Postal Code")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting 4-digit Postal Code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)

        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_postalcode(
            BANK_NAME, loc.PINCODE, data["LESSTHAN_4_DIGIT_PINCODE"], "Fill Less than 4 Digit Postal Code"
        )

        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.PINCODE_DATALENGTH_ERROR,
            data["PINCODE_DATALENGTH_ERROR"],
            "Negative validation: Asserting Less than 4-digit Postal Code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()
        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_postalcode(
            BANK_NAME, loc.PINCODE, data["MORETHAN_4_DIGIT_PINCODE"], "Fill More than 4 Digit Postal Code"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.PINCODE_DATALENGTH_POPUP_MSG,
            data["PINCODE_DATALENGTH_POPUP_MSG"],
            "Negative validation: Asserting More than 4-digit Postal Code PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_contactcountry)
    def test_contact_address_country(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(
            BANK_NAME, loc.CONTACT_ADDRESS_COUNTRY, data["ADDRESS_COUNTRY"], "Select ADDRESS COUNTRY"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Contact Address Country PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_language)
    def test_pg_language(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(BANK_NAME, loc.LANGUAGE, data["LANGUAGE"], "Select LANGUAGE")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Select LANGUAGE PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_basecurrency)
    def test_pg_basecurrency(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(
            BANK_NAME, loc.BASE_CURRENCY, data["BASE_CURRENCY"], "Select BASE CURRENCY"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Base Currency PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_permittedcurrency)
    def test_pg_permittedcurrency(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(
            BANK_NAME, loc.PERMITTED_CURRENCY, data["PERMITTED_CURRENCY"], "Select PERMITTED CURRENCY"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Permitted Currency PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_city)
    def test_contact_address_city(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(BANK_NAME, loc.CONTACT_ADDRESS_CITY, data["CITY"], "Select CITY")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Select City PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_state)
    def test_contact_address_state(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(BANK_NAME, loc.CONTACT_ADDRESS_STATE, data["STATE"], "Select STATE")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Contact Address State PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_country)
    def test_pg_country(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.select_dropdown_value(BANK_NAME, loc.COUNTRY, data["COUNTRY"], "Select COUNTRY")
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting Select COUNTRY PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_savebutton)
    def test_save_button_enabled(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_name(BANK_NAME, loc.BANK_NAME, data["BANK_NAME"], "Fill Bank Name")
        bank_info.fill_bank_short_Code(
            BANK_NAME, loc.BANK_SHORT_CODE, data["BANK_CODE"], "Fill Bank Short code"
        )
        bank_info.fill_contactperson_name(
            BANK_NAME, loc.NAME, data["THREEDIGIT_CONTACT_PERSON_NAME"], "Fill Contact Person Name"
        )
        bank_info.fill_contactperson_mobile_number(
            BANK_NAME, loc.MOBILE_NUMBER, data["MOBILE_NUMBER"], "Fill Contact Person Mobile Number"
        )
        bank_info.fill_contactperson_email(
            BANK_NAME, loc.EMAIL, data["EMAIL"], "Fill Contact Person Email"
        )
        bank_info.fill_helpdesk_email(
            BANK_NAME, loc.HELPDESK_EMAIL, data["HELPDESK_EMAIL"], "Fill Help Desk Email"
        )
        bank_info.fill_helpdesk_mobile_number_1(
            BANK_NAME,
            loc.HELPDESK_MOBILE_NUMBER_1,
            data["HELPDESK_MOBILE_NUMBER_1"],
            "Fill Help Desk Mobile Number 1",
        )
        bank_info.fill_helpdesk_toll_free_number_1(
            BANK_NAME,
            loc.HELPDESK_TOLL_FREE_NUMBER_1,
            data["HELPDESK_TOLL_FREE_NUMBER_1"],
            "Fill Help Toll Free Number",
        )
        bank_info.fill_helpdesk_landline_number_1(
            BANK_NAME,
            loc.HELPDESK_LANDLINE_NUMBER_1,
            data["HELPDESK_LANDLINE_NUMBER_1"],
            "Fill Help Land line Number",
        )
        bank_info.fill_building_name(
            BANK_NAME, loc.BUILDING_NAME, data["BUILDING_NAME"], "Fill Building Name"
        )

        bank_info.fill_postalcode(BANK_NAME, loc.PINCODE, data["4_DIGIT_PINCODE"], "Fill Postal code")

        bank_info.select_dropdown_value(BANK_NAME, loc.CONTACT_ADDRESS_CITY, data["CITY"], "Select CITY")
        bank_info.select_dropdown_value(
            BANK_NAME, loc.CONTACT_ADDRESS_COUNTRY, data["ADDRESS_COUNTRY"], "Select ADDRESS COUNTRY"
        )
        bank_info.select_dropdown_value(BANK_NAME, loc.CONTACT_ADDRESS_STATE, data["STATE"], "Select STATE")
        bank_info.select_dropdown_value(BANK_NAME, loc.COUNTRY, data["COUNTRY"], "Select COUNTRY")
        bank_info.select_dropdown_value(BANK_NAME, loc.LANGUAGE, data["LANGUAGE"], "Select LANGUAGE")
        bank_info.select_dropdown_value(
            BANK_NAME, loc.BASE_CURRENCY, data["BASE_CURRENCY"], "Select BASE CURRENCY"
        )
        bank_info.select_dropdown_value(
            BANK_NAME, loc.PERMITTED_CURRENCY, data["PERMITTED_CURRENCY"], "Select PERMITTED CURRENCY"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.SAVE,
            data["SAVE_BUTTON_ENABLED_MSG"],
            "Positive validation: Asserting Save button enabled message",
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_INFORMATION_SUCCESS_MESSAGE,
            data["BANK_INFORMATION_SUCCESS_MESSAGE"],
            "Positive validation: Asserting PG information success message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_mandvalid)
    def test_bank_information_mandatory_msg(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME, loc.BANK_SHORT_CODE, data["EMPTY_BANK_CODE"], "Fill Empty Bank Short code"
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.SHORT_CODE_MANDATORY,
            data["SHORT_CODE_ERROR_MSG"],
            "Negative validation: Asserting Bank Short code Mandatory field error message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_incorrectdatatype)
    def test_bank_information_Incorrect_Datatype_msg(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_bank_short_Code(
            BANK_NAME,
            loc.BANK_SHORT_CODE,
            data["SPECIAL CHARACTERS_BANK_CODE"],
            "Fill Special Characters Bank Short code",
        )
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE,
            data["BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE"],
            "Negative validation: Asserting Bank Short code Special Characters error message",
        )
        BankLoginModule(page).bankportal_logout()

    @pytest.mark.parametrize("data", _params_incorrectdatalen)
    def test_bank_information_Incorrect_Length_msg(self, page, data):

        BankLoginModule(page).bankportal()
        bank_info = BankInformationPage(page)
        bank_info.bank_information_config(BANK_NAME)
        bank_info.fill_postalcode(
            BANK_NAME, loc.PINCODE, data["MORETHAN_4_DIGIT_PINCODE"], "Fill More than 4 digit Postal code"
        )
        bank_info.click_save(BANK_NAME)
        bank_info.assert_validation_success_text(
            BANK_NAME,
            loc.PINCODE_DATALENGTH_POPUP_MSG,
            data["PINCODE_DATALENGTH_POPUP_MSG"],
            "Negative validation: Asserting Postal code Length error message",
        )
        BankLoginModule(page).bankportal_logout()
