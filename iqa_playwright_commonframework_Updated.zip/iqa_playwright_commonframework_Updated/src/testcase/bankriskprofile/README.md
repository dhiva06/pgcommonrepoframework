# Bankriskprofile module

## Add
Adds a new Bank Risk Profile for **ecentric**.

- Positive: Enters Visa and Mastercard limits, selects two country codes, clicks **Proceed**, and verifies the success confirmation message.
- Negative: Leaving the Risk Profile Name blank or not selecting any country code triggers mandatory‑field validation errors.
- Negative: Attempting to add a profile with a name that already exists results in a duplicate‑profile error message.
