import pytest
from src.common.fixtures.browser_fixtures import page
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.bankriskprofile.bankriskprofile_page import BankriskprofilePage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_add_rows = ExcelUtil.get_sheet("Bankriskprofile", "Add")
_error_validation = ExcelUtil.get_sheet("Bankriskprofile", "Error_Validation")
_view_rows = ExcelUtil.get_sheet("Bankriskprofile", "View")
_edit_rows = ExcelUtil.get_sheet("Bankriskprofile", "Edit")
_changestatus_rows = ExcelUtil.get_sheet("Bankriskprofile", "Changestatus")

@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression

class TestBankriskprofileModule:
    @pytest.mark.parametrize("data",_add_rows,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _add_rows])
    def test_Domestic_bankriskprofile_add_and_delete(self, page, data):
        """Verify the add and delete functionality of Bank Risk Profile"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        bankriskprofile_page = BankriskprofilePage(page)
        bankriskprofile_page.navigate_to_bankriskprofile(BANK_NAME)
        bankriskprofile_page.click_add_button(BANK_NAME)
        bankriskprofile_page.fill_domestic_bankriskprofile_form(BANK_NAME, data)
        bankriskprofile_page.click_proceed_button(BANK_NAME)
        bankriskprofile_page.assert_bankriskprofile_success_message(BANK_NAME, data["ExpectedMessage"])
        bankriskprofile_page.search_and_delete_bankriskprofile(BANK_NAME, data)
               
    @pytest.mark.parametrize("data",_add_rows,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _add_rows])
    def test_International_bankriskprofile_add_and_delete(self, page, data):
        """Verify the add and delete functionality of Bank Risk Profile"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        bankriskprofile_page = BankriskprofilePage(page)
        bankriskprofile_page.navigate_to_bankriskprofile(BANK_NAME)
        bankriskprofile_page.click_add_button(BANK_NAME)
        bankriskprofile_page.fill_international_bankriskprofile_form(BANK_NAME, data)
        bankriskprofile_page.click_proceed_button(BANK_NAME)
        bankriskprofile_page.assert_bankriskprofile_success_message(BANK_NAME, data["ExpectedMessage"])
        bankriskprofile_page.search_and_delete_bankriskprofile(BANK_NAME, data)
        
    @pytest.mark.parametrize("data",_error_validation,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _error_validation])
    def test_Domestic_bankriskprofile_error_validation(self, page, data):
        """Verify the error validation functionality of Bank Risk Profile"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        bankriskprofile_page = BankriskprofilePage(page)
        bankriskprofile_page.navigate_to_bankriskprofile(BANK_NAME)
        bankriskprofile_page.click_add_button(BANK_NAME)
        bankriskprofile_page.fill_domestic_bankriskprofile_Detail(BANK_NAME, data)

    @pytest.mark.parametrize("data",_error_validation,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _error_validation])
    def test_International_bankriskprofile_error_validation(self, page, data):
        """Verify the error validation functionality of Bank Risk Profile"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        bankriskprofile_page = BankriskprofilePage(page)
        bankriskprofile_page.navigate_to_bankriskprofile(BANK_NAME)
        bankriskprofile_page.click_add_button(BANK_NAME)
        bankriskprofile_page.fill_international_bankriskprofile_Detail(BANK_NAME, data)

