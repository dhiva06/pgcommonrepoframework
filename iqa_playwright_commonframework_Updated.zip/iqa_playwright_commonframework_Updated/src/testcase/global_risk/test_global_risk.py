"""
Skeleton test for the risk_validations module - establishes the naming/marker
convention only. No demo backend exists yet, so this intentionally fails
with a clear NotImplementedError via RiskValidationsPage._todo_action()
until real locators/steps are filled in (see that file's TODOs).
"""
import pytest
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.pages.global_risk.global_risk_page import GlobalRiskPage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

    
BANK_NAME = ConfigManager.get("bank")
_rows = ExcelUtil.get_sheet("GlobalRisk", "AddBIN")
_rows2 = ExcelUtil.get_sheet("GlobalRisk","BINErrorValidation")
Add_card = ExcelUtil.get_sheet("GlobalRisk", "Add_card")
Card_Validation = ExcelUtil.get_sheet("GlobalRisk","Card_Validation")
Add_IP = ExcelUtil.get_sheet("GlobalRisk", "Add_IP")
IP_Validation = ExcelUtil.get_sheet("GlobalRisk","IP_Validation")
Add_Country = ExcelUtil.get_sheet("GlobalRisk", "Add_Country")
Country_Validation = ExcelUtil.get_sheet("GlobalRisk","Country_Validation")

@pytest.mark.ecentric
@pytest.mark.sanity
@pytest.mark.regression
class TestGlobalRisk:
    @pytest.mark.parametrize("data",_rows,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows])
    def test_add_BIN_number(self, page, data):
        """Verify the Block and Unblock functionality of BIN Blocking across banks"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)
        
        #Add and Delete BIN Blocking
        bin_blocking  = GlobalRiskPage(page)
        bin_blocking._navigate_to_riskprofile()
        bin_blocking._add_bin_blocking(data)
        bin_blocking._delete_bin_blocking(data)
        
        
    @pytest.mark.parametrize("data",_rows2,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows2])    
    def test_Bin_Blocking_Validation(self,page,data):
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)

        bin_blocking  = GlobalRiskPage(page)
        bin_blocking._navigate_to_riskprofile()
        bin_blocking._Validate_error_message_bin(data)
        
    # @pytest.mark.parametrize("data",_rows,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in Add_card])
    # def test_add_and_delete_card_blocking(self, page, data):
    #     """Verify the Block and Unblock functionality of Card Blocking across banks"""
    #     login_page = BankLoginPage(page)
    #     login_page.login(BANK_NAME)
    #     # login_page.assert_dashboard_visible(BANK_NAME)
    # #Add and Delete Card Blocking
    #     card_blocking  = GlobalRiskPage(page)
    #     card_blocking._navigate_to_riskprofile()
    #     card_blocking._add_card_blocking(data)
    #     card_blocking._delete_card_blocking(data)
        
    # @pytest.mark.parametrize("data",_rows2,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in Card_Validation])    
    # def test_card_Blocking_Validation(self,page,data):
    #     login_page = BankLoginPage(page)
    #     login_page.login(BANK_NAME)
    #     # login_page.assert_dashboard_visible(BANK_NAME)

    #     card_blocking  = GlobalRiskPage(page)
    #     card_blocking._navigate_to_riskprofile()
    #     card_blocking._Validate_error_message_card(data)   
        
    # @pytest.mark.parametrize("data",Add_IP,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in Add_IP])
    # def test_add_and_delete_ip_blocking(self, page, data):
    #     """Verify the Block and Unblock functionality of IP Blocking across banks"""
    #     login_page = BankLoginPage(page)
    #     login_page.login(BANK_NAME)
    #     # login_page.assert_dashboard_visible(BANK_NAME)
    # #Add and Delete Card Blocking
    #     ip_blocking  = GlobalRiskPage(page)
    #     ip_blocking._navigate_to_riskprofile()
    #     ip_blocking._add_ip_blocking(data)
    #     ip_blocking._delete_ip_blocking(data)
        
    # @pytest.mark.parametrize("data",IP_Validation,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in IP_Validation])    
    # def test_ip_Blocking_Validation(self,page,data):
    #     login_page = BankLoginPage(page)
    #     login_page.login(BANK_NAME)
    #     # login_page.assert_dashboard_visible(BANK_NAME)
    #     ip_blocking  = GlobalRiskPage(page)
    #     ip_blocking._navigate_to_riskprofile()
    #     ip_blocking._Validate_error_message_ip(data)
        
        
    @pytest.mark.parametrize("data",Add_Country,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in Add_Country])
    def test_add_and_delete_country_blocking(self, page, data):
        """Verify the Block and Unblock functionality of country Blocking across banks"""
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        # login_page.assert_dashboard_visible(BANK_NAME)
        country_blocking  = GlobalRiskPage(page)
        country_blocking._navigate_to_riskprofile()
        country_blocking._add_country_blocking(data)
        # country_blocking._assert_success_message(data,data["successMessage"])
        country_blocking._delete_country_blocking(data)
        # country_blocking._assert_success_message(data,data["unblockedMessage"])
        
    # @pytest.mark.parametrize("data",Country_Validation,ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in Country_Validation])    
    # def test_country_Blocking_Validation(self,page,data):
    #     login_page = BankLoginPage(page)
    #     login_page.login(BANK_NAME)
    #     # login_page.assert_dashboard_visible(BANK_NAME)
    #     country_blocking  = GlobalRiskPage(page)
    #     country_blocking._navigate_to_riskprofile()
    #     country_blocking._Validate_error_message_country(data)