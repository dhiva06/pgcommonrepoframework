"""usermanagement: positive and negative tests in ONE test class.

Test data lives in src/banks/ecentric/testdata/Usermanagement.xlsx
"""
import pytest
from src.common.pages.usermanagement.usermanagement_page import UsermanagementPage, UsermanagementPageNegative
from src.common.pages.authentication.bank_login_page import BankLoginPage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.runtime_data import RuntimeData


BANK_NAME = ConfigManager.get("bank")
_rows_Negative = ExcelUtil.get_sheet("Usermanagement", "Negative")
_rows_NegativeEdit = ExcelUtil.get_sheet("Usermanagement", "NegativeEdit")
_rows_Add = ExcelUtil.get_sheet("Usermanagement", "Add")
_rows_View = ExcelUtil.get_sheet("Usermanagement", "View")
_rows_Edit = ExcelUtil.get_sheet("Usermanagement", "Edit")
_rows_Delete = ExcelUtil.get_sheet("Usermanagement", "Delete")


# ==================================================================
# TESTS
# ==================================================================
class TestUsermanagementModule:

    # ==================================ADD==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(1)
    @pytest.mark.parametrize(
        "data",
        _rows_Add,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_usermanagement_add(self, page, data):
        """Verify user creation with valid data and successful save."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)
        BANK_NAME = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_page = UsermanagementPage(page)
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.click_add_button(BANK_NAME)
        user_page.fill_usermanagement_form(BANK_NAME, data)
        user_page.click_save_button(BANK_NAME)
        user_page.assert_add_success_message(BANK_NAME, data["ExpectedMessage"])


    # ==================================VIEW==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(2)
    @pytest.mark.parametrize(
        "data",
        _rows_View,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_usermanagement_view(self, page, data):
        """Verify user search and view details page display."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)
        BANK_NAME = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_page = UsermanagementPage(page)
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.search_user(BANK_NAME, data)
        user_page.assert_user_in_listing(BANK_NAME, data)
        user_page.click_user_name_link(BANK_NAME, data)
        user_page.assert_user_details_page_displayed(BANK_NAME)
        user_page.assert_user_action_buttons(BANK_NAME)
        user_page.assert_user_details_values(BANK_NAME, data)


    # ==================================EDIT==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(3)
    @pytest.mark.parametrize(
        "data",
        _rows_Edit,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_usermanagement_edit(self, page, data):
        """Verify user edit functionality and successful update."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)
        BANK_NAME = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_page = UsermanagementPage(page)
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.search_user(BANK_NAME, data)
        user_page.click_user_name_link(BANK_NAME, data)
        user_page.click_edit_button(BANK_NAME)
        user_page.assert_edit_form_displayed(BANK_NAME, data)
        user_page.fill_edit_form(BANK_NAME, data)
        user_page.click_update_button(BANK_NAME)
        user_page.assert_edit_success_message(BANK_NAME, data["ExpectedMessage"])

        # Verify updated values on user details page
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.search_user(BANK_NAME, data)
        user_page.click_user_name_link(BANK_NAME, data)
        user_page.assert_user_details_values(BANK_NAME, data)


    # ==================================DELETE==================================

    @pytest.mark.sanity
    @pytest.mark.ecentric
    @pytest.mark.regression
    @pytest.mark.order(4)
    @pytest.mark.parametrize(
        "data",
        _rows_Delete,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_usermanagement_delete(self, page, data):
        """Verify user deletion and confirmation."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)
        BANK_NAME = ConfigManager.get("bank")

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        user_page = UsermanagementPage(page)
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.search_user(BANK_NAME, data)
        user_page.click_user_name_link(BANK_NAME, data)
        user_page.click_delete_button(BANK_NAME)
        user_page.assert_delete_confirmation_displayed(BANK_NAME)
        user_page.click_delete_yes_button(BANK_NAME)
        user_page.assert_delete_success_message(BANK_NAME, data["ExpectedMessage"])

        # Verify user no longer appears in listing
        user_page.navigate_to_usermanagement(BANK_NAME)
        user_page.search_user(BANK_NAME, data)
        user_page.assert_user_not_in_listing(BANK_NAME, data)


    # ==================================NEGATIVE==================================

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.negative
    @pytest.mark.parametrize(
        "data",
        _rows_Negative,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_add_usermanagement_negative(self, page, data):
        """Verify user creation with invalid data and assert error message."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page = UsermanagementPageNegative(page)
        negative_page.navigate_to_usermanagement(BANK_NAME)
        negative_page.click_add_button(BANK_NAME)
        negative_page.add_usermanagement_negative(BANK_NAME, data)

    @pytest.mark.sanity
    @pytest.mark.regression
    @pytest.mark.ecentric
    @pytest.mark.negative
    @pytest.mark.parametrize(
        "data",
        _rows_NegativeEdit,
        ids=lambda d: f"{d.get('ScenarioID', '')} - {d.get('TestcaseID', '')} - {d.get('Description', '')}"
    )
    def test_edit_usermanagement_negative(self, page, data):
        """Verify user edit with invalid data and assert error message."""
        data = RuntimeData.resolve(data, "usermanagement", BANK_NAME)

        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible(BANK_NAME)

        negative_page = UsermanagementPageNegative(page)
        negative_page.navigate_to_usermanagement(BANK_NAME)
        negative_page.edit_usermanagement_negative(BANK_NAME, data)
