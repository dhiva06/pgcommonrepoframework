# Usermanagement module

## Add User

Creates a new user account with specified persona, role, and authentication settings.

**Verified for:** Ecentric

- Positive case: Successfully creates user with Bank persona, FSS Super Admin role, and IHA authentication; confirms success message and return to user listing
- Validates required fields (full name, username, email, mobile) and dropdown selections (persona type, role, authentication source)
- Verifies product/portal fields auto-populate correctly based on persona reference selection
