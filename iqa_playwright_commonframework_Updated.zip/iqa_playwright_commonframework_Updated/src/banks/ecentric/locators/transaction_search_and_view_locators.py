class TransactionSearchViewLocators:
    #---------locators dashboard-----
    payment_id_column = "//th//mat-label[normalize-space()='Payment ID']"
    merchant_track_id_column = "//th//mat-label[normalize-space()='Merchant track ID']"
    merchant_name_column = "//th//mat-label[normalize-space()='Merchant name']"
    organization_name_column = "//th//mat-label[normalize-space()='Organization name']"
    mid_column = "//th//mat-label[normalize-space()='MID']"
    transaction_amount_column = "//th//mat-label[normalize-space()='Transaction amount']"
    transaction_date_column = "//th//mat-label[normalize-space()='Transaction date']"
    transaction_type_column = "//th//mat-label[normalize-space()='Transaction type']"
    payment_mode_column = "//th//mat-label[normalize-space()='Payment mode']"
    rrn_column = "//th//mat-label[normalize-space()='RRN']"
    transaction_status_column = "//th//mat-label[normalize-space()='Transaction status']"
    settlement_status_column = "//th//mat-label[normalize-space()='Settlement status']"  
    actions_column = "//th//mat-label[normalize-space()='Actions']"

    #--------
    transaction_rows = "//tbody/tr"
    rrn_column_values = "//td[contains(@class,'mat-column-rrn')]//span"
    payment_id_column_values = "//td[contains(@class,'mat-column-paymentId')]//span"
    merchant_name_column_values = "//td[contains(@class,'mat-column-merchantName')]//span"
    merchant_trackID_column_values = "//td[contains(@class,'mat-column-merchantTrackId')]//span"
    mid_column_values = "//td[contains(@class,'mat-column-mid')]//span"
    transaction_date_values = "//td[contains(@class,'mat-column-transactionDate')]//span"
    transaction_type_grid_values = "//td[contains(@class,'mat-column-transactionType')]//span"
    payment_mode_grid_values = "//td[contains(@class,'mat-column-paymentMode')]//span"
    transaction_status_grid_values = "//td[contains(@class,'mat-column-transactionStatus')]//span"
    settlement_status_grid_values = "//td[contains(@class,'mat-column-settlementStatus')]//span"
    #-------------


    # Locators for Transaction Search & View page
    unhide_menu="//div[contains(@class,'cursor-pointer')][.//mat-icon[@data-mat-icon-name='bars-3']]"
    transactions_menu = "//a[contains(@href,'transaction-and-refunds-landing')]"
    transactions_tab = "//div[@role='tab' and .//span[normalize-space()='Transactions']]"
    refunds_tab = "//div[@role='tab' and .//span[normalize-space()='Refunds']]"
    bulk_refund_tab = "//div[@role='tab' and .//span[normalize-space()='Bulk refund']]"
    search_field = "//input[@placeholder='Enter Payment ID']"
    date_filter = "//mat-form-field[@id='dateRangeSelect2']//mat-select"
    filter_button = "//mat-icon[@data-mat-icon-name='filter-funnel']/parent::div"
    search_button = "//button[.//div[normalize-space()='Search']]"
    column_customization_button = "//button[@id='colCustomizationBtn']"
    download_button = "//button[.//div[normalize-space()='Download']]"
    pagination_dropdown = "//span[contains(text(),'10 / page')]"
    goto_input = "//input[@formcontrolname='goToPage']"
    transaction_type_option = "//mat-label[normalize-space()='{}']/ancestor::div[contains(@class,'chip')]"
    payment_mode_option = "//mat-label[normalize-space()='{}']/ancestor::div[contains(@class,'chip')]"
    transaction_status_option = "//mat-label[normalize-space()='{}']/ancestor::div[contains(@class,'chip')]"
    settlement_status_option = "//mat-label[normalize-space()='{}']/ancestor::div[contains(@class,'chip')]"
    apply_filter_button = "//button[.//div[normalize-space()='Apply']]"
    transaction_type_value = "(//td[contains(@class,'mat-column-transactionType')]//span)[1]"
    payment_mode_value = "(//td[contains(@class,'mat-column-paymentMode')]//span)[1]"
    transaction_status_value = "(//td[contains(@class,'mat-column-transactionStatus')]//span)[1]"
    settlement_status_value = "(//td[contains(@class,'mat-column-settlementStatus')]//span)[1]"
    payment_id_value = "(//td[contains(@class,'mat-column-paymentId')]//span)[1]"
    merchant_name_value = "(//td[contains(@class,'mat-column-merchantName')]//span)[1]"
    mid_value = "(//td[contains(@class,'mat-column-mid')]//span)[1]"
    rrn_value = "(//td[contains(@class,'mat-column-rrn')]//span)[1]"
    date_filter_dropdown = "//mat-select[contains(@aria-labelledby,'mat-mdc-form-field-label')]"
    date_filter_option = "//mat-option//mat-label[normalize-space()='{}']"
    selected_date_filter = "//mat-form-field[contains(@id,'dateRangeSelect')]//mat-select-trigger"
    refund_icon = ".//button[@id='iconRefund']"
    reversal_icon = ".//button[@id='iconRevoke']"
    column_customization_icon = "//button[@id='colCustomizationBtn']"
    selected_checkboxes = "//input[contains(@class,'mdc-checkbox__native-control') and @checked]"
    column_checkbox = "//label[normalize-space()='{}']"
    column_header = "//th//mat-label[normalize-space()='{}']"
    all_column_checkboxes = "//mat-checkbox"

    #------calendar date picker locators------
    custom_range_option = "//mat-option//mat-label[normalize-space()='Custom range']"
    previous_month = "//mat-icon[@data-mat-icon-name='arrow-left']"
    next_month = "//mat-icon[@data-mat-icon-name='arrow-right']"
    calendar_date = "//tbody[contains(@class,'mat-calendar-body')]//button[@aria-label='{}']"
    apply_button = "//button[@id='btnCalendarApply']"
    transaction_date_values = "//td[contains(@class,'mat-column-transactionDate')]"
    #-----------------------------------#
    refund_tab = "//div[normalize-space()='Refunds']"
    refund_date_filter_dropdown = "//mat-select[contains(@aria-labelledby,'mat-mdc-form-field-label')]"
    refund_date_filter_option = ("//mat-option//mat-label[normalize-space()='{}']")
    refund_filter_button = ("//mat-icon[@data-mat-icon-name='filter-funnel']/ancestor::div[contains(@class,'cursor-pointer')]")
    refund_status_option = ("//div[contains(@class,'chip')]//mat-label[normalize-space()='{}']")
    refund_payment_mode_option = ("//div[contains(@class,'chip')]//mat-label[normalize-space()='{}']")
    refund_apply_button = "//button[@id='btnPrimarySubmit']"
    refund_status_grid_values = ("//td[contains(@class,'mat-column-transactionStatus')]")
    refund_payment_mode_grid_values = ("//td[contains(@class,'mat-column-paymentMode')]")
    refund_rows = "//tbody/tr"

    
