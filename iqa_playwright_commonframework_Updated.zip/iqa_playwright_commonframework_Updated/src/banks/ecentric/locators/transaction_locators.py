class EcentricTransactionLocators:
    class Hosted_TXN:
        amount = "//input[@id='purchaseAmount']"
        card_number = "//input[@id='acctNumber']"
        submit_button = "//input[@value='Submit']"
        # Additional Food Cart form fields
        terminal_id = "//input[@id='tid']"
        currency = "//input[@id='purchaseCurrency']"
        expiry_date = "//input[@id='cardExpiryDate']"
        cvv = "//input[@id='cvv']"
        udf10 = "//input[@id='udf10']"

    class Portal:
        # Navigation
        unhide_menu_button = "//mat-icon[@data-mat-icon-name='bars-3']/parent::div"
        transactions_menu = "//a[@href='#/dashboard/transaction-and-refunds-landing'] | //mat-label[normalize-space()='Transactions']"

        # Tabs
        transactions_tab = "//div[@role='tab'][.//span[normalize-space()='Transactions']]"
        refunds_tab = "//div[@role='tab'][.//span[normalize-space()='Refunds']] | //span[contains(@class,'mdc-tab__text-label') and normalize-space()='Refunds']"
        bulk_refund_tab = "//div[@role='tab'][.//span[normalize-space()='Bulk refund']]"

        # Refunds Search & Filter Bar
        search_payment_id_input = "//input[@placeholder='Enter Payment ID']"
        date_filter_dropdown = "//mat-select[contains(.,'Transaction date') or contains(@aria-labelledby,'Transaction date')]"
        search_button = "//button[normalize-space()='Search' or .//div[contains(text(),'Search')]]"
        filter_icon_button = "//button[contains(@class,'cl-grid-filter') or .//mat-icon[@data-mat-icon-name='funnel']]"
        column_customization_button = "//button[@id='colCustomizationBtn' or .//mat-icon[@data-mat-icon-name='table-cells']]"

        # Table & View
        no_records_found = "//div[contains(text(),'No matching records found') or contains(.,'No matching records found')]"
        table_rows = "//table//tbody//tr | //mat-table//mat-row"
