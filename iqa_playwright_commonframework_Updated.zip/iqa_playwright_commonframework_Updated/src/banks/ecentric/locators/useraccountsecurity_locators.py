class UseraccountsecurityLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_user_administration = "//mat-label[contains(text(),'User administration')]"
    menu_user_account_security = "//mat-label[contains(text(),'User account security')]"
    
    # Policies listing page
    search_policy_input = "input[placeholder='Search policy...']"
    search_button = "//button[contains(normalize-space(),'Search')]"
    add_button = "//button[@id='button31']"
    
    # Dynamic row locator for policy listing
    row_by_policy_id = "input[placeholder*='policy']"
    policy_id_link = "div > div:nth-of-type(2) > table > thead > tr > th:nth-of-type(1) > div > mat-label"
    edit_button_in_summary = "//button[contains(normalize-space(),'Edit')]"
    delete_button_in_summary = "//button[contains(normalize-space(),'Delete')]"
    
    # Add/Edit form fields
    policy_name_input = "#inputPolicyName input[type='text']"
    product_display = "#TODO-verify-product-display"
    portal_display = "#TODO-verify-portal-display"
    
    # Primary configuration section
    idle_session_timeout_input = "#inputIdleSessionTimeout input[type='number']"
    login_attempts_input = "#inputLoginAttempts input[type='number']"
    user_inactive_period_input = "#inputUserActivePeriod input[type='number']"
    
    # Password policy section - Password configuration
    password_min_length_input = "//input[@id='mat-input-11']"
    password_max_length_input = "//input[@id='mat-input-12']"
    
    # Character restrictions
    allowed_special_chars_display = "#TODO-verify-special-chars-display"
    min_capital_letter_input = "//input[@id='mat-input-14']"
    min_digit_input = "//input[@id='mat-input-15']"
    min_special_char_input = "//input[@id='mat-input-16']"
    
    # Disallowed commonly used passwords
    disallowed_password_input = "//input[@id='mat-input-17']"
    add_password_chip_button = "#TODO-verify-add-password-chip"
    
    # Other restrictions
    reused_password_radio_no = "//input[@id='mat-radio-1-input']"
    reused_password_radio_yes = "//input[@id='mat-radio-0-input']"
    frequency_input = "#inputFrequency input[type='number']"
    force_change_password_radio_yes = "//*[@id='forceChangePswd']//mat-radio-button[normalize-space()='Yes']//input[@type='radio']"
    force_change_password_radio_no = "//input[@id='mat-radio-3-input']"
    change_password_period_input = "#inputChangePswdPeriod input[type='number']"
    
    # Buttons
    save_button = "//button[@id='buttonSave']"
    update_button = "div > div:nth-of-type(2) > table > thead > tr > th:nth-of-type(6) > div > mat-label"
    back_button = "//button[contains(normalize-space(),'Back')]"
    
    # Delete confirmation dialog
    delete_confirm_dialog = "#TODO-verify-delete-confirm-dialog"
    delete_confirm_message = "#TODO-verify-delete-confirm-message"
    delete_confirm_button = "#TODO-verify-delete-confirm-button"
    delete_cancel_button = "#TODO-verify-delete-cancel-button"
    
    # Success/Error messages
    success_message_container = "//div[contains(@class, 'success') or contains(@class, 'alert-success')]"
    message_container = "//mat-snack-bar-container"
    
    # View/Summary page
    summary_page_header = "//h2[contains(text(),'Policy Details')]"
    breadcrumb = "//nav//span[contains(text(),'Administration')]"
    view_policy_id = "input[placeholder*='policy']"
    view_policy_name = "//input[contains(@placeholder, 'policy')]"
    view_product = "//span[contains(text(),'Product')]/following-sibling::span"
    view_portal = "//span[contains(text(),'Portal')]/following-sibling::span"
    view_created_on = "//span[contains(text(),'Created on')]/following-sibling::span"
    view_updated_on = "th[class*='cdk-column-updatedON']"
    view_idle_timeout = "//span[contains(text(),'Idle Session timeout')]/following-sibling::span"
    view_login_attempts = "//span[contains(text(),'Login attempts')]/following-sibling::span"
    view_user_inactive = "//span[contains(text(),'User inactive periods')]/following-sibling::span"
    view_password_min_length = "//span[contains(text(),'Password minimum length')]/following-sibling::span"
    view_password_max_length = "//span[contains(text(),'Password maximum length')]/following-sibling::span"
    view_min_capital_letters = "//span[contains(text(),'Minimum capital letter allowed')]/following-sibling::span"
    view_min_digits = "//span[contains(text(),'Minimum digits allowed')]/following-sibling::span"
    view_min_special_chars = "//span[contains(text(),'Minimum special characters allowed')]/following-sibling::span"
    view_disallowed_passwords = "//span[contains(text(),'Disallowed commonly used passwords')]/following-sibling::span"
    view_reused_passwords = "//span[contains(text(),'Previously reused passwords allowed')]/following-sibling::span"
    view_frequency = "[name*='frequency']"
    view_force_change = "//span[contains(text(),'Force change password')]/following-sibling::span"
    view_change_period = "//span[contains(text(),'Change password period')]/following-sibling::span"

    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class UseraccountsecurityLocatorsNegative(UseraccountsecurityLocators):
    """Negative test locators for User Account Security."""

    # Field-level error messages (per-field validation)
    error_policy_name = ".mat-mdc-form-field:has-text('Policy Name') mat-error"
    error_idle_session_timeout = ".mat-mdc-form-field:has-text('Idle Session Timeout') mat-error"
    error_login_attempts = ".mat-mdc-form-field:has-text('Login Attempts') mat-error"
    error_user_inactive_period = ".mat-mdc-form-field:has-text('User Inactive Period') mat-error"
    error_password_min_length = ".mat-mdc-form-field:has-text('Password Minimum Length') mat-error"
    error_password_max_length = ".mat-mdc-form-field:has-text('Password Maximum Length') mat-error"
    error_min_capital_letter = ".mat-mdc-form-field:has-text('Minimum Capital Letter') mat-error"
    error_min_digit = ".mat-mdc-form-field:has-text('Minimum Digit') mat-error"
    error_min_special_char = ".mat-mdc-form-field:has-text('Minimum Special Character') mat-error"
    error_disallowed_password = ".mat-mdc-form-field:has-text('Disallowed Commonly Used Password') mat-error"
    error_reused_password_radio = ".mat-radio-group mat-error"
    error_frequency = ".mat-mdc-form-field:has-text('Frequency') mat-error"
    error_force_change_password_radio = ".mat-radio-group mat-error"
    error_change_password_period = ".mat-mdc-form-field:has-text('Change Password Period') mat-error"

    # Generic error message locators
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    any_validation_error = "//mat-error"
    toast_error_message = "//div[contains(@class, 'snackbar')]//mat-label"



    # Account security
    user_account_security = "//mat-label[text()='User account security']"
    add_policies = "//span/div[text()='Add']"
    policy_name = "//mat-label/span[text()='Policy name']"
    user_account_product = "//mat-label/span[text()='Product']/ancestor::mat-form-field//mat-select"
    user_account_portal = "//mat-label/span[text()='Portal']/ancestor::mat-form-field//mat-select"
    idle_session_timeout = "//mat-label/span[text()='Idle session timeout']"
    login_attempts = "//mat-label/span[text()='Login attempts']"
    user_inactive_period = "//mat-label/span[text()='User inactive period']"
    password_minimum_length = "//mat-label/span[text()='Password minimum length']"
    password_maximum_length = "//mat-label/span[text()='Password maximum length']"
    minimum_capital_letter_allowed = "//mat-label/span[text()=' Minimum capital letter allowed']"
    minimum_digit_allowed = "//mat-label/span[text()=' Minimum digit allowed']"
    minimum_special_characters_allowed = "//mat-label/span[text()=' Minimum special charaters allowed']"
    disallowed_commonly_used_passwords = "//mat-label/span[text()=' Disallowed commonly used password']"
    previously_reused_password_yes = "(//input[@type='radio'])[1]"
    previously_reused_password_no = "(//input[@type='radio'])[2]"
    force_change_password_yes = "(//input[@type='radio'])[3]"
    force_change_password_no = "(//input[@type='radio'])[4]"
    frequency = "//mat-label/span[text()='Frequency']"
    change_password_period = "//mat-label/span[text()=' Change password period']"
    summary_id = "//span[text()='P38858']"
    user_account_edit = "//button[@id='buttonEditUserAccSecurity']"
    user_account_update = "//button[@id='buttonSave']"
    user_account_delete = "//button[@id='buttonDeleteUserAccSecurity']"
    user_account_delete_cancel = "//button/span[text()=' Cancel ']"
    success_message = "//mat-label[contains(@class,'success')]"

