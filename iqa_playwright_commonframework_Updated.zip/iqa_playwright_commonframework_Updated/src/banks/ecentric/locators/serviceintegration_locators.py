class ServiceintegrationLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_pg_configuration = "//mat-label[contains(text(),'PG configuration')]"
    menu_service_integration = "//span[contains(text(),'Service integration')]"
    
    # Channel support section
    payment_gateway_checkbox = "//input[@id='pgChannelCheckbox-input']"
    
    # Chip template for dynamic chip matching
    chip_by_text = "//mat-chip[contains(normalize-space(.), '{value}')]"
    
    # Tokenization section - COFT or Faster checkout radio buttons
    coft_radio_by_value = "//input[@name='mat-radio-group-0' and @value='{value}']"
    
    # Additional services section - Alternate payments radio buttons
    alternate_payments_radio_by_value = "//input[@name='mat-radio-group-1' and @value='{value}']"
    
    # Additional services section - Off Us support radio buttons
    off_us_support_radio_by_value = "//input[@name='mat-radio-group-2' and @value='{value}']"
    
    # Save button
    save_button = "//button[normalize-space()='Save']"
    
    # Success message
    success_message = "//div[contains(@class, 'success') or contains(@class, 'alert-success') or contains(text(), 'successfully')]"


class ServiceintegrationLocatorsNegative:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_pg_configuration = "//mat-label[contains(text(),'PG configuration')]"
    menu_service_integration = "//span[contains(text(),'Service integration')]"
    
    # Channel support section
    payment_gateway_checkbox = "//input[@id='pgChannelCheckbox-input']"
    
    # Chip template for dynamic chip matching
    chip_by_text = "//mat-chip[contains(normalize-space(.), '{value}')]"
    
    # Tokenization section - COFT or Faster checkout radio buttons
    coft_radio_by_value = "//input[@name='mat-radio-group-0' and @value='{value}']"
    
    # Additional services section - Alternate payments radio buttons
    alternate_payments_radio_by_value = "//input[@name='mat-radio-group-1' and @value='{value}']"
    
    # Additional services section - Off Us support radio buttons
    off_us_support_radio_by_value = "//input[@name='mat-radio-group-2' and @value='{value}']"
    
    # Save button
    save_button = "//button[normalize-space()='Save']"
    
    # Error/alert messages for negative scenarios
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    alert_message = "//div[contains(@class, 'error') or contains(@class, 'alert-danger') or contains(text(), 'Error')]"
