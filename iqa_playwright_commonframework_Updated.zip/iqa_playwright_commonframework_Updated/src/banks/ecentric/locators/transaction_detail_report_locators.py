class TransactionDetailReports:
    unhide_menu="//div[contains(@class,'cursor-pointer')][.//mat-icon[@data-mat-icon-name='bars-3']]"
    Reports = "//a[@href='#/dashboard/reports-landing']"
    Transaction_Detail_Report="//span[normalize-space()='Transaction detail report']"
    # Tabs
    search_tab = "//span[normalize-space()='Search']"
    download_history_tab = "//span[normalize-space()='Download History']"
    customize_columns_section = "//div[normalize-space()='Customize columns']"
    manage_preference="//button[@id='filters']"

    # Search Page
    manage_filter_templates = "//span[normalize-space()='Manage filter templates']"
    delete_template_icon = ("//span[normalize-space()='{}']""/ancestor::div[contains(@class,'bg-primary-50')]""//mat-icon[@data-mat-icon-name='profile-delete']")
    yes_button = "//button[.//span[normalize-space()='Yes']]"
    category_textbox = "//mat-label[.//span[normalize-space()='{}']]/ancestor::mat-form-field//input"
    filter_template_radio = "//label[.//span[normalize-space()='Filter templates']]"
    adhoc_search_radio = "//label[.//span[normalize-space()='Adhoc search']]"
    download_from_radio = "//label[.//span[normalize-space()='{}']]"
    template_dropdown = "//mat-select[contains(@id,'mat-select')]"
    view_filters_button = "//button[@id='filters']"
    add_new_template = "//mat-icon[normalize-space()='add_circle_outline']"
    template_option = "//mat-label[normalize-space()='{}']"
    filter_summary="//span[normalize-space()='Preferences']"
    template_filtter_close_icon="//mat-icon[@data-mat-icon-name='close-icon']"
    filter_cancel_bitton="//button[normalize-space()='Cancel']"
    confirm_button = "//button[.//span[normalize-space()='Confirm']]"
    template_name_textbox = "//input[@placeholder='Enter template name']"
    Add_filter_save_button = "//button[@id='saveBtn']"
    close_icon = "//mat-icon[@data-mat-icon-name='close-icon']"
    transaction_period_dropdown = ("//mat-form-field[.//mat-label[contains(normalize-space(),'Transaction period')]]//mat-select")
    date_option = "//mat-option//span[normalize-space()='{}']"
    selected_transaction_period = ("(//mat-select-trigger[contains(@class,'text-base text-neutral-700')])[1]")
    selected_category = ("//mat-select[contains(@class,'mat-mdc-select-empty')]""//span[contains(@class,'mat-mdc-select-placeholder')]")
    category_placeholder = "//span[normalize-space()='Select category']"
    select_category_dropdown = ("//span[normalize-space()='Select category']/ancestor::mat-select")
    category_option = "//mat-option//mat-label[normalize-space()='{}']"
    merchant_name_textbox = "//mat-label[.//span[normalize-space()='Merchant Name']]/ancestor::mat-form-field//input"
    merchant_id_textbox = ("//span[normalize-space()='Merchant ID']""/ancestor::mat-form-field//input")
    terminal_id_textbox = ("//span[normalize-space()='Terminal ID']""/ancestor::mat-form-field//input")
    transactrion_id_textbox = ("//span[normalize-space()='Transaction ID']""/ancestor::mat-form-field//input")
    merchant_track_id_textbox = ("//span[normalize-space()='Merchant Track ID']""/ancestor::mat-form-field//input")
    RRN_textbox = ("//span[normalize-space()='RRN']""/ancestor::mat-form-field//input")
    cardnumber_textbox = ("//span[normalize-space()='Card Number']""/ancestor::mat-form-field//input")
    Bin_textbox = ("//span[normalize-space()='BIN']""/ancestor::mat-form-field//input")
    toast_message = "//div[contains(@class,'snackbar')]//mat-label"
    validation_error_message = "//mat-error"
    download_button = "(//button[@id='downloadBtn'])[1]"
    transaction_mode_dropdown = ("//span[normalize-space()='Transaction mode']""/ancestor::mat-form-field""//div[contains(@class,'mat-mdc-select-arrow-wrapper')]")
    transaction_mode_options = "//mat-option//mat-label"
    select_all_checkbox = ("//mat-label[normalize-space()='Select All']")
    transaction_mode_option_select = ("//mat-option//mat-label[normalize-space()='{}']")
    dropdown_select_all_checked = ("//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]""[.//mat-label[normalize-space()='Select All']]")
    selected_transaction_realted_value = "//mat-chip-set//mat-label"
    transaction_type_dropdown = ("//span[normalize-space()='Transaction type']""/ancestor::mat-form-field//mat-select")
    transaction_type_options = "//mat-option//mat-label"
    payment_insttrument_dropdown = ("//span[normalize-space()='Payment instrument']""/ancestor::mat-form-field//mat-select")
    payment_instrument_options = "//mat-option//mat-label"
    status_all_checked = ("//mat-radio-button[contains(@class,'mat-mdc-radio-checked')]""//input[@value='ALL']")
    status_option = ("//div[@id='status']//span[normalize-space()='{}']")
    status_radio = ("//span[normalize-space()='{}']""/ancestor::mat-radio-button//input[@type='radio']")
    all_status_radio = "//input[@value='ALL']"
    currency_code_dropdown = ("//span[normalize-space()='Currency code']""/ancestor::mat-form-field//mat-select")
    currency_code_options = ("//mat-option//mat-label")
    currency_code_option = ("//mat-option//mat-label[normalize-space()='{}']")
    currency_select_all_checked = ("//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]""[.//mat-label[normalize-space()='Select All']]")
    # MCC_dropdown = ("//span[normalize-space()='MCC']""/ancestor::mat-form-field//mat-select")
    MCC_dropdown = ("//mat-label[normalize-space()='MCC']/ancestor::mat-form-field//mat-select")
    MCC_select_all_checked = ("//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]""[.//mat-label[normalize-space()='Select All']]")
    MCC_options = ("//mat-option//mat-label")
    # MCC_option = ("(//mat-option[@aria-disabled='false']""//mat-label[normalize-space()='{}'])[last()]")
    MCC_option = ('(//mat-option[@aria-disabled="false"]''//mat-label[contains(normalize-space(), "{}")])[last()]')
    select_all_checkbox_dropdown = "//mat-checkbox[.//mat-label[normalize-space()='Select All']]"
    interchange_dropdown = ("//span[normalize-space()='Interchange']""/ancestor::mat-form-field//mat-select")
    interchange_options = ("//mat-option//mat-label")
    interchange_option = ("//mat-option//mat-label[normalize-space()='{}']")
    interchange_select_all_checked = ("//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]""[.//mat-label[normalize-space()='Select All']]")

    customize_coloums_dropdown = ("//span[normalize-space()='Columns']""/ancestor::mat-form-field//mat-select")
    Customize_coloumns_options = ("//mat-option//mat-label")
    Customize_coloums_option = ("//mat-option//mat-label[normalize-space()='{}']")
    Customized_coloumns_select_all_checked = ("//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]""[.//mat-label[normalize-space()='Select All']]")
    customized_coloumns_select_all_checkbox = ("//mat-checkbox[.//mat-label[normalize-space()='Select All']]")
    update_button = "//button[@id='saveBtn']"
    mange_preference_download_button = "(//button[@id='downloadBtn'])[2]"
    download_success_toast = ("//mat-label[normalize-space()='Transaction detail report has been successfully downloaded.']")
    manage_preference_selected_values = "//form[contains(@id,'TransctionDetailReportFilterFormModel')]//mat-label[contains(@class,'text-primary-700')]"
    
    calendar_popup = "//mat-calendar"
    start_date_field = "//label[text()='From date']/following-sibling::label"
    end_date_field = "//label[text()='To date']/following-sibling::label"
    apply_button = "//button[normalize-space()='Apply']"
    cancel_button = "//button[normalize-space()='Cancel']"
    calendar_right_arrow = "//mat-icon[@data-mat-icon-name='arrow-right']"
    calendar_left_arrow = "//mat-icon[@data-mat-icon-name='arrow-left']"
    calendar_date = "//button[@aria-label='{}']"
    selected_date_range = "//span[contains(@class,'mat-mdc-select-value-text')]//mat-select-trigger"



    



