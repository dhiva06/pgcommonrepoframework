class UserrolemanagementLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_user_administration = "span:has-text('User administration')"
    menu_user_role_management = "//span[contains(text(), 'role management')]"
    # Add/Edit User Role page
    add_button = "//button[@id='button253']"
    role_name_input = "#roleName input[type='text']"
    role_description_input = "#description input[type='text']"
    product_field = "#productId mat-select"
    sub_product_field = "#TODO-verify-sub-product-field"
    status_active_radio = "//input[@id='mat-radio-0-input']"
    status_inactive_radio = "//input[@id='mat-radio-1-input']"
    
    # Menu list section
    menu_legend = "#TODO-verify-legend-location"
    menu_checkbox_template = "//label[contains(normalize-space(.), '{menu_name}')]//ancestor::div//input[@type='checkbox']"
    menu_expand_arrow_template = "//label[contains(normalize-space(.), '{menu_name}')]//ancestor::div//button[contains(@class, 'expand')]"
    
    # Save/Update button
    save_button = "//button[@id='saveUserRoleDetailsButton']"
    update_button = "//button[contains(normalize-space(), 'Update')]"
    
    # Success message
    success_message = "//mat-snack-bar-container[contains(normalize-space(), '{message}')]"
    
    # User role listing page
    search_input = "//input[@placeholder='Search user role']"
    search_button = "//button[contains(normalize-space(), 'Search')]"
    role_name_column = "th[class*='cdk-column-roleName']"
    row_by_role_name = "th[mat-header-cell].mat-column-roleName"
    edit_button_in_row = "//tr[./td[contains(normalize-space(), '{role_name}')]]//button[contains(@class, 'edit')]"
    delete_button_in_row = "//tr[./td[contains(normalize-space(), '{role_name}')]]//button[contains(@class, 'delete')]"
    
    # Delete confirmation dialog
    delete_confirmation_message = "//div[contains(normalize-space(), 'Are you sure you want to delete?')]"
    delete_confirmation_detail = "//div[contains(normalize-space(), 'The selected user role')]"
    delete_confirm_button = "//button[contains(normalize-space(), 'Delete')]"
    delete_cancel_button = "//button[contains(normalize-space(), 'Cancel')]"
    
    # No records found message
    no_records_message = "//div[contains(normalize-space(), 'No records found')]"

    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    generic_error_message = "//mat-error"
    toast_message_by_text = "//div[contains(@class, 'snackbar')]//mat-label[contains(normalize-space(.), '{value}')]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class UserrolemanagementLocatorsNegative(UserrolemanagementLocators):
    """Extends UserrolrmanagementLocators with error/validation message locators for negative tests."""

    # Field-level error messages
    role_name_error = ".mat-mdc-form-field:has-text('Role Name') mat-error"
    role_description_error = ".mat-mdc-form-field:has-text('Role Description') mat-error"
    product_error = ".mat-mdc-form-field:has-text('Product') mat-error"
    sub_product_error = ".mat-mdc-form-field:has-text('Sub Product/Portal') mat-error"
    menu_selections_error = ".mat-mdc-form-field:has-text('Menu Selections') mat-error"

    # Generic validation error locators
    generic_error_message = "//mat-error"
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"

    # Toast/Snackbar messages for negative scenarios
    toast_message = "//div[contains(@class, 'snackbar')]//mat-label"
    toast_message_by_text = "//div[contains(@class, 'snackbar')]//mat-label[contains(normalize-space(.), '{value}')]"

    # Duplicate record error
    duplicate_error_message = "//mat-error[contains(normalize-space(.), 'already exists')]"

    # Required field error
    required_field_error = "//mat-error[contains(normalize-space(.), 'required')]"
