class RiskAlertsLocators:
    UNHIDE_MENU = "//mat-icon[@data-mat-icon-name='bars-3']/parent::div"
    ADMINISTRATION = "//*[text()='Administration']"
    RISK_SETUP = "//*[text()='Risk setup']"
    PG = "//*[text()='PG']"
    RISK_ALERTS = "//*[text()='Risk alerts']"
    ADD_BUTTON = "//div[text()='Add']"
    EXISTING_RISK_ALERTS = "//span[normalize-space(text())='MerchantRiskAlert']"
    EXISTING_RISK_ALERTS_1 = "//span[normalize-space()='EcentricRishProfile']/ancestor::tr//td[contains(@class,'riskAlertName')]//span"
    RISK_PROFILE_NAME = "//mat-label[normalize-space(text())='Risk profile name']"
    ALERT_TYPE = "//mat-label[normalize-space(text())='Alert type']"
    STATUS = "//mat-label[normalize-space(text())='Status']"
    RISK_ALERT_NAME = "//mat-label[normalize-space(text())='Risk alert name']"
    ACTION = "//mat-label[normalize-space(text())='Action']"
    TERMINAL = "//div[normalize-space(text())='Terminal']"
    STATUS_DROPDOWN = "//span[normalize-space(text())='Status:']"
    STATUS_DROPDOWN_ACTIVE = "//span[normalize-space(text())='Active']"
    STATUS_DROPDOWN_INACTIVE = "//span[normalize-space(text())='Inactive']"
    SEARCH_BUTTON = "//span[normalize-space(text())='Search']"
    INACTIVE_DROPDOWM_ASSERT = "//mat-label[normalize-space(text())='No matching records found.']"
    ENTER_RISK_ALERT_NAME = "//input[@placeholder='Enter risk alert name/ Risk profile name']"
    ADD_ASSERT_MSG = "//span[normalize-space(text())='Risk profile type']"
    LEVEL_1_THRESHOLD = (
        "//cl-label[.//span[text()='Level 1']]/following-sibling::cl-input//input[@type='text']"
    )
    LEVEL_1_MOBILENUMBER_1 = (
        "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter mobile number'])[1]"
    )
    LEVEL_1_EMAIL_1 = "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter email'])[1]"
    SAVE_BUTTON = "//div[normalize-space(text())='Save']"
    ADD_RISK_PROFILE_NAME = (
        '//mat-label[normalize-space()="Risk profile name"]/ancestor::mat-form-field//mat-select'
    )
    SELECT_RISK_PROFILE_NAME = "//mat-label[normalize-space(text())='Select All']"
    ENTER_RISK_ALERT_ADD = "//span[normalize-space(text())='Risk alert']"
    RISK_ALERT_SUC_MSG = "//*[contains(text(), '{ALERT_NAME}') and contains(text(), 'added successfully')]"
    RISK_ALERT_NAME_DATA_ERROR = "//mat-error[normalize-space(text())='Only letters are allowed.']"
    RISK_ALERT_NAME_MAX_DATA_ERROR = (
        "//mat-error[normalize-space(text())='Maximum length should be 25 characters.']"
    )
    DUPLICATE_RISK_ALERT_NAME = "//mat-label[normalize-space(text())='DUPLICATE RISK ALERT NAME']"
    CHECKRISKALERT = "//tr[.//span[normalize-space()='{ALERT_NAME}']]//mat-icon[@id='iconDelete']"
    CLICK_CONFIRM_BUTTON = "//span[normalize-space(text())='Confirm']"
    CLICK_ANOTHERLEVEL_BUTTON = "//div[normalize-space(text())='Add another level']"
    USER_CLICK_ANOTHERLEVEL_BUTTON = "//mat-expansion-panel[.//div[normalize-space()='User']]//div[normalize-space(text())='Add another level']"
    IP_CLICK_ANOTHERLEVEL_BUTTON = "//mat-expansion-panel[.//div[normalize-space()='IP']]//div[normalize-space(text())='Add another level']"
    LEVEL_2_THRESHOLD = (
        "//cl-label[.//span[text()='Level 2']]/following-sibling::cl-input//input[@type='text']"
    )
    LEVEL_2_MOBILENUMBER_1 = (
        "(//div[@id='grid_6'][.//span[text()='Level 2']]//input[@placeholder='Enter mobile number'])[1]"
    )
    LEVEL_2_EMAIL_1 = "(//div[@id='grid_6'][.//span[text()='Level 2']]//input[@placeholder='Enter email'])[1]"
    LEVEL_3_THRESHOLD = (
        "//cl-label[.//span[text()='Level 3']]/following-sibling::cl-input//input[@type='text']"
    )
    LEVEL_3_MOBILENUMBER_1 = (
        "(//div[@id='grid_6'][.//span[text()='Level 3']]//input[@placeholder='Enter mobile number'])[1]"
    )
    LEVEL_3_EMAIL_1 = "(//div[@id='grid_6'][.//span[text()='Level 3']]//input[@placeholder='Enter email'])[1]"
    ADDANOTHERLEVEL_BUTTON_MSG = "//button[@disabled and contains(.,'Add another level')]"
    DELETE_LEVEL_2 = "//span[normalize-space()='Level 2']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//mat-icon[@data-mat-icon-name='profile-delete']"
    DELETE_LEVEL_1 = "//span[normalize-space()='Level 1']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//mat-icon[@data-mat-icon-name='profile-delete']"
    EMAIL_ERROR_MSG = "//mat-error[normalize-space(text())='invalid email']"
    ALERT_NAME = "//tr[.//span[normalize-space()='{ALERT_NAME}']]//mat-icon[@id='iconDelete']"
    CLICK_YES_BUTTON = "//span[normalize-space(text())='Yes']"
    THRESHOLD_DATA_ERROR = "//mat-error[normalize-space(text())='Value should not be greater than 100.']"
    ADD_MORE_BUTTON_1 = "(//span[normalize-space()='Level 1']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//div[normalize-space(text())='Add more'])[1]"
    ADD_MORE_BUTTON_2 = "(//span[normalize-space()='Level 1']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//div[normalize-space(text())='Add more'])[2]"
    CLICK_ADD_MORE_BUTTON_1 = "(//span[normalize-space()='Level 1']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//div[normalize-space(text())='Add more'])[1]"
    CLICK_ADD_MORE_BUTTON_2 = "(//span[normalize-space()='Level 1']/ancestor::form[contains(@id,'AddRiskAlertLevel')]//div[normalize-space(text())='Add more'])[2]"
    LEVEL_1_MOBILENUMBER_2 = (
        "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter mobile number'])[2]"
    )
    LEVEL_1_EMAIL_2 = "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter email'])[2]"
    LEVEL_1_MOBILENUMBER_3 = (
        "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter mobile number'])[3]"
    )
    LEVEL_1_EMAIL_3 = "(//div[@id='grid_6'][.//span[text()='Level 1']]//input[@placeholder='Enter email'])[3]"
    MAX_REACH_MSG = "//*[contains(normalize-space(),'Maximum limit reached')]"
    LEVEL_1_MOBILENUMBER_3_DELETE_ICON = "(//mat-icon[@id='deleteIcon'])[3]"
    LEVEL_1_EMAIL_3_DELETE_ICON = "(//mat-icon[@id='deleteIcon'])[5]"
    DUPLICATE_MOBILE_NUMBER_MSG = (
        "//mat-label[contains(normalize-space(),'Duplicate mobile number is not allowed in a level')]"
    )
    DUPLICATE_EMAIL_MSG = (
        "//mat-label[contains(normalize-space(),'Duplicate email id is not allowed in a level')]"
    )
    CLICKMERCHANTRISKPROFILETYPE = "//input[@value='MERCHANT']"
    CLICK_USER = "//div[normalize-space(text())='User']"
    CLICK_IP = "//div[normalize-space(text())='IP']"
    USER_THRESHOLD_LEVEL_1 = "//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 1']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"
    USER_LEVEL_1_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 1']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"
    USER_LEVEL_1_EMAIL_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 1']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"

    USER_THRESHOLD_LEVEL_2 = "//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 2']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"

    USER_LEVEL_2_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 2']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"

    USER_LEVEL_2_EMAIL_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 2']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"

    USER_THRESHOLD_LEVEL_3 = "//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 3']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"

    USER_LEVEL_3_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 3']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"

    USER_LEVEL_3_EMAIL_1 = "(//mat-expansion-panel[.//div[normalize-space()='User']]//*[normalize-space()='Level 3']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"

    IP_THRESHOLD_LEVEL_1 = "//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 1']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"

    IP_LEVEL_1_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 1']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"

    IP_LEVEL_1_EMAIL_1 = "(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 1']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"

    IP_THRESHOLD_LEVEL_2 = "//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 2']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"
    IP_LEVEL_2_EMAIL_1="(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 2']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"
    IP_LEVEL_2_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 2']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"

    IP_THRESHOLD_LEVEL_3 = "//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 3']/ancestor::form[1]//cl-input[@name='thresholdPercentage']//input"

    IP_LEVEL_3_MOBILENUMBER_1 = "(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 3']/ancestor::form[1]//input[@placeholder='Enter mobile number'])[1]"
    IP_LEVEL_3_EMAIL_1 = "(//mat-expansion-panel[.//div[normalize-space()='IP']]//*[normalize-space()='Level 3']/ancestor::form[1]//input[@placeholder='Enter email'])[1]"
    USER_LEVEL_1_DELETE_ICON_1 = "//mat-expansion-panel[.//div[normalize-space()='User']]//span[normalize-space()='Level 1']/ancestor::app-riskalertlevelmain[1]//mat-icon[@data-mat-icon-name='profile-delete']"
    IP_LEVEL_1_DELETE_ICON_1 = "//mat-expansion-panel[.//div[normalize-space()='IP']]//span[normalize-space()='Level 1']/ancestor::app-riskalertlevelmain[1]//mat-icon[@data-mat-icon-name='profile-delete']"