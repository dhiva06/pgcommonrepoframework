class BankInformationLocators:
    UNHIDE_MENU = "//mat-icon[@data-mat-icon-name='bars-3']/parent::div"
    ADMINISTRATION = "//*[text()='Administration']"
    BANK_CONFIGURATION = "//*[text()='PG configuration']"

    BANK_INFORMATION = "//*[text()='PG information']"
    BANK_NAME = "//span[normalize-space(text())='Gateway/ FI name']"
    BANK_SHORT_CODE = "//span[normalize-space(text())='Gateway/ FI short code']"
    SELECT_COUNTRY_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[1]"
    CHOOSE_COUNTRY = "//mat-label[normalize-space()='{country}']"
    SELECT_LANGUAGE_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[2]"
    CHOOSE_LANGUAGE = "//mat-label[normalize-space()='{language}']"
    SELECT_BASECURRENCY_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[3]"
    CHOOSE_BASECURRENCY = "(//mat-label[normalize-space()='{basecurrency}'])[2]"
    SELECT_PREMITTEDCURRENCY_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[4]"
    CHOOSE_PREMITTEDCURRENCY = (
        "(//mat-label[normalize-space()='{permittedcurrency}'])[1]"
    )
    EXPAND_HEADER = "//mat-expansion-panel-header[.//mat-panel-title[normalize-space()='{header_name}']]"
    NAME = "//span[normalize-space(text())='Name']"
    MOBILE_NUMBER = "//span[normalize-space(text())='Mobile number']"
    EMAIL = "//span[normalize-space(text())='Email']"
    BUILDING_NAME = "//span[normalize-space(text())='Address']"
    SELECT_CITY_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[6]"
    CHOOSE_CITY = "//mat-label[normalize-space()='{city}']"
    SELECT_STATE_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[7]"
    CHOOSE_STATE = "//mat-label[normalize-space()='{state}']"
    PINCODE = "//span[normalize-space(text())='Postal code']"
    SELECT_CONTACTCOUNTRY_DROPDOWN = "(//*[@class='mat-mdc-select-arrow'])[8]"
    CHOOSE_CONTACTCOUNTRY = "//mat-label[normalize-space()='{ContactCountry}']"
    HELPDESK_EMAIL = "//span[normalize-space(text())='Helpdesk email']"
    HELPDESK_MOBILE_NUMBER_1 = (
        "//span[normalize-space(text())='Helpdesk mobile number 1']"
    )
    HELPDESK_LANDLINE_NUMBER_1 = (
        "//span[normalize-space(text())='Helpdesk landline number 1']"
    )
    HELPDESK_TOLL_FREE_NUMBER_1 = (
        "//span[normalize-space(text())='Helpdesk toll free number 1']"
    )
    HELPDESK_MOBILE_NUMBER_2 = (
        "//span[normalize-space(text())='Helpdesk mobile number 2']"
    )
    HELPDESK_LANDLINE_NUMBER_2 = (
        "//span[normalize-space(text())='Helpdesk landline number 2']"
    )
    HELPDESK_TOLL_FREE_NUMBER_2 = (
        "//span[normalize-space(text())='Helpdesk toll free number 2']"
    )
    SAVE = "//div[normalize-space(text())='Save']"
    BANK_NAME_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Institution name must be between 3 and 128 characters long']"
    BANK_TIME_ZONE_LABEL = "//*[contains(text(),'Country/Language/Currency/Time zone')]"
    BANK_INFORMATION_SUCCESS_MESSAGE = (
        "//*[contains(text(),'PG Information have been configured successfully.')]"
    )
   
    EXPAND1_HEADER = "//mat-expansion-panel-header[.//mat-panel-title[normalize-space()='Contact person’s details']]"
    BANK_CODE_ERROR_MESSAGE = "//mat-error[normalize-space(text())='Short code must be between 3 and 64 characters long']"
    

    BANK_CODE_SPECIAL_CHARACTERS_ERROR_MESSAGE = "//mat-error[normalize-space(text())='Short code can contain only letters and spaces.']"
    
    CONTACT_PERSON_NAME_ERROR_MESSAGE = "//mat-error[normalize-space(text())='Contact person name must be between 3 and 128 characters long']"
    PERSON_NAME_SPECIAL_CHAR_ERROR_MESSAGE = "//mat-error[normalize-space()='Contact person name can contain only letters and spaces']"
    
    MOBILE_MAX_MSG="//mat-error[normalize-space(text())='Mobile number must be between 5 and 10 characters long']"
    MOBILE_SPECIALCHAR_MSG="//mat-error[normalize-space(text())='Mobile number must be between 5 and 9 digits without a leading 0, or 10 digits starting with 0']"

    BANKNAME_SPECIAL_CHAR_ERROR_MESSAGE = "//mat-error[normalize-space(text())='Institution name can contain only letters, numbers, and spaces']"

    MOBILE_NUMBER_DATALENGTH_ERROR = "//mat-label[normalize-space(text())='South Africa mobile number must be numeric and 7-10 digits long']"
    HELPDESK_MOBILE_NUMBER_DATALENGTH_ERROR = "//mat-label[normalize-space(text())='South Africa help desk contact number must be numeric and 7-10 digits long']"
    HELPDESK_MOBILE_NUMBER_MAX_MSG = "//mat-error[normalize-space(text())='Help desk number must be between 5 and 10 characters long']"

    HELPDESK_MOBNUM_SPECIAL_MSG = "//mat-error[normalize-space(text())='Help desk number must be between 5 and 9 digits without a leading 0, or 10 digits starting with 0']"

    EMAIL_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Email must be between 10 and 320 characters long']"
    

    EMAIL_INCORRECT_FORMAT_ERROR = "//mat-error[normalize-space(text())='Enter a valid email address (e.g., user@example.com)']"
    
    HELPDESK_EMAIL_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Help desk email must be between 10 and 320 characters long']"
    HELPDESK_TOLL_FREE_NUMBER_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Data length is invalid for help desk toll free number']"
    HELPDESK_TOLL_FREE_NUMBER_MAX_LENGTH_ERROR = "//mat-error[normalize-space(.)='Help desk toll free number must be between 5 and 10 characters long']"
    HELPDESK_TOLL_FREE_NUMBER_6DIGIT_ERROR = "//mat-label[normalize-space(text())='South Africa help desk tollfree number must be numeric and 7-10 digits long']"

    HELPDESK_TOLL_FREE_NUMBER_MAX_MSG = "//mat-error[contains(normalize-space(.),'Help desk tollfree number must be between 5 and 9 digits without a leading 0, or 10 digits starting with 0')]"
    HELPDESK_TOLLNUM_SPECIAL_MSG = "//mat-error[contains(normalize-space(.),'Help desk tollfree number must be between 5 and 9')]"
    HELPDESK_LANDLINE_NUMBER_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Help desk landline number must be between 5 and 10 characters long']"    
    HELPDESK_TOLL_FREE_NUMBER_SPECIALCHAR_ERROR = "//mat-label[normalize-space(text())='South Africa help desk tollfree number must be numeric and 7-10 digits long']"
    HELPDESK_LANDLINE_SPECIAL_MSG = "//mat-error[contains(normalize-space(.),'Help desk landline number must be between 5 and 9 digits without a leading 0, or 10 digits starting with 0')]"
    HELPDESK_LANDLINE_LESSTHAN_ERROR_MSG = "//mat-label[normalize-space(text())='South Africa help desk landline number must be numeric and 7-10 digits long']"
    MOBILE_CLICK_CHECKBOX = (
        "//mat-label[normalize-space()='Mobile']/following-sibling::mat-icon"
    )
    LANDLINE_CLICK_CHECKBOX = (
        "//mat-label[normalize-space()='Landline']/following-sibling::mat-icon"
    )
    TOLL_FREE_CLICK_CHECKBOX = (
        "//mat-label[normalize-space()='Toll free']/following-sibling::mat-icon"
    )
    ADDITIONAL_LANDLINE_NUMBER = "//div[normalize-space(text())='Additional landline number']"
    ADDITIONAL_MOBILE_NUMBER = "//div[normalize-space(text())='Additional mobile number']"
    ADDITIONAL_TOLL_FREE_NUMBER = "//div[normalize-space(text())='Additional toll free number']"
    DELETE_MOBILE_NUMBER = "(//mat-icon[@data-mat-icon-name='profile-delete'])[1]"
    DELETE_LANDLINE_NUMBER = "(//mat-icon[@data-mat-icon-name='profile-delete'])[3]"
    DELETE_TOLL_FREE_NUMBER = "(//mat-icon[@data-mat-icon-name='profile-delete'])[5]"
    BUILDING_NAME_DATALENGTH_ERROR = "//mat-label[normalize-space(text())='Address should be minimum 4 and maximum 64 character']"
    PINCODE_DATALENGTH_ERROR = "//mat-error[normalize-space(text())='Postal code must be between 4 and 6 characters long']"
    PINCODE_DATALENGTH_POPUP_MSG = "//mat-label[normalize-space(text())='Length of zipcode is invalid(should be 4)']"
    SHORT_CODE_MANDATORY = "//mat-error[normalize-space(text())='Shot code is mandatory']"
    CONTACT_ADDRESS_CITY=('//mat-label[normalize-space()="City"]/ancestor::mat-form-field//mat-select')
    CONTACT_ADDRESS_COUNTRY=('//mat-label[normalize-space()="Country"]/ancestor::mat-form-field//mat-select')
    CONTACT_ADDRESS_STATE=('//mat-label[normalize-space()="State/Province"]/ancestor::mat-form-field//mat-select')
    COUNTRY=('//mat-label[normalize-space()="Gateway/FI country"]/ancestor::mat-form-field//mat-select')
    LANGUAGE=('//mat-label[normalize-space()="Gateway/FI language"]/ancestor::mat-form-field//mat-select')
    BASE_CURRENCY=('//mat-label[normalize-space()="Gateway/FI base currency"]/ancestor::mat-form-field//mat-select')
    PERMITTED_CURRENCY=('//mat-label[normalize-space()="Gateway/FI permitted currency"]/ancestor::mat-form-field//mat-select')
