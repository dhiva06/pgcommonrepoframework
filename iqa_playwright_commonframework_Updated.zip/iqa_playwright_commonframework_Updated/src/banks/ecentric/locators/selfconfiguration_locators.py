class SelfconfigurationLocators:
    # Navigation
    menu_my_account = "//mat-label[contains(text(),'My account')]"
    menu_self_configuration = "//span[contains(text(),'Self configuration')]"
    
    # PG Template Tab
    pg_template_tab = "//div[@role='tab' and contains(., 'PG Template')]"
    
    # Logo Upload Section
    logo_image = "//img[@alt='logo' or contains(@src, 'logo')]"
    logo_delete_button = "//button[.//mat-icon[contains(@data-mat-icon-name, 'trash')]]"
    file_upload_input = "//input[@id='file-upload' and @type='file']"
    
    # Terminal ID Field
    terminal_id_dropdown = "#terminalKey mat-select"
    terminal_id_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    # Choose Color Field
    choose_color_input = "//input[@type='text' and @colorpicker]"
    
    # Select Template Dropdown
    select_template_dropdown = "#paymentPageTemplateCode mat-select"
    select_template_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    # Select Language Field
    select_language_dropdown = "button.mat-mdc-menu-trigger"
    select_language_option = "button[aria-haspopup='menu'][aria-expanded='false']"
    language_chip = "//mat-chip[contains(normalize-space(.), '{value}')]"
    language_chip_remove = "//mat-chip[contains(normalize-space(.), '{value}')]//button[contains(@aria-label, 'remove')]"
    
    # Preview Button
    preview_button = "//button[@id='templatePreviewButton']"
    
    # Save Button
    save_button = "form button"
    # Success Message
    success_message = "//div[contains(@class, 'alert') or contains(@class, 'success')]"
    
    # Preview Modal/Dialog
    preview_modal = "//div[contains(@class, 'modal') or contains(@class, 'dialog')]"
    preview_modal_close = "button#templatePreviewButton"
    preview_logo = "button#templatePreviewButton"
    # Default language note
    default_language_note = "//span[contains(text(), 'Default language will be used')]"

    choose_color_error = ".mat-mdc-form-field:has-text('Choose Color') mat-error"
    select_language_error = ".mat-mdc-form-field:has-text('Select Language') mat-error"
    select_template_error = ".mat-mdc-form-field:has-text('Select Template') mat-error"
    terminal_id_error = ".mat-mdc-form-field:has-text('Terminal ID') mat-error"
    toast_message = "//div[contains(@class, 'snackbar')]//mat-label"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class SelfconfigurationLocatorsNegative(SelfconfigurationLocators):
    """Negative-case locators extending positive Self configuration locators."""
    
    # -------------------- Field-Level Error Messages --------------------
    # Generic error message locators
    error_message_generic = "//mat-error"
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    
    # Field-specific error locators (label-anchored for clarity)
    terminal_id_error = ".mat-mdc-form-field:has-text('Terminal ID') mat-error"
    choose_color_error = ".mat-mdc-form-field:has-text('Choose Color') mat-error"
    select_template_error = ".mat-mdc-form-field:has-text('Select Template') mat-error"
    select_language_error = ".mat-mdc-form-field:has-text('Select Language') mat-error"
    
    # Toast/Snackbar messages (for backend validation errors)
    toast_message = "//div[contains(@class, 'snackbar')]//mat-label"
    snackbar_error = "//div[contains(@class, 'mat-mdc-snack-bar-container')]"
