class EcentricLoginLocators:
    class Bank:
        username_field = "//span[text()='User Name']"     # TODO: confirm real selector
        password_field = "//span[normalize-space()='Password']"      # TODO: confirm real selector
        captcha_field = "//mat-form-field[@id='captcha']//input"
        captcha_image = "//cl-captcha-input[@id='captcha']//span[contains(@class,'font-bold')]"
        captcha_error = "//mat-error[contains(text(),'CAPTCHA does not match')]"
        captcha_refresh = "//button[.//mat-icon[@data-mat-icon-name='arrow-path']]"
        login_button = "//button[normalize-space()='Login']"
        dashboard_marker='//div[contains(text(),"WELCOME BACK")]'
    class Merchant:
        username_field = "//span[text()='User Name']"     # TODO: confirm real selector
        password_field = "//span[normalize-space()='Password']"      # TODO: confirm real selector
        captcha_field = "//mat-form-field[@id='captcha']//input"
        captcha_image = "//cl-captcha-input[@id='captcha']//span[contains(@class,'font-bold')]"
        captcha_error = "//mat-error[contains(text(),'CAPTCHA does not match')]"
        captcha_refresh = "//button[.//mat-icon[@data-mat-icon-name='arrow-path']]"
        login_button = "//button[normalize-space()='Login']"
