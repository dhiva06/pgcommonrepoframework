class GeneralLocators:
    # Navigation
    menu_administration = "//mat[contains(text(),'Administration')]"
    menu_notification = "//mat[contains(text(),'Notification')]"
    menu_general = "//mat[contains(text(),'General')]"
    
    # Add/Edit Notification page
    add_button = "//button[@id='button21']"
    event_dropdown = "[name*='event']"
    event_option_by_text = "input[placeholder*='event']"
    mode_radio_by_label = "label[for='mat-radio-0-input']"
    template_name_input = "//input[@id=//label[contains(., 'Template name')]/@for]"
    content_textarea = "//textarea[@id=//label[contains(., 'content')]/@for]"
    preview_panel = "//div[@data-testid='preview-panel']"
    save_button = "//button[@id='saveButton']"
    update_button = "//button[@id='updateButton']"
    character_counter = "//span[@data-testid='character-counter']"
    breadcrumb = "[class*='breadcrumb']"
    success_message = "//mat-snack-bar-container[contains(normalize-space(), '{value}')]"
    
    # Notification listing page
    search_input = "input[placeholder='Enter event name']"
    search_button = "button#btnSubmit"
    row_by_event_code = "//tr[contains(., '{value}')]"
    event_code_cell = row_by_event_code + "//td[1]"
    event_cell = row_by_event_code + "//td[2]"
    notification_type_cell = row_by_event_code + "//td[3]"
    template_name_cell = row_by_event_code + "//td[4]"
    edit_button = row_by_event_code + "//button[@data-testid='edit-button']"
    delete_button = row_by_event_code + "//button[@data-testid='delete-button']"
    total_items_label = "//span[contains(text(), 'Total')]"
    no_records_message = "//div[contains(text(), 'No records found')]"
    
    # Delete confirmation dialog
    delete_confirmation_dialog = "//div[@role='dialog'][contains(., 'delete')]"
    delete_confirm_yes_button = delete_confirmation_dialog + "//button[contains(normalize-space(), 'Yes')]"
    delete_confirm_cancel_button = delete_confirmation_dialog + "//button[contains(normalize-space(), 'Cancel')]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class GeneralLocatorsNegative(GeneralLocators):
    """Extends GeneralLocators with error and validation message locators for negative tests."""

    # Error/validation message locators
    field_error_message = "//mat-error[contains(normalize-space(), '{value}')]"
    validation_error_generic = "//mat-error"
    toast_error_message = "//div[contains(@class, 'snack-bar')]//mat-label"
    
    # Per-field error locators
    event_dropdown_error = ".mat-mdc-form-field:has-text('Event') mat-error"
    mode_notification_error = ".mat-mdc-form-field:has-text('Mode of notification') mat-error"
    template_name_error = ".mat-mdc-form-field:has-text('Template name') mat-error"
    content_error = ".mat-mdc-form-field:has-text('Content') mat-error"
    
    # Character counter (used to verify state after invalid input)
    character_counter_negative = "//span[@data-testid='character-counter']"
