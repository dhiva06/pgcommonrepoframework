class UsermanagementLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_user_administration = "//mat-label[contains(text(),'User administration')]"
    menu_user_management = "//mat-label[contains(text(),'User management')]"
    
    # User management listing page
    search_user_textbox = "input[placeholder='Search user role']"
    search_button = "//button[contains(normalize-space(), 'Search')]"
    add_button = "button#addUserSaveButton"
    user_name_link_template = "//a[contains(normalize-space(), '{user_name}')]"
    
    # Add/Edit user form
    user_full_name_input = "#userFullname input[type='text']"
    persona_type_dropdown = "#personaTc mat-select"
    persona_reference_id_dropdown = "#personaReferenceId mat-select"
    product_field = "//span[contains(text(), 'ACQUIRING PG')]"
    sub_product_field = "//span[contains(text(), 'ACQUIRING PG BANK')]"
    role_dropdown = "#roleId mat-select"
    user_name_input = "#username input[type='text']"
    email_input = "#emailAddress input[type='email']"
    country_code_dropdown = "//mat-select[@formcontrolname='countryCode']"
    mobile_number_input = "#mobileNo input[type='text']"
    authentication_source_radio_template = "input[type='radio'][value='IDP']"
    status_field = "th[class*='statusTc']"
    save_button = "//button[@id='addUserSaveButton']"
    update_button = "//button[contains(normalize-space(), 'Update')]"
    
    # User details/View page
    user_details_page_header = "//h2[contains(text(), 'User Details')]"
    breadcrumb = "//nav[contains(@class, 'breadcrumb')]"
    delete_button = "//button[contains(normalize-space(), 'Delete')]"
    edit_button = "//button[contains(normalize-space(), 'Edit')]"
    view_user_full_name = "//*[contains(text(), 'full name')]//following::input[1]"
    view_persona_type = "//span[contains(@class, 'persona-type')]"
    view_persona_reference_id = "//span[contains(@class, 'persona-ref-id')]"
    view_product = "//span[contains(@class, 'product')]"
    view_sub_product = "//span[contains(@class, 'sub-product')]"
    view_role = "//span[contains(@class, 'role')]"
    view_user_name = "//span[contains(@class, 'user-name')]"
    view_email = "//span[contains(@class, 'email')]"
    view_mobile_number = "//span[contains(@class, 'mobile-number')]"
    view_authentication_source = "//span[contains(@class, 'auth-source')]"
    view_idp_provider = "//span[contains(@class, 'idp-provider')]"
    view_fusion_auth_provider = "//span[contains(@class, 'fusion-auth-provider')]"
    view_status = "//span[contains(@class, 'status')]"
    
    # Delete confirmation dialog
    delete_confirmation_message = "//mat-dialog-container//div[contains(text(), 'Are you sure you want to delete?')]"
    delete_confirmation_detail = "//mat-dialog-container//div[contains(text(), 'The selected user')]"
    delete_cancel_button = "//button[contains(normalize-space(), 'Cancel')]"
    delete_yes_button = "//button[contains(normalize-space(), 'Yes')]"
    
    # Success/Error messages
    success_message = "//div[contains(@class, 'success')]"
    message_container = "//mat-snack-bar-container"
    
    # Dropdowns and options
    option_by_text = "xpath=(//mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') or (contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')) and not(../mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]))])[1]"
    # Edit page specific
    password_recovery_button = "//button[contains(normalize-space(), 'Send password recovery mail')]"
    user_name_readonly = "//input[@id='mat-input-10' and @readonly]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class UsermanagementLocatorsNegative(UsermanagementLocators):
    """Extends UsermanagementLocators with additional locators for negative test cases."""

    # Field-level error messages
    user_full_name_error = ".mat-mdc-form-field:has-text('User full name') mat-error"
    user_name_error = ".mat-mdc-form-field:has-text('User name') mat-error"
    email_error = ".mat-mdc-form-field:has-text('Email') mat-error"
    country_code_error = ".mat-mdc-form-field:has-text('Country code') mat-error"
    mobile_number_error = ".mat-mdc-form-field:has-text('Mobile number') mat-error"
    authentication_source_error = ".mat-mdc-form-field:has-text('Authentication source') mat-error"

    # Generic validation error locators
    any_mat_error = "//mat-error"
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"

    # Toast/snackbar message
    toast_message = "//div[contains(@class, 'snackbar')]//mat-label"



    class CreateUserLocators:
    UNHIDE_MENU = "//mat-icon[@data-mat-icon-name='bars-3']/parent::div"
    ADMINISTRATION = "//mat-label[text()='Administration']"
    USER_ADMINISTRATION = "//mat-label[text()='User administration']"
    USER_MANAGEMENT_USER = "//mat-label[text()='User management']"
    ADD_USER = "(//button[@type='button'])[3]"
    USER_FULL_NAME = "//span[text()='User full name']"
    PERSONA_TC = "//mat-form-field[@id='personaTc']"
    PERSONA_REFERENCE_ID = "(//div[@class='mat-mdc-select-arrow'])[2]"
    PRODUCT_USER = "(//mat-select[@role='combobox'])[3]"
    SUB_PRODUCT_USER = "(//mat-select[@role='combobox'])[4]"
    ACQUIRING_PG = "(//mat-label[text()='ACQUIRING PG'])"
    # ROLE = "//mat-label//span[text()='Role']"
    USERNAME = "//span[text()='User name']"
    EMAIL = "//span[text()='Email']"
    MOBILE = "//span[text()='Mobile number']"
    STATUS = "(//mat-select[@role='combobox'])[7]"
    USER_AUTHENTICATION_SOURCE = "//input[@value='IHA']"
    PRODUCT_USER = "(//mat-select[@role='combobox'])[3]"
    SUB_PRODUCT_USER = "(//mat-select[@role='combobox'])[4]"
    ROLE_DROPDOWN = "(//mat-select[@role='combobox'])[5]"
    ROLE_SEARCH="//input[@placeholder='Search...']"
    USER_SEARCH = "//input[@placeholder='Search user role']"
    EDIT_ICON = "//cl-icon[@id='iconEdit']"
    SAVE_BUTTON = "//span/div[text()='Save']"
    EDIT_USER ="//div[text()='Edit']"
    UPDATE_BUTTON = "//span/div[text()='Update']"
    User_Status = "(//div[@class='mat-mdc-select-arrow'])[7]"
    persona_type_dropdown = "mat-select:near(:text('Persona type'))"
    persona_reference_id_dropdown = "mat-select:near(:text('Persona reference ID'))"
    product_dropdown = "mat-select:near(:text('Product'))"
    sub_product_dropdown = "mat-select:near(:text('Sub product/ Portal'))"
    role_dropdown = "mat-select:near(:text('Role'))"
 
    user_full_name_field = "input[formcontrolname='userFullName']"
    save_button = "button:has-text('Save')"
    success_marker = "text=User created successfully"

