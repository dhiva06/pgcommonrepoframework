class BinmanagementLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_bin_management = "//mat-label[text()='BIN Management']"
    menu_bin_management_approval = "//mat-label[text()='BIN Management Approval']"
    
    # Add BIN form
    add_button = "//button[@id='button70']"
    bin_input = "#bin input[type='number']"
    bin_low_range_input = "#lowRange input[type='text']"
    bin_high_range_input = "#highRange input[type='text']"
    
    # Dropdowns (mat-select elements)
    interchange_code_dropdown = "#interChangeCode mat-select"
    card_type_dropdown = "#cardType mat-select"
    card_product_dropdown = "#cardProduct mat-select"
    country_dropdown = "#country mat-select"
    acquiring_type_dropdown = "#acquiringType mat-select"
    message_type_dropdown = "#messageType mat-select"
    
    # Radio buttons for BIN status
    bin_status_radio = "input[type='radio'][value='ACTIVE']"
    # Buttons
    send_for_approval_button = "//button[contains(normalize-space(), 'Send for approval')]"
    save_button = "//button[@id='saveUpdateBinButton']"
    approve_button = "//button[contains(normalize-space(), 'Approve')]"
    edit_button = "//button[contains(normalize-space(), 'Edit')]"
    delete_button = "//button[contains(normalize-space(), 'Delete') or contains(@class, 'delete')]"
    back_button = "//button[contains(normalize-space(), 'Back')]"
    
    # Search and listing
    search_bin_input = "input[placeholder='Search BIN']"
    search_button = "//button[contains(normalize-space(), 'Search')]"
    bin_row_by_value = "//tr[contains(., '{value}')]"
    expand_icon = "//mat-icon[@id='icon153']"
    
    # Dynamic row locators for listing
    row_template = "//tr[.//*[contains(normalize-space(),'{bin_value}')]]"
    view_link_in_row = row_template + "//a[contains(normalize-space(),'View')]"
    
    # Message/Status elements
    message_container = "//mat-error | //div[contains(@class, 'alert')] | //div[@role='alert']"
    success_message = "//div[contains(text(), 'successfully')]"
    
    # Confirmation dialog
    confirm_approve_button = "//*[@id='approveBinManagementButton']/div/span/div"
    confirm_delete_button = "//button[contains(normalize-space(), 'Delete')]"
    
    # BIN Details page
    bin_number_display = "//span[contains(@class, 'bin-number')]"
    request_status_display = "//span[contains(text(), 'Request status')]"
    request_type_display = "//span[contains(text(), 'Request type')]"
    
    # Mat-option template for dropdowns
    option_by_text = "xpath=(//mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') or (contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')) and not(../mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]))])[1]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class BinmanagementLocatorsNegative(BinmanagementLocators):
    """Extends BinmanagementLocators with error/validation message locators for negative tests."""

    # -------------------- Field-level error locators --------------------
    # These locators detect validation errors on individual form fields
    
    bin_error = ".mat-mdc-form-field:has-text('BIN') mat-error"
    bin_low_range_error = ".mat-mdc-form-field:has-text('BIN low range') mat-error"
    bin_high_range_error = ".mat-mdc-form-field:has-text('BIN high range') mat-error"
    
    interchange_code_error = ".mat-mdc-form-field:has-text('Interchange code') mat-error"
    card_type_error = ".mat-mdc-form-field:has-text('Card type') mat-error"
    card_product_error = ".mat-mdc-form-field:has-text('Card product') mat-error"
    country_error = ".mat-mdc-form-field:has-text('Country') mat-error"
    acquiring_type_error = ".mat-mdc-form-field:has-text('Acquiring type') mat-error"
    message_type_error = ".mat-mdc-form-field:has-text('Message type') mat-error"
    bin_status_error = ".mat-mdc-form-field:has-text('BIN status') mat-error"
    
    # -------------------- Generic validation/error locators --------------------
    # Generic matchers for any validation error on the form
    
    any_field_error = "//mat-error"
    form_validation_error = "//div[contains(@class, 'mat-mdc-form-field-error')]"
    
    # -------------------- Toast/Snackbar message locators --------------------
    # For post-submit error/success messages
    
    toast_message = "//div[contains(@class, 'snackbar')]//mat-label"
    snackbar_message = "//div[contains(@class, 'snackbar')]"
    alert_message = "//div[@role='alert']"
    
    # -------------------- Generic expected message locator --------------------
    # Template for asserting any expected error message text
    
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    message_by_text = "//div[contains(normalize-space(.), '{value}')]"
