class selfconfigurationapilocators:
    #------API dashboard locators to verify dashboard visible or not------#
    search_box = "//input[@placeholder='Search...']"
    search_button = "//button[@id='btnSubmit']"
    add_button = "//button[@id='button100']"
    api_key_grid = "//table[@role='table']"
    key_id_header = "//mat-label[normalize-space()='Key ID']"
    terminal_id_header = "//mat-label[normalize-space()='Terminal ID']"
    date_creation_header = "//mat-label[normalize-space()='Date of creation']"
    channel_header = "//mat-label[normalize-space()='Channel']"
    expiry_header = "//mat-label[normalize-space()='Expiry']"
    actions_header = "//mat-label[normalize-space()='Actions']"
    #-------------------------------------#
    #-----------My Accounts dashboard--------#
    business_name = "//div[@id='businessName']//span"
    merchant_id_label = "//span[normalize-space()='Merchant ID:']"
    merchant_id_value = "//div[@id='merchantId']//span"
    business_information_card = "//span[normalize-space()='Business information']"
    self_configuration_card = "//span[normalize-space()='Self configuration']"
    #-----------------------------------------------------------------#

    unhide_menu="//div[contains(@class,'cursor-pointer')][.//mat-icon[@data-mat-icon-name='bars-3']]"
    my_account_menu="//a[contains(@class,'cl-vertical-navigation-item') and .//mat-label[normalize-space()='My account']]"
    self_configuration="//span[normalize-space()='Self configuration']"
    api_key="//span[contains(@class,'mat-mdc-tooltip-trigger') and normalize-space()='API Key']"
    api_key_grid = "//cl-data-grid[@id='dataGrid9']"
    api_add_button = "//button[.//div[normalize-space()='Add']]"
    terminal_dropdown = "//mat-label[normalize-space()='Terminal ID']/ancestor::mat-form-field//mat-select"
    dropdown_option = "//mat-option[.//mat-label[normalize-space()='{value}']]"
    generate_button = "//button[.//div[normalize-space()='Generate']]"
    channel_field = "//span[normalize-space()='Channel']"
    deactivate_old_key_immediately = "//span[normalize-space()='Deactivate old key immediately']"
    deactivate_old_key_24hrs = "//span[normalize-space()='Deactivate old key in 24 hours']"
    key_id_value = "//cl-label[@id='keyIdLabel']//span"
    key_id_copy_icon = "//cl-icon[@id='copyKeyId']"
    key_secret_value = "//cl-label[@id='secretKeyLabel']//span"
    key_secret_copy_icon = "//cl-icon[@id='copySecretKey']"
    Key_Id_success_toast = "//mat-label[normalize-space()='Key Id copied succesfully.']"
    secret_Key_Id_success_toast = "//mat-label[normalize-space()='Key secret copied successfully.']"
    download_key_button = "//button[@id='downloadButton']"
    first_row_key_id = "(//tbody/tr[1]/td[1]//span)[1]"
    first_row_terminal_id = "(//tbody/tr[1]/td[2]//span)[1]"
    first_row_created_date = "(//td[contains(@class,'mat-column-createdOn')]//span)[1]"
    first_row_channel = "(//td[contains(@class,'mat-column-paymentChannelCode')]//span)[1]"
    first_row_expiry_date = "(//td[contains(@class,'mat-column-expiryDate')]//span)[1]"
    pg_template_tab = "//span[normalize-space()='PG Template']"
    webhooks_tab = "//span[normalize-space()='Webhooks']"
    api_key_tab = "//span[normalize-space()='API Key']"
    second_row_expiry_date = "(//td[contains(@class,'mat-column-expiryDate')]//span)[2]"
    channel_in_generate = "//cl-label[@id='channelLabel']//span[normalize-space()='PG']"
    download_once_message = "//div[contains(@class,'cl-status-message-message')]"
    success_popup = "//div[contains(text(),'New API key has been generated successfully')]"
    key_id_rows = "//td[contains(@class,'mat-column-terminalApiKeyId')]//span"
    latest_key_id = "(//td[contains(@class,'mat-column-terminalApiKeyId')]//span)[1]"
    delete_icon = "(//button[@id='deleteButton'])[1]"
    delete_confirmation_popup = "//div[normalize-space()='Delete']"
    delete_confirmation_message = "//mat-dialog-container"
    yes_button = "//button[.//span[normalize-space()='Yes']]"
    cancel_button = "//button[.//span[normalize-space()='Cancel']]"
    close_icon = "//mat-dialog-container//button[contains(@class,'close')]"
    delete_success_toast = "//*[contains(text(),'API Key successfully deleted')]"
    toast_message = "//cl-toast//mat-label"
    delete_button_by_terminal = ("//tr[.//td[contains(@class,'mat-column-terminalId')]""//span[normalize-space()='{}']]""//button[@id='deleteButton' and not(@disabled)][1]")
    terminal_all_options = "//mat-option//mat-label"












