from src.banks.ecentric.locators.channelsupportpg_locators import ChannelsupportpgLocators


class ChannelsupportpgLocatorsNegative(ChannelsupportpgLocators):
    """Negative case locators for Channel Support - PG configuration."""
    
    # Error message locators
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    field_error_api = ".mat-mdc-form-field:has-text('API') mat-error"
    field_error_hosted_payment_page = ".mat-mdc-form-field:has-text('Hosted Payment Page') mat-error"
    field_error_card_masking = ".mat-mdc-form-field:has-text('Enable card number masking') mat-error"
    field_error_gateway_users = ".mat-mdc-form-field:has-text('Number of gateway users allowed') mat-error"
    field_error_mpgs_url = ".mat-mdc-form-field:has-text('MPGS URL') mat-error"
    field_error_mpgs_version = ".mat-mdc-form-field:has-text('MPGS Version') mat-error"
    field_error_cybersource_api_url = ".mat-mdc-form-field:has-text('Cybersource Service API URL') mat-error"
    field_error_cybersource_auth_url = ".mat-mdc-form-field:has-text('Cybersource Auth URL') mat-error"
    field_error_merchant_users = ".mat-mdc-form-field:has-text('Number of merchant user(s) allowed') mat-error"
    field_error_merchant_url_auth = ".mat-mdc-form-field:has-text('Merchant URL authentication') mat-error"
    field_error_intl_transactions = ".mat-mdc-form-field:has-text('Enable international transactions') mat-error"
    field_error_multiple_refunds = ".mat-mdc-form-field:has-text('Multiple refunds') mat-error"
    field_error_refunds_reversal = ".mat-mdc-form-field:has-text('Refunds and reversal from portal') mat-error"
    field_error_card_capture = ".mat-mdc-form-field:has-text('Card capture screen expiry time') mat-error"
    field_error_success_failure = ".mat-mdc-form-field:has-text('Success/Failure page') mat-error"
    field_error_page_timeout = ".mat-mdc-form-field:has-text('Page time out') mat-error"
    field_error_auto_key_expiry = ".mat-mdc-form-field:has-text('Automatic key expiry') mat-error"
    field_error_expiry_period = ".mat-mdc-form-field:has-text('Expiry period') mat-error"
    field_error_enable_webstore = ".mat-mdc-form-field:has-text('Enable webstore') mat-error"
    field_error_enable_webhook = ".mat-mdc-form-field:has-text('Enable webhook') mat-error"
    field_error_enable_payment_button = ".mat-mdc-form-field:has-text('Enable payment button') mat-error"
    field_error_enable_payment_link = ".mat-mdc-form-field:has-text('Enable payment link') mat-error"
    field_error_enable_multiple_terminal = ".mat-mdc-form-field:has-text('Enable multiple terminal') mat-error"
    field_error_max_terminals = ".mat-mdc-form-field:has-text('Maximum number of terminal(s)') mat-error"
    
    # Generic validation error
    validation_error = "//mat-error"
