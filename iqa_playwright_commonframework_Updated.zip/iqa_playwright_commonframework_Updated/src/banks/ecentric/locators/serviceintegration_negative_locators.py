from src.banks.ecentric.locators.serviceintegration_locators import ServiceintegrationLocators


class ServiceintegrationLocatorsNegative(ServiceintegrationLocators):
    """Negative test locators for Service integration - extends positive locators with error/validation messages."""
    
    # Error and validation message locators
    error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    validation_error_generic = "//mat-error"
    alert_message = "//div[contains(@class, 'error') or contains(@class, 'alert-danger')]"
    toast_message = "//div[contains(@class, 'snackbar') or contains(@class, 'toast')]//mat-label"
