class GoconnectLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_goconnect = "//mat-label[contains(text(),'GoConnect')]"
    
    # Add Connection page
    add_button = "//button[@id='button9']"
    page_title_add = "button#button9"
    breadcrumb = "//nav//span[contains(text(),'Administration')]"
    
    # Product network segmentation section
    product_dropdown = "#productCode mat-select"
    network_dropdown = "//mat-select[@formcontrolname='network']"
    option_by_text = "xpath=(//mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') or (contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')) and not(../mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]))])[1]"
    # Connection details section
    connection_name_input = "#connectionName input[type='text']"
    connection_mode_radio = "//*[@id='connectionMode']//mat-radio-button[normalize-space()='Client']//input[@type='radio']"
    login_required_radio = "//*[@id='isLoginRequired']//mat-radio-button[normalize-space()='No']//input[@type='radio']"
    auto_login_flag = "span.text-md:has-text('Auto login flag')"
    echo_required_radio = "//*[@id='isEchoRequired']//mat-radio-button[normalize-space()='Yes']//input[@type='radio']"
    echo_frequency_input = "#echoFreq input[type='number']"
    echo_retry_attempts_input = "#echoRetryAttempts input[type='number']"
    ip_address_input = "#host input[type='text']"
    port_input = "#port input[type='number']"
    
    # Buttons
    save_button = "//button[@id='saveGoConnectDetailsButton']"
    update_button = "//button[contains(text(),'Update')]"
    
    # Success message
    success_message = "//div[contains(@class,'alert-success')]"
    
    # GoConnect listing page
    search_input = "input[formcontrolname='goToPage']"
    search_button = "form button"
    page_marker = "//h2[contains(text(),'Go connect')]"
    
    # Dynamic row locator for listing
    row_by_connection_name = "//tr[td[contains(normalize-space(),'{connection_name}')]]"
    connection_name_link = row_by_connection_name + "//a[contains(normalize-space(),'{connection_name}')]"
    
    # Connection summary page
    summary_page_title = "//h2[contains(text(),'Connection summary')]"
    summary_breadcrumb = "//nav//span[contains(text(),'Go connect')]"
    connection_status_display = "//span[contains(text(),'Connection status')]"
    edit_icon = "//button[contains(@class,'edit')]"
    delete_button = "//button[contains(text(),'Delete')]"
    stop_button = "//button[contains(text(),'Stop')]"
    start_button = "//button[contains(text(),'Start')]"
    
    # Edit connection page
    edit_page_title = "(//input[@type='text'])[1]"
    edit_breadcrumb = "//nav//span[contains(text(),'Edit connection')]"
    product_display = "th[mat-header-cell].mat-column-productName"
    network_display = "//span[text()='MASTERCARD']"
    connection_name_display = "//label[contains(., 'Connection name')]/following-sibling::input"
    # Delete confirmation dialog
    delete_dialog = "//div[@role='dialog']"
    delete_confirmation_message = "//div[contains(text(),'Are you sure you want to delete')]"
    delete_dialog_cancel_button = "//button[contains(text(),'Cancel')]"
    delete_dialog_yes_button = "//button[contains(text(),'Yes')]"
    
    # Field display values for summary/edit verification
    field_value_by_label = "//label[contains(text(),'{label}')]/../following-sibling::*/span"

    # selectors that were written inline in the page code (templates use .format(value=...))
    inline_selector = "//span[contains(text(),'{value}')]"
    inline_selector_2 = "//span[text()='{value}']"

    any_error_message = "//mat-error"
    error_message_by_text = "//mat-error[contains(normalize-space(), '{value}')]"


# ==================================================================
# NEGATIVE LOCATORS
# ==================================================================
class GoconnectLocatorsNegative(GoconnectLocators):
    """Extends GoconnectLocators with error/validation message locators for negative tests."""

    # Field-level error messages
    connection_name_error = ".mat-mdc-form-field:has-text('Connection name') mat-error"
    connection_mode_error = ".mat-mdc-form-field:has-text('Connection mode') mat-error"
    login_required_error = ".mat-mdc-form-field:has-text('Login required') mat-error"
    auto_login_flag_error = ".mat-mdc-form-field:has-text('Auto login flag') mat-error"
    echo_required_error = ".mat-mdc-form-field:has-text('Echo required') mat-error"
    echo_frequency_error = ".mat-mdc-form-field:has-text('Echo frequency') mat-error"
    echo_retry_attempts_error = ".mat-mdc-form-field:has-text('Echo retry attempts') mat-error"
    ip_address_error = ".mat-mdc-form-field:has-text('IP address') mat-error"
    port_error = ".mat-mdc-form-field:has-text('Port') mat-error"
    
    # Generic validation/error message locators
    any_error_message = "//mat-error"
    error_message_by_text = "//mat-error[contains(normalize-space(), '{value}')]"
    toast_message = "//div[contains(@class,'snackbar')]//mat-label"
    validation_error_dialog = "//div[@role='alert']"
    
    # Product/Network segmentation section errors
    product_error = ".mat-mdc-form-field:has-text('Product') mat-error"
    network_error = ".mat-mdc-form-field:has-text('Network') mat-error"
