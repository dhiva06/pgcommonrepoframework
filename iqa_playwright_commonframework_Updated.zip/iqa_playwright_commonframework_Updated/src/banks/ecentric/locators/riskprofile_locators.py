class EcentricRiskprofileLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_risk_setup = "//mat-label[contains(text(),'Risk setup')]"
    menu_pg = "a[href='#/dashboard/administration-risk-setup-pg-landing-page-with-cards']"
    risk_profile_tab = "//span[contains(text(),'Risk profiles')]"
    
    # Add/Edit Risk Profile Form
    add_button = "button"
    risk_profile_name_input = "//input[@id=//label[contains(., 'Risk profile name')]/@for]"
    currency_code_dropdown = "#currencyCode mat-select"
    option_by_text = "xpath=(//mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') or (contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')) and not(../mat-option[translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')=translate('{value}','ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')]))])[1]"
    international_transaction_no_radio = "//*[@id='hasRiskInternational']//mat-radio-button[normalize-space()='No']//input[@type='radio']"
    
    # Terminal Section - Domestic
    terminal_section_header = "//mat-expansion-panel-header[contains(normalize-space(), 'Terminal')]"
    terminal_domestic_label = "//span[contains(text(), 'Domestic')]"
    maximum_transactions_chips = "//mat-chip[contains(normalize-space(), '{value}')]"
    cumulative_transaction_amount_chips = "//mat-chip[contains(normalize-space(), '{value}')]"
    cumulative_refund_amount_chips = "//mat-chip[contains(normalize-space(), '{value}')]"
    terminal_actions_radio = "//mat-radio-button[contains(normalize-space(), '{value}')]"
    transaction_amount_min_input = "//input[@formcontrolname='minTransactionAmount']"
    transaction_amount_max_input = "//input[@formcontrolname='maxTransactionAmount']"
    
    # User Section - Domestic
    user_section_header = "//mat-expansion-panel-header[contains(normalize-space(), 'User')]"
    user_domestic_label = "//span[contains(text(), 'Domestic')]"
    user_actions_radio = "//mat-radio-button[contains(normalize-space(), '{value}')]"
    
    # IP Section - Domestic
    ip_section_header = "//mat-expansion-panel-header[contains(normalize-space(), 'IP')]"
    ip_domestic_label = "//span[contains(text(), 'Domestic')]"
    ip_actions_radio = "//mat-radio-button[contains(normalize-space(), '{value}')]"
    
    # Buttons
    proceed_button = "//button[contains(normalize-space(), 'Proceed')]"
    save_button = "//button[@id='saveRiskProfileButton']"
    edit_button = "//button[contains(normalize-space(), 'Edit')]"
    back_button = "//button[contains(normalize-space(), 'Back')]"
    
    # Messages
    success_message = "//div[contains(@class, 'alert') and contains(@class, 'success')]"
    
    # Search/Filter
    search_risk_profile_name_input = "input#mat-input-5"
    search_currency_input = "//input[@placeholder='Search by Currency']"
    mode_dropdown = "//mat-select[@formcontrolname='mode']"
    search_button = "//button"
    # Risk Profile Listing
    def risk_profile_row_by_name(self, name: str) -> str:
        return f"//tr[td[contains(normalize-space(), '{name}')]]"
    
    risk_profile_name_link = "//*[contains(@name, 'riskProfileName')]"
    delete_icon = "//button[contains(@class, 'delete')]"
    
    # Risk Profile Summary/View Page
    breadcrumb = "//nav//span[contains(text(), '{value}')]"
    risk_profile_name_display = "//span[contains(text(), 'Risk profile name')]/following-sibling::span"
    currency_display = "cl-autocomplete[id*='currency']"
    international_transactions_display = "//span[contains(text(), 'Enable international transactions')]/following-sibling::span"
    terminal_section_display = "//div[contains(normalize-space(), 'Terminal')]"
    user_section_display = "//div[contains(normalize-space(), 'User')]"
    ip_section_display = "//div[contains(normalize-space(), 'IP')]"
    
    # Input fields for dynamic sections (using index/positioning within sections)
    no_of_transactions_daily_input = "//input[@formcontrolname='maxTransactionsDaily']"
    no_of_transactions_weekly_input = "//input[@formcontrolname='maxTransactionsWeekly']"
    no_of_transactions_monthly_input = "//input[@formcontrolname='maxTransactionsMonthly']"
    cumulative_amount_daily_input = "//input[@formcontrolname='cumulativeAmountDaily']"
    cumulative_amount_weekly_input = "//input[@formcontrolname='cumulativeAmountWeekly']"
    cumulative_amount_monthly_input = "//input[@formcontrolname='cumulativeAmountMonthly']"
    cumulative_refund_daily_input = "//input[@formcontrolname='cumulativeRefundDaily']"
    cumulative_refund_weekly_input = "//input[@formcontrolname='cumulativeRefundWeekly']"
    cumulative_refund_monthly_input = "//input[@formcontrolname='cumulativeRefundMonthly']"
    
    user_max_transactions_daily_input = "//input[@formcontrolname='userMaxTransactionsDaily']"
    user_max_transactions_weekly_input = "//input[@formcontrolname='userMaxTransactionsWeekly']"
    user_max_transactions_monthly_input = "//input[@formcontrolname='userMaxTransactionsMonthly']"
    user_cumulative_amount_daily_input = "//input[@formcontrolname='userCumulativeAmountDaily']"
    user_cumulative_amount_weekly_input = "//input[@formcontrolname='userCumulativeAmountWeekly']"
    user_cumulative_amount_monthly_input = "//input[@formcontrolname='userCumulativeAmountMonthly']"
    user_cumulative_refund_daily_input = "//input[@formcontrolname='userCumulativeRefundDaily']"
    user_cumulative_refund_weekly_input = "//input[@formcontrolname='userCumulativeRefundWeekly']"
    user_cumulative_refund_monthly_input = "//input[@formcontrolname='userCumulativeRefundMonthly']"
    
    ip_max_transactions_daily_input = "//input[@formcontrolname='ipMaxTransactionsDaily']"
    ip_max_transactions_weekly_input = "//input[@formcontrolname='ipMaxTransactionsWeekly']"
    ip_max_transactions_monthly_input = "//input[@formcontrolname='ipMaxTransactionsMonthly']"
    ip_cumulative_amount_daily_input = "//input[@formcontrolname='ipCumulativeAmountDaily']"
    ip_cumulative_amount_weekly_input = "//input[@formcontrolname='ipCumulativeAmountWeekly']"
    ip_cumulative_amount_monthly_input = "//input[@formcontrolname='ipCumulativeAmountMonthly']"
    
    # Confirmation Dialog
    confirmation_dialog = "//div[@role='dialog']"
    confirmation_message = "//div[@role='dialog']//p[contains(text(), '{value}')]"
    confirmation_yes_button = "//div[@role='dialog']//button[contains(normalize-space(), 'Yes')]"
    confirmation_cancel_button = "//div[@role='dialog']//button[contains(normalize-space(), 'Cancel')]"
    
    # No records found message
    no_records_message = "//p[contains(text(), 'No records found')]"
