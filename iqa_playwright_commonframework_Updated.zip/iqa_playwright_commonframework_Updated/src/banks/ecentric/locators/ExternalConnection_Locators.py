class EcentricExternalConnectionLocators:
 
    menu_administration = "div.cl-vertical-navigation-item-title-wrapper:has(mat-label:text-is('Administration'))"
    menu_routing_configuration = "div.cl-vertical-navigation-item-title-wrapper:has(mat-label:text-is('Routing Configuration'))"
    menu_setup_routing_plan = "a[href*='setup-routing-plan-landing']"
    page_marker = "span.mat-mdc-tooltip-trigger:text-is('Set up routing plan')"
    tab_external_connections = "span.mat-mdc-tooltip-trigger:text-is('External connections')"
    add_button = "button:has-text('Add')"
    external_connection_name_field = ".mat-mdc-form-field:has-text('External connection name') input"
    protocol_field = ".mat-mdc-form-field:has-text('Protocol') mat-select"
    protocol_option_https = "mat-option:has-text('HTTPS')"
    protocol_option_goconnect = "mat-option:has-text('Go-connect')"
    timeout_field = ".mat-mdc-form-field:has-text('Timeout') input"
    retry_attempts_field = ".mat-mdc-form-field:has-text('Retry attempts') input"
    url_field = ".mat-mdc-form-field:has-text('URL') input"
 
    method_type_post = "mat-radio-button:has-text('Post')"
    method_type_get = "mat-radio-button:has-text('Get')"
 
    goconnect_connection_name_field = ".mat-mdc-form-field:has-text('Connection name') mat-select"
    goconnect_connection_option_template = "mat-option:has-text('{value}')"  # .format(value=...) in page object
 
    save_button = "button:has-text('Save')"
    required_field_error = "text=This field is required"
 
   
    external_connections_table = "table"

    Authorization_entity = ".mat-mdc-form-field:has-text('Authorization entity') mat-select"
 
    # Authorization_type = ".mat-mdc-form-field:has-text('Authorization type') mat-select"
    Authorization_type='//mat-label[normalize-space()="Authorization type"]/ancestor::mat-form-field//mat-select'
 

    content_type_field = ".mat-mdc-form-field:has-text('Context path') input"
    authentication_type_visa = "mat-option:has-text('Visa')"
    authentication_type_master = "mat-option:has-text('Master')"
    
    success_message='//*[@id="cdk-drop-list-2"]/tbody/tr[1]/td[1]/span'
    
    toast_message = "//div[contains(@class,'snackbar')]//mat-label"
    validation_error_message = "//mat-error"
    dummy_locator="//span[text()='External connection name']"
    
    message_container_Add="//*[contains(text(),'External connection have been configured successfully')]"
    message_container_Edit="//*[contains(text(),'External connection have been configured successfully')]"
    message_container_Delete="//*[contains(text(),'External connection details has been deleted.')]"
    
    
    # ------------------------------------------------------------------
    # List page: search / add / row actions
    # ------------------------------------------------------------------
    SEARCH_INPUT = "//input[@placeholder='Search...']"
    SEARCH_BUTTON = "//button[normalize-space(.)='Search']"
    ADD_BUTTON = "//button[contains(.,'Add')]"

    # ------------------------------------------------------------------
    # Landing page: tabs, empty state, table headers (TC-AEC-035 to 045)
    # ------------------------------------------------------------------
    EXTERNAL_CONNECTIONS_TAB = "//div[normalize-space(.)='External connections']"
    ROUTING_PLAN_TAB = "//a[normalize-space(.)='Setup routing plan'] | //div[normalize-space(.)='Set up Routing Plan']"
    EMPTY_STATE_MESSAGE = "//*[contains(text(),'There are no connections yet')]"
    TABLE_HEADER_ROW = "//table//thead//tr | //div[contains(@class,'table-header')]"

    ALL_TABLE_ROWS = "//table//tbody//tr"

    def table_header_cell(self, header_text: str) -> str:
        return f"//table//th[normalize-space(.)='{header_text}']"

    def row_by_connection_name(connection_name: str) -> str:
        return f"//tr[.//td[normalize-space(text())='{connection_name}']]"
    
    
    edit_button='//cl-icon[@id="iconEdit"]'
    
    

    def edit_icon_for_row(self, connection_name: str) -> str:
        return self.row_by_connection_name(connection_name) + "//*[@id='iconEdit']"

    def delete_icon_for_row(self, connection_name: str) -> str:
        return self.row_by_connection_name(connection_name) + "//mat-icon[normalize-space(text())='delete']"

    # ------------------------------------------------------------------
    # Delete confirmation dialog
    # ------------------------------------------------------------------
    delete_button='//cl-icon[@id="iconDelete"]'
    delete_yes_dialog_handle='//span[text()=" Yes "]'
    delete_cancel_dialog_handle='//span[text()=" Cancel "]'

    # ------------------------------------------------------------------========================================
    # ===========================================================================================================
    
    
        # Navigation menu locators
    setup_routing_plan_menu = "//span[contains(text(),'Set up routing plan')]"
    
    # List page locators
    setup_add_button="//*[contains(text(),'add_circle_outline')]"
    search_field = "//input[@placeholder='Search' or contains(@aria-label, 'Search')]"
    search_button = "//button[contains(text(),'Search')]"
    
    # Form field locators - Add/Edit
    routing_plan_name_input = "//input[@id=//label[contains(., 'Routing plan name')]/@for]"
    auto_bin_routing_yes='(//*[contains(.,"Auto BIN routing")]//input[@type="radio" and @value="1"])[1]'
    auto_bin_routing_no = '(//*[contains(.,"Auto BIN routing")]//input[@type="radio" and @value="0"])[1]'
    activate_this_plan_yes='(//*[contains(.,"Activate this plan")]//input[@type="radio" and @value="ACTIVE"])[1]'
    activate_this_plan_no = '(//*[contains(.,"Activate this plan")]//input[@type="radio" and @value="INACTIVE"])[1]'
    file_upload="//input[@type='file']"
    rounting_save_button="//div[text()='Save']"
    external_connection_id_dropdown = "(//mat-select[@role='combobox'])[1]"
    external_connection_id_dropdown2="(//mat-label[contains(.,'External connection ID')]/ancestor::mat-form-field//mat-select)[2]"
    add_connection="//*[text()='Add connection']"
    on_us_routing_yes = '(//*[contains(.,"Auto BIN routing")]//input[@type="radio" and @value="1"])[2]'
    on_us_routing_no = '(//*[contains(.,"Auto BIN routing")]//input[@type="radio" and @value="0"])[2]'
    scheme_routing_dropdown = "(//mat-select[@role='combobox'])[2]"
    card_type_dropdown = "(//mat-select[@role='combobox'])[3]"
    
    # Buttons
    add_connection_button = "//button[contains(text(),'Add connection')]"
    # save_button1 = "//button[contains(text(),'Save')]"
    cancel_button = "//button[contains(text(),'Cancel')]"
    
    # Success/Error message locators
    success_message = "//div[contains(@class,'success') or contains(@class,'mat-snack-bar-container')]//span[contains(text(),'Routing plan have been configured successfully')]"
    error_message = "//mat-error[contains(text(),'required') or contains(text(),'already exists')]"
    
    # List page action buttons (per-row)
    edit_button_template = "//tr[td[contains(normalize-space(text()),'{value}')]]//button[contains(@aria-label,'edit') or .//mat-icon[contains(text(),'edit')]]"
    delete_button_template = "//tr[td[contains(normalize-space(text()),'{value}')]]//button[contains(@aria-label,'delete') or .//mat-icon[contains(text(),'delete')]]"
    
    # Delete confirmation dialog
    delete_confirmation_dialog = "//div[contains(@class,'mat-mdc-dialog-container')]"
    delete_confirmation_message = "//div[contains(text(),'Are you sure you want to delete')]"
    delete_confirmation_yes = "//button[contains(text(),'Yes')]"
    delete_confirmation_cancel = "//button[contains(text(),'Cancel')]"
    delete_success_message = "//div[contains(@class,'success') or contains(@class,'mat-snack-bar-container')]//span[contains(text(),'Routing plan have been deleted successfully')]"



    
