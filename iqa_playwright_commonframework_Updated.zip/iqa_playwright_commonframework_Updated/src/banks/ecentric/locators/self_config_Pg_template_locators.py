class SelfconfigurationLocators:
        #------API dashboard locators to verify dashboard visible or not------#
    upload_logo_label = "//span[normalize-space()='Upload logo']"
    terminal_id_label = "//span[normalize-space()='Terminal ID']"
    choose_color_label = "//span[normalize-space()='Choose color']"
    select_template_label = "//span[normalize-space()='Select template']"
    select_language_label = "//span[normalize-space()='Select language']"
    #-----------------------preview page dashboard--------------#
    add_new_card_label = "//span[normalize-space()='Add new card']"
    order_summary_label = "//span[normalize-space()='Order summary']"
    credit_debit_card = "//span[normalize-space()='Credit/Debit card']"
    credit_debit_subtitle = "(//span[normalize-space()='Choose your Debit/Credit card'])[1]"
    net_banking = "//span[normalize-space()='Net banking']"
    upi = "//span[normalize-space()='UPI']"
    wallet = "//span[normalize-space()='Wallet']"
    emi = "//span[normalize-space()='EMI']"
    preview_logo = "//img[@id='templateImagePreviewProperties']"
    pay_now_button = "//button[@id='button16']"
    cancel_button = "//button[@id='button17']"
    card_number_field = "//input[@placeholder='0000 0000 0000 0000']"
    cvv_field = "//input[@placeholder='000']"
    card_holder_name_field = "//input[@placeholder=\"Enter card holder's name\"]"
    expiry_field = "//input[@placeholder='MM/YY']"
    save_card_checkbox = "//input[@id='checkbox12-input']"
    total_price_label = "//span[normalize-space()='Total price']"
    shipping_charges_label = "//span[normalize-space()='Shipping charges']"
    total_label = "//span[normalize-space()='Total']"
    #-----------------------------------------------------------------#
    toast_message = "//cl-toast//mat-label"
    file_upload_error = "//mat-label[contains(@class,'text-warn')]"
    unhide_menu="//div[contains(@class,'cursor-pointer')][.//mat-icon[@data-mat-icon-name='bars-3']]"
    my_account_menu="//a[contains(@class,'cl-vertical-navigation-item') and .//mat-label[normalize-space()='My account']]"
    self_configuration="//span[normalize-space()='Self configuration']"
    preview_button = "//button[@id='templatePreviewButton']"
    push_live_button = "//div[normalize-space()='Push to live']/ancestor::button"
    back_to_edit_button = "//button[contains(.,'Back to edit')]"
    confirm_button = "//button[.//span[normalize-space()='Confirm']]"
    upload_logo_input = "//input[@id='file-upload']"
    delete_logo_icon = "//mat-icon[@data-mat-icon-name='trash']"
    color_input = "//input[@colorpicker]"
    color_picker_popup = "//div[contains(@class,'color-picker') and contains(@class,'open')]"
    preview_header = "//div[@id='row_121']"
    language_dropdown = "//cl-multiselect[@id='paymentPageLanguageCodes']//mat-select"
    select_all_checkbox = "//mat-label[normalize-space()='Select All']/ancestor::mat-checkbox"
    select_all_checked = "//mat-label[normalize-space()='Select All']/ancestor::mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]"
    language_option = "//mat-option//mat-label[normalize-space()='{}']"
    template_dropdown = "//mat-form-field[@id='paymentPageTemplateCode']//mat-select"
    template_option = "//mat-option//span[normalize-space()='{}']"
    selected_template = "//mat-form-field[@id='paymentPageTemplateCode']//span[contains(@class,'mat-mdc-select-min-line')]"
    terminal_dropdown = "(//mat-select[contains(@class,'cl-mat-select')])[1]"
    terminal_option = "//mat-option//mat-label[normalize-space()='{}']"






    


