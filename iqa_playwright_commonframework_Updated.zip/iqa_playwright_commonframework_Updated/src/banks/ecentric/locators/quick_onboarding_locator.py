class QuickOnboardingLocator:
    menu_sidebar = '//div[contains(@class,"cursor-pointer")]//mat-icon[@data-mat-icon-name="bars-3"]'
    onboarding_menu = '(//*[normalize-space()="Onboarding"])[1]'
    quick_onboarding_menu = '(//*[normalize-space()="Quick onboarding"])[1]'
    
    new_card_text='(//span[normalize-space()="New"])[1]'
    pending_card_text='(//span[normalize-space()="Final approval pending"])[1]'
    rejected_card_text='(//span[normalize-space()="Rejected"])[1]'
    approved_card_text='(//span[normalize-space()="Approved"])[1]'
    application_no='//div[normalize-space()="Application no"]'
    business_name='//mat-label[normalize-space()="Business name"]'
    contact_person='//div[normalize-space()="Contact person"]'
    updated_on='//div[normalize-space()="Updated on"]'
    reviewer='//div[normalize-space()="Reviewer"]'
    application_status='//div[normalize-space()="Application status"]'
    search_button='(//div[normalize-space()="Search"])[1]'
    
    # Landing page locators
    search_textbox="//input[@placeholder='Search']"
    result_table_rows = "tbody tr"
    result_table_cells = "td"
    no_matching_records = "//*[contains(normalize-space(), 'No matching records found') and not(.//*[contains(normalize-space(), 'No matching records found')])]"
    updated_on_dropdown='//span[normalize-space()="Updated on:"]'
    application_status_dropdown='//span[normalize-space()="Application status:"]'

    add_button = '//button[contains(., "Add") or @id="button42"]'
    contact_name = '//span[text()="Contact name"]'
    assert_contact_name_error = "//cl-input[@id='contactName']//mat-error"
    assert_business_name_error = "//cl-input[@id='businessName']//mat-error"
    assert_merchant_id_error = "//cl-input[@id='merchantID']//mat-error"
    assert_mobile_number_error = "//cl-contact-input[@id='mobileNumber']//mat-error"
    assert_email_error = "//cl-input[@id='email']//mat-error"
    
    business_name = ('//mat-label[normalize-space()="Business name"]/ancestor::mat-form-field//input')
    merchant_id = ('//mat-label[normalize-space()="Merchant ID"]/ancestor::mat-form-field//input')
    mcc_description_dropdown = "#mat-select-value-4"
    mobile_number = ('//mat-label[normalize-space()="Mobile number"]/ancestor::mat-form-field//input')
    email = '//mat-label[normalize-space()="Email"]/ancestor::mat-form-field//input'
    organization_name='//mat-label[normalize-space()="Organization name"]/ancestor::mat-form-field//mat-select'
    save_basic_info_button = '//button[@id="saveOnboardingBasicInformation"]'
    assert_save_basic_info_success = '//mat-snack-bar-container'
    
    assert_merchant_legal_name="//cl-input[@id='merchantLegalName']//mat-error"
    assert_website_address="//cl-input[@id='websiteAddress']//mat-error"
    assert_office_address="//cl-textarea[@id='merchantAddress']//mat-error"
    assert_postal_code="//cl-input[@id='zipcode']//mat-error"
    
    merchant_legal_name = '//mat-label[normalize-space()="Merchant legal name"]/ancestor::mat-form-field//input'
    business_info_website_address = '//mat-label[normalize-space()="Website address"]/ancestor::mat-form-field//input'
    incorporation_status = '//mat-label[normalize-space()="Incorporation status"]/ancestor::mat-form-field//mat-select'
    office_address = '//mat-label[normalize-space()="Office address"]/ancestor::mat-form-field//textarea'
    postal_code = '//mat-label[normalize-space()="Postal code"]/ancestor::mat-form-field//input'
    country = '//mat-label[normalize-space()="Country"]/ancestor::mat-form-field//mat-select'
    state_province = '//mat-label[normalize-space()="State/Province"]/ancestor::mat-form-field//mat-select'
    city = '//*[normalize-space()="City"]/ancestor::mat-form-field'
    country_of_origin = '//mat-label[normalize-space()="Country of origin"]/ancestor::mat-form-field//mat-select'
    save_business_info_button = '//button[@id="saveBusinessInfo"]'
    
    assert_store_id="//cl-input[@id='storeId']//mat-error"
    assert_website_address="//cl-input[@id='websiteAddress']//mat-error"
    assert_store_email_id="//cl-input[@id='storeEmailId']//mat-error"
    assert_store_contact="//cl-contact-input[@id='storeContactNo']//mat-error"
    assert_store_address="//cl-textarea[@id='storeAddress']//mat-error"
    
    store_id = "//mat-label[normalize-space()='Store ID']/ancestor::mat-form-field//input"
    store_type_offline = '//input[@type="radio" and @value="Offline"]'
    store_type_online = '//input[@type="radio" and @value="Online"]'
    store_website_address = '(//label[contains(.,"Website address")]/ancestor::mat-form-field//input)[2]'
    number_of_terminals_allocated = '//mat-label[normalize-space()="Number of terminals allowed"]/ancestor::mat-form-field//input'
    store_name = '//div[contains(.,"Store 1")]//mat-label[contains(normalize-space(),"Store name")]/ancestor::mat-form-field//input'
    store_email_id = '//div[contains(.,"Store 1")]//mat-label[contains(normalize-space(),"Store email ID")]/ancestor::mat-form-field//input'
    store_contact_number = '//div[contains(.,"Store 1")]//mat-label[contains(normalize-space(),"Merchant customer service number")]/ancestor::mat-form-field//input'
    save_store_details_button = '//button[@id="saveOnboardingStoreDetails"]'
    store_address='//mat-label[normalize-space()="Store address"]/ancestor::mat-form-field//textarea'
    
    assert_terminal_id="//cl-input[@id='terminalId']//mat-error"
    assert_terminal_name="//cl-input[@id='terminalName']//mat-error"
    assert_mrch_auth_url="//cl-input[@id='merchantAuthUrl']//mat-error"

    assert_cardCaptureScreenExpiryTime="//cl-input[@id='cardCaptureScreenExpiryTime']//mat-error"
    assert_keyExpiryPeriodInDay="//cl-input[@id='keyExpiryPeriodInDay']//mat-error"
    
    service_type = '//mat-label[normalize-space()="Service type"]/ancestor::mat-form-field//mat-select'
    authentication_service_provider = '//mat-label[normalize-space()="Authentication service provider"]/ancestor::mat-form-field//mat-select'
    integration_method = '//mat-label[normalize-space()="Integration methods"]/ancestor::mat-form-field//mat-select'
    terminal_id = '//mat-label[normalize-space()="Terminal ID"]/ancestor::mat-form-field//input'
    terminal_name = '//mat-label[contains(normalize-space(),"Terminal name")]/ancestor::mat-form-field//input'
    select_store_to_add = '//mat-label[normalize-space()="Select a store to add"]/ancestor::mat-form-field//mat-select'
    merchant_auth_url = '//mat-label[normalize-space()="Merchant Auth URL"]/ancestor::mat-form-field//input'
    status_active = '//input[@type="radio" and @value="Active"]'
    status_inactive = "//input[@type='radio' and @value='Inactive']"
    payment_gateway = '//mat-label[normalize-space()="Payment gateway"]/ancestor::mat-form-field//mat-select'
    accepted_scheme_brands = '//mat-label[normalize-space()="Accepted scheme brands"]/ancestor::mat-form-field//mat-select'
    accepted_transaction_types = '//mat-label[normalize-space()="Accepted transaction types"]/ancestor::mat-form-field//mat-select'
    permitted_acquiring_currency = '//mat-label[normalize-space()="Permitted acquiring currency"]/ancestor::mat-form-field//mat-select'
    accepted_payment_methods = '//mat-label[normalize-space()="Accepted payment methods"]/ancestor::mat-form-field//mat-select'
    transaction_via_base_24_yes = '(//div[contains(.,"Transaction via base24")]//input[@type="radio" and @value="Yes"])[1]'
    transaction_via_base_24_no = '(//div[contains(.,"Transaction via base24")]//input[@type="radio" and @value="No"])[1]'
    acquirer_institution_id = '//mat-label[normalize-space()="Acquirer institution ID"]/ancestor::mat-form-field//input'
    terminal_data = '//mat-label[normalize-space()="Terminal data"]/ancestor::mat-form-field//input'
    retailer_id = '//mat-label[normalize-space()="Retailer ID"]/ancestor::mat-form-field//input'
    retailer_group = '//mat-label[normalize-space()="Retailer group"]/ancestor::mat-form-field//input'
    retailer_region = '//mat-label[normalize-space()="Retailer region"]/ancestor::mat-form-field//input'
    routing_plan = '//mat-label[normalize-space()="Routing plan"]/ancestor::mat-form-field//mat-select'
    payment_page_template = '//mat-label[normalize-space()="Payment page template"]/ancestor::mat-form-field//mat-select'
    merchant_acquiring_bank = '//mat-label[normalize-space()="Merchant acquiring bank"]/ancestor::mat-form-field//mat-select'
    merchant_terms_and_conditions_url = '//mat-label[normalize-space()="Merchant terms and conditions URL"]/ancestor::mat-form-field//input'
    enable_risk_yes='(//*[contains(.,"Enable risk")]//input[@type="radio" and @value="Yes"])[2]'
    enable_risk_no='(//*[contains(.,"Enable risk")]//input[@type="radio" and @value="No"])[2]'

    view_update_settings = '//div[contains(text(), "View/update settings")]'
    multiple_refund_yes='(//*[contains(.,"Multiple refunds")]//input[@type="radio" and @value="Yes"])[4]'
    multiple_refund_no='(//*[contains(.,"Multiple refunds")]//input[@type="radio" and @value="No"])[4]'
    card_capture_screen_expiry_time='//mat-label[normalize-space()="Card capture screen expiry time"]/ancestor::mat-form-field//input'
    page_time_out='//mat-label[normalize-space()="Page time out"]/ancestor::mat-form-field//input'
    key_expiry_period_no = '(//*[contains(.,"Key expiry period")]//input[@type="radio" and @value="No"])[8]'
    key_expiry_period_yes = '(//*[contains(.,"Key expiry period")]//input[@type="radio" and @value="Yes"])[8]'
    expiry_period = '//mat-label[normalize-space()="Expiry period"]/ancestor::mat-form-field//input'
    enable_international_transactions_no = '(//*[contains(.,"Enable international transactions")]//input[@type="radio" and @value="No"])[10]'
    enable_international_transactions_yes = '(//*[contains(.,"Enable international transactions")]//input[@type="radio" and @value="Yes"])[10]'
    message_type = '//mat-label[normalize-space()="Message type"]/ancestor::mat-form-field//mat-select'
    recon_file_required_yes = '(//*[contains(.,"Recon file required")]//input[@type="radio" and @value="Yes"])[11]'
    recon_file_required_no = '(//*[contains(.,"Recon file required")]//input[@type="radio" and @value="No"])[11]'
    merchant_markoff_file_required_yes = '(//*[contains(.,"Merchant mark off file required")]//input[@type="radio" and @value="Yes"])[12]'
    merchant_markoff_file_required_no = '(//*[contains(.,"Merchant mark off file required")]//input[@type="radio" and @value="No"])[12]'
    success_failure_page_no = '(//*[contains(.,"Success/Failure page")]//input[@type="radio" and @value="No"])[14]'
    success_failure_page_yes = '(//*[contains(.,"Success/Failure page")]//input[@type="radio" and @value="Yes"])[14]'
    enable_webhook_yes = '(//*[contains(.,"Enable Webhook")]//input[@type="radio" and @value="Yes"])[16]'
    enable_webhook_no = '(//*[contains(.,"Enable Webhook")]//input[@type="radio" and @value="No"])[16]'
    subscription_refund_reversal_allowed_yes = '(//*[contains(.,"Subscription refund and reversal allowed")]//input[@type="radio" and @value="Yes"])[21]'
    subscription_refund_reversal_allowed_no = '(//*[contains(.,"Subscription refund and reversal allowed")]//input[@type="radio" and @value="No"])[21]'
    additional_settings_save_button = "//button[@id='saveTerminalAdditionalConfigButton']"
    save_terminal_details_button = '//button[@id="saveOnboardingTerminalDetailsSubmit"]'