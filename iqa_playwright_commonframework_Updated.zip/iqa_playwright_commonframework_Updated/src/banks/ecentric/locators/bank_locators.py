class BankLocators:
    # Navigation
    administration_menu = "//span[contains(text(),'Administration')]"
    bin_management_submenu = "//span[contains(text(),'Bin Management')]"
    
    # Add Form
    add_button = "//button[contains(text(),'Add')]"
    bin_input = "//input[@placeholder='Enter BIN']"
    bin_low_range_input = "//input[@placeholder='Low Range']"
    bin_high_range_input = "//input[@placeholder='High Range']"
    interchange_code_dropdown = "//select[@name='interchangeCode']"
    card_type_dropdown = "//select[@name='cardType']"
    card_product_dropdown = "//select[@name='cardProduct']"
    country_dropdown = "//select[@name='country']"
    acquiring_type_dropdown = "//select[@name='acquiringType']"
    message_type_dropdown = "//select[@name='messageType']"
    bin_status_dropdown = "//select[@name='binStatus']"
    send_for_approval_button = "//button[contains(text(),'Send for Approval')]"
    
    # Search/List
    search_bin_field = "//input[@placeholder='Search BIN']"
    search_button = "//button[contains(text(),'Search')]"
    
    # List table
    @staticmethod
    def row_by_bin(bin_value):
        return f"//tr[td[contains(normalize-space(text()),'{bin_value}')]]"
    
    expand_icon = "//button[contains(@class,'expand')]"
    view_link = ".//a[contains(text(),'View')]"
    edit_button = "//button[contains(text(),'Edit')]"
    delete_icon = "//button[contains(@class,'delete')]"
    
    # Details page
    bin_display = "//div[@class='bin-display']"
    bin_low_range_display = "//div[@class='bin-low-range-display']"
    bin_high_range_display = "//div[@class='bin-high-range-display']"
    interchange_code_display = "//div[@class='interchange-code-display']"
    card_type_display = "//div[@class='card-type-display']"
    card_product_display = "//div[@class='card-product-display']"
    country_display = "//div[@class='country-display']"
    acquiring_type_display = "//div[@class='acquiring-type-display']"
    message_type_display = "//div[@class='message-type-display']"
    bin_status_display = "//div[@class='bin-status-display']"
    
    # Request History
    request_history_table = "//table[@class='request-history-table']"
    request_history_row_by_type_status = lambda request_type, status: f"//tr[td[contains(text(),'{request_type}')] and td[contains(text(),'{status}')]]"
    
    # Confirmation dialog
    confirmation_dialog = "//div[@role='dialog']"
    confirmation_send_for_approval_button = "//button[contains(text(),'Send for Approval')]"
    
    # Messages
    success_message = "//div[@class='success-message']"
    validation_error_message = "//div[@class='error-message']"
