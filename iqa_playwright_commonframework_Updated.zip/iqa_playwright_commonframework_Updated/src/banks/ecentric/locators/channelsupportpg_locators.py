class ChannelsupportpgLocators:
    # Navigation
    menu_administration = "//mat-label[contains(text(),'Administration')]"
    menu_pg_configuration = "//mat-label[contains(text(),'PG configuration')]"
    
    # Channel Support - PG page
    channel_support_pg_tile = "//div[contains(text(),'Channel support - PG')]"
    
    # Stepper
    stepper_primary = "//span[contains(text(),'Primary')]"
    stepper_terminal_configurations = "//span[contains(text(),'Terminal configurations')]"
    stepper_merchant_services = "//span[contains(text(),'Merchant services')]"
    
    # Step 1: Primary
    api_dropdown = "//mat-select[@formcontrolname='api']"
    api_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    hosted_payment_page_dropdown = "//mat-select[@formcontrolname='hostedPaymentPage']"
    hosted_payment_page_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    card_masking_dropdown = "//mat-select[@formcontrolname='cardMasking']"
    card_masking_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    gateway_users_allowed_input = "//input[@formcontrolname='gatewayUsersAllowed']"
    
    # MPGS Integration Section
    mpgs_url_input = "//input[@formcontrolname='mpgsUrl']"
    mpgs_version_input = "//input[@formcontrolname='mpgsVersion']"
    
    # Cybersource Integration Section
    cybersource_api_url_input = "//input[@formcontrolname='cybersourceApiUrl']"
    cybersource_auth_url_input = "//input[@formcontrolname='cybersourceAuthUrl']"
    
    # Step 1 Continue Button
    step1_continue_button = "//button[contains(normalize-space(), 'Continue')]"
    
    # Step 1 Success Message
    step1_success_message = "//mat-error[contains(normalize-space(), 'Primary Saved successfully')]"
    
    # Step 2: Terminal Configurations
    merchant_users_allowed_input = "//input[@formcontrolname='merchantUsersAllowed']"
    
    merchant_url_auth_dropdown = "//mat-select[@formcontrolname='merchantUrlAuth']"
    merchant_url_auth_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    international_transactions_dropdown = "//mat-select[@formcontrolname='internationalTransactions']"
    international_transactions_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    multiple_refunds_dropdown = "//mat-select[@formcontrolname='multipleRefunds']"
    multiple_refunds_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    refunds_reversal_dropdown = "//mat-select[@formcontrolname='refundsReversal']"
    refunds_reversal_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    card_capture_expiry_input = "//input[@formcontrolname='cardCaptureExpiry']"
    
    success_failure_page_dropdown = "//mat-select[@formcontrolname='successFailurePage']"
    success_failure_page_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    page_timeout_input = "//input[@formcontrolname='pageTimeout']"
    
    automatic_key_expiry_dropdown = "//mat-select[@formcontrolname='automaticKeyExpiry']"
    automatic_key_expiry_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    expiry_period_input = "//input[@formcontrolname='expiryPeriod']"
    
    # Step 2 Continue Button
    step2_continue_button = "//button[contains(normalize-space(), 'Continue')]"
    
    # Step 2 Success Message
    step2_success_message = "//mat-error[contains(normalize-space(), 'Terminal Config saved successfully')]"
    
    # Step 3: Merchant Services
    enable_webstore_dropdown = "//mat-select[@formcontrolname='enableWebstore']"
    enable_webstore_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    enable_webhook_dropdown = "//mat-select[@formcontrolname='enableWebhook']"
    enable_webhook_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    enable_payment_button_dropdown = "button[aria-haspopup='menu'][class*='mat-mdc-menu-trigger']"
    enable_payment_button_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    enable_payment_link_dropdown = "//mat-select[@formcontrolname='enablePaymentLink']"
    enable_payment_link_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    enable_multiple_terminal_dropdown = "//mat-select[@formcontrolname='enableMultipleTerminal']"
    enable_multiple_terminal_option = "//mat-option[contains(normalize-space(.), '{value}')]"
    
    max_terminals_input = "//input[@formcontrolname='maxTerminals']"
    
    # Step 3 Continue Button
    step3_continue_button = "//button[contains(normalize-space(), 'Continue')]"
    
    # Step 3 Success Message (generic success for completion)
    step3_success_message = "//mat-error[contains(normalize-space(), 'saved successfully')]"
    
    # Page marker for verification
    page_marker = "//div[contains(text(),'Channel support')]"
