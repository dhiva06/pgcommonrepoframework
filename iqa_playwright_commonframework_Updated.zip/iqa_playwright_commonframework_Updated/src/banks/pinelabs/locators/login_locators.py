class PinelabsLoginLocators:
    class Admin:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "input[id='adminuserId']"
        password_field = "input[id='adminpassword']"
        submit_button = "input[value='Submit']"
        dashboard_marker = "//li[contains(text(),'Welcome')]"
        already_logged_in_text = "User already logged in"
        error_message = "#adminLoginError"

    class Bank:
        institution_field = "input[name='instId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"
        error_message = "#bankLoginError"
        dashboard_marker = "#bankDashboard"

    class Merchant:
        institution_name_field = "input[name='instId']"
        merchant_id_field = "input[name='merchantId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"
        error_message = "#merchantLoginError"
        dashboard_marker = "#merchantDashboard"
