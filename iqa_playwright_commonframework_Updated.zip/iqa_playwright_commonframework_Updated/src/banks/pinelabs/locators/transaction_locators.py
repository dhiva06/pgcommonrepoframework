class PinelabsTransactionLocators:
    class Hosted_TXN:
        click_buy_button = "//input[@value='Buy']"
        amount = "//input[@name='amount']"
        card_number = "//input[@id='creditCardNumber']"
        cardholder_name = "//input[@id='creditCardholderName']"
        expiry_date = "//input[@id='creditExpiry']"
        cvv = "//input[@id='cardCvv']"
        pay_button = "//button[@id='payBtn']"
        OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'
        ActualStatus = "//td[contains(text(),'Transaction Status')]/following-sibling::td"
        ACTION_DROPDOWN = 'select[name="action"]'
        UDF5_DROPDOWN = 'select[name="udf5"]'
        COMMENT_FIELD = 'input[name="comment"]'
        # CTP Login Locators
        ctp_mobile_input = '//*[@id="ctp-email-mobile-input"]'
        ctp_email_input = '//*[@id="ctp-email-input"]'
        ctp_continue_btn = '//*[@id="ctp-continue-login-btn"]'