class NegativeIPLocators:
    # Negative IP
    risk_congiguration = '//*[@id="stUI45_txt"]'
    negative_IP = '//*[@id="stUI50_cnt"]'
    negative_IP_add_button = '//input[@name="add"]'
    negative_IP_field = '(//*[@id="ipAddress"])[1]'
    negative_IP_reason_field = '(//*[@id="reason"])[1]'
    negative_IP_save_button = '//*[@id="command"]/div[2]/div[3]/input[1]'
    page_marker = "//h4[contains(text(),'IP Block')]"
    message_container='(//div[contains(normalize-space(),"See the log to view the details")])[5]'
    validation_message = "//label[@class='must']"
    IP_addRow_button='//*[@id="ipblock[0]"]/span/input[1]'
    no_records_message = "//div[@align='center' and contains(@class,'alert-info')]"
    
    IP_textfeild1='(//*[@id="ipAddress"])[2]'
    ip_reasonfeild1='(//*[@id="reason"])[2]'
    IP_textfeild2='(//*[@id="ipAddress"])[3]'
    ip_reasonfeild2='(//*[@id="reason"])[3]'
    IP_textfeild3='/html/body/div[1]/div/div[2]/section/div[3]/form/div[2]/div[2]/div[7]/div[1]/div[1]/input'
    ip_reasonfeild3='/html/body/div[1]/div/div[2]/section/div[3]/form/div[2]/div[2]/div[7]/div[1]/div[2]/input'
    ip_dropdown='//*[@id="cuselFrame-columnName"]'
    dropdown_value='//div[@id="cusel-scroll-currencyCode"]/span[4]' 
    IP_search_textfeild='//*[@id="ipAddress1"]'
    search_button="//input[@value='Search']"
    Search_Assert_message='//*[@id="IPBlock"]/tbody/tr/td[2]'
    
   
    
    
