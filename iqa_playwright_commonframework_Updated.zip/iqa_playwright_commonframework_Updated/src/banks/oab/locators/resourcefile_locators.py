class ResourceFileLocators:
    
    Configuration="//span[@id='stUI12_txt']"
    generate_resource_file="//span[@id='stUI29_txt']"
    page_marker="//h4[normalize-space()='Generate Resource File']"
    click_merchant_file="//div[@class='cuselText']"
    generate_resource_file_button="//input[@value='Generate']"
    message_container='(//div[contains(normalize-space(),"Resource file generated successfully")])[5]'
    validation_message="//label[@class='must']"