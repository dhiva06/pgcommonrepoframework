class OabNegativeBinLocators:
    # Negative Bin
    risk_congiguration = '//*[@id="stUI45_txt"]'
    negative_bin = '//*[@id="stUI49_cnt"]'
    negative_Bin_add_button = '//input[@name="add"]'
    negative_Bin_field = '//*[@id="binNumber"]'
    negative_Bin_reason_field = '//*[@id="reason"]'
    negative_Bin_field1 = '(//*[@name="binNumber"])[2]'
    negative_Bin_reason_field1 = '(//*[@name="reason"])[2]'
    negative_Bin_field2 = '(//*[@name="binNumber"])[3]'
    negative_Bin_reason_field2 = '(//*[@name="reason"])[3]'
    
    negative_Bin_save_button = '//*[@id="command"]/div[2]/div[5]/input[1]'
    page_marker = "//label[contains(text(),'Enter Negative BIN Number')]"
    validation_message = "//label[@class='must']"
    bin_addRow_button='//*[@id="negativebin[0]"]/span[3]/input[1]'
    minus_button='//*[@id="negativebin[0]"]/span[3]/input[2]'
    message_container='(//div[contains(normalize-space(),"See the log to view the details")])[5]'
    
    file_upload="//input[@type='file']"
    upload_button="//input[@value='Upload']"
    sample_format_button="//input[@value='Sample Format']"
    x_click='//*[@id="fileFormat"]/div/div/div[1]/button/span[1]'
    Bin_search_textfeild="//input[@name='binNumber1']"
    search_button="//input[@value='Search']"
    row_template = "//tr[contains(normalize-space(),'{bin_value}')]"
    change_status_button="//input[@name='changeStatus']"
    
    
