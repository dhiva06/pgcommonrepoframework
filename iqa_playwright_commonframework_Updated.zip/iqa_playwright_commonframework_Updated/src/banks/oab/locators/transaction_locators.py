class OabTransactionLocators:
    class Hosted_TXN:
        click_buy_button = "//input[@value='Buy']"
        password_input = "#adminPassword"
        login_button = "#adminLoginBtn"
        error_message = "#adminLoginError"