class currencyLocators:

    menu_configuration = '//*[@id="stUI12_txt"]'
    menu_currency='//*[@id="stUI22_txt"]'
    add_button ='//input[@value="Add"]'
    currency_code_input='//*[@name="currCode"]'
    currency_description_input='//*[@name="currDesc"]'
    minor_digits_input='//*[@name="minorDigits"]'
    currency_symbol_input='//*[@name="currSymbol"]'
    Currency_save_button='//*[@value="Save"]'
    page_marker = "//a[contains(text(),'Currency Code')]"
    message_container="//div[contains(text(),'Created successfully')]"
    dashboard_marker="//span[text()='Logout']"
    validation_message = "//label[@class='must' and contains(text(),'{0}')]"
    
# --------------------------VIEW-----------------------------------
    @staticmethod
    def view_link_in_row(code: str) -> str:
        return f"//table[@id='curr']//tr[td[contains(normalize-space(text()),'{code}')]]//a[contains(text(),'View')]"
    
    back_button="//input[@value='Back']"
    navigate_to_next_page="//a[contains(@onclick, \"currPage('2')\")]"
    message_container_CC="//span[contains(text(),'512')]"
    
    
# --------------------------EDIT-----------------------------------

    @staticmethod
    def Edit_link_in_row(code: str) -> str:
        return f"//table[@id='curr']//tr[td[contains(normalize-space(text()),'{code}')]]//a[contains(text(),'Edit')]"
    
    message_container_Edit="//div[contains(text(),'Updated successfully')]"
    
    
# --------------------------CHANGE STATUS-----------------------------------

    @staticmethod
    def checkbox_in_row(code: str) -> str:
        return f"//table[@id='curr']//tr[td[contains(normalize-space(text()),'{code}')]]//input[@name='currCodes']/following-sibling::a[1]"
    
    change_status_button="//input[@value='Change Status']"
    
    message_container_ChangeStatus="//div[contains(text(),'Changed successfully')]"
    
    
    
    # message_container_NegativeCases="//label[contains(text(),'Should be numeric')]"
    message_container_NegativeCases="//label[contains(text(),'{expected_message}')]"
    


