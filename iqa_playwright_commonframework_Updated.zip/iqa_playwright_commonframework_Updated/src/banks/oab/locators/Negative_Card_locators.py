class OabNegativeCardLocators:
    # Negative Card
    risk_congiguration = '//*[@id="stUI45_txt"]'
    # risk_congiguration = '//*[@id="stUI46_txt"]'
    negative_card = '//*[@id="stUI48_txt"]'
    # negative_card = '//*[@id="stUI49_txt"]'
    negative_add_button = '//input[@name="add"]'
    negative_card_field = '//*[@id="cardNumber"]'
    negative_reason_field = '//*[@id="reason"]'
    negative_card_field1='(//*[@name="cardNumber"])[2]'
    negative_reason_field1='(//*[@name="reason"])[2]'
    negative_card_field2='(//*[@name="cardNumber"])[3]'
    negative_reason_field2='(//*[@name="reason"])[3]'
    negative_save_button= '//*[@id="command"]/div[2]/div[5]/div/input[1]'
    page_marker = "//label[contains(text(),'Negative Card Number')]"
    message_container='(//div[contains(normalize-space(),"See the log to view the details ")])[5]' 
    # or '(//div[contains(normalize-space(),"Please Upload Valid Text File")])[5]'
    IP_addRow_button='//*[@id="negativecard[0]"]/span[3]/input[1]'
    validation_message = "//label[@class='must']"
    file_upload="//input[@type='file']"
    upload_button="//input[@value='Upload']"
    message_container1='(//div[contains(normalize-space(),"Please Upload Valid Text File")])[5]'
    sample_format_button="//input[@value='Sample Format']"
    # x_click="(//span[text()='×'])[1]"
    x_click='//*[@id="fileFormat"]/div/div/div[1]/button/span[1]'
    SearchTextFeild="//input[@id='cardNumber1']"
    SearchButton="//input[@value='Search']"
    no_records_message="//div[@align='center']"