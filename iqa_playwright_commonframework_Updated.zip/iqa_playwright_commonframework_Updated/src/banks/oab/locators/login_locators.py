class OabLoginLocators:
    class Admin:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "//input[@id='adminuserId']"
        password_field = "//input[@id='adminpassword']"
        captcha_field = "#passline"
        captcha_image = "//img[@id='captcha_image']"
        captcha_error = "//*[@id='adminErrorMsgVal']/label/text()"
        captcha_refresh = "//img[@id='reload']"
        submit_button = "//input[@type='submit']"
        dashboard_marker = "//li[contains(text(),'Welcome')]"
        error_message = "#adminLoginError"
        

    class Merchant:
        login_button="//span[text()='Login']"
        merchant_id="//input[@id='mrchId']"
        username_field = "//input[@id='mrchuserId']"
        password_field = "//input[@id='mrchpassword']"
        captcha_field = "#passline"
        captcha_image = "//img[@id='captcha_image']"
        captcha_error = "//*[@id='adminErrorMsgVal']/label/text()"
        captcha_refresh = "//img[@id='reload']"
        submit_button = "//input[@type='submit']"

        
    class Bank:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "//input[@id='instuserId']"
        password_field = "//input[@id='instpassword']"
        captcha_field = "#passline"
        captcha_image = "//img[@id='captcha_image']"
        captcha_error = "//*[@id='adminErrorMsgVal']/label/text()"
        submit_button="//input[@type='submit']"
        logout_button="//span[contains(text(),'Logout')]"
        captcha_refresh = "//img[@id='reload']"
        


   
 
