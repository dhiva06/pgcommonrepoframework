class AlrajhiLoginLocators:
    class Admin:
        username_input = "#adminUsername"
        password_input = "#adminPassword"
        login_button = "#adminLoginBtn"
        error_message = "#adminLoginError"
        dashboard_marker = "#adminDashboard"
        otp_field = "#otpvalue"   # TODO: confirm real selector

    class Bank:
        institution_field = "input[name='instId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"
        error_message = "#bankLoginError"
        dashboard_marker = "#bankDashboard"
        otp_field = "#otpvalue"   # TODO: confirm real selector

    class Merchant:
        institution_name_field = "input[name='instId']"
        merchant_id_field = "input[name='merchantId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"
        error_message = "#merchantLoginError"
        dashboard_marker = "#merchantDashboard"
        otp_field = "#otpvalue"   # TODO: confirm real selector
