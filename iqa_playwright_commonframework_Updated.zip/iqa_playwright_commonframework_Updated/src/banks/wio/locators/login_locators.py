class WioLoginLocators:
    class Admin:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "input[id='adminuserId']"
        password_field = "input[id='adminpassword']"
        submit_button = "input[value='Submit']"
        dashboard_marker = "//li[contains(text(),'Welcome')]"
        already_logged_in_text = "User already logged in"
        logout_button = "//span[text()='Logout']"

    class Bank:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "input[id='instuserId']"
        password_field = "input[id='instpassword']"
        submit_button = "input[value='Submit']"
        dashboard_marker = "//li[contains(text(),'Welcome')]"
        already_logged_in_text = "User already logged in"

    class Hosted_TXN:
        institution_field = "input[name='instId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"

    class Merchant:
        base_url = "http://10.136.2.146:8320/RESTMerchantDemo/"
