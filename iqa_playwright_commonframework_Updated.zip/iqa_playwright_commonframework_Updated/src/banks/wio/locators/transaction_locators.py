class WioTransactionLocators:
    class Hosted_TXN:
        click_buy_button = "//input[@value='Buy']"
        amount = "//input[@name='amount']"
        card_number = "//input[@id='creditCardNumber']"
        cardholder_name = "//input[@id='creditCardholderName']"
        expiry_date = "//input[@id='creditExpiry']"
        cvv = "//input[@id='cardCvv']"
        pay_button = "//button[@id='payBtn']"
        OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'
        ActualStatus = "//td[contains(text(),'Transaction Status')]/following-sibling::td"
        ACTION_DROPDOWN = 'select[name="action"]'
        UDF5_DROPDOWN = 'select[name="udf5"]'
        COMMENT_FIELD = 'input[name="comment"]'
        mobilenumber = "//input[@name='udf6']"