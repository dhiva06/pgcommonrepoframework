"""
Thread-local helpers for injecting current-test context into the heal
pipeline without any global state pollution.

The challenge: when ``BasePage`` action methods run, they know which test
is executing, but the ``AutohealEngine`` is instantiated inside a pytest
fixture and has no natural access to ``request.node.name`` from there.

Two integration paths are supported:

1. **pytest (normal runs)**: ``conftest.py`` registers the running test name
   via ``set_current_test_name`` inside ``pytest_runtest_makereport``.
   The ``HealEngine`` reads it back via ``get_current_test_name()``.

2. **Standalone / ad-hoc runs**: the calling script (e.g. ``verify_autoheal.py``)
   calls ``set_current_test_name`` directly before running.
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Optional

from playwright.sync_api import Locator

_test_name_store: threading.local = threading.local()


def set_current_test_name(name: str) -> None:
    """Store the currently-running pytest test name in thread-local storage."""
    _test_name_store.test_name = name


def get_current_test_name() -> str:
    """Return the currently-running pytest test name, or ``"unknown"``."""
    return getattr(_test_name_store, "test_name", "unknown")


def try_gemini_heal(
    *,
    page,
    bank: str,
    description: str,
    action_type: str,
    broken_selector: str,
    engine,
    action_value: Optional[str] = None,
):
    """
    Bridge between ``BasePage._gemini_heal`` and ``AutohealEngine.try_heal``.

    Resolves the broken selector back to its source ``*_locators.py`` file
    and dotted attribute path via the global ``SelectorRegistry``, then
    delegates to the engine's full pipeline. Returns the healed
    Playwright ``Locator`` on success, or ``None`` on failure.

    Parameters
    ----------
    page:
        The active Playwright ``Page`` (unused here, but kept for API
        parity with the engine's other callers).
    bank:
        Current bank name (from ``ConfigManager``).
    description:
        Human-readable step name (e.g. "Buy button").
    action_type:
        ``click``, ``fill``, ``check``, ``select``, etc.
    broken_selector:
        The original XPath / CSS string that failed.
    engine:
        The cached ``AutohealEngine`` instance from ``BasePage``.
    action_value:
        For ``fill``-type actions, the text to use during validation.
    """
    from src.common.autoheal.selector_registry import GLOBAL_REGISTRY

    rec = GLOBAL_REGISTRY.lookup(broken_selector)
    if rec is None:
        return None

    file_path: Optional[Path] = rec.get("file")  # type: ignore[assignment]
    outer = rec.get("outer")
    inner = rec.get("inner")
    attr = rec.get("attr")
    if not file_path or not outer or not inner or not attr:
        return None

    attr_path = f"{outer}.{inner}.{attr}"
    test_name = get_current_test_name()

    return engine.try_heal(
        description=description,
        action_type=action_type,
        broken_selector=broken_selector,
        locators_file=file_path,
        attr_path=attr_path,
        test_name=test_name,
        bank=bank,
        action_value=action_value,
    )
