"""
Locate the source class attribute behind a Playwright Locator or selector string.

The page-object pattern in this project is:

    loc_class = SomeBankSomeModuleLocators.SomeInnerNamespace
    page.fill_by_locator(loc_class.some_attribute, "value", "label")

By the time `BasePage.fill_by_locator` runs, the only thing it sees is
either a CSS/XPath string or a Playwright ``Locator`` object. To support
the auto-heal flow, we need to know the original class + attribute name
that produced it. This module provides the reverse lookup.

The reverse-lookup uses the page object's already-loaded locator class
namespace(s). We try two strategies:

1. If the caller passed a Playwright ``Locator``, fall through — the
   string must have been registered by the time the Locator was built.
2. If the caller passed a string, look it up in the global registry.

For the registry to be populated, the page object must call
``register_locators(...)`` once during ``__init__``. That helper walks
the nested class structure and registers every string attribute. See
``BasePage.__init__`` for the integration point.
"""
from __future__ import annotations

import importlib
import inspect
import pkgutil
from pathlib import Path
from typing import Any, Optional

from src.common.autoheal.selector_registry import GLOBAL_REGISTRY

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def register_locators(loc_class_namespace: Any) -> int:
    """
    Walk a locator class (e.g. ``WioTransactionLocators.Hosted_TXN``) and
    register every string attribute under the global registry, indexed by
    its value.

    Returns the number of selectors registered.
    """
    # Determine the outer class and the inner class from a namespace instance
    inner_name = type(loc_class_namespace).__name__
    file_path = _resolve_source_path(loc_class_namespace)
    # Walk the outer class attributes to find this inner class
    outer = _find_outer_class(loc_class_namespace)
    if outer is None:
        return 0
    outer_name = outer.__name__
    count = 0
    for attr_name, value in inspect.getmembers(loc_class_namespace):
        if attr_name.startswith("_"):
            continue
        if isinstance(value, str) and value:
            GLOBAL_REGISTRY.register(
                outer_class=outer_name,
                inner_class=inner_name,
                attr_name=attr_name,
                selector=value,
                file_path=file_path,
            )
            count += 1
    return count


def _find_outer_class(inner_instance: Any) -> Optional[type]:
    """
    Return the outer class that contains the inner class, e.g. given an
    instance of ``WioTransactionLocators.Hosted_TXN``, return the class
    ``WioTransactionLocators``.
    """
    inner_type = type(inner_instance)
    inner_name = inner_type.__name__
    qualname = getattr(inner_type, "__qualname__", inner_name)
    outer_name = qualname.split(".")[0] if "." in qualname else None
    if outer_name is None:
        return None
    # Try to import the outer class from the same module
    module = inspect.getmodule(inner_type)
    if module is None:
        return None
    return getattr(module, outer_name, None)


def _resolve_source_path(instance: Any) -> Path:
    """Resolve the locators.py file that contains the source class."""
    cls = type(instance)
    module = inspect.getmodule(cls)
    if module is None or not hasattr(module, "__file__") or module.__file__ is None:
        # Fallback to project root
        return PROJECT_ROOT
    return Path(module.__file__).resolve()


def auto_register_all_locators() -> int:
    """
    Walk every bank folder under src/banks/ and register every locator
    class attribute into the global registry. Used as a catch-all in
    ``BasePage.__init__`` so the engine works even if the page object
    doesn't explicitly call ``register_locators``.

    Returns total selectors registered.
    """
    banks_dir = PROJECT_ROOT / "src" / "banks"
    if not banks_dir.exists():
        return 0

    total = 0
    for bank_dir in banks_dir.iterdir():
        if not bank_dir.is_dir() or bank_dir.name.startswith("_"):
            continue
        locators_dir = bank_dir / "locators"
        if not locators_dir.exists():
            continue
        for py_file in locators_dir.glob("*.py"):
            if py_file.name.startswith("_"):
                continue
            module_name = (
                f"src.banks.{bank_dir.name}.locators.{py_file.stem}"
            )
            try:
                module = importlib.import_module(module_name)
            except Exception:
                continue
            for outer_name in dir(module):
                if outer_name.startswith("_"):
                    continue
                outer = getattr(module, outer_name, None)
                if not inspect.isclass(outer):
                    continue
                # Look for inner classes (nested namespaces)
                for inner_name in dir(outer):
                    if inner_name.startswith("_"):
                        continue
                    inner = getattr(outer, inner_name, None)
                    if not inspect.isclass(inner):
                        continue
                    try:
                        instance = inner()
                    except Exception:
                        continue
                    for attr_name, value in inspect.getmembers(instance):
                        if attr_name.startswith("_"):
                            continue
                        if isinstance(value, str) and value:
                            GLOBAL_REGISTRY.register(
                                outer_class=outer_name,
                                inner_class=inner_name,
                                attr_name=attr_name,
                                selector=value,
                                file_path=Path(module.__file__).resolve(),
                            )
                            total += 1
    return total
