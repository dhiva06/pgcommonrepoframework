"""
Pytest hooks + fixtures for the autoheal package.

Two things live here:

1. ``pytest_sessionstart`` — registers every selector from every bank
   locator file into the global registry once, before any test runs.
   ``BasePage.__init__`` also calls this idempotently; the session hook
   is the safety net so the registry is populated even if no page object
   is instantiated before the first heal attempt.

2. ``pytest_terminal_summary`` — appends a compact heal summary to the
   terminal output after the run (additive; does not touch existing
   report generation).
"""
from __future__ import annotations

import pytest

from src.common.autoheal.heal_history import extract_summary


def pytest_sessionstart(session) -> None:
    """
    Called once before any test runs.  Registers every selector from every
    bank locator file so the heal engine can look up ``file`` + ``attr_path``
    for any selector string, even if the corresponding page object was never
    instantiated.
    """
    try:
        from src.common.autoheal.selector_locator import auto_register_all_locators
        count = auto_register_all_locators()
        # Write to the terminal so the user knows the pipeline is armed
        session.config._autheal_reg_count = count  # type: ignore[attr-defined]
    except Exception:
        pass  # Fail silently — the pipeline must not break a run


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """
    For each test phase (setup/call/teardown), set the active test name
    into a thread-local that ``BasePage`` reads at heal time.
    """
    outcome = yield
    try:
        from src.common.autoheal.heal_action_helpers import set_current_test_name
        test_name = item.name
        set_current_test_name(test_name)
    except Exception:
        pass


def pytest_terminal_summary(terminalreporter, exitstatus, config) -> None:
    """Append a compact autoheal summary to the terminal output."""
    try:
        summary = extract_summary()
    except Exception:
        return

    if summary["total"] == 0:
        # Show the registration count on every run so users know it's active
        reg_count = getattr(config, "_autheal_reg_count", None)
        if reg_count:
            terminalreporter.write_sep("=", "AUTOHEAL STATUS")
            terminalreporter.write_line(f"Selectors registered: {reg_count} (AUTOHEAL_ENABLED=true, no heals needed this run)")
        return

    terminalreporter.write_sep("=", "AUTOHEAL SUMMARY")
    terminalreporter.write_line(f"Total heal attempts : {summary['total']}")
    terminalreporter.write_line(f"Validated OK         : {summary['valid']}")
    terminalreporter.write_line(f"Failed validation    : {summary['invalid']}")
    terminalreporter.write_line(f"Persisted to files  : {summary['persist']}")
    terminalreporter.write_line(f"Last model used     : {summary['last_model'] or 'n/a'}")
    reg_count = getattr(config, "_autheal_reg_count", None)
    if reg_count:
        terminalreporter.write_line(f"Selectors registered : {reg_count}")
