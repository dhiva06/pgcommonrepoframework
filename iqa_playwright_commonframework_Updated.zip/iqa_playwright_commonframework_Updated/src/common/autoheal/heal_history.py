"""
Append-only log for every autoheal attempt.

Each entry is a JSON object with keys:
  ts, test, bank, file, attr_path, old, new,
  strategy, confidence, valid, persist, gemini_model, duration_ms

Serialized to reports/autoheal_log.jsonl (one line per entry). The file
is auto‑cleaned when it reaches MAX_SIZE_MB (default: 100 MB) to avoid
slowing down the system.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[3]
REPORTS_DIR = PROJECT_ROOT / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

LOG_FILE = REPORTS_DIR / "autoheal_log.jsonl"
MAX_SIZE_MB = int(os.getenv("AUTOHEAL_LOG_MAX_SIZE_MB", "100"))


@dataclass
class HealEntry:
    ts: float
    test: str
    bank: str
    file: str
    attr_path: str
    old: str
    new: str
    strategy: str
    confidence: float
    valid: bool
    persist: bool
    gemini_model: str
    duration_ms: float

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> HealEntry:
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


def _maybe_rotate() -> None:
    """Truncate log if it exceeds MAX_SIZE_MB."""
    if not LOG_FILE.exists():
        return
    size_mb = LOG_FILE.stat().st_size / (1024 * 1024)
    if size_mb > MAX_SIZE_MB:
        # Keep last 10% of entries to preserve some history
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
        keep = max(1, len(lines) // 10)
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.writelines(lines[-keep:])


def log_heal(entry: HealEntry) -> None:
    """Append a new entry to the JSONL log."""
    _maybe_rotate()
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(asdict(entry)) + "\n")


def extract_summary() -> dict[str, Any]:
    """Return counts and metrics from the log for human consumption."""
    if not LOG_FILE.exists() or LOG_FILE.stat().st_size == 0:
        return {
            "total": 0,
            "valid": 0,
            "invalid": 0,
            "persist": 0,
            "last_model": None,
            "last_ts": None,
        }

    with open(LOG_FILE, "r", encoding="utf-8") as f:
        entries = [json.loads(line) for line in f if line.strip()]

    total = len(entries)
    valid = sum(1 for e in entries if e.get("valid"))
    persist = sum(1 for e in entries if e.get("persist"))
    last = entries[-1]

    return {
        "total": total,
        "valid": valid,
        "invalid": total - valid,
        "persist": persist,
        "last_model": last.get("gemini_model"),
        "last_ts": last.get("ts"),
    }