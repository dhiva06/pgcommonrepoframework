"""
DOM snapshot capture for the auto-heal pipeline.

Given a page and a broken selector, we extract a focused window of visible
elements around where the selector *would* have matched, serialised into a
compact text format that fits comfortably in a Gemini prompt.

Design constraints:
- No heavyweight DOM serialisation (outerHTML is huge and token-expensive).
- Only visible elements (display:none / visibility:hidden / zero-area filtered out).
- Skip <script>, <style>, <svg>, <noscript>, <meta>, <link>, comments.
- Cap at AUTOHEAL_DOM_WINDOW elements (default 40) to bound prompt size.
- Include: tag, id, name, type, placeholder, aria-label, role, text (truncated), class (truncated).
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

from playwright.sync_api import Page, Locator

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def snapshot_around_failure(
    page: Page,
    broken_selector: str,
    window: int | None = None,
) -> str:
    """
    Build a focused DOM summary near the broken selector.

    Returns a multi-line string, one element per line, e.g.:

        1 <input id="buyBtn" name="buy" value="Pay Now" type="submit">
        2 <button id="cancelBtn" name="cancel" value="Cancel" type="button">
        3 <label for="buyBtn">Buy now</label>

    If the broken selector cannot be located, falls back to a page-level
    summary of the first `window` visible interactive elements.
    """
    if window is None:
        window = int(os.getenv("AUTOHEAL_DOM_WINDOW", "40"))

    try:
        elements = _collect_elements_near(page, broken_selector, window)
    except Exception:
        # Any unexpected error → safe fallback
        elements = _collect_top_interactive(page, window)

    if not elements:
        return "(no visible interactive elements found)"

    return "\n".join(f"{i} {el}" for i, el in enumerate(elements, 1))


# -------------------------------------------------------------------------- #
# Internal helpers
# -------------------------------------------------------------------------- #
_SKIP_TAGS = frozenset(
    {"script", "style", "svg", "noscript", "meta", "link", "head", "title", "base", "template"}
)
_ATTRS = ("id", "name", "type", "placeholder", "aria-label", "role", "value", "href", "data-testid")


def _collect_elements_near(page: Page, selector: str, limit: int) -> list[str]:
    """
    Try to resolve the broken selector.  If it resolves to ≥1 element,
    take that element's ancestors up to <body> and their siblings,
    flatten to a visible set, and return up to `limit` items.

    If the selector resolves to nothing, fall back to _collect_top_interactive.
    """
    try:
        cand = page.locator(selector)
        if cand.count() == 0:
            return _collect_top_interactive(page, limit)
        # Use the first match as the anchor
        anchor = cand.first
    except Exception:
        return _collect_top_interactive(page, limit)

    # Walk up ancestors and collect visible siblings
    seen: set[int] = set()
    out: list[str] = []

    def _maybe_add(loc: Locator) -> None:
        if loc.count() == 0:
            return
        try:
            if not loc.first.is_visible():
                return
        except Exception:
            return
        key = id(loc)
        if key in seen:
            return
        seen.add(key)
        s = _format_locator(loc.first)
        if s:
            out.append(s)

    # Start from anchor's parent and walk up to body
    current = anchor
    for _ in range(6):  # max 6 levels up (typical DOM depth before <body>)
        try:
            parent = current.locator("xpath=..")
            if parent.count() == 0:
                break
            _maybe_add(parent)
            # Siblings of parent
            siblings = parent.locator("xpath=../*")
            for i in range(min(siblings.count(), limit)):
                _maybe_add(siblings.nth(i))
            if len(out) >= limit:
                break
            current = parent
        except Exception:
            break

    # If still under limit, add page-level interactive elements
    if len(out) < limit:
        for el in _collect_top_interactive(page, limit - len(out)):
            if el not in out:
                out.append(el)

    return out[:limit]


def _collect_top_interactive(page: Page, limit: int) -> list[str]:
    """Fallback: first `limit` visible interactive elements on the page."""
    # Interactive-ish selectors
    selector = (
        "button, a, input, select, textarea, [role=button], [role=link], "
        "[role=tab], [role=menuitem], [role=option], [role=checkbox], "
        "[role=radio], [role=switch], [role=textbox], [role=searchbox], "
        "[role=combobox], [role=listbox], [tabindex], [onclick]"
    )
    try:
        locs = page.locator(selector)
        count = min(locs.count(), limit)
        out = []
        for i in range(count):
            s = _format_locator(locs.nth(i))
            if s:
                out.append(s)
        return out
    except Exception:
        return []


def _format_locator(loc: Locator) -> Optional[str]:
    """Serialise a single element to a compact attribute string."""
    try:
        if not loc.is_visible():
            return None
    except Exception:
        return None

    # Use evaluate to grab multiple attributes in one round-trip.
    # The function runs in Playwright's Node.js context, so it uses
    # explicit parameters (no `arguments` available).
    try:
        data = loc.evaluate(
            """(el, attrNames) => {
                const attrs = {};
                for (const a of attrNames) {
                    const v = el.getAttribute(a);
                    if (v !== null) attrs[a] = v;
                }
                return {
                    tag: el.tagName.toLowerCase(),
                    attrs: attrs,
                    text: (el.innerText || el.textContent || "").trim().slice(0, 80),
                    class: (el.className || "").slice(0, 120),
                };
            }""",
            list(_ATTRS),
        )
    except Exception:
        return None

    tag = data.get("tag", "")
    attrs = data.get("attrs", {})
    text = data.get("text", "")
    cls = data.get("class", "")

    # Build attribute string: id="..." name="..." type="..." etc.
    attr_parts = []
    for k in _ATTRS:
        v = attrs.get(k)
        if v is not None:
            # escape quotes
            v_escaped = v.replace('"', '\\"')
            attr_parts.append(f'{k}="{v_escaped}"')

    if text and text != attrs.get("value") and text != attrs.get("aria-label"):
        attr_parts.append(f'text="{text.replace("\\", "\\\\").replace("\"", "\\\"")}"')
    if cls:
        attr_parts.append(f'class="{cls}"')

    attr_str = " ".join(attr_parts)
    return f"<{tag} {attr_str}>" if attr_str else f"<{tag}>"