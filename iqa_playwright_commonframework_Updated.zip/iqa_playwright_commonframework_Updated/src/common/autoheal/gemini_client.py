"""
Thin wrapper around the Google Gemini SDK.

Provides:
- load config from environment (.env via python-dotenv)
- propose_selector: the main prompt → JSON call
- embed_text: future-proof hook for semantic matching (not used yet)

Retries up to 3× with exponential backoff on 429 / transient errors,
then raises.  All network calls are synchronous to match the rest of
the framework's sync Playwright usage.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Optional

from dotenv import load_dotenv

# Load .env at import time — matches the framework's top-level config pattern
load_dotenv()


@dataclass(frozen=True)
class HealProposal:
    """Parsed response from Gemini."""
    selector: Optional[str]
    strategy: str          # "css" | "xpath" | "role" | "test_id"
    confidence: float      # 0.0–1.0
    reasoning: str


class GeminiClientError(RuntimeError):
    """Any failure from the Gemini client layer (config, network, parse)."""
    pass


class GeminiClient:
    """
    Synchronous Gemini client tuned for the auto-heal use case.

    Parameters
    ----------
    api_key:
        Override the ``GEMINI_API_KEY`` env var (mainly for tests).
    model:
        Override the ``GEMINI_MODEL`` env var (default: ``gemini-2.0-flash``).
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
    ) -> None:
        # Import inside so a missing package is a clear error at instantiation time
        try:
            from google import genai
            from google.genai import types as genai_types
        except ImportError as e:  # pragma: no cover
            raise GeminiClientError(
                "google-genai not installed. Run: pip install google-genai"
            ) from e

        self._api_key = api_key or os.getenv("GEMINI_API_KEY", "").strip()
        self._model_name = model or os.getenv("GEMINI_MODEL", "gemini-2.0-flash").strip()
        self._genai_types = genai_types

        if not self._api_key:
            # Not a hard failure — let the engine log once and fall back silently
            self._client = None
            self._ready = False
            return

        self._client = genai.Client(api_key=self._api_key)
        self._ready = True

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def propose_selector(
        self,
        prompt: str,
        *,
        temperature: float = 0.1,
        max_output_tokens: int = 512,
    ) -> HealProposal:
        """
        Send the built prompt to Gemini and return a parsed HealProposal.

        Raises
        ------
        GeminiClientError
            If the model is not configured, the API call fails after retries,
            or the response cannot be parsed as the expected JSON shape.
        """
        if not self._ready:
            raise GeminiClientError("Gemini client not configured (missing API key)")

        response = self._generate_with_retry(
            prompt=prompt,
            temperature=temperature,
            max_output_tokens=max_output_tokens,
        )
        return self._parse_proposal(response)

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _generate_with_retry(
        self,
        prompt: str,
        temperature: float,
        max_output_tokens: int,
    ) -> str:
        """Call the model with up to 3 retries on 429 / 5xx.

        If the configured model hits a *daily quota* (RESOURCE_EXHAUSTED),
        the pipeline falls back to ``GEMINI_FALLBACK_MODEL`` — the free tier
        gives each model its own 20 req/day bucket, so switching models
        unblocks the run without waiting for a reset.
        """
        if self._client is None:
            raise GeminiClientError(
                "Gemini client is not initialised. "
                "Set the GEMINI_API_KEY environment variable (or .env file) and retry."
            )
        last_exc: Exception | None = None
        for attempt in range(1, 4):
            try:
                resp = self._client.models.generate_content(
                    model=self._model_name,
                    contents=prompt,
                    config=self._genai_types.GenerateContentConfig(
                        temperature=temperature,
                        max_output_tokens=max_output_tokens,
                        response_mime_type="application/json",
                    ),
                )
                return resp.text or ""
            except Exception as e:
                last_exc = e
                # Quota errors must NOT retry - waiting a few seconds won't
                # unblock a daily quota.  Fail fast and let the engine give
                # up so the user gets a clear, fast error.
                if self._is_quota_exhausted(e):
                    # Try the fallback model before giving up
                    fb = self._fallback_model()
                    if fb and fb != self._model_name:
                        print(
                            f"[GeminiClient] Quota exhausted for {self._model_name}; "
                            f"falling back to {fb}"
                        )
                        self._model_name = fb
                        continue
                    break
                # Only retry on transient rate-limit / server errors
                if self._is_retryable(e):
                    wait = min(2 ** attempt, 8)
                    time.sleep(wait)
                    continue
                break

        raise GeminiClientError(f"Gemini call failed after retries: {last_exc}")

    def _fallback_model(self) -> str:
        """Return the fallback model name (env override or default)."""
        fb = os.getenv("GEMINI_FALLBACK_MODEL", "").strip()
        return fb or "gemini-2.5-flash"

    @staticmethod
    def _is_retryable(exc: Exception) -> bool:
        """Heuristic: retry on transient 5xx / network errors (NOT on quota)."""
        msg = str(exc).lower()
        if "429" in msg and "quota" in msg:
            return False
        return any(code in msg for code in ("429", "500", "502", "503", "504", "timeout", "connection"))

    @staticmethod
    def _is_quota_exhausted(exc: Exception) -> bool:
        """Detect daily-quota / RESOURCE_EXHAUSTED errors specifically.

        These are NOT transient - waiting seconds won't help, the user must
        wait for daily reset or upgrade their plan.  Returning ``True`` from
        this method causes the retry loop to break immediately.
        """
        msg = str(exc).lower()
        return "quota" in msg or "resource_exhausted" in msg or "generate_requests" in msg

    @staticmethod
    def _parse_proposal(raw: str) -> HealProposal:
        """Parse the JSON payload into a HealProposal, with safe defaults."""
        import json

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            raise GeminiClientError(f"Gemini returned invalid JSON: {e}") from e

        # Required keys with safe fallbacks
        selector = data.get("selector")
        if selector is not None and not isinstance(selector, str):
            raise GeminiClientError(f"Gemini 'selector' must be string or null, got {type(selector)}")

        strategy = str(data.get("strategy", "css")).lower()
        if strategy not in ("css", "xpath", "role", "test_id"):
            strategy = "css"

        confidence = float(data.get("confidence", 0.5))
        confidence = max(0.0, min(1.0, confidence))

        reasoning = str(data.get("reasoning", "")).strip()

        return HealProposal(
            selector=selector,
            strategy=strategy,
            confidence=confidence,
            reasoning=reasoning,
        )

    # ------------------------------------------------------------------ #
    # Future-proof hook (unused today)
    # ------------------------------------------------------------------ #
    def embed_text(self, text: str) -> list[float]:
        """
        Return a vector embedding for `text`.  Currently unused — the
        auto-heal pipeline uses text prompts, but this hook is here for
        a future semantic-matching stage.
        """
        if not self._ready:
            raise GeminiClientError("Gemini client not configured (missing API key)")
        resp = self._client.models.embed_content(
            model="models/text-embedding-004",
            contents=text,
        )
        return resp.embeddings[0].values