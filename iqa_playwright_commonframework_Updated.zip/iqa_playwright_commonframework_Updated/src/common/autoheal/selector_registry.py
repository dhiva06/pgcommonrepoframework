"""
SelectorRegistry: tracks which locator strings came from which
`*_locators.py` file and which attribute name.

When `BasePage` receives a locator (string or Locator object), the page
object's locators are passed in. We record:

    (selector_string) -> {"file": Path, "attr": str, "outer": str, "inner": str}

So when a heal attempt fires later, we can ask the registry "what file
and attribute did this selector come from?" and write the new value
back to the exact right place.

Usage (called by BasePage / page objects):

    registry.register("WioTransactionLocators", "Hosted_TXN", "click_buy_button",
                       "//input[@value='Buy']", file_path)
    registry.lookup("//input[@value='Buy']")
    # -> {"file": Path, "outer": "WioTransactionLocators",
    #     "inner": "Hosted_TXN", "attr": "click_buy_button"}

The registry is intentionally simple — a single dict keyed by the raw
selector string. It only stores data; it does not mutate any locator.
"""
from __future__ import annotations

from pathlib import Path
from threading import RLock
from typing import Optional


class SelectorRegistry:
    """Thread-safe registry of selector -> {file, outer, inner, attr}."""

    def __init__(self) -> None:
        self._by_selector: dict[str, dict[str, str | Path]] = {}
        self._lock = RLock()

    def register(
        self,
        outer_class: str,
        inner_class: str,
        attr_name: str,
        selector: str,
        file_path: Path,
    ) -> None:
        """Record one (selector, source) entry."""
        if not selector or not isinstance(selector, str):
            return
        with self._lock:
            self._by_selector[selector] = {
                "outer": outer_class,
                "inner": inner_class,
                "attr": attr_name,
                "file": file_path,
            }

    def lookup(self, selector: str) -> Optional[dict[str, str | Path]]:
        """Return the recorded source for a selector, or None if unknown."""
        if not selector or not isinstance(selector, str):
            return None
        with self._lock:
            return self._by_selector.get(selector)

    def attr_path(self, selector: str) -> Optional[str]:
        """Convenience: return the dotted Python path, e.g.
        ``WioTransactionLocators.Hosted_TXN.click_buy_button``."""
        rec = self.lookup(selector)
        if rec is None:
            return None
        return f"{rec['outer']}.{rec['inner']}.{rec['attr']}"

    def file_path(self, selector: str) -> Optional[Path]:
        """Convenience: return the locators file path for a selector."""
        rec = self.lookup(selector)
        if rec is None:
            return None
        return rec.get("file")  # type: ignore[return-value]

    def clear(self) -> None:
        """Drop all registered entries (used at the start of each test)."""
        with self._lock:
            self._by_selector.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._by_selector)


# Module-level singleton; one registry per test process is fine
# (selector strings are unique within a project).
GLOBAL_REGISTRY = SelectorRegistry()