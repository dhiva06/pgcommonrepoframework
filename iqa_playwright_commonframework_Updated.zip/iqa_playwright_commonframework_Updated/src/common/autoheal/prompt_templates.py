"""Versioned Gemini prompt templates for the auto-heal pipeline.

Each template ends with a strict instruction for Gemini to return a JSON
object.  Version bump = API contract change; existing prompts stay pinned
so the model behaviour is auditable.
"""
from __future__ import annotations

import json

SYSTEM_PROMPT = """You are a Playwright selector repair agent.
Your job is to take a broken selector, the type of action that failed,
and a compact DOM snapshot of the page around where the selector would match,
and return a *new* selector that will make the action succeed again.

Return **exactly** a single JSON object with these keys — nothing else:

{
  "selector": "string | null",
  "strategy": "css | xpath | role | test_id",
  "confidence": 0.0–1.0,
  "reasoning": "one-sentence why this selector should work"
}

Rules:
- If the DOM snapshot does NOT contain an element that could replace the broken
  one, set ``selector`` to ``null``.
- ``strategy`` must be one of: css, xpath, role, test_id.
- ``confidence`` is your numeric confidence that the proposed selector will
  make the step succeed.  Use 0.5 as the default when you are uncertain.
- The ``reasoning`` field should explain the heuristic in one short sentence.
- Do NOT return any prose, markdown fences, or extra keys.  The JSON parser
  will reject anything that is not a single JSON object on its own line.
"""


FIRST_ATTEMPT_PROMPT = """BROKEN SELECTOR: {broken_selector}
ACTION TYPE: {action_type}  (e.g. click, fill, check, select_option)
DESCRIPTION: {description}  (human-readable name of the step, e.g. "Buy button")
DOM SNAPSHOT (up to {dom_window} elements, closest to the broken selector first):
{dom_summary}

Please propose a replacement selector using the DOM snapshot above.  If no
element looks like a viable replacement, set ``selector`` to ``null``.
"""


RETRY_PROMPT = """BROKEN SELECTOR: {broken_selector}
ACTION TYPE: {action_type}
DESCRIPTION: {description}

Your FIRST proposal (attempt 1) was:
  selector={first_selector}
  confidence={first_confidence}
  reasoning={first_reasoning}

That proposal FAILED validation in Playwright.  The error was:
  {validation_error}

Please propose a *new* selector taking the above failure into account.
If you cannot improve on the first attempt, you may return the same selector
with a revised confidence/reasoning explaining why it should still work.
Again, return exactly one JSON object with keys ``selector``, ``strategy``,
``confidence``, ``reasoning``.  No prose, no markdown, no extra keys.
"""


def first_attempt_prompt(
    broken_selector: str,
    action_type: str,
    description: str,
    dom_summary: str,
    dom_window: int = 40,
) -> str:
    """Render the first-attempt prompt for Gemini."""
    return FIRST_ATTEMPT_PROMPT.format(
        broken_selector=broken_selector,
        action_type=action_type,
        description=description,
        dom_summary=dom_summary,
        dom_window=dom_window,
    )


def retry_prompt(
    broken_selector: str,
    action_type: str,
    description: str,
    first_selector: str,
    first_confidence: float,
    first_reasoning: str,
    validation_error: str,
    dom_window: int = 40,
) -> str:
    """Render the retry prompt for Gemini after a validation failure."""
    return RETRY_PROMPT.format(
        broken_selector=broken_selector,
        action_type=action_type,
        description=description,
        first_selector=first_selector,
        first_confidence=first_confidence,
        first_reasoning=first_reasoning,
        validation_error=validation_error,
        dom_window=dom_window,
    )