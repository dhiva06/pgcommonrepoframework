"""
AST-based writer that updates a single attribute in a locators.py file.

Approach:
1. Parse the file with ast.
2. Walk the AST to find the target Assign node (outer class -> inner class
   -> attribute).
3. Use the Assign node's `lineno` and `end_lineno` to locate the source
   line in the file.
4. Re-emit that line with the new value (preserving indentation, keeping
   comments and surrounding lines untouched).
5. Write the result back only if the value actually changed.

Safety gates (config-driven via env vars):
- AUTOHEAL_BANK_SCOPE_ONLY (default: true): refuses to write any file that
  does not live under src/banks/<bank>/locators/ relative to the project root.
- AUTOHEAL_ENABLED (default: true): engine is a no-op when false.
"""
from __future__ import annotations

import ast
import os
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parents[3]

# Environment gate
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

AUTOHEAL_ENABLED = os.getenv("AUTOHEAL_ENABLED", "true").lower() == "true"
AUTOHEAL_BANK_SCOPE_ONLY = os.getenv("AUTOHEAL_BANK_SCOPE_ONLY", "true").lower() == "true"


class SelectorUpdaterError(RuntimeError):
    """Raised when anything fails about writing the updated selector."""
    pass


class SelectorUpdater:
    """
    Update one dotted attribute path (e.g.
    WioTransactionLocators.Hosted_TXN.click_buy_button) in a locators.py file.
    """

    def __init__(self, file_path: Path) -> None:
        self.file_path = file_path.resolve()
        if AUTOHEAL_ENABLED:
            self._validate_scope()
        self._src = self._read_file()
        self._lines = self._src.splitlines(keepends=True)

    def _validate_scope(self) -> None:
        """Enforce AUTOHEAL_BANK_SCOPE_ONLY when the env flag is on."""
        if not AUTOHEAL_BANK_SCOPE_ONLY:
            return
        try:
            rel = self.file_path.relative_to(PROJECT_ROOT / "src" / "banks")
        except ValueError:
            raise SelectorUpdaterError(
                f"Cannot enforce bank scope — file {self.file_path} is outside project src/banks/: "
                "refusing to write outside the allowed directory."
            )
        if len(rel.parts) < 2 or rel.parts[0] not in self._available_banks():
            raise SelectorUpdaterError(
                f"Attempted to update a selector outside src/banks/<bank>/locators/: {self.file_path}"
            )

    @staticmethod
    def _available_banks() -> list[str]:
        banks_dir = PROJECT_ROOT / "src" / "banks"
        if not banks_dir.exists():
            return []
        return sorted(p.name for p in banks_dir.iterdir() if p.is_dir())

    def _read_file(self) -> str:
        with open(self.file_path, "r", encoding="utf-8") as f:
            return f.read()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def update_attribute(
        self,
        attr_path: str,
        new_value: str,
    ) -> bool:
        """
        Update a single dotted-attribute in the locators file.

        Parameters
        ----------
        attr_path : str
            Dotted path, e.g. ``WioTransactionLocators.Hosted_TXN.click_buy_button``.
        new_value : str
            The new selector string to write.

        Returns
        -------
        bool
            ``True`` if the file was modified, ``False`` if the value was
            already the same (no write performed).
        """
        if not AUTOHEAL_ENABLED:
            return False

        target = self._resolve_attr_path(attr_path)
        if target is None:
            raise SelectorUpdaterError(f"Attribute path not found: {attr_path}")

        old_value = self._extract_value(target)
        if old_value == new_value:
            return False

        self._replace_line(target, new_value)
        self._write_file()
        return True

    # ------------------------------------------------------------------ #
    # Internal AST helpers
    # ------------------------------------------------------------------ #
    def _resolve_attr_path(self, path: str) -> Optional[ast.Assign]:
        """Walk the AST and return the Assign node matching the dotted path."""
        parts = path.split(".")
        if len(parts) < 3:
            return None

        # parts[-3] = outermost class (e.g. WioTransactionLocators)
        # parts[-2] = inner class (e.g. Hosted_TXN)
        # parts[-1] = attribute name (e.g. click_buy_button)
        outer_name = parts[-3]
        inner_name = parts[-2]
        attr_name = parts[-1]

        try:
            tree = ast.parse(self._src)
        except SyntaxError as e:
            raise SelectorUpdaterError(f"Could not parse locators file: {e}") from e

        outer_class = next(
            (c for c in tree.body if isinstance(c, ast.ClassDef) and c.name == outer_name),
            None,
        )
        if outer_class is None:
            return None

        inner_class = next(
            (c for c in outer_class.body if isinstance(c, ast.ClassDef) and c.name == inner_name),
            None,
        )
        if inner_class is None:
            return None

        # Find the Assign whose target name matches attr_name (not just the first Assign)
        assign = next(
            (
                a
                for a in inner_class.body
                if isinstance(a, ast.Assign)
                and len(a.targets) == 1
                and isinstance(a.targets[0], ast.Name)
                and a.targets[0].id == attr_name
            ),
            None,
        )
        if assign is None:
            return None

        return assign

    @staticmethod
    def _extract_value(assign_node: ast.Assign) -> str:
        """Extract the string value from an Assign node's Constant."""
        if not isinstance(assign_node.value, ast.Constant):
            return ""
        value = assign_node.value.value
        return "" if value is None else str(value)

    def _replace_line(self, assign_node: ast.Assign, new_value: str) -> None:
        """Replace the source line containing the Assign node with a new one."""
        # AST line numbers are 1-indexed
        if assign_node.lineno is None:
            raise SelectorUpdaterError("Assign node has no line number; cannot locate source")
        line_idx = assign_node.lineno - 1
        if line_idx >= len(self._lines):
            raise SelectorUpdaterError(
                f"Line {assign_node.lineno} out of range (file has {len(self._lines)} lines)"
            )
        original = self._lines[line_idx]

        # Preserve indentation + trailing newline, find the '=' position
        stripped = original.lstrip()
        indent = original[: len(original) - len(stripped)]

        eq_pos = original.find("=")
        if eq_pos < 0:
            raise SelectorUpdaterError(f"No '=' on line {assign_node.lineno}")

        # Keep everything up to and including '=' plus the original whitespace
        after_eq = original[eq_pos + 1 :]
        # Detect line ending
        line_end = ""
        if original.endswith("\r\n"):
            line_end = "\r\n"
        elif original.endswith("\n"):
            line_end = "\n"

        # Strip leading whitespace and any existing value, then emit new value
        new_value_escaped = new_value.replace("\\", "\\\\").replace('"', '\\"')
        self._lines[line_idx] = f'{indent}{assign_node.targets[0].id} = "{new_value_escaped}"{line_end}'

    def _write_file(self) -> None:
        with open(self.file_path, "w", encoding="utf-8") as f:
            f.writelines(self._lines)