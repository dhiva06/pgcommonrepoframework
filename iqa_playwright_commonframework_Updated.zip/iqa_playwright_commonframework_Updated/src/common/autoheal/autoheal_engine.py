"""
Autoheal engine: the orchestration layer between BasePage actions and the
Gemini API.

Usage pattern:
1. A BasePage action fails (timeout / element not found, etc.)
2. The except block calls ``heal_engine.try_heal(...)`` with context.
3. Engine:
   a. Builds a DOM snapshot
   b. Calls Gemini to propose a new selector
   c. Validates the new selector by re-running the action in Playwright
   d. If valid and AUTOHEAL_PERSIST=true, writes the new selector into the
      locators.py file and emits a unified diff for review
   e. Logs the result to heal_history.jsonl
   f. Returns a fresh Playwright Locator (or None on failure)
"""
from __future__ import annotations

import difflib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from playwright.sync_api import Locator, Page, TimeoutError as PlaywrightTimeoutError

from src.common.autoheal.dom_summarizer import snapshot_around_failure
from src.common.autoheal.gemini_client import GeminiClient, HealProposal, GeminiClientError
from src.common.autoheal.heal_action_helpers import get_current_test_name
from src.common.autoheal.heal_history import HealEntry, log_heal
from src.common.autoheal.prompt_templates import first_attempt_prompt, retry_prompt
from src.common.autoheal.selector_updater import SelectorUpdater

if TYPE_CHECKING:
    from src.common.base.base_page import LocatorAutoHeal


PROJECT_ROOT = Path(__file__).resolve().parents[3]
REPORTS_DIR = PROJECT_ROOT / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

DIFS_DIR = REPORTS_DIR / "autoheal_diffs"
DIFS_DIR.mkdir(exist_ok=True)


@dataclass
class HealResult:
    """Result of a heal attempt."""
    success: bool
    new_locator: Optional[Locator] = None
    new_selector: Optional[str] = None
    strategy: str = ""
    confidence: float = 0.0
    error: str = ""


class AutohealEngine:
    """
    Orchestrates the self-healing process: Gemini proposal -> validation -> persist.

    Designed to be instantiated once per Test run and injected into BasePage.
    """

    def __init__(self, page: Page, heuristic_healer: "LocatorAutoHeal") -> None:
        self.page = page
        self.heuristic_healer = heuristic_healer
        self.gemini = GeminiClient()

        # Counters for the test run
        self._total_attempts = 0
        self._valid_count = 0
        self._persist_count = 0

    def try_heal(
        self,
        *,
        description: str,
        action_type: str,
        broken_selector: str,
        locators_file: Path,
        attr_path: str,
        test_name: str,
        bank: str,
        action_value: Optional[str] = None,
    ) -> Optional[Locator]:
        """
        Full heal pipeline: propose, validate, persist.

        Parameters
        ----------
        description : str
            Human-readable step name (e.g. "Buy button", "Username field").
        action_type : str
            One of: click, fill, check, select, double_click, right_click, drag, etc.
        broken_selector : str
            The original XPath or CSS selector that failed.
        locators_file : Path
            Path to the *_locators.py file to update.
        attr_path : str
            Dotted Python path to the attribute (e.g. "WioTransactionLocators.Hosted_TXN.click_buy_button").
        test_name : str
            Full pytest test name (used for logging).
        bank : str
            Bank name (used for logging).
        action_value : str | None
            The value to fill (only for action_type="fill"); used during
            validation so the engine exercises the actual operation.

        Returns
        -------
        Locator | None
            A fresh Playwright Locator pointing to the healed element,
            or None if healing failed.
        """
        self._total_attempts += 1
        start_ts = time.time()

        try:
            return self._try_heal_pipeline(
                description=description,
                action_type=action_type,
                broken_selector=broken_selector,
                locators_file=locators_file,
                attr_path=attr_path,
                test_name=test_name,
                bank=bank,
                start_ts=start_ts,
                action_value=action_value,
            )
        except Exception as e:
            # Log and fall back to None
            self._log_attempt(
                description=description,
                action_type=action_type,
                broken_selector=broken_selector,
                locators_file=locators_file,
                attr_path=attr_path,
                test_name=test_name,
                bank=bank,
                start_ts=start_ts,
                valid=False,
                error=str(e),
            )
            return None

    # ------------------------------------------------------------------ #
    # Internal pipeline steps
    # ------------------------------------------------------------------ #
    def _try_heal_pipeline(
        self,
        description: str,
        action_type: str,
        broken_selector: str,
        locators_file: Path,
        attr_path: str,
        test_name: str,
        bank: str,
        start_ts: float,
        action_value: Optional[str] = None,
    ) -> Optional[Locator]:
        # 1. Build DOM snapshot
        dom_snapshot = snapshot_around_failure(
            self.page, broken_selector, window=int(os.getenv("AUTOHEAL_DOM_WINDOW", "40"))
        )

        # 2. Call Gemini to propose a new selector
        try:
            prompt = first_attempt_prompt(
                broken_selector=broken_selector,
                action_type=action_type,
                description=description,
                dom_summary=dom_snapshot,
                dom_window=40,
            )
            proposal = self.gemini.propose_selector(prompt)
        except GeminiClientError as e:
            raise RuntimeError(f"Gemini error during first attempt: {e}")

        if proposal.selector is None:
            raise RuntimeError("Gemini returned no viable selector")

        # 3. Validate the proposed selector in Playwright
        if not self._validate_selector(proposal, action_type, action_value):
            # Retry with Gemini once more
            retry_p = retry_prompt(
                broken_selector=broken_selector,
                action_type=action_type,
                description=description,
                first_selector=proposal.selector,
                first_confidence=proposal.confidence,
                first_reasoning=proposal.reasoning,
                validation_error="Element not found or not visible within timeout",
            )
            proposal2 = self.gemini.propose_selector(retry_p)
            if not self._validate_selector(proposal2, action_type, action_value):
                raise RuntimeError(f"Gemini proposal did not pass validation (attempt 2)")
            proposal = proposal2

        new_selector = proposal.selector
        strategy = proposal.strategy
        confidence = proposal.confidence

        # 4. Persist the selector (if enabled)
        persist = False
        if (
            str(locators_file) != ""
            and os.getenv("AUTOHEAL_PERSIST", "true").lower() == "true"
        ):
            try:
                updater = SelectorUpdater(locators_file)
                if updater.update_attribute(attr_path, new_selector):
                    self._persist_count += 1
                    persist = True
                    self._emit_diff(locators_file, attr_path, broken_selector, new_selector)
            except Exception as e:
                # Don't fail the run; just log that persist failed
                pass

        # 5. Build the final Locator for Playwright
        final_loc = self._build_locator(new_selector, strategy)

        # 6. Log the attempt
        duration_ms = (time.time() - start_ts) * 1000
        self._log_attempt(
            description=description,
            action_type=action_type,
            broken_selector=broken_selector,
            locators_file=locators_file,
            attr_path=attr_path,
            test_name=test_name,
            bank=bank,
            start_ts=start_ts,
            new_selector=new_selector,
            strategy=strategy,
            confidence=confidence,
            persist=persist,
            valid=True,
        )

        return final_loc

    def _validate_selector(
        self,
        proposal: HealProposal,
        action_type: str,
        action_value: Optional[str] = None,
    ) -> bool:
        """Run the actual action (click/fill/etc.) against the proposed selector."""
        try:
            locator = self._build_locator(proposal.selector, proposal.strategy)
            locator.wait_for(state="visible", timeout=5000)

            if action_type == "click":
                locator.click(timeout=5000)
            elif action_type == "fill":
                # Validate with the actual fill value when available
                if action_value is not None:
                    locator.fill(action_value, timeout=5000)
                else:
                    return locator.is_visible()
            elif action_type == "check":
                locator.check(timeout=5000)
            elif action_type == "uncheck":
                locator.uncheck(timeout=5000)
            elif action_type == "select":
                return locator.is_visible()
            elif action_type in ("double_click", "right_click", "drag"):
                # These need more context; skip validation for now
                return locator.is_visible()
            elif action_type == "hover":
                return locator.is_visible()
            else:
                # Default: assume click is a safe lower bound
                locator.click(timeout=5000)

            return True
        except Exception:
            return False

    def _build_locator(self, selector: str, strategy: str) -> Locator:
        """Convert a selector string back into a Playwright Locator."""
        if strategy == "css":
            return self.page.locator(selector)
        elif strategy == "xpath":
            return self.page.locator(f"xpath={selector}")
        elif strategy == "role":
            # selectors like "button|Buy button" → split on bar
            parts = selector.split("|", 1)
            if len(parts) == 2:
                return self.page.get_by_role(parts[0].strip(), name=parts[1].strip())
            return self.page.get_by_role(selector)
        elif strategy == "test_id":
            return self.page.get_by_test_id(selector)
        else:
            # Default to CSS
            return self.page.locator(selector)

    def _emit_diff(
        self,
        file_path: Path,
        attr_path: str,
        old_value: str,
        new_value: str,
    ) -> None:
        """Write a unified diff file under reports/autoheal_diffs/."""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        diff_file = DIFS_DIR / f"{file_path.stem}_{attr_path.replace('.', '_')}_{timestamp}.diff"

        diff_text = "\n".join(
            difflib.unified_diff(
                [f"{old_value}\n"],
                [f"{new_value}\n"],
                fromfile=f"{file_path} (before)",
                tofile=f"{file_path} (after; changed {attr_path})",
            )
        )

        with open(diff_file, "w", encoding="utf-8") as f:
            f.write(diff_text)

    def _log_attempt(
        self,
        *,
        description: str,
        action_type: str,
        broken_selector: str,
        locators_file: Path,
        attr_path: str,
        test_name: str,
        bank: str,
        start_ts: float,
        new_selector: str = "",
        strategy: str = "",
        confidence: float = 0.0,
        persist: bool = False,
        valid: bool = False,
        error: str = "",
    ) -> None:
        duration_ms = (time.time() - start_ts) * 1000 if start_ts else 0.0
        if valid:
            self._valid_count += 1

        entry = HealEntry(
            ts=time.time(),
            test=test_name,
            bank=bank,
            file=str(locators_file),
            attr_path=attr_path,
            old=broken_selector,
            new=new_selector,
            strategy=strategy,
            confidence=confidence,
            valid=valid,
            persist=persist,
            gemini_model=self.gemini._model_name if self.gemini._ready else "",
            duration_ms=duration_ms,
        )
        log_heal(entry)

    # ------------------------------------------------------------------ #
    # Summary / stats
    # ------------------------------------------------------------------ #
    @property
    def stats(self) -> dict[str, int | str | None]:
        return {
            "attempts": self._total_attempts,
            "valid": self._valid_count,
            "persist": self._persist_count,
        }