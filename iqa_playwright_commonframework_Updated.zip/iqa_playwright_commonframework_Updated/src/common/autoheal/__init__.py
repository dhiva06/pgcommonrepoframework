"""
Autoheal package: AI-powered self-healing locators using Google Gemini.

Pipeline on a failed step:

    BasePage action ``except`` block
        -> AutohealEngine.try_heal(...)
            1. dom_summarizer.snapshot_around_failure(...)
            2. gemini_client.propose_selector(...)
            3. validate in Playwright (action-type gate)
            4. selector_updater.persist(...)   [if validated + AUTOHEAL_PERSIST]
            5. heal_history.log(...)

Every piece honors a single on/off switch read from config (env override):
``AUTOHEAL_ENABLED``.  When ``False`` the engine is fully inert and the
existing heuristic ``LocatorAutoHeal`` fallback on BasePage is the only
healer that runs.
"""
from src.common.autoheal.autoheal_engine import AutohealEngine
from src.common.autoheal.gemini_client import GeminiClient, HealProposal

__all__ = ["AutohealEngine", "GeminiClient", "HealProposal"]
