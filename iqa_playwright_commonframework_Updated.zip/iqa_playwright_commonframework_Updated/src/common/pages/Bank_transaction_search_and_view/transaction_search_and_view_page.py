from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.transaction_search_and_view_locators import TransactionSearchViewLocators as EcentricLocators
from pathlib import Path
from datetime import datetime
class TransactionSearchViewPage(BasePage):

    def __init__(self, page, module_name="TransactionSearchView"):
        super().__init__(page, module_name=module_name)

        self._dispatch = {
            "ecentric": (self._navigate_ecentric_transaction_search_view, self._assert_dashboard_Transactions_ecentric, EcentricLocators),
        }
    def navigate_to_transactions_menue(self, bank: str, data: dict) -> None:
        navigate_method, _, loc = self._dispatch[bank.lower()]
        navigate_method(loc)
    def assert_Transactions_dashboard_page(self, bank: str, data: dict) -> None:
        _, assert_method, loc = self._dispatch[bank.lower()]
        assert_method(loc)
    def _navigate_ecentric_transaction_search_view(self, loc) -> None:
        self.click_by_locator(loc.unhide_menu, "Display Menu")
        self.click_by_locator(loc.transactions_menu, "Transactions Menu")

    def _assert_dashboard_Transactions_ecentric(self, loc) -> None:
        self.assert_visible(self.locator(loc.transactions_tab),"Transactions Tab is visible")
        self.assert_visible(self.locator(loc.refunds_tab),"Refunds Tab is visible")
        self.assert_visible(self.locator(loc.bulk_refund_tab),"Bulk Refund Tab is visible")
        self.assert_visible(self.locator(loc.search_field),"Payment ID Search Field is visible")
        self.assert_visible(self.locator(loc.filter_button),"Filter Button is visible")
        self.assert_visible(self.locator(loc.search_button),"Search Button is visible")
        self.assert_visible(self.locator(loc.column_customization_button),"Column Customization Button is visible")
        self.assert_visible(self.locator(loc.payment_id_column),"Payment ID Column is visible")
        self.assert_visible(self.locator(loc.merchant_track_id_column),"Merchant Track ID Column is visible")
        self.assert_visible(self.locator(loc.pagination_dropdown),"Pagination Dropdown is visible")
        self.assert_visible(self.locator(loc.goto_input),"Go To Page Field is visible")

    def verify_transactions_filters_and_grid_data(self, bank: str, data: dict):
        transaction_type = str(data.get("TransactionType") or "").strip()
        payment_mode = str(data.get("PaymentMode") or "").strip()
        transaction_status = str(data.get("TransactionStatus") or "").strip()
        settlement_status = str(data.get("SettlementStatus") or "").strip()
        date_filter = str(data.get("DateFilter") or "").strip()
        self.click_by_locator(EcentricLocators.date_filter_dropdown, "Transaction Date Dropdown")
        self.click_by_locator(EcentricLocators.date_filter_option.format(date_filter),f"Select Date Filter : {date_filter}")
        self.click_by_locator(EcentricLocators.filter_button, "Filter Button")
        if transaction_type:
            self.click_by_locator(EcentricLocators.transaction_type_option.format(transaction_type), f"Transaction Type : {transaction_type}")
        if payment_mode:
            self.click_by_locator(EcentricLocators.payment_mode_option.format(payment_mode), f"Payment Mode : {payment_mode}")
        if transaction_status:
            self.click_by_locator(EcentricLocators.transaction_status_option.format(transaction_status), f"Transaction Status : {transaction_status}")
        if settlement_status:
            self.click_by_locator(EcentricLocators.settlement_status_option.format(settlement_status), f"Settlement Status : {settlement_status}")
        self.click_by_locator(EcentricLocators.apply_filter_button, "Apply Filter Button")
        self.page.wait_for_timeout(3000)
        row_count = self.page.locator(EcentricLocators.transaction_rows).count()
        print(f"Total rows after filtering: {row_count}")
        assert row_count > 0, "No records found after applying filter"
        if transaction_type:
            rows = self.page.locator(EcentricLocators.transaction_type_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Transaction Type: "f"{actual_value}")
                assert actual_value.lower() == transaction_type.lower(), (f"Row {i+1}: Expected Transaction Type " f"'{transaction_type}', Got '{actual_value}'")
        if payment_mode:
            rows = self.page.locator(EcentricLocators.payment_mode_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Payment Mode: "f"{actual_value}")
                assert actual_value.lower() == payment_mode.lower(), (f"Row {i+1}: Expected Payment Mode " f"'{payment_mode}', Got '{actual_value}'")
        if transaction_status:
            rows = self.page.locator(EcentricLocators.transaction_status_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Transaction Status: "f"{actual_value}")
                assert actual_value.lower() == transaction_status.lower(), (f"Row {i+1}: Expected Transaction Status " f"'{transaction_status}', Got '{actual_value}'")
        if settlement_status:
            rows = self.page.locator(EcentricLocators.settlement_status_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Settlement Status: " f"{actual_value}")
                assert actual_value.lower() == settlement_status.lower(), (f"Row {i+1}: Expected Settlement Status "f"'{settlement_status}', Got '{actual_value}'")

    def verify_transactions_search(self, bank: str, data: dict):
        search_by = str(data.get("SearchBy") or "").strip()
        search_value = str(data.get("SearchValue") or "").strip()
        date_filter = str(data.get("DateFilter") or "").strip()
        self.click_by_locator(EcentricLocators.date_filter_dropdown,"Transaction Date Dropdown")
        self.click_by_locator(EcentricLocators.date_filter_option.format(date_filter), f"Select Date Filter : {date_filter}")
        self.fill_by_locator(EcentricLocators.search_field, search_value, "Search Field")
        self.click_by_locator(EcentricLocators.search_button, "Search Button")
        self.page.wait_for_timeout(2000)
        if search_by.lower() == "payment id":
            actual_value = self.get_text(self.locator(EcentricLocators.payment_id_value), "Payment ID").strip()
            print("Actual Payment ID:", actual_value)
        elif search_by.lower() == "merchant name":
            actual_value = self.get_text(self.locator(EcentricLocators.merchant_name_value), "Merchant Name").strip()
            print("Actual Merchant Name:", actual_value)
        elif search_by.lower() == "mid":
            actual_value = self.get_text(self.locator(EcentricLocators.mid_value), "MID").strip()
            print("Actual MID:", actual_value)
        elif search_by.lower() == "rrn":
            actual_value = self.get_text(self.locator(EcentricLocators.rrn_value), "RRN").strip()
            print("Actual RRN:", actual_value)
        else:
            raise AssertionError(f"Unsupported SearchBy value : {search_by}")
        assert search_value.lower() in actual_value.lower(), (f"Expected : {search_value}, "f"Actual : {actual_value}")

    def verify_transactions_search_and_grid_values(self, bank: str, data: dict):
        search_by = str(data.get("SearchBy") or "").strip()
        search_value = str(data.get("SearchValue") or "").strip()
        date_filter = str(data.get("DateFilter") or "").strip()
        self.click_by_locator(EcentricLocators.date_filter_dropdown,"Transaction Date Dropdown")
        self.click_by_locator(EcentricLocators.date_filter_option.format(date_filter), f"Select Date Filter : {date_filter}")
        self.fill_by_locator(EcentricLocators.search_field, search_value, "Search Field")
        self.click_by_locator(EcentricLocators.search_button, "Search Button")
        self.page.wait_for_timeout(2000)
        if search_by.lower() == "payment id":
            elements = self.page.locator(EcentricLocators.payment_id_column_values)
        elif search_by.lower() == "merchant name":
            elements = self.page.locator(EcentricLocators.merchant_name_column_values)
        elif search_by.lower() == "mid":
            elements = self.page.locator(EcentricLocators.mid_column_values)
        elif search_by.lower() == "rrn":
            elements = self.page.locator(EcentricLocators.rrn_column_values)
        else:
            raise AssertionError(f"Unsupported SearchBy value : {search_by}")
        row_count = elements.count()
        print(f"Number of rows found: {row_count}")
        assert row_count > 0, (f"No records found for {search_value}")
        for i in range(row_count):
            actual_value = elements.nth(i).text_content().strip()
            print(f"Row {i + 1} - Actual Value: {actual_value}")
            assert actual_value.lower() == search_value.lower(), (f"Unexpected row found. "f"Expected : {search_value}, "f"Actual : {actual_value}")

    def verify_default_transaction_date(self, bank: str, data: dict):
        actual_value = self.get_text(self.locator(EcentricLocators.selected_date_filter), "Transaction Date Default Value").strip()
        print("Default Date Filter :", actual_value)
        assert "today" in actual_value.lower(), (f"Expected default date filter to be Today, "f"but found: {actual_value}")
        today_date = datetime.now().strftime("%d %b, %Y")
        date_elements = self.page.locator(EcentricLocators.transaction_date_values)
        row_count = date_elements.count()
        print(f"Number of transaction rows found: {row_count}")
        assert row_count > 0, "No transaction records found"
        for i in range(row_count):
            actual_date = (date_elements.nth(i).text_content().strip())
            print(f"Row {i+1} Date : {actual_date}")
            assert today_date in actual_date, (f"Date mismatch in row {i+1}. "f"Expected date: {today_date}, "f"Actual date: {actual_date}")

    def select_calendar_date(self, date_str):
        target_date = datetime.strptime(date_str, "%d-%b-%Y")  
        month_year = target_date.strftime("%m/%d/%Y")
        aria_label = f"{target_date.month}/{target_date.day}/{target_date.year}"
        while True:
            current_month = self.get_text(self.locator("//button[contains(@class,'mat-calendar-period-button')]"), "Current Month").strip()
            current_dt = datetime.strptime(current_month, "%m/%d/%Y")
            current_key = current_dt.year * 12 + current_dt.month
            target_key = target_date.year * 12 + target_date.month
            if current_key == target_key:
                break
            elif current_key > target_key:
                self.click_by_locator(EcentricLocators.previous_month, "Previous Month")
            else:
                self.click_by_locator(EcentricLocators.next_month, "Next Month")
        self.click_by_locator(EcentricLocators.calendar_date.format(aria_label), f"Date {date_str}")

    def verify_custom_date_range(self, bank: str, data: dict):
        from_date = data["FromDate"].strip()
        to_date = data["ToDate"].strip()
        print(type(data["FromDate"]))
        print(data["FromDate"])
        print(type(data["ToDate"]))
        print(data["ToDate"])
        self.click_by_locator(EcentricLocators.date_filter_dropdown, "Date Filter")
        self.click_by_locator(EcentricLocators.custom_range_option, "Custom Range")
        self.select_calendar_date(from_date)
        self.page.wait_for_timeout(1000)
        self.select_calendar_date(to_date)
        self.click_by_locator(EcentricLocators.apply_button, "Apply Button")
        self.click_by_locator(EcentricLocators.search_button, "search button")
        self.page.wait_for_timeout(3000)
        start_date = datetime.strptime(from_date, "%d-%b-%Y").date()
        end_date = datetime.strptime(to_date, "%d-%b-%Y").date()
        dates = self.page.locator(EcentricLocators.transaction_date_values)
        count = dates.count()
        print(f"Number of transaction rows found: {count}")
        assert count > 0, "No records found"
        for i in range(count):
            actual_date_text = (dates.nth(i).text_content().strip())
            print(f"Row {i+1}: {actual_date_text}")
            actual_date = datetime.strptime(actual_date_text, "%d %b, %Y, %I:%M %p").date()
            assert start_date <= actual_date <= end_date, (f"Date {actual_date} not within range "f"{start_date} to {end_date}")

    def verify_refund_reversal_Icon(self, bank: str, data: dict):
        self.verify_transactions_filters_and_grid_data(bank, data)
        transaction_status = str(data.get("TransactionStatus") or "").strip().lower()
        settlement_status = str(data.get("SettlementStatus") or "").strip().lower()
        rows = self.page.locator(EcentricLocators.transaction_rows)
        row_count = rows.count()
        print(f"Total rows found: {row_count}")
        assert row_count > 0, ("No Success + Settled transactions found")
        for i in range(row_count):
            row = rows.nth(i)
            refund_icon = row.locator(EcentricLocators.refund_icon)
            reversal_icon = row.locator(EcentricLocators.reversal_icon)
            print(f"Validating Actions for Row {i+1}")
            # Success + Settled
            if (transaction_status == "success" and settlement_status == "settled"):
                assert refund_icon.is_enabled(), (f"Row {i+1}: Refund should be enabled")
                assert reversal_icon.is_disabled(), (f"Row {i+1}: Reversal should be disabled")
            # Success + Not Settled
            elif (transaction_status == "success" and settlement_status == "not settled"):
                assert reversal_icon.is_enabled(), (f"Row {i+1}: Reversal should be enabled")
                assert refund_icon.is_disabled(), (f"Row {i+1}: Refund should be disabled")
            # Failed Transaction
            elif transaction_status == "failed":
                assert refund_icon.is_disabled(), (f"Row {i+1}: Refund should be disabled")
                assert reversal_icon.is_disabled(), (f"Row {i+1}: Reversal should be disabled")


    #------------------------------------------------
    def verify_Refund_tab_filters_and_grid_data(self, bank: str, data: dict):
        payment_mode = str(data.get("PaymentMode") or "").strip()
        transaction_status = str(data.get("TransactionStatus") or "").strip()
        date_filter = str(data.get("DateFilter") or "").strip()
        self.click_by_locator(EcentricLocators.refunds_tab,"Refund Tab")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.refund_date_filter_dropdown, "Transaction Date Dropdown")
        self.click_by_locator(EcentricLocators.refund_date_filter_option.format(date_filter),f"Select Date Filter : {date_filter}")
        self.click_by_locator(EcentricLocators.refund_filter_button, "Filter Button")
        if payment_mode:
            self.click_by_locator(EcentricLocators.refund_payment_mode_option.format(payment_mode), f"Payment Mode : {payment_mode}")
        if transaction_status:
            self.click_by_locator(EcentricLocators.refund_status_option.format(transaction_status), f"Status : {transaction_status}")
        self.click_by_locator(EcentricLocators.refund_apply_button, "Apply Filter Button")
        self.page.wait_for_timeout(3000)
        row_count = self.page.locator(EcentricLocators.refund_rows).count()
        print(f"Total rows after filtering: {row_count}")
        assert row_count > 0, "No records found after applying filter"
        if payment_mode:
            rows = self.page.locator(EcentricLocators.refund_payment_mode_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Payment Mode: "f"{actual_value}")
                assert actual_value.lower() == payment_mode.lower(), (f"Row {i+1}: Expected Payment Mode " f"'{payment_mode}', Got '{actual_value}'")
        if transaction_status:
            rows = self.page.locator(EcentricLocators.refund_status_grid_values)
            for i in range(rows.count()):
                actual_value = rows.nth(i).text_content().strip()
                print(f"Row {i+1} Transaction Status: "f"{actual_value}")
                assert actual_value.lower() == transaction_status.lower(), (f"Row {i+1}: Expected Transaction Status " f"'{transaction_status}', Got '{actual_value}'")

    def verify_Refund_tab_search_and_grid_values(self, bank: str, data: dict):
        search_by = str(data.get("SearchBy") or "").strip()
        search_value = str(data.get("SearchValue") or "").strip()
        date_filter = str(data.get("DateFilter") or "").strip()
        self.click_by_locator(EcentricLocators.refunds_tab,"Refund Tab")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.date_filter_dropdown,"Transaction Date Dropdown")
        self.click_by_locator(EcentricLocators.date_filter_option.format(date_filter), f"Select Date Filter : {date_filter}")
        self.fill_by_locator(EcentricLocators.search_field, search_value, "Search Field")
        self.click_by_locator(EcentricLocators.search_button, "Search Button")
        self.page.wait_for_timeout(2000)
        if search_by.lower() == "payment id":
            elements = self.page.locator(EcentricLocators.payment_id_column_values)
        elif search_by.lower() == "merchant track id":
            elements = self.page.locator(EcentricLocators.merchant_trackID_column_values)
        else:
            raise AssertionError(f"Unsupported SearchBy value : {search_by}")
        row_count = elements.count()
        print(f"Number of rows found: {row_count}")
        assert row_count > 0, (f"No records found for {search_value}")
        for i in range(row_count):
            actual_value = elements.nth(i).text_content().strip()
            print(f"Row {i + 1} - Actual Value: {actual_value}")
            assert actual_value.lower() == search_value.lower(), (f"Unexpected row found. "f"Expected : {search_value}, "f"Actual : {actual_value}")

    def verify_Refund_tab_default_transaction_date(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.refunds_tab,"Refund Tab")
        self.page.wait_for_timeout(2000)
        actual_value = self.get_text(self.locator(EcentricLocators.selected_date_filter), "Transaction Date Default Value").strip()
        print("Default Date Filter :", actual_value)
        assert "today" in actual_value.lower(), (f"Expected default date filter to be Today, "f"but found: {actual_value}")
        today_date = datetime.now().strftime("%d %b, %Y")
        date_elements = self.page.locator(EcentricLocators.transaction_date_values)
        row_count = date_elements.count()
        print(f"Number of transaction rows found: {row_count}")
        assert row_count > 0, "No transaction records found"
        for i in range(row_count):
            actual_date = (date_elements.nth(i).text_content().strip())
            print(f"Row {i+1} Date : {actual_date}")
            assert today_date in actual_date, (f"Date mismatch in row {i+1}. "f"Expected date: {today_date}, "f"Actual date: {actual_date}")

    def verify_Refund_tab_custom_date_range(self, bank: str, data: dict):
        from_date = data["FromDate"].strip()
        to_date = data["ToDate"].strip()
        print(type(data["FromDate"]))
        print(data["FromDate"])
        print(type(data["ToDate"]))
        print(data["ToDate"])
        self.click_by_locator(EcentricLocators.refunds_tab,"Refund Tab")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.date_filter_dropdown, "Date Filter")
        self.click_by_locator(EcentricLocators.custom_range_option, "Custom Range")
        self.select_calendar_date(from_date)
        self.page.wait_for_timeout(1000)
        self.select_calendar_date(to_date)
        self.click_by_locator(EcentricLocators.apply_button, "Apply Button")
        self.click_by_locator(EcentricLocators.search_button, "search button")
        self.page.wait_for_timeout(3000)
        start_date = datetime.strptime(from_date, "%d-%b-%Y").date()
        end_date = datetime.strptime(to_date, "%d-%b-%Y").date()
        dates = self.page.locator(EcentricLocators.transaction_date_values)
        count = dates.count()
        print(f"Number of transaction rows found: {count}")
        assert count > 0, "No records found"
        for i in range(count):
            actual_date_text = (dates.nth(i).text_content().strip())
            print(f"Row {i+1}: {actual_date_text}")
            actual_date = datetime.strptime(actual_date_text, "%d,%b %Y %I:%M %p").date()
            assert start_date <= actual_date <= end_date, (f"Date {actual_date} not within range "f"{start_date} to {end_date}")

    def verify_column_customization(self, bank: str, data: dict):
        columns_to_hide = [column.strip() for column in data["ColumnsToHide"].split(",") if column.strip()]
        if data["TestcaseID"] == "TC-BTRX-030":
            self.click_by_locator(EcentricLocators.refunds_tab,"Refund Tab")
            self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.column_customization_button, "Column Customization Button")
        # Verify all columns are selected by default
        checkboxes = self.page.locator(EcentricLocators.all_column_checkboxes)
        checkbox_count = checkboxes.count()
        print(f"Total Column Options : {checkbox_count}")
        for i in range(checkbox_count):
            checkbox = checkboxes.nth(i)
            class_value = (checkbox.get_attribute("class") or "")
            assert ("mat-mdc-checkbox-checked" in class_value), (f"Checkbox at position {i + 1} " f"is not selected by default")
        print("All column options are selected by default")    
        # Unselect columns from Excel
        for column in columns_to_hide:
            self.click_by_locator(EcentricLocators.column_checkbox.format(column), f"Unselect Column : {column}")
        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(2000)
        for column in columns_to_hide:
            header = self.page.locator(EcentricLocators.column_header.format(column))
            assert header.count() == 0, (f"Column '{column}' is still visible in grid")
            print(f"Column '{column}' is hidden successfully")





