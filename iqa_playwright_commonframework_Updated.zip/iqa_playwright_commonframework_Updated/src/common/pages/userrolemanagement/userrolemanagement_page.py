from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.userrolemanagement_locators import UserrolemanagementLocators as EcentricUserrolemanagementLocators, UserrolemanagementLocatorsNegative as EcentricUserrolemanagementLocatorsNegative


class UserrolemanagementPage(BasePage):
    def __init__(self, page, module_name="Userrolemanagement"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_standard, EcentricUserrolemanagementLocators),
        }

    # -------------------- Navigation --------------------

    def navigate_to_user_role_management(self, bank: str) -> None:
        """Navigate to User role management page via Administration menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_user_administration, "User administration submenu")
        self.click_by_locator(loc.menu_user_role_management, "User role management submenu")

    # -------------------- ADD ACTION --------------------

    def click_add_button(self, bank: str) -> None:
        """Click the Add button to open Add user role form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_user_role_form(self, bank: str, data: dict) -> None:
        """Fill Role name and Role description fields."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Standard add flow for user role."""
        self.fill_by_locator(loc.role_name_input, data["Role Name"], "Role Name")
        self.fill_by_locator(loc.role_description_input, data["Role Description"], "Role Description")

    def verify_product_and_sub_product(self, bank: str, data: dict) -> None:
        """Verify Product and Sub product/Portal fields display correct values."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.product_field), data["Product"], "Product")
        self.assert_text(self.locator(loc.sub_product_field), data["Sub Product/Portal"], "Sub Product/Portal")

    def verify_status_active_selected_by_default(self, bank: str) -> None:
        """Verify Status Active radio is selected by default."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.status_active_radio), "Status Active radio selected")

    def verify_menu_legend(self, bank: str) -> None:
        """Verify menu legend shows Fully/Partially/Not selected icons."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.menu_legend), "Menu legend")

    def scroll_and_select_menus(self, bank: str, data: dict) -> None:
        """Scroll through menu list and select specified menus."""
        _, loc = self._dispatch[bank.lower()]
        menu_names = [m.strip() for m in data["Menu Selections"].split(",")]
        for menu_name in menu_names:
            checkbox_locator = loc.menu_checkbox_template.format(menu_name=menu_name)
            self.click_by_locator(checkbox_locator, f"Checkbox for {menu_name}")

    def expand_first_selected_menu(self, bank: str, data: dict) -> None:
        """Expand first selected menu to verify sub-menus are displayed."""
        _, loc = self._dispatch[bank.lower()]
        first_menu = data["Menu Selections"].split(",")[0].strip()
        expand_locator = loc.menu_expand_arrow_template.format(menu_name=first_menu)
        self.click_by_locator(expand_locator, f"Expand arrow for {first_menu}")

    def click_save_button(self, bank: str) -> None:
        """Click Save button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        message_locator = loc.success_message.format(message=expected_message)
        self.assert_visible(self.locator(message_locator), f"Success message: {expected_message}")

    def search_user_role(self, bank: str, role_name: str) -> None:
        """Search for a user role by name."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, role_name, "Search user role input")
        self.click_by_locator(loc.search_button, "Search button")

    def assert_role_in_listing(self, bank: str, data: dict) -> None:
        """Assert role is displayed in listing with correct details."""
        _, loc = self._dispatch[bank.lower()]
        role_row = loc.row_by_role_name.format(role_name=data["Role Name"])
        self.assert_visible(self.locator(role_row), f"Role row for {data['Role Name']}")

    def assert_listing_total_count(self, bank: str, expected_count: str) -> None:
        """Assert total item count in listing."""
        _, loc = self._dispatch[bank.lower()]
        total_message = f"Total {expected_count} items"
        self.assert_visible(self.locator(loc.success_message.format(message=total_message)), f"Total {expected_count} items")

    # -------------------- EDIT ACTION --------------------

    def click_edit_button_for_role(self, bank: str, role_name: str) -> None:
        """Click edit button for the role in the listing."""
        _, loc = self._dispatch[bank.lower()]
        edit_locator = loc.edit_button_in_row.format(role_name=role_name)
        self.click_by_locator(edit_locator, f"Edit button for {role_name}")

    def verify_edit_page_displays(self, bank: str, data: dict) -> None:
        """Verify edit page is displayed with correct role details."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.role_name_input), data["Role Name"], "Role Name on edit page")
        self.assert_text(self.locator(loc.role_description_input), data["Role Description"], "Role Description on edit page")

    def update_role_description(self, bank: str, new_description: str) -> None:
        """Update role description field."""
        _, loc = self._dispatch[bank.lower()]
        self.clear_field(loc.role_description_input, "Role Description input")
        self.fill_by_locator(loc.role_description_input, new_description, "Updated Role Description")

    def toggle_menu_selection(self, bank: str, menu_name: str) -> None:
        """Toggle selection state of a specific menu using eye icon."""
        _, loc = self._dispatch[bank.lower()]
        menu_toggle = loc.menu_checkbox_template.format(menu_name=menu_name)
        self.click_by_locator(menu_toggle, f"Toggle eye icon for {menu_name}")

    def click_update_button(self, bank: str) -> None:
        """Click Update button to save changes."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    # -------------------- DELETE ACTION --------------------

    def click_delete_button_for_role(self, bank: str, role_name: str) -> None:
        """Click delete button for the role in the listing."""
        _, loc = self._dispatch[bank.lower()]
        delete_locator = loc.delete_button_in_row.format(role_name=role_name)
        self.click_by_locator(delete_locator, f"Delete button for {role_name}")

    def verify_delete_confirmation_dialog(self, bank: str, role_name: str) -> None:
        """Verify delete confirmation dialog is displayed with correct messages."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.delete_confirmation_message), "Delete confirmation message")
        self.assert_visible(self.locator(loc.delete_confirmation_detail), f"Confirmation detail for {role_name}")

    def confirm_delete_action(self, bank: str) -> None:
        """Click Delete button in confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirm_button, "Delete confirmation button")

    def assert_delete_success_message(self, bank: str, role_name: str, expected_message: str) -> None:
        """Assert delete success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        message_with_role = expected_message.format(role_name=role_name)
        message_locator = loc.success_message.format(message=message_with_role)
        self.assert_visible(self.locator(message_locator), f"Delete success message")

    def verify_no_records_found(self, bank: str) -> None:
        """Verify no records found message after searching for deleted role."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.no_records_message), "No records found message")

    def add_user_role_negative(self, bank: str, data: dict) -> None:
        """Perform add user role with negative data and assert error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")
        self._add_user_role_negative(bank, loc, data)

    def _add_user_role_negative(self, bank: str, loc, data: dict) -> None:
        """Fill form with negative data and validate error message."""
        # Fill Role Name
        if "Role Name" in data and data["Role Name"]:
            self.fill_by_locator(loc.role_name_input, data["Role Name"], "Role Name")

        # Fill Role Description
        if "Role Description" in data and data["Role Description"]:
            self.fill_by_locator(loc.role_description_input, data["Role Description"], "Role Description")

        # Fill Product if provided
        if "Product" in data and data["Product"]:
            self.select_custom_dropdown(loc.product_field, data["Product"])

        # Fill Sub Product/Portal if provided
        if "Sub Product/Portal" in data and data["Sub Product/Portal"]:
            self.select_custom_dropdown(loc.sub_product_field, data["Sub Product/Portal"])

        # Fill Menu Selections if provided
        if "Menu Selections" in data and data["Menu Selections"] and data["Menu Selections"].strip():
            menu_names = [m.strip() for m in data["Menu Selections"].split(",") if m.strip()]
            for menu_name in menu_names:
                checkbox_locator = loc.menu_checkbox_template.format(menu_name=menu_name)
                self.click_by_locator(checkbox_locator, f"Checkbox for {menu_name}")

        # Click Save and assert error message
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_negative_error(bank, loc, data)

    def _assert_negative_error(self, bank: str, loc, data: dict) -> None:
        """Assert the expected error message is displayed."""
        if not data.get("ExpectedMessage") or data["ExpectedMessage"] == "TBD-verify-message":
            # For TBD messages, just verify that some error is visible
            self.assert_visible(self.locator(loc.generic_error_message), "Error message displayed")
        else:
            expected_msg = data["ExpectedMessage"]
            # Try field-level error first, then generic error
            error_locator = loc.error_message_by_text.format(value=expected_msg)
            if self.locator(error_locator).count() > 0:
                self.assert_visible(self.locator(error_locator), f"Error message: {expected_msg}")
            else:
                # Fallback to toast message
                toast_locator = loc.toast_message_by_text.format(value=expected_msg)
                self.assert_visible(self.locator(toast_locator), f"Toast message: {expected_msg}")

    def edit_user_role_negative(self, bank: str, data: dict) -> None:
        """Perform edit user role with negative data and assert error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        
        # Search for the role to edit
        if "Role Name" in data and data["Role Name"]:
            self.search_user_role(bank, data["Role Name"])
            self.click_edit_button_for_role(bank, data["Role Name"])
        
        # Update Role Description if it contains the negative test data
        if "Role Description" in data and data["Role Description"]:
            self.clear_field(loc.role_description_input, "Role Description input")
            self.fill_by_locator(loc.role_description_input, data["Role Description"], "Role Description")

        # Update Updated Role Description if it contains the negative test data
        if "Updated Role Description" in data and data["Updated Role Description"]:
            # First clear and fill the original description field to prepare for update
            self.clear_field(loc.role_description_input, "Role Description input")
            self.fill_by_locator(loc.role_description_input, data["Updated Role Description"], "Updated Role Description")

        # Toggle Menu if provided and not empty
        if "Toggle Menu Name" in data and data["Toggle Menu Name"] and data["Toggle Menu Name"].strip():
            menu_name = data["Toggle Menu Name"].strip()
            menu_toggle = loc.menu_checkbox_template.format(menu_name=menu_name)
            self.click_by_locator(menu_toggle, f"Toggle for {menu_name}")

        # Click Update and assert error message
        self.click_by_locator(loc.update_button, "Update button")
        self._assert_negative_error(bank, loc, data)


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
class UserrolemanagementPageNegative(UserrolemanagementPage):
    """Negative test page for User role management - inherits all positive methods and adds negative flows."""

    def __init__(self, page, module_name="Userrolrmanagement"):
        super().__init__(page, module_name=module_name)
        self._dispatch_negative = {
            "ecentric": (self._add_user_role_negative, EcentricUserrolemanagementLocatorsNegative),
        }

    # -------------------- ADD NEGATIVE FLOWS --------------------

    # -------------------- EDIT NEGATIVE FLOWS --------------------
