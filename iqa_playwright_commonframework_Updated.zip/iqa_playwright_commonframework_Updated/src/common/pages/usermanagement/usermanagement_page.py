from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.usermanagement_locators import UsermanagementLocators as EcentricUsermanagementLocators, UsermanagementLocatorsNegative
from src.common.utilities.dropdown_helper import select_mat_option


class UsermanagementPage(BasePage):
    def __init__(self, page, module_name="Usermanagement"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_standard, EcentricUsermanagementLocators),
        }

    # -------------------- ADD ACTION --------------------

    def navigate_to_usermanagement(self, bank: str) -> None:
        """Navigate to User Management page via Administration menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_user_administration, "User administration submenu")
        self.click_by_locator(loc.menu_user_management, "User management submenu")

    def click_add_button(self, bank: str) -> None:
        """Click the Add button to open Add New User form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_usermanagement_form(self, bank: str, data: dict) -> None:
        """Fill the Add/Edit user form with provided data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Fill standard user form fields."""
        self.fill_by_locator(loc.user_full_name_input, data["User full name"], "User full name")
        
        # Select Persona type
        select_mat_option(self.page, loc.persona_type_dropdown, data["Persona type"], 'Persona type')
        
        # Select Persona reference ID
        select_mat_option(self.page, loc.persona_reference_id_dropdown, data["Persona reference ID"], 'Persona reference ID')
        
        # Verify Product and Sub product/Portal are pre-filled (read-only)
        self.assert_visible(loc.product_field, "Product field (ACQUIRING PG)")
        self.assert_visible(loc.sub_product_field, "Sub product/Portal field (ACQUIRING PG BANK)")
        
        # Select Role
        select_mat_option(self.page, loc.role_dropdown, data["Role"], 'Role')
        
        # Fill User name
        self.fill_by_locator(loc.user_name_input, data["User name"], "User name")
        
        # Fill Email
        self.fill_by_locator(loc.email_input, data["Email"], "Email")
        
        # Select country code
        select_mat_option(self.page, loc.country_code_dropdown, data["Country code"], 'Country code')
        
        # Fill Mobile number
        self.fill_by_locator(loc.mobile_number_input, data["Mobile number"], "Mobile number")
        
        # Select Authentication source
        auth_source_radio = loc.authentication_source_radio_template.format(value=data["Authentication source"])
        self.click_by_locator(auth_source_radio, "Authentication source radio")
        
        # Verify Status is Active (read-only)
        self.assert_visible(loc.status_field, "Status field (Active)")

    def click_save_button(self, bank: str) -> None:
        """Click the Save button to create user."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_add_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message is displayed after user creation."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.message_container, "Success message")

    # -------------------- VIEW ACTION --------------------

    def search_user(self, bank: str, data: dict) -> None:
        """Search for user by name in the search textbox."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_user_textbox, data["Search value"], "Search user textbox")
        self.click_by_locator(loc.search_button, "Search button")

    def assert_user_in_listing(self, bank: str, data: dict) -> None:
        """Assert user appears in the listing with correct details."""
        _, loc = self._dispatch[bank.lower()]
        user_link = loc.user_name_link_template.format(user_name=data["User name"])
        self.assert_visible(user_link, "User name link in listing")

    def click_user_name_link(self, bank: str, data: dict) -> None:
        """Click the user name link to open user details page."""
        _, loc = self._dispatch[bank.lower()]
        user_link = loc.user_name_link_template.format(user_name=data["User name"])
        self.click_by_locator(user_link, "User name link")

    def assert_user_details_page_displayed(self, bank: str) -> None:
        """Assert the user details summary page is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.user_details_page_header, "User details page header")
        self.assert_visible(loc.breadcrumb, "Breadcrumb navigation")

    def assert_user_details_values(self, bank: str, data: dict) -> None:
        """Assert all user details are correctly displayed on the view page."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.view_user_full_name, "User full name in details")
        self.assert_visible(loc.view_persona_type, "Persona type in details")
        self.assert_visible(loc.view_persona_reference_id, "Persona reference ID in details")
        self.assert_visible(loc.view_product, "Product in details")
        self.assert_visible(loc.view_sub_product, "Sub product/portal in details")
        self.assert_visible(loc.view_role, "Role in details")
        self.assert_visible(loc.view_user_name, "User name in details")
        self.assert_visible(loc.view_email, "Email in details")
        self.assert_visible(loc.view_mobile_number, "Mobile number in details")
        self.assert_visible(loc.view_authentication_source, "Authentication source in details")
        self.assert_visible(loc.view_idp_provider, "IDP provider in details")
        self.assert_visible(loc.view_fusion_auth_provider, "Fusion auth provider in details")
        self.assert_visible(loc.view_status, "Status in details")

    def assert_user_action_buttons(self, bank: str) -> None:
        """Assert Delete and Edit buttons are present on user details page."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.delete_button, "Delete button")
        self.assert_visible(loc.edit_button, "Edit button")

    # -------------------- EDIT ACTION --------------------

    def click_edit_button(self, bank: str) -> None:
        """Click the Edit button to open Edit user form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button, "Edit button")

    def assert_edit_form_displayed(self, bank: str, data: dict) -> None:
        """Assert the Edit user page is displayed with current values."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.user_full_name_input, "User full name input")
        self.assert_visible(loc.user_name_readonly, "User name (read-only)")
        self.assert_visible(loc.password_recovery_button, "Send password recovery mail button")
        self.assert_visible(loc.update_button, "Update button")

    def fill_edit_form(self, bank: str, data: dict) -> None:
        """Fill the Edit user form with updated data."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.user_full_name_input, data["User full name"], "User full name")
        self.fill_by_locator(loc.mobile_number_input, data["Mobile number"], "Mobile number")

    def click_update_button(self, bank: str) -> None:
        """Click the Update button to save user changes."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    def assert_edit_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message after user update."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.message_container, "Success message")

    # -------------------- DELETE ACTION --------------------

    def click_delete_button(self, bank: str) -> None:
        """Click the Delete button to open delete confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_button, "Delete button")

    def assert_delete_confirmation_displayed(self, bank: str) -> None:
        """Assert the delete confirmation dialog is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.delete_confirmation_message, "Delete confirmation message")
        self.assert_visible(loc.delete_confirmation_detail, "Delete confirmation detail")
        self.assert_visible(loc.delete_cancel_button, "Cancel button")
        self.assert_visible(loc.delete_yes_button, "Yes button")

    def click_delete_yes_button(self, bank: str) -> None:
        """Click Yes button in delete confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_yes_button, "Yes button")

    def assert_delete_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message after user deletion."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.message_container, "Success message")

    def assert_user_not_in_listing(self, bank: str, data: dict) -> None:
        """Assert user no longer appears in the listing after deletion."""
        _, loc = self._dispatch[bank.lower()]
        user_link = loc.user_name_link_template.format(user_name=data["User name"])
        self.assert_not_visible(user_link, "User name link (should not exist)")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
def _v(data: dict, snake_key: str, pascal_key: str = "") -> str:
    """Extract and normalize a value from data dict by key variants."""
    if snake_key in data and data[snake_key] is not None:
        return str(data[snake_key]).strip()
    if pascal_key and pascal_key in data and data[pascal_key] is not None:
        return str(data[pascal_key]).strip()
    return ""


class UsermanagementPageNegative(UsermanagementPage):
    """Negative test page class for User Management - extends positive page with negative methods."""

    def __init__(self, page, module_name="UsermanagementNegative"):
        super().__init__(page, module_name=module_name)
        # Override dispatch to use negative locators
        self._dispatch = {
            "ecentric": (self._add_standard_negative, UsermanagementLocatorsNegative),
        }

    # -------------------- ADD NEGATIVE ACTION --------------------

    def add_usermanagement_negative(self, bank: str, data: dict) -> None:
        """Execute negative add user flow and assert error message."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_negative_message(loc, data)

    def _add_standard_negative(self, loc, data: dict) -> None:
        """Fill standard user form with negative test data (one field invalid, others valid)."""
        baseline = {
            "User full name": "testtest_baseline",
            "Persona type": "Bank",
            "Persona reference ID": "ECE_baseline",
            "Role": "FSS Super Admin",
            "User name": "testetst_baseline",
            "Email": "test_baseline@gmail.com",
            "Country code": "12345678",
            "Mobile number": "1454451370",
            "Authentication source": "IHA",
        }

        # Fill with baseline or test value depending on which field is under test
        user_full_name = _v(data, "user_full_name", "User full name")
        if not user_full_name:
            user_full_name = baseline["User full name"]
        self.fill_by_locator(loc.user_full_name_input, user_full_name, "User full name")

        # Select Persona type
        persona_type = _v(data, "persona_type", "Persona type")
        if not persona_type:
            persona_type = baseline["Persona type"]
        select_mat_option(self.page, loc.persona_type_dropdown, persona_type, 'Persona type')

        # Select Persona reference ID
        persona_ref = _v(data, "persona_reference_id", "Persona reference ID")
        if not persona_ref:
            persona_ref = baseline["Persona reference ID"]
        select_mat_option(self.page, loc.persona_reference_id_dropdown, persona_ref, 'Persona reference ID')

        # Verify Product and Sub product (read-only)
        self.assert_visible(loc.product_field, "Product field (ACQUIRING PG)")
        self.assert_visible(loc.sub_product_field, "Sub product/Portal field (ACQUIRING PG BANK)")

        # Select Role
        role = _v(data, "role", "Role")
        if not role:
            role = baseline["Role"]
        select_mat_option(self.page, loc.role_dropdown, role, 'Role')

        # Fill User name
        user_name = _v(data, "user_name", "User name")
        if not user_name:
            user_name = baseline["User name"]
        self.fill_by_locator(loc.user_name_input, user_name, "User name")

        # Fill Email
        email = _v(data, "email", "Email")
        if not email:
            email = baseline["Email"]
        self.fill_by_locator(loc.email_input, email, "Email")

        # Select country code
        country_code = _v(data, "country_code", "Country code")
        if not country_code:
            country_code = baseline["Country code"]
        select_mat_option(self.page, loc.country_code_dropdown, country_code, 'Country code')

        # Fill Mobile number
        mobile_number = _v(data, "mobile_number", "Mobile number")
        if not mobile_number:
            mobile_number = baseline["Mobile number"]
        self.fill_by_locator(loc.mobile_number_input, mobile_number, "Mobile number")

        # Select Authentication source
        auth_source = _v(data, "authentication_source", "Authentication source")
        if not auth_source:
            auth_source = baseline["Authentication source"]
        auth_source_radio = loc.authentication_source_radio_template.format(value=auth_source)
        self.click_by_locator(auth_source_radio, "Authentication source radio")

        # Verify Status is Active (read-only)
        self.assert_visible(loc.status_field, "Status field (Active)")

    def _assert_negative_message(self, loc, data: dict) -> None:
        """Assert error message is displayed for negative test case."""
        expected_msg = data.get("ExpectedMessage", "").strip()
        if not expected_msg or expected_msg == "TBD-verify-message":
            # If no specific message, just verify an error is shown somewhere
            self.assert_visible(loc.any_mat_error, "Some validation error message")
            return

        # Try to find the error message in the UI
        error_locator = loc.error_message_by_text.format(value=expected_msg)
        if self.page.locator(error_locator).count() > 0:
            self.assert_visible(error_locator, f"Error message: {expected_msg}")
        else:
            # Fall back to generic error visibility
            self.assert_visible(loc.any_mat_error, f"Validation error (expected: {expected_msg})")

    # -------------------- EDIT NEGATIVE ACTION --------------------

    def edit_usermanagement_negative(self, bank: str, data: dict) -> None:
        """Execute negative edit user flow: search, click edit, update one field with invalid value, assert error."""
        _, loc = self._dispatch[bank.lower()]
        
        # Search for the user
        search_value = _v(data, "search_value", "Search value")
        if search_value and search_value != "   ":
            self.fill_by_locator(loc.search_user_textbox, search_value, "Search user textbox")
            self.click_by_locator(loc.search_button, "Search button")
            # If search fails due to invalid input, we still want to verify the error
            self._assert_negative_message(loc, data)
            return

        if not search_value or search_value == "   ":
            # Search with blank/spaces - should show error or fail gracefully
            self.fill_by_locator(loc.search_user_textbox, search_value or "", "Search user textbox")
            self.click_by_locator(loc.search_button, "Search button")
            self._assert_negative_message(loc, data)
            return

    def edit_usermanagement_field_negative(self, bank: str, data: dict) -> None:
        """Edit user with one invalid field value (assumes user already found and edit form open)."""
        _, loc = self._dispatch[bank.lower()]
        
        baseline = {
            "User full name": "testtest_baseline",
            "Mobile number": "1454451370",
        }

        # Fill with baseline or test value
        user_full_name = _v(data, "user_full_name", "User full name")
        if not user_full_name:
            user_full_name = baseline["User full name"]
        self.fill_by_locator(loc.user_full_name_input, user_full_name, "User full name")

        # Fill Mobile number
        mobile_number = _v(data, "mobile_number", "Mobile number")
        if not mobile_number:
            mobile_number = baseline["Mobile number"]
        self.fill_by_locator(loc.mobile_number_input, mobile_number, "Mobile number")

        # Click Update button
        self.click_by_locator(loc.update_button, "Update button")
        self._assert_negative_message(loc, data)
