from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.riskprofile_locators import EcentricRiskprofileLocators as EcentricRiskprofileLocators

BANK_LOCATORS = {
    "ecentric": EcentricRiskprofileLocators,
}

class RiskprofilePage(BasePage):
    def __init__(self, page, module_name="Riskprofile"):
        super().__init__(page, module_name=module_name)

    def navigate_to_riskprofile(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_risk_setup, "Risk setup submenu")
        self.click_by_locator(loc.menu_pg, "PG submenu")
        self.click_by_locator(loc.risk_profile_tab, "Risk profile tab")

    def click_add_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_riskprofile_form(self, bank: str, data: dict) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.fill_by_locator(loc.risk_profile_name_input, data["Risk profile name"], "Risk profile name")
        self.select_dropdown(loc.currency_code_dropdown, data["Currency code"], "Currency code dropdown")
        self.click_by_locator(loc.profile_international_no_radio, "No radio button under Profile international transaction")
        self.click_by_locator(loc.terminal_domestic_daily_toggle, "Daily toggle under Maximum number of transactions allowed in Terminal Domestic")
        self.click_by_locator(loc.terminal_domestic_weekly_toggle, "Weekly toggle under Maximum number of transactions allowed in Terminal Domestic")
        self.click_by_locator(loc.terminal_domestic_monthly_toggle, "Monthly toggle under Maximum number of transactions allowed in Terminal Domestic")
        self.fill_by_locator(loc.terminal_domestic_daily_input, data["No of transactions Daily"], "No of transactions field for Daily")
        self.fill_by_locator(loc.terminal_domestic_weekly_input, data["No of transactions Weekly"], "No of transactions field for Weekly")
        self.fill_by_locator(loc.terminal_domestic_monthly_input, data["No of transactions Monthly"], "No of transactions field for Monthly")
        self.click_by_locator(loc.cumulative_transaction_daily_toggle, "Daily toggle under Cumulative transaction amount in Terminal Domestic")
        self.click_by_locator(loc.cumulative_refund_daily_toggle, "Daily toggle under Cumulative refund amount in Terminal Domestic")
        self.click_by_locator(loc.terminal_blocking_radio, "Terminal blocking radio button under Terminal Actions")
        self.fill_by_locator(loc.transaction_amount_min_input, data["Minimum amount"], "Minimum amount field under Transaction amount allowed")
        self.fill_by_locator(loc.transaction_amount_max_input, data["Maximum amount"], "Maximum amount field under Transaction amount allowed")
        self.click_by_locator(loc.user_domestic_daily_toggle, "Daily toggle under Maximum number of transactions allowed in User Domestic")
        self.click_by_locator(loc.card_blocking_radio, "Card blocking radio button under User Actions")
        self.click_by_locator(loc.ip_domestic_daily_toggle, "Daily toggle under Maximum number of transactions allowed in IP Domestic")
        self.click_by_locator(loc.ip_blocking_radio, "IP blocking radio button under IP Actions")

    def click_save_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_riskprofile_success_message(self, bank: str, expected_message: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message")

    def fill_search_form(self, bank: str, data: dict) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.fill_by_locator(loc.search_risk_profile_name_input, data["Risk profile name"], "Risk profile name")
        self.fill_by_locator(loc.search_currency_input, data["Currency code"], "Currency code")
        self.select_dropdown(loc.mode_dropdown, data["Mode"], "Mode dropdown")

    def click_search_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.search_button, "Search button")

    def assert_search_result_displayed(self, bank: str, risk_profile_name: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        row_locator = loc.risk_profile_row_by_name(risk_profile_name)
        self.assert_visible(self.locator(row_locator), f"Risk profile '{risk_profile_name}' row in search results")
