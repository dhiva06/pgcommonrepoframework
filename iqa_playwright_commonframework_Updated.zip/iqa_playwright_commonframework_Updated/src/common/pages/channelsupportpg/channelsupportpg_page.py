from src.banks.ecentric.locators.channelsupportpg_locators import ChannelsupportpgLocators as EcentricChannelsupportpgLocators
from src.common.base.base_page import BasePage


class ChannelsupportpgPage(BasePage):
    def __init__(self, page, module_name="Channelsupportpg"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._edit_channel_support_pg, EcentricChannelsupportpgLocators),
        }

    # -------------------- Navigation --------------------

    def navigate_to_channel_support_pg(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_pg_configuration, "PG configuration submenu")
        self.assert_visible(self.locator(loc.channel_support_pg_tile), "Channel support - PG tile")

    def click_channel_support_pg_tile(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.channel_support_pg_tile, "Channel support - PG tile")

    def verify_stepper_steps(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.stepper_primary), "Primary step")
        self.assert_visible(self.locator(loc.stepper_terminal_configurations), "Terminal configurations step")
        self.assert_visible(self.locator(loc.stepper_merchant_services), "Merchant services step")

    # -------------------- Step 1: Primary --------------------

    def fill_step1_primary(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self._fill_step1_primary(loc, data)

    def _fill_step1_primary(self, loc, data: dict) -> None:
        self.click_by_locator(loc.api_dropdown, "API dropdown")
        self.click_by_locator(loc.api_option.format(value=data["API"]), "API option")

        self.click_by_locator(loc.hosted_payment_page_dropdown, "Hosted Payment Page dropdown")
        self.click_by_locator(loc.hosted_payment_page_option.format(value=data["Hosted Payment Page"]), "Hosted Payment Page option")

        self.click_by_locator(loc.card_masking_dropdown, "Card masking dropdown")
        self.click_by_locator(loc.card_masking_option.format(value=data["Enable card number masking"]), "Card masking option")

        self.fill_by_locator(loc.gateway_users_allowed_input, data["Number of gateway users allowed"], "Number of gateway users allowed")

        self.fill_by_locator(loc.mpgs_url_input, data["MPGS URL"], "MPGS URL")
        self.fill_by_locator(loc.mpgs_version_input, data["MPGS Version"], "MPGS Version")

        self.fill_by_locator(loc.cybersource_api_url_input, data["Cybersource Service API URL"], "Cybersource Service API URL")
        self.fill_by_locator(loc.cybersource_auth_url_input, data["Cybersource Auth URL"], "Cybersource Auth URL")

    def click_step1_continue(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.step1_continue_button, "Step 1 Continue button")

    def assert_step1_success_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.step1_success_message), expected_message, "Step 1 success message")

    def assert_step2_active(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.stepper_terminal_configurations), "Terminal configurations step active")

    # -------------------- Step 2: Terminal Configurations --------------------

    def fill_step2_terminal_configurations(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self._fill_step2_terminal_configurations(loc, data)

    def _fill_step2_terminal_configurations(self, loc, data: dict) -> None:
        self.fill_by_locator(loc.merchant_users_allowed_input, data["Number of merchant user(s) allowed"], "Number of merchant user(s) allowed")

        self.click_by_locator(loc.merchant_url_auth_dropdown, "Merchant URL authentication dropdown")
        self.click_by_locator(loc.merchant_url_auth_option.format(value=data["Merchant URL authentication"]), "Merchant URL authentication option")

        self.click_by_locator(loc.international_transactions_dropdown, "Enable international transactions dropdown")
        self.click_by_locator(loc.international_transactions_option.format(value=data["Enable international transactions"]), "Enable international transactions option")

        self.click_by_locator(loc.multiple_refunds_dropdown, "Multiple refunds dropdown")
        self.click_by_locator(loc.multiple_refunds_option.format(value=data["Multiple refunds"]), "Multiple refunds option")

        self.click_by_locator(loc.refunds_reversal_dropdown, "Refunds and reversal from portal dropdown")
        self.click_by_locator(loc.refunds_reversal_option.format(value=data["Refunds and reversal from portal"]), "Refunds and reversal from portal option")

        self.fill_by_locator(loc.card_capture_expiry_input, data["Card capture screen expiry time"], "Card capture screen expiry time")

        self.click_by_locator(loc.success_failure_page_dropdown, "Success/Failure page dropdown")
        self.click_by_locator(loc.success_failure_page_option.format(value=data["Success/Failure page"]), "Success/Failure page option")

        self.fill_by_locator(loc.page_timeout_input, data["Page time out"], "Page time out")

        self.click_by_locator(loc.automatic_key_expiry_dropdown, "Automatic key expiry dropdown")
        self.click_by_locator(loc.automatic_key_expiry_option.format(value=data["Automatic key expiry"]), "Automatic key expiry option")

        self.fill_by_locator(loc.expiry_period_input, data["Expiry period"], "Expiry period")

    def click_step2_continue(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.step2_continue_button, "Step 2 Continue button")

    def assert_step2_success_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.step2_success_message), expected_message, "Step 2 success message")

    def assert_step3_active(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.stepper_merchant_services), "Merchant services step active")

    # -------------------- Step 3: Merchant Services --------------------

    def fill_step3_merchant_services(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self._fill_step3_merchant_services(loc, data)

    def _fill_step3_merchant_services(self, loc, data: dict) -> None:
        self.click_by_locator(loc.enable_webstore_dropdown, "Enable webstore dropdown")
        self.click_by_locator(loc.enable_webstore_option.format(value=data["Enable webstore"]), "Enable webstore option")

        self.click_by_locator(loc.enable_webhook_dropdown, "Enable webhook dropdown")
        self.click_by_locator(loc.enable_webhook_option.format(value=data["Enable webhook"]), "Enable webhook option")

        self.click_by_locator(loc.enable_payment_button_dropdown, "Enable payment button dropdown")
        self.click_by_locator(loc.enable_payment_button_option.format(value=data["Enable payment button"]), "Enable payment button option")

        self.click_by_locator(loc.enable_payment_link_dropdown, "Enable payment link dropdown")
        self.click_by_locator(loc.enable_payment_link_option.format(value=data["Enable payment link"]), "Enable payment link option")

        self.click_by_locator(loc.enable_multiple_terminal_dropdown, "Enable multiple terminal dropdown")
        self.click_by_locator(loc.enable_multiple_terminal_option.format(value=data["Enable multiple terminal"]), "Enable multiple terminal option")

        self.fill_by_locator(loc.max_terminals_input, data["Maximum number of terminal(s)"], "Maximum number of terminal(s)")

    def click_step3_continue(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.step3_continue_button, "Step 3 Continue button")

    def assert_step3_success_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.step3_success_message), expected_message, "Step 3 success message")

    # -------------------- Reopen and Verify Values --------------------

    def reopen_channel_support_pg(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_pg_configuration, "PG configuration submenu")
        self.click_by_locator(loc.channel_support_pg_tile, "Channel support - PG tile")

    def assert_step1_values_retained(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.api_dropdown), data["API"], "API retained value")

    def assert_step2_values_retained(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.merchant_users_allowed_input), data["Number of merchant user(s) allowed"], "Merchant users allowed retained value")

    def assert_step3_values_retained(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.max_terminals_input), data["Maximum number of terminal(s)"], "Max terminals retained value")

    def _edit_channel_support_pg(self, loc, data: dict) -> None:
        """Placeholder for future bank-specific edit logic if needed."""
        pass
