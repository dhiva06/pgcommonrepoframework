from src.banks.ecentric.locators.channelsupportpg_locators import ChannelsupportpgLocators as EcentricChannelsupportpgLocators
from src.banks.ecentric.locators.channelsupportpg_negative_locators import ChannelsupportpgLocatorsNegative as EcentricChannelsupportpgLocatorsNegative
from src.common.pages.channelsupportpg.channelsupportpg_page import ChannelsupportpgPage


class ChannelsupportpgPageNegative(ChannelsupportpgPage):
    """Negative test page for Channel Support - PG configuration."""
    
    def __init__(self, page, module_name="ChannelsupportpgNegative"):
        super().__init__(page, module_name=module_name)
        self._dispatch_negative = {
            "ecentric": (self._edit_channel_support_pg_negative, EcentricChannelsupportpgLocatorsNegative),
        }

    # -------------------- Step 1 Negative Cases --------------------

    def fill_step1_primary_negative(self, bank: str, data: dict) -> None:
        """Fill Step 1 with one invalid field and assert error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self._fill_step1_primary_negative(loc, data)

    def _fill_step1_primary_negative(self, loc, data: dict) -> None:
        """Internal method to fill Step 1 fields with negative data."""
        # Fill API
        if data.get("API"):
            self.click_by_locator(loc.api_dropdown, "API dropdown")
            self.click_by_locator(loc.api_option.format(value=data["API"]), "API option")
        else:
            # API is blank - skip selection to trigger validation
            pass

        # Fill Hosted Payment Page
        if data.get("Hosted Payment Page"):
            self.click_by_locator(loc.hosted_payment_page_dropdown, "Hosted Payment Page dropdown")
            self.click_by_locator(loc.hosted_payment_page_option.format(value=data["Hosted Payment Page"]), "Hosted Payment Page option")

        # Fill Card Masking
        if data.get("Enable card number masking"):
            self.click_by_locator(loc.card_masking_dropdown, "Card masking dropdown")
            self.click_by_locator(loc.card_masking_option.format(value=data["Enable card number masking"]), "Card masking option")

        # Fill Gateway Users
        if data.get("Number of gateway users allowed"):
            self.fill_by_locator(loc.gateway_users_allowed_input, data["Number of gateway users allowed"], "Number of gateway users allowed")

        # Fill MPGS URL
        if data.get("MPGS URL"):
            self.fill_by_locator(loc.mpgs_url_input, data["MPGS URL"], "MPGS URL")

        # Fill MPGS Version
        if data.get("MPGS Version"):
            self.fill_by_locator(loc.mpgs_version_input, data["MPGS Version"], "MPGS Version")

        # Fill Cybersource API URL
        if data.get("Cybersource Service API URL"):
            self.fill_by_locator(loc.cybersource_api_url_input, data["Cybersource Service API URL"], "Cybersource Service API URL")

        # Fill Cybersource Auth URL
        if data.get("Cybersource Auth URL"):
            self.fill_by_locator(loc.cybersource_auth_url_input, data["Cybersource Auth URL"], "Cybersource Auth URL")

    def click_step1_continue_and_assert_error_negative(self, bank: str, data: dict) -> None:
        """Click Step 1 Continue button and assert the error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.click_by_locator(loc.step1_continue_button, "Step 1 Continue button")
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Step 1 error message"
        )

    # -------------------- Step 2 Negative Cases --------------------

    def fill_step2_terminal_configurations_negative(self, bank: str, data: dict) -> None:
        """Fill Step 2 with one invalid field and assert error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self._fill_step2_terminal_configurations_negative(loc, data)

    def _fill_step2_terminal_configurations_negative(self, loc, data: dict) -> None:
        """Internal method to fill Step 2 fields with negative data."""
        # Fill Merchant Users
        if data.get("Number of merchant user(s) allowed"):
            self.fill_by_locator(loc.merchant_users_allowed_input, data["Number of merchant user(s) allowed"], "Number of merchant user(s) allowed")

        # Fill Merchant URL Auth
        if data.get("Merchant URL authentication"):
            self.click_by_locator(loc.merchant_url_auth_dropdown, "Merchant URL authentication dropdown")
            self.click_by_locator(loc.merchant_url_auth_option.format(value=data["Merchant URL authentication"]), "Merchant URL authentication option")

        # Fill International Transactions
        if data.get("Enable international transactions"):
            self.click_by_locator(loc.international_transactions_dropdown, "Enable international transactions dropdown")
            self.click_by_locator(loc.international_transactions_option.format(value=data["Enable international transactions"]), "Enable international transactions option")

        # Fill Multiple Refunds
        if data.get("Multiple refunds"):
            self.click_by_locator(loc.multiple_refunds_dropdown, "Multiple refunds dropdown")
            self.click_by_locator(loc.multiple_refunds_option.format(value=data["Multiple refunds"]), "Multiple refunds option")

        # Fill Refunds Reversal
        if data.get("Refunds and reversal from portal"):
            self.click_by_locator(loc.refunds_reversal_dropdown, "Refunds and reversal from portal dropdown")
            self.click_by_locator(loc.refunds_reversal_option.format(value=data["Refunds and reversal from portal"]), "Refunds and reversal from portal option")

        # Fill Card Capture Expiry
        if data.get("Card capture screen expiry time"):
            self.fill_by_locator(loc.card_capture_expiry_input, data["Card capture screen expiry time"], "Card capture screen expiry time")

        # Fill Success/Failure Page
        if data.get("Success/Failure page"):
            self.click_by_locator(loc.success_failure_page_dropdown, "Success/Failure page dropdown")
            self.click_by_locator(loc.success_failure_page_option.format(value=data["Success/Failure page"]), "Success/Failure page option")

        # Fill Page Timeout
        if data.get("Page time out"):
            self.fill_by_locator(loc.page_timeout_input, data["Page time out"], "Page time out")

        # Fill Automatic Key Expiry
        if data.get("Automatic key expiry"):
            self.click_by_locator(loc.automatic_key_expiry_dropdown, "Automatic key expiry dropdown")
            self.click_by_locator(loc.automatic_key_expiry_option.format(value=data["Automatic key expiry"]), "Automatic key expiry option")

        # Fill Expiry Period
        if data.get("Expiry period"):
            self.fill_by_locator(loc.expiry_period_input, data["Expiry period"], "Expiry period")

    def click_step2_continue_and_assert_error_negative(self, bank: str, data: dict) -> None:
        """Click Step 2 Continue button and assert the error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.click_by_locator(loc.step2_continue_button, "Step 2 Continue button")
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Step 2 error message"
        )

    # -------------------- Step 3 Negative Cases --------------------

    def fill_step3_merchant_services_negative(self, bank: str, data: dict) -> None:
        """Fill Step 3 with one invalid field and assert error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self._fill_step3_merchant_services_negative(loc, data)

    def _fill_step3_merchant_services_negative(self, loc, data: dict) -> None:
        """Internal method to fill Step 3 fields with negative data."""
        # Fill Enable Webstore
        if data.get("Enable webstore"):
            self.click_by_locator(loc.enable_webstore_dropdown, "Enable webstore dropdown")
            self.click_by_locator(loc.enable_webstore_option.format(value=data["Enable webstore"]), "Enable webstore option")

        # Fill Enable Webhook
        if data.get("Enable webhook"):
            self.click_by_locator(loc.enable_webhook_dropdown, "Enable webhook dropdown")
            self.click_by_locator(loc.enable_webhook_option.format(value=data["Enable webhook"]), "Enable webhook option")

        # Fill Enable Payment Button
        if data.get("Enable payment button"):
            self.click_by_locator(loc.enable_payment_button_dropdown, "Enable payment button dropdown")
            self.click_by_locator(loc.enable_payment_button_option.format(value=data["Enable payment button"]), "Enable payment button option")

        # Fill Enable Payment Link
        if data.get("Enable payment link"):
            self.click_by_locator(loc.enable_payment_link_dropdown, "Enable payment link dropdown")
            self.click_by_locator(loc.enable_payment_link_option.format(value=data["Enable payment link"]), "Enable payment link option")

        # Fill Enable Multiple Terminal
        if data.get("Enable multiple terminal"):
            self.click_by_locator(loc.enable_multiple_terminal_dropdown, "Enable multiple terminal dropdown")
            self.click_by_locator(loc.enable_multiple_terminal_option.format(value=data["Enable multiple terminal"]), "Enable multiple terminal option")

        # Fill Max Terminals
        if data.get("Maximum number of terminal(s)"):
            self.fill_by_locator(loc.max_terminals_input, data["Maximum number of terminal(s)"], "Maximum number of terminal(s)")

    def click_step3_continue_and_assert_error_negative(self, bank: str, data: dict) -> None:
        """Click Step 3 Continue button and assert the error message."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.click_by_locator(loc.step3_continue_button, "Step 3 Continue button")
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Step 3 error message"
        )

    # -------------------- Edit Negative Cases --------------------

    def edit_channel_support_pg_negative(self, bank: str, data: dict) -> None:
        """Reopen configuration, edit one field with negative data, and assert error."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.reopen_channel_support_pg(bank)
        
        # Determine which step to edit based on the description
        description = data.get("Description", "").lower()
        
        if "step 1" in description or "primary" in description or "api" in description or "hosted payment" in description or "card" in description or "gateway" in description or "mpgs" in description or "cybersource" in description:
            self._edit_step1_negative(loc, data)
        elif "step 2" in description or "terminal" in description or "merchant user" in description or "merchant url" in description or "international" in description or "refund" in description or "expiry" in description or "timeout" in description or "automatic key" in description:
            self._edit_step2_negative(loc, data)
        elif "step 3" in description or "webstore" in description or "webhook" in description or "payment button" in description or "payment link" in description or "multiple terminal" in description or "maximum terminal" in description:
            self._edit_step3_negative(loc, data)

    def _edit_step1_negative(self, loc, data: dict) -> None:
        """Edit Step 1 with one invalid field."""
        description = data.get("Description", "").lower()
        
        if "api" in description:
            self.click_by_locator(loc.api_dropdown, "API dropdown")
            if data.get("API"):
                self.click_by_locator(loc.api_option.format(value=data["API"]), "API option")
        elif "hosted payment" in description:
            self.click_by_locator(loc.hosted_payment_page_dropdown, "Hosted Payment Page dropdown")
            if data.get("Hosted Payment Page"):
                self.click_by_locator(loc.hosted_payment_page_option.format(value=data["Hosted Payment Page"]), "Hosted Payment Page option")
        elif "card" in description or "masking" in description:
            self.click_by_locator(loc.card_masking_dropdown, "Card masking dropdown")
            if data.get("Enable card number masking"):
                self.click_by_locator(loc.card_masking_option.format(value=data["Enable card number masking"]), "Card masking option")
        elif "gateway" in description:
            self.fill_by_locator(loc.gateway_users_allowed_input, data.get("Number of gateway users allowed", ""), "Number of gateway users allowed")
        elif "mpgs url" in description:
            self.fill_by_locator(loc.mpgs_url_input, data.get("MPGS URL", ""), "MPGS URL")
        elif "mpgs version" in description:
            self.fill_by_locator(loc.mpgs_version_input, data.get("MPGS Version", ""), "MPGS Version")
        elif "cybersource" in description and "api url" in description:
            self.fill_by_locator(loc.cybersource_api_url_input, data.get("Cybersource Service API URL", ""), "Cybersource Service API URL")
        elif "cybersource" in description and "auth url" in description:
            self.fill_by_locator(loc.cybersource_auth_url_input, data.get("Cybersource Auth URL", ""), "Cybersource Auth URL")
        
        self.click_step1_continue(data.get("bank", "ecentric"))
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Edit Step 1 error message"
        )

    def _edit_step2_negative(self, loc, data: dict) -> None:
        """Edit Step 2 with one invalid field."""
        description = data.get("Description", "").lower()
        
        if "merchant user" in description:
            self.fill_by_locator(loc.merchant_users_allowed_input, data.get("Number of merchant user(s) allowed", ""), "Number of merchant user(s) allowed")
        elif "merchant url" in description:
            self.click_by_locator(loc.merchant_url_auth_dropdown, "Merchant URL authentication dropdown")
            if data.get("Merchant URL authentication"):
                self.click_by_locator(loc.merchant_url_auth_option.format(value=data["Merchant URL authentication"]), "Merchant URL authentication option")
        elif "international" in description:
            self.click_by_locator(loc.international_transactions_dropdown, "Enable international transactions dropdown")
            if data.get("Enable international transactions"):
                self.click_by_locator(loc.international_transactions_option.format(value=data["Enable international transactions"]), "Enable international transactions option")
        elif "multiple refund" in description:
            self.click_by_locator(loc.multiple_refunds_dropdown, "Multiple refunds dropdown")
            if data.get("Multiple refunds"):
                self.click_by_locator(loc.multiple_refunds_option.format(value=data["Multiple refunds"]), "Multiple refunds option")
        elif "reversal" in description:
            self.click_by_locator(loc.refunds_reversal_dropdown, "Refunds and reversal from portal dropdown")
            if data.get("Refunds and reversal from portal"):
                self.click_by_locator(loc.refunds_reversal_option.format(value=data["Refunds and reversal from portal"]), "Refunds and reversal from portal option")
        elif "card capture" in description:
            self.fill_by_locator(loc.card_capture_expiry_input, data.get("Card capture screen expiry time", ""), "Card capture screen expiry time")
        elif "success" in description or "failure" in description:
            self.click_by_locator(loc.success_failure_page_dropdown, "Success/Failure page dropdown")
            if data.get("Success/Failure page"):
                self.click_by_locator(loc.success_failure_page_option.format(value=data["Success/Failure page"]), "Success/Failure page option")
        elif "page time out" in description or "timeout" in description:
            self.fill_by_locator(loc.page_timeout_input, data.get("Page time out", ""), "Page time out")
        elif "automatic key" in description:
            self.click_by_locator(loc.automatic_key_expiry_dropdown, "Automatic key expiry dropdown")
            if data.get("Automatic key expiry"):
                self.click_by_locator(loc.automatic_key_expiry_option.format(value=data["Automatic key expiry"]), "Automatic key expiry option")
        elif "expiry period" in description:
            self.fill_by_locator(loc.expiry_period_input, data.get("Expiry period", ""), "Expiry period")
        
        self.click_step2_continue(data.get("bank", "ecentric"))
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Edit Step 2 error message"
        )

    def _edit_step3_negative(self, loc, data: dict) -> None:
        """Edit Step 3 with one invalid field."""
        description = data.get("Description", "").lower()
        
        if "webstore" in description:
            self.click_by_locator(loc.enable_webstore_dropdown, "Enable webstore dropdown")
            if data.get("Enable webstore"):
                self.click_by_locator(loc.enable_webstore_option.format(value=data["Enable webstore"]), "Enable webstore option")
        elif "webhook" in description:
            self.click_by_locator(loc.enable_webhook_dropdown, "Enable webhook dropdown")
            if data.get("Enable webhook"):
                self.click_by_locator(loc.enable_webhook_option.format(value=data["Enable webhook"]), "Enable webhook option")
        elif "payment button" in description:
            self.click_by_locator(loc.enable_payment_button_dropdown, "Enable payment button dropdown")
            if data.get("Enable payment button"):
                self.click_by_locator(loc.enable_payment_button_option.format(value=data["Enable payment button"]), "Enable payment button option")
        elif "payment link" in description:
            self.click_by_locator(loc.enable_payment_link_dropdown, "Enable payment link dropdown")
            if data.get("Enable payment link"):
                self.click_by_locator(loc.enable_payment_link_option.format(value=data["Enable payment link"]), "Enable payment link option")
        elif "multiple terminal" in description and "enable" in description:
            self.click_by_locator(loc.enable_multiple_terminal_dropdown, "Enable multiple terminal dropdown")
            if data.get("Enable multiple terminal"):
                self.click_by_locator(loc.enable_multiple_terminal_option.format(value=data["Enable multiple terminal"]), "Enable multiple terminal option")
        elif "maximum terminal" in description or "max terminal" in description:
            self.fill_by_locator(loc.max_terminals_input, data.get("Maximum number of terminal(s)", ""), "Maximum number of terminal(s)")
        
        self.click_step3_continue(data.get("bank", "ecentric"))
        self.wait_for_field_populated(self.locator(loc.validation_error), "Validation error visible")
        self.assert_text(
            self.locator(loc.error_message_by_text.format(value=data["ExpectedMessage"])),
            data["ExpectedMessage"],
            "Edit Step 3 error message"
        )

    def _edit_channel_support_pg_negative(self, loc, data: dict) -> None:
        """Placeholder for bank-specific negative edit logic."""
        pass
