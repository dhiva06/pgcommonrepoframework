from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.self_config_Pg_template_locators import SelfconfigurationLocators as EcentricLocators
from pathlib import Path
class SelfconfigurationPage(BasePage):

    def __init__(self, page, module_name="SelfConfigurationAPI"):
        super().__init__(page, module_name=module_name)

        self._dispatch = {
            "ecentric": (self._navigate_ecentric_pg_template, self._assert_dashboard_api_ecentric, EcentricLocators),
        }
    def navigate_to_pg_template(self, bank: str, data: dict) -> None:
        navigate_method, _, loc = self._dispatch[bank.lower()]
        navigate_method(loc)
    def assert_pg_template_dashboard_page(self, bank: str, data: dict) -> None:
        _, assert_method, loc = self._dispatch[bank.lower()]
        assert_method(loc)
    def _navigate_ecentric_pg_template(self, loc) -> None:
        self.click_by_locator(loc.unhide_menu, "Display Menu")
        self.click_by_locator(loc.my_account_menu, "My Account Menu")
        self.click_by_locator(loc.self_configuration, "self configuration")
    def _assert_dashboard_api_ecentric(self, loc) -> None:
        self.assert_visible(self.locator(loc.upload_logo_label), "Upload logo label is visible")
        self.assert_visible(self.locator(loc.terminal_id_label), "Terminal ID label is visible")
        self.assert_visible(self.locator(loc.choose_color_label), "Choose color label is visible")
        self.assert_visible(self.locator(loc.select_template_label), "Select template label is visible")
        self.assert_visible(self.locator(loc.select_language_label), "Select language label is visible")
        self.assert_visible(self.locator(loc.preview_button), "Preview button is visible")
        self._record("API Key dashboard loaded successfully", "pass")


    def verify_push_live_pg_template(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.preview_button, "Click on Preview button")
        self.assert_visible(self.locator(EcentricLocators.add_new_card_label), "Add new card label is visible")
        self.assert_visible(self.locator(EcentricLocators.order_summary_label), "Order summary label is visible")
        self.assert_visible(self.locator(EcentricLocators.credit_debit_card), "Credit/Debit card label is visible")
        self.assert_visible(self.locator(EcentricLocators.net_banking), "Net banking label is visible")
        self.assert_visible(self.locator(EcentricLocators.upi), "UPI label is visible")
        self.assert_visible(self.locator(EcentricLocators.wallet), "Wallet label is visible")
        self.assert_visible(self.locator(EcentricLocators.emi), "EMI label is visible")
        self.assert_visible(self.locator(EcentricLocators.preview_logo), "Preview logo is visible")
        self.assert_visible(self.locator(EcentricLocators.pay_now_button), "Pay now button is visible")
        self.assert_visible(self.locator(EcentricLocators.cancel_button), "Cancel button is visible")
        self.click_by_locator(EcentricLocators.push_live_button, "Click on Push to live button")
        expected_message = data["ExpectedMessage"].strip()
        actual_message = self.get_toast_message(EcentricLocators.toast_message, "Push Live Success Toast").strip()
        print("Actual Message:", actual_message)
        try:
            assert actual_message == expected_message, (f"Expected: {expected_message} | Actual: {actual_message}")
        except AssertionError:
            raise

    def verify_back_to_edit_pg_template(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.preview_button, "Click on Preview button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.back_to_edit_button, "Click on Back to edit button")
        self.assert_visible(self.locator(EcentricLocators.upload_logo_label), "Upload logo label is visible")
        self.assert_visible(self.locator(EcentricLocators.terminal_id_label), "Terminal ID label is visible")
        self.assert_visible(self.locator(EcentricLocators.choose_color_label), "Choose color label is visible")
        self.assert_visible(self.locator(EcentricLocators.select_template_label), "Select template label is visible")
        self.assert_visible(self.locator(EcentricLocators.select_language_label), "Select language label is visible")
        self.assert_visible(self.locator(EcentricLocators.preview_button), "Preview button is visible")
   
    def verify_upload_and_edit_logo(self, bank: str, data: dict):
        image_path = data["LogoPath"]
        self.click_by_locator(EcentricLocators.delete_logo_icon, "Delete Logo Icon")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.confirm_button, "Confirm Button")
        self.page.wait_for_timeout(2000)
        self.page.set_input_files(EcentricLocators.upload_logo_input,image_path)
        self.page.wait_for_timeout(2000)
        self.assert_visible(self.locator(EcentricLocators.delete_logo_icon),"Delete Logo Icon")

    def verify_invalid_logo_upload(self, bank: str, data: dict):
        image_path = data["LogoPath"]
        self.click_by_locator(EcentricLocators.delete_logo_icon, "Delete Logo Icon")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricLocators.confirm_button, "Confirm Button")
        self.page.wait_for_timeout(2000)
        self.page.set_input_files(EcentricLocators.upload_logo_input,image_path)
        self.page.wait_for_timeout(2000)
        expected_message = data["ExpectedMessage"].strip()
        actual_message = self.get_toast_message(EcentricLocators.file_upload_error, "Invalid Logo Upload error msg").strip()
        print("Actual Message:", actual_message)
        try:
            assert actual_message == expected_message, (f"Expected: {expected_message} | Actual: {actual_message}")
        except AssertionError:
            raise
    def verify_select_color(self, bank: str, data: dict):
        color_value = data["ColorCode"]
        old_color = self.locator(EcentricLocators.color_input).input_value()
        # Click color field
        self.click_by_locator(EcentricLocators.color_input, "Choose Color Field")
        # Verify color picker opened
        self.assert_visible(self.locator(EcentricLocators.color_picker_popup), "Color Picker Popup")
        # Clear existing color
        self.page.locator(EcentricLocators.color_input).fill(color_value)
        # Tab out to apply
        self.page.locator("body").click()
        self.page.wait_for_timeout(1000)
        # Get updated color
        new_color = self.locator(EcentricLocators.color_input).input_value()
        assert new_color == color_value, f"Expected: {color_value}, Actual: {new_color}"
        assert old_color != new_color, "Color was not updated"
        self.verify_selected_color_applied_in_preview(bank, data)

    def verify_selected_color_applied_in_preview(self, bank: str, data: dict):
        expected_color = data["ColorCode"]
        self.click_by_locator(EcentricLocators.preview_button, "Click on Preview button")
        self.page.wait_for_timeout(2000)
        actual_color = self.locator(EcentricLocators.preview_header).evaluate("el => window.getComputedStyle(el).backgroundColor")
        print("Actual Color:", actual_color)
        expected_color_map = {
            "#FF0000": "rgb(255, 0, 0)",
            "#00FF00": "rgb(0, 255, 0)",
            "#0000FF": "rgb(0, 0, 255)",
            "#8F2B00": "rgb(143, 43, 0)"
        }
        expected_rgb = expected_color_map[expected_color.upper()]
        assert actual_color == expected_rgb, (f"Expected Color: {expected_rgb}, "f"Actual Color: {actual_color}")

    def verify_language_dropdown(self, bank: str, data:dict):
        language = data["Language"]
        self.click_by_locator(EcentricLocators.language_dropdown , "Click on Language Dropdown")
        self.assert_visible(self.locator(EcentricLocators.select_all_checkbox), "Select All checkbox is visible")
        self.assert_visible(self.locator(EcentricLocators.language_option.format(language)), f"Language Option: {language} is visible")
        select_all_checked = self.page.locator(EcentricLocators.select_all_checked).count() > 0
        if select_all_checked:
            # Uncheck Select All
            self.click_by_locator(EcentricLocators.select_all_checkbox, "Uncheck Select All")
        else:
            # Check
            self.click_by_locator(EcentricLocators.select_all_checkbox, "Check Select All")
            # Uncheck
            self.click_by_locator(EcentricLocators.select_all_checkbox, "Uncheck Select All")
        # Select required language from Excel
        self.click_by_locator(EcentricLocators.language_option.format(language), f"Select Language Option: {language}")

    def verify_template_dropdown(self, bank: str, data: dict):
        template = data["Template"].strip()
        self.click_by_locator(EcentricLocators.template_dropdown, "Click Template Dropdown")
        expected_templates = [
            "Standard",
            "Entertainment",
            "Travel"
        ]
        for option in expected_templates:
            self.assert_visible(self.locator(EcentricLocators.template_option.format(option)), f"{option} Template Option")
        self.click_by_locator(EcentricLocators.template_option.format(template), f"Select Template {template}")

        self.page.wait_for_timeout(1000)
        actual_template = self.page.locator(EcentricLocators.selected_template).text_content().strip()
        assert actual_template == template, (f"Expected Template: {template}, "f"Actual Template: {actual_template}")

    def select_terminal_id(self, bank:str, data: dict):
        terminal_id = str(data.get("TerminalID") or "").strip()
        self.click_by_locator(EcentricLocators.terminal_dropdown, "Terminal Dropdown")
        self.click_by_locator(EcentricLocators.terminal_option.format(terminal_id),f"Terminal : {terminal_id}")

    def verify_preview_page(self, bank:str, data: dict):
        self.select_terminal_id(bank, data)
        image_path = data["LogoPath"]
        color_value = data["ColorCode"]
        template = data["Template"].strip()
        delete_icon = self.page.locator(EcentricLocators.delete_logo_icon)
        if delete_icon.count() > 0 and delete_icon.is_visible():
            self.click_by_locator(EcentricLocators.delete_logo_icon, "Delete Logo Icon")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricLocators.confirm_button, "Confirm Button")
            self.page.wait_for_timeout(2000)
        assert self.locator(EcentricLocators.preview_button).is_disabled(), "previe button is not disabled"
        self.page.set_input_files(EcentricLocators.upload_logo_input,image_path)
        self.page.wait_for_timeout(2000)
        # Click color field
        self.click_by_locator(EcentricLocators.color_input, "Choose Color Field")
        self.page.locator(EcentricLocators.color_input).fill(color_value)
        self.page.locator("body").click()
        self.page.wait_for_timeout(1000)
        self.click_by_locator(EcentricLocators.template_dropdown, "Click Template Dropdown")
        self.click_by_locator(EcentricLocators.template_option.format(template), f"Select Template {template}")
        assert self.locator(EcentricLocators.preview_button).is_enabled(), "preview button is not enabled"
        self.verify_pg_template_preview_page(bank, data)
        self.verify_selected_color_applied_in_preview(bank, data)


    def verify_pg_template_preview_page(self, bank: str, data: dict):
        card_number = str(data["CardNumber"]).strip()
        cvv = str(data["CVV"]).strip()
        card_holder_name = str(data["CardHolderName"]).strip()
        expiry = str(data["Expiry"]).strip()
        self.click_by_locator(EcentricLocators.preview_button, "Click on Preview button")
        self.assert_visible(self.locator(EcentricLocators.preview_logo), "Preview logo is visible")
        self.assert_visible(self.locator(EcentricLocators.add_new_card_label), "Add new card label is visible")
        self.assert_visible(self.locator(EcentricLocators.credit_debit_card), "Credit/Debit card label is visible")
        self.assert_visible(self.locator(EcentricLocators.credit_debit_subtitle), "Choose your Debit/Credit card is visible under Debit/credit card Title")
        self.assert_visible(self.locator(EcentricLocators.net_banking), "Net banking label is visible")
        self.assert_visible(self.locator(EcentricLocators.upi), "UPI label is visible")
        self.assert_visible(self.locator(EcentricLocators.wallet), "Wallet label is visible")
        self.assert_visible(self.locator(EcentricLocators.emi), "EMI label is visible")
        self.assert_visible(self.locator(EcentricLocators.card_number_field), "Card Number field is visible")
        self.assert_visible(self.locator(EcentricLocators.expiry_field), "Expiry field is visible")
        self.assert_visible(self.locator(EcentricLocators.cvv_field), "cvv_field is visible")
        self.assert_visible(self.locator(EcentricLocators.card_holder_name_field), "card_holder_name_field is visible")
        self.fill_by_locator(EcentricLocators.card_number_field,card_number, "Card Number")
        self.fill_by_locator(EcentricLocators.cvv_field,cvv, "CVV")
        self.fill_by_locator(EcentricLocators.card_holder_name_field, card_holder_name, "Card Holder Name")
        self.fill_by_locator(EcentricLocators.expiry_field,expiry, "Expiry")
        self.assert_visible(self.locator(EcentricLocators.save_card_checkbox), "Save Card Checkbox is visible")
        self.click_by_locator(EcentricLocators.save_card_checkbox, "Save Card Checkbox")
        assert self.page.locator(EcentricLocators.save_card_checkbox).is_checked(), "Checkbox not checked"
        self.assert_visible(self.locator(EcentricLocators.order_summary_label), "Order summary label is visible")
        self.assert_visible(self.locator(EcentricLocators.total_price_label), "Total Price label is visible")
        self.assert_visible(self.locator(EcentricLocators.shipping_charges_label), "shipping_charges_label is visible")
        self.assert_visible(self.locator(EcentricLocators.total_label), "total_label is visible")
        self.assert_visible(self.locator(EcentricLocators.pay_now_button), "Pay now button is visible")
        self.assert_visible(self.locator(EcentricLocators.cancel_button), "Cancel button is visible")
        self.click_by_locator(EcentricLocators.back_to_edit_button, "Back To edit button")

        

       