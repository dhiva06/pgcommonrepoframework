from src.common.base.base_page import BasePage
from datetime import datetime, timedelta
# from src.banks.neoleap.locators.self_configuration_api_locators import SelfConfigurationApiLocators as NeoleapLocators
# from src.banks.oab.locators.self_configuration_api_locators import SelfConfigurationApiLocators as OabLocators
# from src.banks.alrajhi.locators.self_configuration_api_locators import SelfConfigurationApiLocators as AlrajhiLocators
from src.banks.ecentric.locators.self_configuration_API_locators import selfconfigurationapilocators as EcentricLocators


class SelfConfigurationApiPage(BasePage):

    def __init__(self, page, module_name="SelfConfigurationAPI"):
        super().__init__(page, module_name=module_name)

        self._dispatch = {
            "ecentric": (self._navigate_ecentric, self._assert_dashboard_api_ecentric, EcentricLocators),
        }
    def navigate_to_api_key(self, bank: str, data: dict) -> None:
        navigate_method, _, loc = self._dispatch[bank.lower()]
        navigate_method(loc)
    def assert_api_key_dashboard_page(self, bank: str) -> None:
        _, assert_method, loc = self._dispatch[bank.lower()]
        assert_method(loc)
    def _navigate_ecentric(self, loc) -> None:
        self.click_by_locator(loc.unhide_menu, "Display Menu")
        self.click_by_locator(loc.my_account_menu, "My Account Menu")
        self.click_by_locator(loc.self_configuration, "self configuration")
        self.click_by_locator(loc.api_key,"API Key")
    def _assert_dashboard_api_ecentric(self, loc) -> None:
        self.assert_visible(self.locator(loc.search_box), "serach box is visible")
        self.assert_visible(self.locator(loc.search_button), "search Button is visible")
        self.assert_visible(self.locator(loc.add_button), "add Button is visible")
        self.assert_visible(self.locator(loc.api_key_grid), "API Key grid is visible")
        self.assert_visible(self.locator(loc.key_id_header), "key_id_header is visible")
        self.assert_visible(self.locator(loc.terminal_id_header), "terminal_id_header is visible")
        self.assert_visible(self.locator(loc.date_creation_header), "date_creation_header is visible")
        self.assert_visible(self.locator(loc.channel_header), "channel_header is visible")
        self.assert_visible(self.locator(loc.expiry_header), "expiry_header is visible")
        self.assert_visible(self.locator(loc.actions_header), "actions_header is visible")
        self._record("API Key dashboard loaded successfully", "pass")
          
    def add_api_key_ecentric(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.api_add_button,"Add Button")
        self.click_by_locator(EcentricLocators.terminal_dropdown)
        self.click_by_role("option",data["TerminalID"])
        self.page.get_by_label(data["KeyExpiry"]).check()
        self.click_by_locator(EcentricLocators.generate_button, description="click on generate button")
    def verify_default_key_expiry_preview_page(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.api_add_button,"Add Button")
        # TC: Channel and Terminal fields are present
        try:
            self.assert_visible(self.locator(EcentricLocators.channel_field),"Channel Field is visible")
            self.assert_visible(self.locator(EcentricLocators.terminal_dropdown), "terminal field is visible")
        except AssertionError as e:
            self.logger.warning(str(e))
            raise
        # TC: Terminal dropdown is clickable
        try:
            self.click_by_locator(EcentricLocators.terminal_dropdown)
            self.click_by_role("option",data["TerminalID"])
            self._record("Terminal dropdown is clickable","pass")
        except Exception as e:
            self._record(f"Terminal dropdown is not clickable : {str(e)}","fail")
            raise
        # TC: Default expiry option selected
        radio = self.get_by_label(data["KeyExpiry"])
        try:
            self.assert_visible(self.locator(EcentricLocators.deactivate_old_key_immediately),"Deactivate old key in 24 hours Radio Button is visible")
            self.assert_visible(self.locator(EcentricLocators.deactivate_old_key_24hrs),"Deactivate old key in 24 hours Radio Button is visible")
            assert radio.is_checked()
            self.logger.info(f"{data['KeyExpiry']} is selected")
        except AssertionError as e:
            self.logger.warning(str(e))  
            raise

    def verify_key_id(self, bank:str, data: dict):
        key_id = self.get_text(self.locator(EcentricLocators.key_id_value),"Key ID").strip()
        try:
            assert len(key_id) == 20
            self._record(f"Key ID contains 20 characters : {key_id}","pass")
            self.assert_visible(self.locator(EcentricLocators.key_id_copy_icon),"Copy Key ID Icon")
        except AssertionError:
            self._record(f"Key ID length is {len(key_id)} instead of 20", "fail")
            self._record("copy Icon not visible to copy the Key ID")
            raise

        self.click_by_locator(EcentricLocators.key_id_copy_icon,"Copy Key ID")
        # Validate toast message
        actual_message = self.get_toast_message(EcentricLocators.Key_Id_success_toast,"Copy Success Toast").strip()
        print("The toast msg is: ",  actual_message)
        try:
            assert actual_message == "Key Id copied succesfully."
            print("The actual msg is : ", actual_message)
            self._record(f"Toast message validated : {actual_message}","pass")
        except AssertionError:
            self._record(f"Expected : Key Id copied succesfully. | Actual :{actual_message}", "fail")
            raise


 
    def verify_key_secret(self, bank: str, data: dict):
        secret = self.get_text(self.locator(EcentricLocators.key_secret_value),"Key Secret").strip()
        try:
            assert 20 <= len(secret) <= 64
            self._record(f"Key Secret length validation passed : {len(secret)}","pass")
            self.assert_visible(self.locator(EcentricLocators.key_secret_copy_icon),"Copy Secret Key Icon")

        except AssertionError:
            self._record(
                f"Key Secret length validation failed : {len(secret)}", "fail")
            raise


        self.click_by_locator(EcentricLocators.key_secret_copy_icon, "Copy Secret Key") 
        actual_message = self.get_toast_message(EcentricLocators.secret_Key_Id_success_toast,"Copy Success Toast").strip()
        try:
            assert actual_message == "Key secret copied successfully."
            self._record(f"Toast message validated : {actual_message}","pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            self.logger.warning(str(e))  
            raise


    def download_api_key(self, bank: str, data: dict):
        with self.page.expect_download() as download_info:
            self.click_by_locator(EcentricLocators.download_key_button, "Download Key")
        download = download_info.value
        file_name = download.suggested_filename
        self.logger.info(f"Downloaded file: {file_name}")
        self._record(f"Downloaded file: {file_name}","pass")
        # Verify button disabled after download
        download_btn = self.locator(EcentricLocators.download_key_button)
        try:
            self.page.wait_for_timeout(6000)
            assert file_name.endswith((".xlsx", ".xls"))
            self._record(f"Downloaded file is in Excel format: {file_name}","pass")
            assert not download_btn.is_enabled()
            self._record("Download button is disabled after download","pass")
        except AssertionError:
            self._record("Download button is still enabled after download","fail")
            raise
        return file_name  

    def verify_new_api_key_added(self, bank: str, data: dict):
        terminal_id = self.get_text(self.locator(EcentricLocators.first_row_terminal_id),"Latest Terminal ID").strip()
        created_date = self.get_text(self.locator(EcentricLocators.first_row_created_date),"Latest Created Date").strip()
        today = datetime.now().strftime("%d,%b %Y")
        try:
            assert terminal_id == data["TerminalID"]
            self._record(f"Terminal ID validated: {terminal_id}","pass")
        except AssertionError:
            self._record(f"Expected Terminal ID {data['TerminalID']} but got {terminal_id}","fail")
            raise

        try:
            assert today in created_date
            self._record(f"Latest API key added today: {created_date}","pass")
        except AssertionError:
            self._record(f"Expected date {today} but got {created_date}","fail")
            raise

    def verify_self_configuration_tabs(self, bank: str, data: dict):
        try:
            self.assert_visible(self.locator(EcentricLocators.pg_template_tab).first,"PG Template Tab")
            self.assert_visible(self.locator(EcentricLocators.webhooks_tab).first, "webhook tab")
            self.assert_visible(self.locator(EcentricLocators.api_key_tab).first, "webhook tab")
            self._record("All Tabs are visible")
        except AssertionError:
            self._record("All Tabs are not visible")
            raise


    def verify_date_creation_format(self, bank: str, data:dict):
        date_text = self.get_text(self.locator(EcentricLocators.first_row_created_date),
                                  "Date Of Creation").strip()
        self.logger.info(f"Date displayed: {date_text}")
        try:
            assert datetime.strptime(date_text,"%d,%b %Y %I:%M %p")
            self._record(f"Date format validated successfully : {date_text}","pass")
        except AssertionError:
            self._record(f"Invalid date format displayed : {date_text}","fail")
            raise


    def verify_channel_value(self, bank: str, data: dict):
        actual_channel=self.get_text(self.locator(EcentricLocators.first_row_channel), "channel value").strip()
        try:
            assert actual_channel=="PG"
            self._record(f"channel validated: {actual_channel}","pass")
        except AssertionError:
            self._record(f"Expected channel value: PG but got {actual_channel}","fail")
            raise

                         
    def verify_expiry_date(self, bank: str, data: dict):
        expiry_date = self.get_text(self.locator(EcentricLocators.second_row_expiry_date),"Expiry Date").strip()
        self.logger.info(f"Actual Expiry Date = {expiry_date}")
        try:
            # Validate value is not empty
            assert expiry_date, "Expiry date is empty"
            # Validate format
            assert datetime.strptime(expiry_date,"%d,%b %Y %I:%M %p")
            self._record(f"Expiry date displayed with valid format: {expiry_date}", "pass")
        except ValueError as e:
            self._record(f"Invalid Expiry Date: '{expiry_date}'. Reason: {str(e)}","fail")
            raise
            


    def verify_date_creation_based_on_key_expiry_type(self, bank:str, data: dict):
        self.click_by_locator(EcentricLocators.my_account_menu)
        self.click_by_locator(EcentricLocators.self_configuration)
        self.click_by_locator(EcentricLocators.api_key)
        created_date = self.get_text(self.locator(EcentricLocators.first_row_created_date),"Date Of Creation").strip()
        self.logger.info(f"Date Of Creation displayed: {created_date}")
        try:
            # Verify value exists
            assert created_date, "Date Of Creation is empty"
            # Verify format
            actual_date = datetime.strptime(created_date,"%d,%b %Y %I:%M %p")
            # Verify generated today
            today = datetime.now().date()
            assert actual_date.date() == today
            self._record(f"Date Of Creation validated successfully: {created_date}","pass")
        except AssertionError as e:
            self._record(f"Date Of Creation validation failed: {created_date}. Reason: {str(e)}", "fail")
            raise


    def verify_My_Account(self, bank:str, data:dict):
        self.click_by_locator(EcentricLocators.my_account_menu, "My Account menu")
        try:
            self.assert_visible(self.locator(EcentricLocators.business_name),"Business Name")
            self.assert_visible(self.locator(EcentricLocators.merchant_id_label),"Merchant ID Label")
            self.assert_visible(self.locator(EcentricLocators.business_information_card),"Business Information Card")
            self.assert_visible(self.locator(EcentricLocators.self_configuration_card),"Self Configuration Card")
            self._record("My Account Dashboard Loaded Successfully","pass")
        except AssertionError as e:
            self._record(f"My Account Dashboard validation failed: {str(e)}", "fail")
            raise

    def verify_Navigation_to_generate_api_page(self, bank:str, data:dict):
        expected_message = "This key can be downloaded or viewed only once for security reasons"
        actual_message = self.get_text(self.locator(EcentricLocators.download_once_message), "information_message").strip()
        try:
            assert actual_message == expected_message
            self.assert_visible(self.locator(EcentricLocators.channel_in_generate), "Channel visible")
            self.assert_visible(self.locator(EcentricLocators.key_id_value), "Key Id visible")
            self.assert_visible(self.locator(EcentricLocators.key_secret_value), "Key secret value visible")
            self.assert_visible(self.locator(EcentricLocators.download_key_button), "Download key button is visible")
        except AssertionError as e:
            self._record(f"Navigation generate api page failed and fields not displayed: {str(e)}", "fail")
            self._record(f"Expected: {expected_message} | Actual: {actual_message}", "fail")
            raise
    def verify_auto_populated_expiry_date(self, bank:str, data:dict):
        expiry_value = self.get_text(self.locator(EcentricLocators.first_row_expiry_date), "Expiry Date").strip()
        self.logger.info(f"Actual Expiry Date = {expiry_value}")

        value=str(data["Automatic key renewal in Instituition"]).lower().strip()
        if value == "yes":
            try:

                assert datetime.strptime(expiry_value,"%d,%b %Y %I:%M %p")
                self._record(f"Expiry date displayed with valid format: {expiry_value}", "pass")
            except AssertionError as e:
                self._record(f"Invalid Expiry Date: '{expiry_value}'. Reason: {str(e)}","fail")
                raise
        if value == "no":
            try:
                assert expiry_value == "Never"
                self._record(f"Expiry value validated as 'Never': {expiry_value}", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise

    def verify_inactive_terminal_not_displayed(self, bak: str, data:dict):
        self.click_by_locator(EcentricLocators.api_add_button,"Add Button")
        self.click_by_locator(EcentricLocators.terminal_dropdown, "Terminal Dropdown")
        inactive_terminal = data["TerminalID"]
        terminals = self.page.locator(EcentricLocators.terminal_all_options).all_text_contents()
        terminals = [t.strip() for t in terminals]
        try:
            assert inactive_terminal not in terminals, (f"Inactive Terminal '{inactive_terminal}' is displayed in dropdown")
            self._record(f"Inactive Terminal '{inactive_terminal}' is not displayed", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise
    def verify_api_key_generation_success_popup(self, bank:str, data:dict):
        actual_message = self.get_text(self.locator(EcentricLocators.success_popup), "API Key Success Popup").strip()
        expected_message = "New API key has been generated successfully"
        try:
            assert actual_message == expected_message
            self._record(f"Success popup validated: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise
    def verify_delete_api_key(self, bank: str, data: dict):
        terminal_id = data["TerminalID"].strip()
        action = data["DeleteAction"].strip().lower()
        rows = self.page.locator(f"xpath=//tr[.//td[contains(@class,'mat-column-terminalId')]//span[normalize-space()='{terminal_id}']]")
        row_count = rows.count()
        print("Matching Rows:", row_count)
        if row_count < 2:
            raise AssertionError(f"Previous API key record not found for Terminal ID: {terminal_id}")
        # Previous API Key row
        previous_row = rows.nth(1)
        previous_row.locator("button#deleteButton").click()
        self._record(f"Delete button clicked for previous API key of {terminal_id}","pass")
        if action == "yes":
            self.click_by_locator(EcentricLocators.yes_button,"Yes Button")
            actual_message = self.get_toast_message(EcentricLocators.toast_message,
                                                   "Delete Success Toast").strip()
            expected_message = "Api key deleted successfully."
            print("Actual:", actual_message)
            try:
                assert actual_message == expected_message, (f"Expected: {expected_message} | Actual: {actual_message}")
                self._record("API Key successfully deleted", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise
        elif action == "cancel":
            self.click_by_locator(EcentricLocators.cancel_button,"Cancel Button")
            try:
                self.assert_visible(self.locator(EcentricLocators.api_key_grid),"API Key Grid")
                self._record("Delete cancelled successfully using Cancel button", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise
        elif action == "close":
            self.click_by_locator(EcentricLocators.close_icon,"Close Icon")
            try:
                self.assert_visible(self.locator(EcentricLocators.api_key_grid),"API Key Grid")
                self._record("Delete popup closed successfully", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise
    # def verify_expiry_based_on_key_expiry_type(self, bank:str, data:dict):
    #     self.click_by_locator(EcentricLocators.my_account_menu)
    #     self.click_by_locator(EcentricLocators.self_configuration)
    #     self.click_by_locator(EcentricLocators.api_key)

    #     key_expiry_type = data["KeyExpiry"].strip().lower()
    #     created_date_text = self.get_text(self.locator(EcentricLocators.first_row_created_date),"Date Of Creation").strip()
    #     expiry_date_text = self.get_text(self.locator(EcentricLocators.second_row_expiry_date), "Expiry Date").strip()
    #     try:
    #         created_date = datetime.strptime(created_date_text,"%d,%b %Y %I:%M %p")
    #         expiry_date = datetime.strptime(expiry_date_text,"%d,%b %Y %I:%M %p")
    #         if "immediately" in key_expiry_type:
    #             assert expiry_date == created_date
    #             self._record(f"Immediate expiry validated. Creation Date: {created_date_text}, Expiry Date: {expiry_date_text}", "pass")
    #         elif "24" in key_expiry_type:
    #             expected_expiry = created_date + timedelta(hours=24)
    #             assert expiry_date == expected_expiry
    #             self._record(f"24-hour expiry validated. Creation Date: {created_date_text}, Expiry Date: {expiry_date_text}", "pass")
    #     except (AssertionError, ValueError) as e:
    #         self._record(f"Expiry Date validation failed. Reason: {str(e)}","fail")
    #         raise


    def verify_expiry_based_on_key_expiry_type(self, bank: str, data: dict):
        self.click_by_locator(EcentricLocators.my_account_menu)
        self.click_by_locator(EcentricLocators.self_configuration)
        self.click_by_locator(EcentricLocators.api_key)
        key_expiry_type = data["KeyExpiry"].strip().lower()
        terminal_id = data["TerminalID"].strip()
        self.page.wait_for_load_state("networkidle")
        self.page.locator("//td[contains(@class,'mat-column-terminalId')]//span").first.wait_for(timeout=10000)
        terminals = self.page.locator("//td[contains(@class,'mat-column-terminalId')]//span").all_text_contents()
        print("Available Terminal IDs:", terminals)
        rows = self.page.locator(f"xpath=//tr[.//td[contains(@class,'mat-column-terminalId')]//span[normalize-space()='{terminal_id}']]")
        row_count = rows.count()
        print("Matching Rows:", row_count)
        if row_count < 2:
            raise AssertionError(f"Previous API key record not found for Terminal ID: {terminal_id}")
        # Latest generated row
        latest_row = rows.nth(0)
        # Previous row for same terminal id
        previous_row = rows.nth(1)
        created_date_text = latest_row.locator("td:nth-child(3) span").text_content().strip()
        print("Latest Created Date:", created_date_text)
        expiry_date_text = previous_row.locator("td:nth-child(5) span").text_content().strip()
        print("Previous Expiry Date:", expiry_date_text)
        try:
            created_date = datetime.strptime(created_date_text, "%d,%b %Y %I:%M %p")
            expiry_date = datetime.strptime(expiry_date_text, "%d,%b %Y %I:%M %p")
            if "immediately" in key_expiry_type:
                assert expiry_date == created_date
                self._record(f"Immediate expiry validated. Creation Date: {created_date_text}, Expiry Date: {expiry_date_text}", "pass")
            elif "24" in key_expiry_type:
                expected_expiry = created_date + timedelta(hours=24)
                assert expiry_date == expected_expiry
                self._record(f"24-hour expiry validated. Creation Date: {created_date_text}, Expiry Date: {expiry_date_text}", "pass")
        except (AssertionError, ValueError) as e:
            self._record(f"Expiry Date validation failed. Reason: {str(e)}", "fail")
            raise


        
            














        
                                              
    

         
                                  