from src.banks.ecentric.locators.serviceintegration_locators import ServiceintegrationLocators as EcentricServiceintegrationLocators
from src.banks.ecentric.locators.serviceintegration_locators import ServiceintegrationLocatorsNegative as EcentricServiceintegrationLocatorsNegative
from src.common.base.base_page import BasePage


class ServiceintegrationPage(BasePage):
    def __init__(self, page, module_name="Serviceintegration"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._edit_standard, EcentricServiceintegrationLocators),
        }

    def navigate_to_serviceintegration(self, bank: str) -> None:
        """Navigate to Service integration page via Administration > PG configuration > Service integration."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_pg_configuration, "PG configuration submenu")
        self.click_by_locator(loc.menu_service_integration, "Service integration page")

    def verify_channel_support_initial_state(self, bank: str) -> None:
        """Verify Payment Gateway checkbox is checked and required chips are selected."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.payment_gateway_checkbox), "Payment Gateway checkbox")
        assert self.is_checked(loc.payment_gateway_checkbox, "Payment Gateway checkbox", timeout=10000)
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Mastercard Payment Gateway Services")), "Mastercard Payment Gateway Services chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Cybersource")), "Cybersource chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="FSS Payment Gateway")), "FSS Payment Gateway chip")

    def verify_services_initial_state(self, bank: str) -> None:
        """Verify Services section shows correct Service type and Scheme selections."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Authentication")), "Service type: Authentication chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Authorization")), "Service type: Authorization chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Integrated")), "Service type: Integrated chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Visa")), "Scheme: Visa chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Mastercard")), "Scheme: Mastercard chip")

    def verify_tokenization_initial_state(self, bank: str) -> None:
        """Verify COFT or Faster checkout is set to Disable initially."""
        _, loc = self._dispatch[bank.lower()]
        coft_disable = self.locator(loc.coft_radio_by_value.format(value="false"))
        self.assert_visible(coft_disable, "COFT or Faster checkout Disable radio")
        assert self.is_checked(loc.coft_radio_by_value.format(value="false"), "COFT Disable radio", timeout=10000)

    def select_coft_enable(self, bank: str) -> None:
        """Select Enable for COFT or Faster checkout."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio")

    def assert_coft_enable_selected(self, bank: str) -> None:
        """Assert COFT Enable radio is selected."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio", timeout=10000)

    def verify_alternate_payments_initial_state(self, bank: str) -> None:
        """Verify Alternate payments (UPI & Wallets) is set to Disable initially."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.alternate_payments_radio_by_value.format(value="false")), "Alternate payments Disable radio")
        assert self.is_checked(loc.alternate_payments_radio_by_value.format(value="false"), "Alternate payments Disable radio", timeout=10000)

    def select_alternate_payments_enable(self, bank: str) -> None:
        """Select Enable for Alternate payments (UPI & Wallets)."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio")

    def assert_alternate_payments_enable_selected(self, bank: str) -> None:
        """Assert Alternate payments Enable radio is selected."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio", timeout=10000)

    def verify_off_us_support_initial_state(self, bank: str) -> None:
        """Verify Off Us support is set to Enable initially."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.off_us_support_radio_by_value.format(value="true")), "Off Us support Enable radio")
        assert self.is_checked(loc.off_us_support_radio_by_value.format(value="true"), "Off Us support Enable radio", timeout=10000)

    def select_off_us_support_disable(self, bank: str) -> None:
        """Select Disable for Off Us support."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio")

    def assert_off_us_support_disable_selected(self, bank: str) -> None:
        """Assert Off Us support Disable radio is selected."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio", timeout=10000)

    def select_off_us_support_enable(self, bank: str) -> None:
        """Select Enable for Off Us support."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="true"), "Off Us support Enable radio")

    def verify_authentication_provider_chips(self, bank: str) -> None:
        """Verify EMVCO and PayInc are selected in Authentication service provider."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="EMVCO")), "Authentication service provider: EMVCO chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="PayInc")), "Authentication service provider: PayInc chip")

    def verify_payment_method_and_transaction_type(self, bank: str) -> None:
        """Verify payment method type and transaction type selections."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Debit Card")), "Payment method type: Debit Card chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Credit Card")), "Payment method type: Credit Card chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Prepaid Card")), "Payment method type: Prepaid Card chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Purchase")), "Transaction type: Purchase chip")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Refund")), "Transaction type: Refund chip")

    def click_save_button(self, bank: str) -> None:
        """Click Save button at the bottom of the page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_success_message_displayed(self, bank: str, expected_message: str = None) -> None:
        """Assert success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message), "Success message")

    def verify_saved_state_coft_enable(self, bank: str) -> None:
        """Verify COFT or Faster checkout is set to Enable after reload."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio after reload", timeout=10000)

    def verify_saved_state_alternate_payments_enable(self, bank: str) -> None:
        """Verify Alternate payments is set to Enable after reload."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio after reload", timeout=10000)

    def verify_saved_state_off_us_support_enable(self, bank: str) -> None:
        """Verify Off Us support is set to Enable after reload."""
        _, loc = self._dispatch[bank.lower()]
        assert self.is_checked(loc.off_us_support_radio_by_value.format(value="true"), "Off Us support Enable radio after reload", timeout=10000)

    def verify_saved_channel_support_state(self, bank: str) -> None:
        """Verify Channel support section after reload."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.payment_gateway_checkbox), "Payment Gateway checkbox after reload")
        assert self.is_checked(loc.payment_gateway_checkbox, "Payment Gateway checkbox after reload", timeout=10000)
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Mastercard Payment Gateway Services")), "Mastercard Payment Gateway Services chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Cybersource")), "Cybersource chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="FSS Payment Gateway")), "FSS Payment Gateway chip after reload")

    def verify_saved_services_state(self, bank: str) -> None:
        """Verify Services section after reload."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Authentication")), "Service type: Authentication chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Authorization")), "Service type: Authorization chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Integrated")), "Service type: Integrated chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Visa")), "Scheme: Visa chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Mastercard")), "Scheme: Mastercard chip after reload")

    def verify_saved_authentication_provider_state(self, bank: str) -> None:
        """Verify Authentication service provider after reload."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="EMVCO")), "Authentication service provider: EMVCO chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="PayInc")), "Authentication service provider: PayInc chip after reload")

    def verify_saved_payment_and_transaction_state(self, bank: str) -> None:
        """Verify payment method type and transaction type after reload."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Debit Card")), "Payment method type: Debit Card chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Credit Card")), "Payment method type: Credit Card chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Prepaid Card")), "Payment method type: Prepaid Card chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Purchase")), "Transaction type: Purchase chip after reload")
        self.assert_visible(self.locator(loc.chip_by_text.format(value="Refund")), "Transaction type: Refund chip after reload")

    def _edit_standard(self, loc, data: dict = None) -> None:
        """Placeholder for standard edit flow - no form filling needed for this scenario."""
        pass


class ServiceintegrationPageNegative(ServiceintegrationPage):
    """Negative test methods for Service integration - validation and error scenarios."""
    
    def __init__(self, page, module_name="Serviceintegration"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._edit_standard, EcentricServiceintegrationLocatorsNegative),
        }
    
    def select_coft_invalid_state_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to select COFT Enable and verify system behavior with invalid/conflicting state.
        Fills all fields with valid baseline values, then applies negative action.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_services_initial_state(bank)
        self.verify_tokenization_initial_state(bank)
        self.click_by_locator(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio")
        self.click_by_locator(loc.save_button, "Save button")
        expected_message = data.get("ExpectedMessage", "") if data else ""
        if expected_message and self.page.locator(loc.error_message_by_text.format(value=expected_message)).count() > 0:
            self.assert_visible(
                self.locator(loc.error_message_by_text.format(value=expected_message)),
                f"Validation error: {expected_message}"
            )
        else:
            self.assert_visible(
                self.locator(loc.alert_message),
                "Error/alert message displayed"
            )
    
    def select_alternate_payments_invalid_state_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to select Alternate payments Enable and verify system behavior with invalid state.
        Fills all fields with valid baseline values, then applies negative action.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_services_initial_state(bank)
        self.verify_alternate_payments_initial_state(bank)
        self.click_by_locator(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio")
        self.click_by_locator(loc.save_button, "Save button")
        expected_message = data.get("ExpectedMessage", "") if data else ""
        if expected_message and self.page.locator(loc.error_message_by_text.format(value=expected_message)).count() > 0:
            self.assert_visible(
                self.locator(loc.error_message_by_text.format(value=expected_message)),
                f"Validation error: {expected_message}"
            )
        else:
            self.assert_visible(
                self.locator(loc.alert_message),
                "Error/alert message displayed"
            )
    
    def select_off_us_support_disable_without_prerequisite_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to select Off Us support Disable without required prerequisites and verify error.
        Fills all fields with valid baseline values, then applies negative action.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_services_initial_state(bank)
        self.verify_off_us_support_initial_state(bank)
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio")
        self.click_by_locator(loc.save_button, "Save button")
        expected_message = data.get("ExpectedMessage", "") if data else ""
        if expected_message and self.page.locator(loc.error_message_by_text.format(value=expected_message)).count() > 0:
            self.assert_visible(
                self.locator(loc.error_message_by_text.format(value=expected_message)),
                f"Validation error: {expected_message}"
            )
        else:
            self.assert_visible(
                self.locator(loc.alert_message),
                "Error/alert message displayed"
            )
    
    def click_save_without_required_selections_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to save without required field selections and verify validation error.
        Navigates to page and attempts save without making required selections.
        """
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")
        expected_message = data.get("ExpectedMessage", "") if data else ""
        if expected_message and self.page.locator(loc.error_message_by_text.format(value=expected_message)).count() > 0:
            self.assert_visible(
                self.locator(loc.error_message_by_text.format(value=expected_message)),
                f"Validation error: {expected_message}"
            )
        else:
            self.assert_visible(
                self.locator(loc.alert_message),
                "Error/alert message displayed"
            )
    
    def toggle_conflicting_radio_options_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to toggle multiple conflicting radio options and verify system prevents invalid state.
        Selects conflicting options and verifies error on save.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_services_initial_state(bank)
        self.click_by_locator(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio")
        self.click_by_locator(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio")
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio")
        self.click_by_locator(loc.save_button, "Save button")
        expected_message = data.get("ExpectedMessage", "") if data else ""
        if expected_message and self.page.locator(loc.error_message_by_text.format(value=expected_message)).count() > 0:
            self.assert_visible(
                self.locator(loc.error_message_by_text.format(value=expected_message)),
                f"Validation error: {expected_message}"
            )
        else:
            self.assert_visible(
                self.locator(loc.alert_message),
                "Error/alert message displayed"
            )
