from src.common.pages.serviceintegration.serviceintegration_page import ServiceintegrationPage
from src.banks.ecentric.locators.serviceintegration_locators import ServiceintegrationLocatorsNegative


class ServiceintegrationPageNegative(ServiceintegrationPage):
    """Negative test methods for Service integration - validation and error scenarios."""
    
    def __init__(self, page, module_name="Serviceintegration"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._edit_standard, ServiceintegrationLocatorsNegative),
        }
    
    def select_coft_enable_without_channel_support_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to enable COFT without required channel support prerequisites.
        Verifies baseline state, attempts invalid COFT enable, and asserts error message.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_tokenization_initial_state(bank)
        self.click_by_locator(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio")
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "COFT enable validation failed")
    
    def select_alternate_payments_without_prerequisites_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to enable Alternate payments without required prerequisites.
        Verifies baseline state, attempts invalid alternate payments enable, and asserts error message.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_alternate_payments_initial_state(bank)
        self.click_by_locator(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio")
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Alternate payments enable validation failed")
    
    def disable_off_us_support_without_prerequisites_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to disable Off Us support without meeting required conditions.
        Verifies baseline state, attempts invalid off us support disable, and asserts error message.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_off_us_support_initial_state(bank)
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio")
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Off Us support disable validation failed")
    
    def save_without_required_selections_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to save without completing required field selections.
        Clicks save directly and asserts validation error is displayed.
        """
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Required fields validation failed")
    
    def toggle_conflicting_tokenization_options_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt to toggle conflicting radio options in tokenization section.
        Selects conflicting combinations and verifies system prevents invalid state on save.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_tokenization_initial_state(bank)
        self.click_by_locator(loc.coft_radio_by_value.format(value="true"), "COFT Enable radio")
        self.click_by_locator(loc.alternate_payments_radio_by_value.format(value="true"), "Alternate payments Enable radio")
        self.click_by_locator(loc.off_us_support_radio_by_value.format(value="false"), "Off Us support Disable radio")
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Conflicting options validation failed")
    
    def toggle_conflicting_services_options_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt invalid state transitions in services section.
        Modifies service type and scheme selections to invalid combinations and verifies error on save.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_channel_support_initial_state(bank)
        self.verify_services_initial_state(bank)
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Services configuration validation failed")
    
    def toggle_conflicting_payment_method_options_negative(self, bank: str, data: dict = None) -> None:
        """
        Negative: Attempt invalid payment method type and transaction type combinations.
        Selects incompatible payment method and transaction type options and verifies error on save.
        """
        _, loc = self._dispatch[bank.lower()]
        self.verify_payment_method_and_transaction_type(bank)
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_error_message(loc, data, "Payment method configuration validation failed")
    
    def _assert_error_message(self, loc, data: dict = None, fallback_description: str = "") -> None:
        """
        Helper method to assert error message is displayed.
        First attempts to find error with ExpectedMessage from data, then falls back to generic error locator.
        """
        if data and data.get("ExpectedMessage", "").strip():
            expected_message = data["ExpectedMessage"].strip()
            error_locator = self.page.locator(loc.error_message_by_text.format(value=expected_message))
            if error_locator.count() > 0:
                self.assert_visible(error_locator, f"Validation error: {expected_message}")
                return
        
        # Fallback to generic error message locator
        self.assert_visible(
            self.locator(loc.alert_message),
            f"Error/alert message displayed - {fallback_description}"
        )
