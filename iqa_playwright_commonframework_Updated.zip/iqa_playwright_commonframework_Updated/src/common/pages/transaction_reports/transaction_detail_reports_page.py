from src.common.base.base_page import BasePage
from datetime import datetime
from src.banks.neoleap.locators.user_role_locators import UserRoleLocators as NeoleapUserRoleLocators
from src.banks.oab.locators.user_role_locators import UserRoleLocators as OabUserRoleLocators
# from src.banks.alrajhi.locators.transaction_detail_report_locators import txndetailreports as Alrajhitxndetailreportlocators
from src.banks.wio.locators.user_role_locators import UserRoleLocators as WioUserRoleLocators
from src.banks.pinelabs.locators.user_role_locators import UserRoleLocators as PinelabsUserRoleLocators
from src.banks.ecentric.locators.transaction_detail_report_locators import TransactionDetailReports as EcentricTxndetaiilReportlocators

class TransactiondetailreportsPage(BasePage):
    def __init__(self, page, module_name="TransactionDetailReports"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "neoleap": (self._add_role_neoleap, NeoleapUserRoleLocators),
            # "oab": (self._add_role_oab, self._assert_oab, OabUserRoleLocators),
            # "alrajhi": (self._add_role_alrajhi, self._assert_alrajhi, Alrajhitxndetailreportlocators),
            # "wio": (self._add_role_wio, self._assert_wio, WioUserRoleLocators),
            # "pinelabs": (self._add_role_pinelabs, self._assert_pinelabs, PinelabsUserRoleLocators),
            "ecentric": (self._Ecentric_Transaction_detail_dashboard_summary,self._Ecentric_Testcase_execution, EcentricTxndetaiilReportlocators),
        }

    def navigate_to_transaction_detail_reports(self, bank: str) -> None:
        _, _, loc = self._dispatch[bank.lower()]
        if bank.lower() == "ecentric":
            self.click_by_locator(loc.unhide_menu, f"{bank} unhide menu")
            self.click_by_locator(loc.Reports, f"{bank} Reports menu")
            self.click_by_locator(loc.Transaction_Detail_Report, f"{bank} Transaction Detail reports menu")
        else:
            self.click_by_locator(loc.Reports, f"{bank} Reports menu")
            self.click_by_locator(loc.Transaction_Detail_Report, f"{bank} Transaction Detail reports menu")

    def Transaction_detail_dashboard_summary(self, bank: str, data: dict) -> None:
        dashboardmethod, _, loc = self._dispatch[bank.lower()]
        dashboardmethod(loc, data)

    def Bank_test_execution(self, bank: str, data: dict) -> None:
        dashboardmethod, testcase_method,loc = self._dispatch[bank.lower()]
        testcase_method(data)
    

    def _Ecentric_Transaction_detail_dashboard_summary(self, loc, data) -> None:
        try:
            # self.assert_visible(self.locator(loc.search_tab), "search tab")
            # self._record("Transaction Detail Report page displayed with Search tab", "pass")
            # self.assert_visible(self.locator(loc.download_history_tab),"Download History Tab")
            # self._record("Transaction Detail Report page displayed with Download History tabs", "pass")
            self.assert_visible(self.locator(loc.filter_template_radio),"Filter Templates Radio Button")
            self._record("filtter radio button is displayed", "pass")
            self.assert_visible(self.locator(loc.adhoc_search_radio),"Adhoc Search Radio Button")
            self._record("adhoc_search_radio is displayed", "pass")
            self.assert_visible(self.locator(loc.template_dropdown),"Choose Filter Template Dropdown")
            self._record("template_dropdown is displayed", "pass")
            assert self.locator(loc.view_filters_button).is_disabled()
            self._record("view_filters_button is disabled by default", "pass")
            # assert self.locator(loc.view_button).is_disabled()
            # self._record("View button is disabled by default", "pass")
            assert self.locator(loc.download_button).is_disabled()
            self._record("download button button is disabled by default", "pass")

        except AssertionError as e:
            self._record(f"Transaction Detail Report page validation failed: {str(e)}", "fail")
            raise

        try:
            assert self.locator(loc.adhoc_search_radio).is_checked()
            self._record("adhoc radio is checked by default", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise
        self.click_by_locator(loc.filter_template_radio, "filter template radio button")
        self.click_by_locator(loc.template_dropdown, "template dropdown")
        try:
            self.assert_visible(self.locator(loc.add_new_template),"Add New Filter Template Icon")
            assert self.locator(loc.view_filters_button).is_disabled()
            self._record("Add new filter templet and view filter button is enabled", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise
        template_name = data["TemplateName"].strip()
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_option.format(template_name), "Template option")
        try:
            assert self.locator(loc.view_filters_button).is_enabled()
            # assert self.locator(loc.view_button).is_enabled()
            assert self.locator(loc.download_button).is_enabled()
            self._record("view_filter_button,view button and download button is enabled now")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise

    def _Ecentric_Testcase_execution(self, data:dict) -> None:

        testcase = data["TestcaseID"]
        self.Veify_Test_execution(data, testcase)
        if testcase == "TC-TDR-014":
            self.verify_reject_discard_filter_creation(data)
        elif testcase == "TC-TDR-015":
            self.verify_transaction_date_dropdown(data)
        elif testcase == "TC-TDR-016":
            self.verify_default_transaction_date(data)
        elif testcase == "TC-TDR-017 To TC-TDR-020":
            self.verify_transaction_date_selection(data)
        elif testcase in ("TC-TDR-021", "TC-TDR-202"):
            self.verify_category_default_empty(data)
        elif testcase in ("TC-TDR-022", "TC-TDR-203"):
            self.verify_select_category_options(data)
        elif testcase == "TC-TDR-023":
            self.verify_merchant_name_category(data)
        elif testcase in("TC-TDR-024", "TC-TDR-169"):
            self.verify_valid_merchant_name(data)
        elif testcase =="TC-TDR-025":
            self.verify_Invalid_merchant_name(data)
        elif testcase in ("TC-TDR-026", "TC-TDR-027"):
            self.verify_merchant_name_report(data)
        elif testcase == "TC-TDR-028":
            self.verify_merchant_Id(data)
        elif testcase in ("TC-TDR-029", "TC-TDR-159"):
            self.verify_valid_merchant_id(data)
        elif testcase == "TC-TDR-030":
            self.verify_invalid_merchant_id(data)
        elif testcase in ("TC-TDR-031", "TC-TDR-032"):
            self.verify_merchant_id_report(data)
        elif testcase =="TC-TDR-033":
            self.verify_Terminal_Id(data)
        elif testcase in ("TC-TDR-034", "TC-TDR-164"):
            self.verify_valid_Terminal_id(data)
        elif testcase == "TC-TDR-035":
            self.verify_invalid_terminal_id(data)
        elif testcase in ("TC-TDR-036", "TC-TDR-037", "TC-TDR-167"):
            self.verify_Terminal_id_report(data)
        elif testcase == "TC-TDR-038":
            self.verify_Transaction_Id(data)
        elif testcase == "TC-TDR-039":
            self.verify_valid_Transaction_id(data)
        elif testcase == "TC-TDR-040":
            self.verify_invalid_transaction_id(data)
        elif testcase in ("TC-TDR-041", "TC-TDR-042"):
            self.verify_Transaction_id_report(data)
        elif testcase == "TC-TDR-043":
            self.verify_Merchant_Track_Id(data)
        elif testcase == "TC-TDR-044":
            self.verify_valid_merchant_track_id(data)
        elif testcase == "TC-TDR-045":
            self.verify_invalid_merchant_track_id(data)
        elif testcase in ("TC-TDR-046", "TC-TDR-047"):
            self.verify_merchant_track_id_report(data) 
        elif testcase == "TC-TDR-048":
            self.verify_RRN_category(data)
        elif testcase == "TC-TDR-049":
            self.verify_valid_RRN(data)
        elif testcase == "TC-TDR-050":
            self.verify_invalid_RRN(data)
        elif testcase in ("TC-TDR-051", "TC-TDR-052"):
            self.verify_RRN_report(data)
        elif testcase == "TC-TDR-058":
            self.verify_Cardnumber_category(data)
        elif testcase in ("TC-TDR-059", "TC-TDR-180"):
            self.verify_valid_Cardnumber(data)
        elif testcase == "TC-TDR-060":
            self.verify_invalid_Cardnumber(data)
        elif testcase in ("TC-TDR-061", "TC-TDR-062", "TC-TDR-183"):
            self.verify_Cardnumber_report(data)
        elif testcase == "TC-TDR-63":
            self.verify_Bin_category(data)
        elif testcase == "TC-TDR-064":
            self.verify_valid_Bin(data)
        elif testcase == "TC-TDR-065":
            self.verify_invalid_Bin(data)   
        elif testcase == "TC-TDR-066":
            self.verify_Bin_report(data)
        elif testcase in("TC-TDR-067", "TC-TDR-248"):
            self.verify_transaction_mode_dropdown(data)
        elif testcase in ("TC-TDR-068", "TC-TDR-069", "TC-TDR-249", "TC-TDR-250", "TC-TDR-251", "TC-TDR-252"):
            self.verify_transaction_mode_selection(data)
        elif testcase in ("TC-TDR-074", "TC-TDR-075", "TC-TDR-256", "TC-TDR-257"):
            self.verify_transactiomode_report(data)
        elif testcase in ("TC-TDR-077", "TC-TDR-259"):
            self.verify_transaction_type_dropdown(data)
        elif testcase in ("TC-TDR-078", "TC-TDR-079", "TC-TDR-080", "TC-TDR-084", "TC-TDR-260", "TC-TDR-261", "TC-TDR-262", "TC-TDR-263", "TC-TDR-264", "TC-TDR-265", "TC-TDR-266"):
            self.verify_transaction_type_selection(data)
        elif testcase in ("TC-TDR-085", "TC-TDR-086", "TC-TDR-268", "TC-TDR-269", "TC-TDR-270", "TC-TDR-271"):
            self.verify_transaction_type_report(data)
        elif testcase in ("TC-TDR-089", "TC-TDR-272"):
            self.verify_payment_instrument_dropdown(data)
        elif testcase in ("TC-TDR-090", "TC-TDR-091", "TC-TDR-092", "TC-TDR-093", "TC-TDR-273", "TC-TDR-274", "TC-TDR-275", "TC-TDR-276", "TC-TDR-277"):
            self.verify_Payment_instrument_selection(data)
        elif testcase in ("TC-TDR-099", "TC-TDR-100", "TC-TDR-101", "TC-TDR-283", "TC-TDR-284", "TC-TDR-285"):
            self.verify_Payment_instrument_report(data)
        elif testcase in ("TC-TDR-112", "TC-TDR-297"):
            self.verify_status_options(data)
        elif testcase in ("TC-TDR-113", "TC-TDR-114", "TC-TDR-115", "TC-TDR-298", "TC-TDR-299", "TC-TDR-300", "TC-TDR-301"):
            self.verify_status_option_selection(data)
        elif testcase in ("TC-TDR-116", "TC-TDR-117", "TC-TDR-302", "TC-TDR-303"):
            self.verify_status_Report(data)
        elif testcase in ("TC-TDR-118", "TC-TDR-304"):
            self.verify_currency_code_dropdown(data)
        elif testcase in ("TC-TDR-119", "TC-TDR-120", "TC-TDR-121", "TC-TDR-122", "TC-TDR-123", "TC-TDR-124", "TC-TDR-305", "TC-TDR-306", "TC-TDR-307", "TC-TDR-308", "TC-TDR-309", "TC-TDR-310"):
            self.verify_currency_code_selection(data)
        elif testcase in ("TC-TDR-125", "TC-TDR-126", "TC-TDR-127", "TC-TDR-311", "TC-TDR-312", "TC-TDR-313"):
            self.verify_currency_code_report(data)
        elif testcase in ("TC-TDR-128", "TC-TDR-314"):
            self.verify_MCC_dropdown_default_value(data)
        elif testcase in ("TC-TDR-129", "TC-TDR-130", "TC-TDR-131", "TC-TDR-132", "TC-TDR-133", "TC-TDR-134", "TC-TDR-135", "TC-TDR-315", "TC-TDR-316", "TC-TDR-317", "TC-TDR-318", "TC-TDR-319", "TC-TDR-320", "TC-TDR-321", "TC-TDR-322"):
            self.verify_MCC_selection(data)
        elif testcase in ("TC-TDR-136", "TC-TDR-137", "TC-TDR-138", "TC-TDR-139", "TC-TDR-323", "TC-TDR-324", "TC-TDR-325", "TC-TDR-326"):
            self.verify_MCC_report(data)
        elif testcase in ("TC-TDR-140", "TC-TDR-327"):
            self.verify_interchange_dropdown(data)
        elif testcase in ("TC-TDR-141", "TC-TDR-142", "TC-TDR-143", "TC-TDR-144", "TC-TDR-145", "TC-TDR-146", "TC-TDR-328", "TC-TDR-329", "TC-TDR-330", "TC-TDR-331", "TC-TDR-332", "TC-TDR-333"):
            self.verify_interchange_selection(data)
        elif testcase in ("TC-TDR-147", "TC-TDR-148", "TC-TDR-335", "TC-TDR-336"):
            self.verify_interchange_report(data)
        elif testcase in ("TC-TDR-150", "TC-TDR-338"):
            self.verify_Customize_coloumns_dropdown(data)
        elif testcase in ("TC-TDR-151", "TC-TDR-339"):
            self.verify_transaction_id_mandatory_column(data)
        elif testcase in ("TC-TDR-152", "TC-TDR-153", "TC-TDR-340", "TC-TDR-341"):
            self.verify_Customize_coloumns_selection(data)
        elif testcase in ("TC-TDR-154", "TC-TDR-155", "TC-TDR-342", "TC-TDR-343"):
            self.verify_Customize_coloumns_report(data)
        elif testcase in ("TC-TDR-157", "TC-TDR-158"):
            self.verify_update_existing_filter_and_generate_report(data)
        elif testcase == "TC-TDR-162":
            self.verify_download_report(data)
        elif testcase in("TC-TDR-163", "TC-TDR-173", "TC-TDR-184"):
            self.verify_save_filter(data)
        elif testcase in ("TC-TDR-165", "TC-TDR-166", "TC-TDR-170", "TC-TDR-171", "TC-TDR-181", "TC-TDR-182"):
            self.verify_save_download_button(data)
        elif testcase == "TC-TDR-185":
            self.verify_adhoc_search_option(data)
        elif testcase == "TC-TDR-186":
            self.verify_adhoc_transaction_date_dropdown(data)
        elif testcase in ("TC-TDR-187", "TC-TDR-188", "TC-TDR-189", "TC-TDR-190", "TC-TDR-191", "TC-TDR-192", "TC-TDR-193", "TC-TDR-194", "TC-TDR-195", "TC-TDR-196", "TC-TDR-201"):
            self.verify_default_adhoc_search(data)
        elif testcase in ("TC-TDR-197", "TC-TDR-198", "TC-TDR-199", "TC-TDR-200"):
            self.verify_custom_range_functionality(data)
        elif testcase in ("TC-TDR-209", "TC-TDR-204", "TC-TDR-214", "TC-TDR-219", "TC-TDR-224", "TC-TDR-229", "TC-TDR-239", "TC-TDR-244"):
            self.verify_category_textbox_adhoc_search(data)
        elif testcase in ("TC-TDR-205", "TC-TDR-210", "TC-TDR-215", "TC-TDR-220", "TC-TDR-225", "TC-TDR-230", "TC-TDR-240", "TC-TDR-245"):
            self.verify_valid_category_name_adhoc_search(data)
        elif testcase in ("TC-TDR-206", "TC-TDR-211", "TC-TDR-216", "TC-TDR-221", "TC-TDR-226", "TC-TDR-231", "TC-TDR-241", "TC-TDR-246"):
            self.verify_Invalid_category_name_adhoc_search(data)
        elif testcase in ("TC-TDR-207", "TC-TDR-208", "TC-TDR-212", "TC-TDR-213", "TC-TDR-217", "TC-TDR-218", "TC-TDR-222", "TC-TDR-223", "TC-TDR-227", "TC-TDR-228", "TC-TDR-232", "TC-TDR-233", "TC-TDR-242", "TC-TDR-243", "TC-TDR-247"):
            self.verify_category_report_adhoc_search(data)
        elif testcase == "TC-TDR-344":
            self.delete_profile_template(data)
        elif testcase in ("TC-TDR-345", "TC-TDR-346", "TC-TDR-347", "TC-TDR-348", "TC-TDR-349", "TC-TDR-350", "TC-TDR-351", "TC-TDR-352"):
            self.verify_adhoc_search_category_filter(data)
        


    def Veify_Test_execution(self, data:dict, testcase) -> None:
        if testcase == "TC-TDR-010":
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            template_name = data["TemplateName"].strip()
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_option.format(template_name), "Template option")
            self.click_by_locator(EcentricTxndetaiilReportlocators.view_filters_button, "view filttersummary")
            try:
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.filter_summary))
                self._record("summary is visible")
            except AssertionError as e:
                self._record(str(e), "fail")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon, "close filtter icon")
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button, "filter cofirm button")


        elif testcase == "TC-TDR-011  To TC-TDR-013":
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template)
            try:
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_name_textbox),"Template Name Textbox")
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button),"Add_filter_save_button")
                assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
                self._record("This assertion is passed")
                self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
                assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_enabled()
                self._record("The save button is visible", "pass")
            except AssertionError as e:
                self._record(str(e))
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
            try:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"])))
                self._record("created template option displayed in dropdown list", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                return
            
    def verify_reject_discard_filter_creation(self, data:dict):
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template)
        
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_enabled()
            self._record("The save button is visible", "pass")

            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
            try:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
                self.assert_not_visible(self.locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"])))
                self._record("created template option displayed in dropdown list", "pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                return
    def verify_transaction_date_dropdown(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_period_dropdown,"Transaction Date Dropdown")
        expected_options = [
            "Today",
            "Yesterday",
            "Last 7 days",
            "Last 30 days",
            "Last 90 days",
            "Custom range"
        ]
        for option in expected_options:
            try:

                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.date_option.format(option)),option)
                self._record("All Transaction Date options displayed", "pass")
            except AssertionError as e:
                self._record(str(e))
                return
            
    def verify_default_transaction_date(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        actual_date = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_period).text_content().strip()
        try:
            assert actual_date == "Today"
        except AssertionError :
            return
    def verify_transaction_date_selection(self, data: dict):
        expected_date = data["Date Range"].strip()
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_period_dropdown,"Transaction period Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(expected_date),"Yesterday Option")
        actual_date = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_period).text_content().strip()
        try:
            assert actual_date == expected_date
            self._record(f"{expected_date} selected successfully", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise

    def verify_category_default_empty(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-202":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")

        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "Add new template clicked")
        actual_text = self.locator(EcentricTxndetaiilReportlocators.category_placeholder).text_content().strip()
        print(actual_text)
        try:
            assert actual_text == "Select category"
            self._record("Select Category field is empty by default", "pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise

    def verify_select_category_options(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-203":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        expected_options = [
            "Merchant ID",
            "Terminal ID",
            "Merchant Name",
            "Transaction ID",
            "Payment ID",
            "Merchant Track ID",
            "RRN",
            "Card Number",
            "BIN",
            "Payer Virtual Address",
            "Payee Virtual Address",
            "UPI Transaction ID"
        ]
        for option in expected_options:
            try:
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.category_option.format(option)),"option")
                self._record("All Select Category options are displayed successfully", "pass")
            except AssertionError as e:
                self._record(str(e))

    def verify_merchant_name_category(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "Add new template clicked")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Name"),"Merchant Name")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.merchant_name_textbox), "Merchant Name Textbox")

         

    def verify_valid_merchant_name(self, data: dict):
        merchant_name = data["MerchantName"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "Add new template clicked")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Name"),"Merchant Name")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_name_textbox,merchant_name,"Merchant Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
        if data["TestcaseID"] == "TC-TDR-169":
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            self.page.wait_for_timeout(3000)
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"])),f"new {merchant_name} template is visible in template dropdown")

    def verify_Invalid_merchant_name(self, data: dict):
        merchant_name = data["MerchantName"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Name"),"Merchant Name")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_name_textbox,merchant_name,"Merchant Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        expected_msg = data["ExpectedMessage"]
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_merchant_name_report(self, data: dict):
        merchant_name = data["MerchantName"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Name"),"Merchant Name")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_name_textbox,merchant_name,"Merchant Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
        

    def select_category(self, data: dict):
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]),"category option selected")
            return

    def verify_merchant_Id(self, data: dict):
            self.select_category(data)
            try:
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.merchant_id_textbox), "Merchant id Textbox")
                self._record("Merchant id textbox displayed","pass")
            except AssertionError as e:
                self._record (str(e))
            return
    
    def verify_valid_merchant_id(self,data:dict):
        merchant_id = data["MerchantId"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant ID"),"Merchant Id selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_id_textbox,merchant_id,"Merchant id filled")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
        if data["TestcaseID"] == "TC-TDR-159":
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            self.page.wait_for_timeout(3000)  # Wait for 2 seconds to ensure the template is saved and visible
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"])),f"new {merchant_id} template is visible in template dropdown")

    def verify_invalid_merchant_id(self,data:dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        merchant_id=data["MerchantId"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_id_textbox,merchant_id, "enter merchant id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))
    
        
    def verify_merchant_id_report(self, data: dict):
        merchant_id=data["MerchantId"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant ID"),"Merchant Id selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_id_textbox,merchant_id,"Merchant Id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "clcik download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_Terminal_Id(self, data: dict):
                self.select_category(data)
                try:
                    self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.terminal_id_textbox), "Terminal id Textbox")
                    self._record("Terminal id textbox displayed","pass")
                except AssertionError as e:
                    self._record (str(e))
                return

    def verify_valid_Terminal_id(self, data: dict):
        Terminal_ID = data["TerminalId"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Terminal ID"),"Terminal Id")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.terminal_id_textbox,Terminal_ID,"Terminal Id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
        if data["TestcaseID"] == "TC-TDR-164":
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
            self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
            self.page.wait_for_timeout(3000)  # Wait for 2 seconds to ensure the template is saved and visible
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"])),f"new {Terminal_ID} template is visible in template dropdown")

    def verify_invalid_terminal_id(self,data:dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        Terminal_Id=data["TerminalId"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.terminal_id_textbox,Terminal_Id, "enter Terminal id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_Terminal_id_report(self, data: dict):
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Terminal ID"), "Terminal ID")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.terminal_id_textbox,data["TerminalId"],"Terminal Id")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
            self.page.wait_for_timeout(3000)
            expected_message = "Transaction detail report has been successfully downloaded."
            toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
            toast.wait_for(state="visible", timeout=10000)
            actual_message = toast.text_content().strip()
            print(actual_message)
            try:
                assert actual_message == expected_message
                self._record(f"Toast message displayed: {actual_message}", "pass")
            except AssertionError as e:
                self._record(str(e))
                raise

    def verify_Transaction_Id(self, data: dict):
                self.select_category(data)
                try:
                    self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.transactrion_id_textbox), "Transaction id Textbox")
                    self._record("Transaction id textbox displayed","pass")
                except AssertionError as e:
                    self._record (str(e))
                return

    def verify_valid_Transaction_id(self, data: dict):
        Transaction_ID = data["TransactionId"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Transaction ID"),"Transaction Id")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.transactrion_id_textbox,Transaction_ID,"Transaction Id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_invalid_transaction_id(self,data:dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        TransactionId=data["TransactionId"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.transactrion_id_textbox,TransactionId, "enter Transaction id")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_Transaction_id_report(self, data: dict):
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Transaction ID"),"Transaction Id selected")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.transactrion_id_textbox,data["TransactionId"],"Transaction Id")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
            self.page.wait_for_timeout(3000)
            expected_message = "Transaction detail report has been successfully downloaded."
            toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
            toast.wait_for(state="visible", timeout=10000)
            actual_message = toast.text_content().strip()
            print(actual_message)
            try:
                assert actual_message == expected_message
                self._record(f"Toast message displayed: {actual_message}", "pass")
            except AssertionError as e:
                self._record(str(e))
                raise
            

    def verify_Merchant_Track_Id(self, data: dict):
        self.select_category(data)
        try:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.merchant_track_id_textbox),"Merchant Track ID Textbox")
            self._record("Merchant Track ID textbox displayed","pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_valid_merchant_track_id(self, data: dict):
        merchant_track_id = data["MerchantTrackId"]
        self.click_by_locator(
            EcentricTxndetaiilReportlocators.filter_template_radio,
            "Filter Template Radio"
        )
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Track ID"),"Merchant Track ID")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_track_id_textbox,merchant_track_id,"Merchant Track ID")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
    def verify_invalid_merchant_track_id(self, data: dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        merchant_track_id = data["MerchantTrackId"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_track_id_textbox,merchant_track_id, "enter Merchant Track ID")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_merchant_track_id_report(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Merchant Track ID"),"Merchant Track ID selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.merchant_track_id_textbox,data["MerchantTrackId"],"MerchantTrackId")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "clciked download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise    

    def verify_RRN_category(self, data: dict):
        self.select_category(data)
        try:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.RRN_textbox),"RRN Textbox")
            self._record("RRN textbox displayed","pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_valid_RRN(self, data: dict):
        RRN_value = data["RRN"]
        self.click_by_locator(
            EcentricTxndetaiilReportlocators.filter_template_radio,
            "Filter Template Radio"
        )
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("RRN"),"RRN Track ID")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.RRN_textbox,RRN_value,"RRN value")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
    def verify_invalid_RRN(self, data: dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        RRN_value = data["RRN"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.RRN_textbox,RRN_value, "enter Merchant Track ID")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_RRN_report(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("RRN"),"RRN selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.RRN_textbox,data["RRN"],"RRN")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_Cardnumber_category(self, data: dict):
        self.select_category(data)
        try:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.cardnumber_textbox),"cardnumber Textbox")
            self._record("cardnumber textbox displayed","pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_valid_Cardnumber(self, data: dict):
        cardnumber = data["CardNumber"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Card Number"),"Card Number")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.cardnumber_textbox,cardnumber,"cardnumber value")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
    def verify_invalid_Cardnumber(self, data: dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        cardnumber = data["CardNumber"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.cardnumber_textbox,cardnumber, "enter cardnumber")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_Cardnumber_report(self, data: dict):
            cardnumber = data["CardNumber"]
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category")
            self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("Card Number"),"Card Number")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.cardnumber_textbox,cardnumber,"cardnumber value")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
            self.page.wait_for_timeout(3000)
            expected_value = "Transaction detail report has been successfully downloaded."
            actual_value = self.locator(EcentricTxndetaiilReportlocators.download_success_toast).text_content().strip()
            try:
                assert expected_value == actual_value
                self._record("The report is downloaded")
            except AssertionError as e:
                raise

    def verify_Bin_category(self, data: dict):
        self.select_category(data)
        try:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.Bin_textbox),"bin Textbox")
            self._record("bin textbox displayed","pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_valid_Bin(self, data: dict):
        bin = data["BIN"]
        self.click_by_locator(
            EcentricTxndetaiilReportlocators.filter_template_radio,
            "Filter Template Radio"
        )
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("BIN"),"bin")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.Bin_textbox,bin,"bin")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button)
        expected_message = "Template saved successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
    def verify_invalid_Bin(self, data: dict):
        self.select_category(data)
        expected_msg = data["ExpectedMessage"]
        bin = data["BIN"]
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.Bin_textbox,bin, "enter bin")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled()
            self._record("invalid input msg and save button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_Bin_report(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template, "click add new template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format("BIN"),"BIN selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.Bin_textbox,data["BIN"],"bin")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_transaction_mode_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-248":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"Transaction Mode Dropdown")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.transaction_mode_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        expected_options = [
            "Select All",
            "Hosted Payment Page",
            "API"
        ]
        for option in expected_options:
            try:
                assert option in actual_options
                self._record(f"Transaction Mode options displayed: {actual_options}","pass")

            except AssertionError as e:
                self._record(str(e))

    # def verify_transaction_mode_selection(self, data: dict):
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"Transaction Mode Dropdown")
    #     # Unselect Select All
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
    #     # Select BANKHOSTED
    #     self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format("BANKHOSTED"), "Bank hosted")
    #     self.page.keyboard.press("Escape")
    #     selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
    #     print("Selected Values:", selected_values)
    #     try:
    #         assert "BANKHOSTED" in "".join(selected_values).upper()
    #         self._record("BANKHOSTED displayed under Transaction Mode field","pass")
    #     except AssertionError as e:
    #         self._record(str(e), "fail")
    #         raise

    def verify_transaction_mode_selection(self, data: dict):
            transaction_modes = [mode.strip() for mode in data["TransactionMode"].split(",")]
            print(transaction_modes)
            if data["TestcaseID"] in ("TC-TDR-249", "TC-TDR-250", "TC-TDR-251", "TC-TDR-252"):
                self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
                self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
            else:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"Transaction Mode Dropdown")
            # Unselect Select All
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
            # Select BANKHOSTED
            for mode in transaction_modes:
                self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
            
            self.page.keyboard.press("Escape")
            self.page.wait_for_timeout(3000)
            selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
            print("Selected Values:", selected_values)
            try:
                for mode in transaction_modes:
                    assert mode in "".join(selected_values)
                    self._record("Transaction Mode displayed successfully","pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise

    def verify_transactiomode_report(self, data:dict):
        transaction_modes = [mode.strip() for mode in data["TransactionMode"].split(",")]
        if data["TestcaseID"] in ("TC-TDR-256", "TC-TDR-257"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"Transaction Mode Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")

        for mode in transaction_modes:
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
        self.page.keyboard.press("Escape")
        if data.get("New Template Name"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "save button clicked")

        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "download button clicked")
        self.page.wait_for_timeout(3000)
        expected_message = "Transactiondetail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise
    
    def verify_transaction_type_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-259":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"Transaction type Dropdown clicked")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.transaction_type_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        expected_options = [
            "Select All"
            "Purchase",
            "Refund",
            "Purchase Reversal",
            "Refund Reversal"
        ]
        for option in expected_options:
            try:
                assert option in actual_options
                self._record(f"Transaction type options displayed: {actual_options}","pass")

            except AssertionError as e:
                self._record(str(e))    

    def verify_transaction_type_selection(self, data: dict):
            transaction_Types = [mode.strip() for mode in data["TransactionType"].split(",")]
            print(transaction_Types)
            if not data["New Template Name"]:
                self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
                self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
            else:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"Transaction type Dropdown")
            # Unselect Select All
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
            for mode in transaction_Types:
                self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
            
            self.page.keyboard.press("Escape")
            self.page.wait_for_timeout(3000)
            selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
            print("Selected Values:", selected_values)
            try:
                for mode in transaction_Types:
                    assert mode in "".join(selected_values)
                    self._record("Transaction tye displayed successfully","pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise

    def verify_transaction_type_report(self, data:dict):
        transaction_Types = [mode.strip() for mode in data["TransactionType"].split(",")]
        print(transaction_Types)
        if data["TestcaseID"] in ("TC-TDR-268", "TC-TDR-269", "TC-TDR-270", "TC-TDR-271"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"Transaction type Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")

        for mode in transaction_Types:
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
        self.page.keyboard.press("Escape")
        if data["TestcaseID"] in ("TC-TDR-085", "TC-TDR-086"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "save button clicked")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "download button clicked")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_payment_instrument_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-272":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"payment instrument Dropdown clicked")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.payment_instrument_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        expected_options = [
            "Select All"
            "Debit Card",
            "Credit Card",
            "Prepaid Card"
        ]
        for option in expected_options:
            try:
                assert option in actual_options
                self._record(f"payment instrument options displayed: {actual_options}","pass")

            except AssertionError as e:
                self._record(str(e))

    def verify_Payment_instrument_selection(self, data: dict):
            payment_instrument_Types = [mode.strip() for mode in data["PaymentInstrument"].split(",")]
            print(payment_instrument_Types)
            if data["TestcaseID"] in ("TC-TDR-273", "TC-TDR-274", "TC-TDR-275", "TC-TDR-276", "TC-TDR-277"):
                self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
                self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
            else:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"Payment instrument Dropdown")
            # Unselect Select All
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
            for mode in payment_instrument_Types:
                self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
                
            self.page.keyboard.press("Escape")
            self.page.wait_for_timeout(3000)
            selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
            print("Selected Values:", selected_values)
            try:
                for mode in payment_instrument_Types:
                    assert mode in "".join(selected_values)
                    self._record("Payment instrument displayed successfully","pass")
            except AssertionError as e:
                self._record(str(e), "fail")
                raise


    def verify_Payment_instrument_report(self, data:dict):
        payment_instrument_Types = [mode.strip() for mode in data["PaymentInstrument"].split(",")]
        print(payment_instrument_Types)
        if data["TestcaseID"] in ("TC-TDR-283", "TC-TDR-284", "TC-TDR-285"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"Payment Instrument Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")

        for mode in payment_instrument_Types:
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(mode), f"{mode} is selected")
        self.page.keyboard.press("Escape")
        if data["TestcaseID"] in ("TC-TDR-099", "TC-TDR-100", "TC-TDR-101"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "save button clicked")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "download button clicked")
        self.page.wait_for_timeout(3000)

        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise


    def verify_status_options(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-297":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")

        expected_options = ["All", "Success", "Failure"]
        for option in expected_options:
            try:
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.status_option.format(option)), option)
                self._record(f"{option} status option is displayed", "pass")
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.status_all_checked),"All selected by default")
                self._record("All status is selected by default","pass")
            except AssertionError as e:
                self._record(str(e))

    def verify_status_option_selection(self, data: dict):
            status = data["OutcomesStatus"].strip()
            if data["TestcaseID"] in ("TC-TDR-298", "TC-TDR-299", "TC-TDR-300", "TC-TDR-301"):
                self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
                self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
            else:
                self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
                self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
                self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            if status == "All":
                self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format("Success"), "clicked the success")
                self.click_by_locator(EcentricTxndetaiilReportlocators.all_status_radio, f"{status} is selected")
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.status_all_checked),"All selected")
            else:
                self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format(status), f"{status} is selected")
                self.page.wait_for_timeout(3000)
                assert self.locator(EcentricTxndetaiilReportlocators.status_radio.format(status)).is_checked()

    def verify_status_Report(self, data: dict):
        status = data["OutcomesStatus"].strip()
        if data["TestcaseID"] in ("TC-TDR-302", "TC-TDR-303"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox, data["New Template Name"], "fill the template name")
        if status == "All":
            if data["TestcaseID"] in ("TC-TDR-116", "TC-TDR-117"):
                self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
            self.page.wait_for_timeout(2000)    
            self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format(status), f"{status} is selected")
            if data["TestcaseID"] in ("TC-TDR-116", "TC-TDR-117"):
                self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "click save button")
            self.page.wait_for_timeout(2000)    
            self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise    
        
    def verify_currency_code_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-304":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:   
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"currency code Dropdown clicked")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.currency_code_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        expected_options = [
                "DZD",
                "INR",
                "ZAR"
            ]
        for option in expected_options:
            try:
                assert option in actual_options
                self._record(f"currency code options displayed: {actual_options}","pass")
                self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.currency_select_all_checked),"Select All checked by default")
    
            except AssertionError as e:
                self._record(str(e))
                raise

    def verify_currency_code_selection(self, data: dict):
        currency_code = [code.strip().upper() for code in data["CurrencyCode"].split(",")]
        print(currency_code)
        if data["TestcaseID"] in ("TC-TDR-305", "TC-TDR-306", "TC-TDR-307", "TC-TDR-308", "TC-TDR-309", "TC-TDR-310"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"Currency code Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
        for currency in currency_code:
            self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_option.format(currency), f"{currency} is selected")
                
        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(3000)
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print("Selected Values:", selected_values)
        try:
            for currency in currency_code:
                assert currency in "".join(selected_values)
                self._record("Currency displayed successfully","pass")
        except AssertionError as e:
                self._record(str(e), "fail")
                raise
    def verify_currency_code_report(self, data:dict):
        currency_code = [code.strip().upper() for code in data["CurrencyCode"].split(",")]
        print(currency_code)
        if data["TestcaseID"] in ("TC-TDR-311", "TC-TDR-312", "TC-TDR-313"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"Currency code Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"Select All")
        for currency in currency_code:
            self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_option.format(currency), f"{currency} is selected")
        self.page.keyboard.press("Escape")
        if data["TestcaseID"] in ("TC-TDR-125", "TC-TDR-126", "TC-TDR-127"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")

        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise


    def verify_MCC_dropdown_default_value(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-314":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_dropdown,"MCC Dropdown clicked")
        try:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.MCC_select_all_checked),"Select All checked by default")
        except AssertionError as e:
            self._record(str(e))
            raise                

    def verify_MCC_selection(self, data: dict):
        MCC_value = [mcc.strip().upper() for mcc in data["MCC"].split("|")]
        print(MCC_value)
        if data["TestcaseID"] in ("TC-TDR-315", "TC-TDR-316", "TC-TDR-317", "TC-TDR-318", "TC-TDR-319", "TC-TDR-320", "TC-TDR-321", "TC-TDR-322"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_dropdown,"MCC Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"unSelect All")

        if len(MCC_value) == 1 and MCC_value[0] == "SELECT ALL":
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox_dropdown,"Select All")
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.select_all_checkbox), "select all checked")
            return                
        else:
            for mcc in MCC_value:
                self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_option.format(mcc), f"{mcc} is selected")
            
        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(3000)
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print("Selected Values:", selected_values)
        try:
            for mcc in MCC_value:
                assert mcc in "".join(selected_values).upper()
                self._record("MCC displayed successfully","pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise

    def verify_MCC_report(self, data:dict):
        MCC_value = [mcc.strip().upper() for mcc in data["MCC"].split("|")]
        print(MCC_value)
        if data["TestcaseID"] in ("TC-TDR-323", "TC-TDR-324", "TC-TDR-325", "TC-TDR-326"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_dropdown,"click MCC Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"UnSelect All")
        for mcc in MCC_value:
            self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_option.format(mcc), f"{mcc} is selected")

        self.page.keyboard.press("Escape")
        if data["TestcaseID"] in ("TC-TDR-136", "TC-TDR-137", "TC-TDR-138", "TC-TDR-139"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_interchange_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-327":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"Interchange Dropdown clicked")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.interchange_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.interchange_select_all_checked),"Select All checked by default")
        actual_options = self.locator(EcentricTxndetaiilReportlocators.currency_code_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        expected_options = [
                "Visa",
                "MasterCard",
            ]
        for option in expected_options:
            try:
                assert option in actual_options
                print(f"{option} is visible")
                self._record(f"Interchange options displayed: {actual_options}","pass")   
            except AssertionError as e:
                self._record(str(e))
                raise            

    def verify_interchange_selection(self, data: dict):
        interchange_codes = [code.strip() for code in data["InterchangeCode"].split(",")]
        print(interchange_codes)
        if data["TestcaseID"] in ("TC-TDR-328", "TC-TDR-329", "TC-TDR-330", "TC-TDR-331", "TC-TDR-332", "TC-TDR-333"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")

        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"Interchange Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"UnSelect All")
        if len(interchange_codes) == 1 and interchange_codes[0] == "Select All":
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox_dropdown,"Select All")
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.interchange_select_all_checked), "select all checked")
            return
                  
        else:
            for interchange in interchange_codes:
                self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_option.format(interchange), f"{interchange} is selected")

        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(3000)
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print("Selected Values:", selected_values)
        try:
            for interchange in interchange_codes:
                assert interchange in "".join(selected_values)
                self._record("Interchange displayed successfully","pass")
        except AssertionError as e:
                self._record(str(e), "fail")
                raise


    def verify_interchange_report(self, data: dict):
        interchange_codes = [code.strip() for code in data["InterchangeCode"].split(",")]
        print(interchange_codes)
        if data["TestcaseID"] in ("TC-TDR-335", "TC-TDR-336"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")            
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"Interchange Dropdown")
        # Unselect Select All
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"UnSelect All")
        if len(interchange_codes) == 1 and interchange_codes[0] == "Select All":
            self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox_dropdown,"Select All")
                  
        else:
            for interchange in interchange_codes:
                self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_option.format(interchange), f"{interchange} is selected")

        self.page.keyboard.press("Escape")
        self.page.wait_for_timeout(2000)
        if data["TestcaseID"] in ("TC-TDR-147", "TC-TDR-148"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
        self.page.wait_for_timeout(3000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise


    def verify_Customize_coloumns_dropdown(self, data: dict):
        if data["TestcaseID"] == "TC-TDR-338":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")

        arrow = self.page.locator("//mat-form-field[@id='columns']//div[contains(@class,'mat-mdc-select-arrow-wrapper')]")
        arrow.click(position={"x": 5, "y": 5}, force=True)
        actual_options = self.locator(EcentricTxndetaiilReportlocators.Customize_coloumns_options).all_text_contents()
        print("Actual Options from UI:", actual_options)
        # self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.Customized_coloumns_select_all_checked),"Select All checked by default")

    def verify_transaction_id_mandatory_column(self, data:dict):
        Transaction_ID = data["CustomizeColumns"].strip()
        if data["TestcaseID"] == "TC-TDR-339":
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        arrow = self.page.locator("//mat-form-field[@id='columns']//div[contains(@class,'mat-mdc-select-arrow-wrapper')]")
        arrow.click(position={"x": 5, "y": 5}, force=True)
        try:
            assert self.locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(Transaction_ID)).is_disabled()
            self._record(" The Transaction Id field is not editable")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise


    def verify_Customize_coloumns_selection(self, data: dict):
        Customize_columns = [code.strip() for code in data["CustomizeColumns"].split(",")]
        print(Customize_columns)
        if data["TestcaseID"] in ("TC-TDR-340", "TC-TDR-341"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        arrow = self.page.locator("//mat-form-field[@id='columns']//div[contains(@class,'mat-mdc-select-arrow-wrapper')]")
        arrow.click(position={"x": 5, "y": 5}, force=True)
        self.page.wait_for_timeout(5000)

        if self.locator(EcentricTxndetaiilReportlocators.Customized_coloumns_select_all_checked).count() > 0:
            # Select All is already checked
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"unSelect All")

            for columns in Customize_columns:
                self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(columns), f"{columns} is selected")
        else:
            # Select All is not checked
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"Select All")
            self.page.wait_for_timeout(3000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"Unselect All")
            for columns in Customize_columns:
                self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(columns), f"{columns} is selected")
        self.page.keyboard.press("Escape")
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print("Selected Values:", selected_values)
        try:
            for columns in Customize_columns:
                assert columns in "".join(selected_values)
                self._record("Customize columns displayed successfully","pass")
        except AssertionError as e:
                self._record(str(e), "fail")
                raise

    def verify_Customize_coloumns_report(self, data: dict):
        Customize_columns = [code.strip() for code in data["CustomizeColumns"].split(",")]
        print(Customize_columns)
        if data["TestcaseID"] in ("TC-TDR-342", "TC-TDR-343"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        else:    
            self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
            self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")

        arrow = self.page.locator("//mat-form-field[@id='columns']//div[contains(@class,'mat-mdc-select-arrow-wrapper')]")
        arrow.click(position={"x": 5, "y": 5}, force=True)
        self.page.wait_for_timeout(5000)
    
        if self.locator(EcentricTxndetaiilReportlocators.Customized_coloumns_select_all_checked).count() > 0:
            # Select All is already checked
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"unSelect All")

            for columns in Customize_columns:
                self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(columns), f"{columns} is selected")
        else:
            # Select All is not checked
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"Select All")
            self.page.wait_for_timeout(3000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"Unselect All")
            for columns in Customize_columns:
                self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(columns), f"{columns} is selected")
        self.page.keyboard.press("Escape")
        if data["TestcaseID"] in ("TC-TDR-154", "TC-TDR-155"):
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
        self.page.wait_for_timeout(2000)
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_update_existing_filter_and_generate_report(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "clicked on manage preference button")
        if data.get("TestcaseID") == "TC-TDR-158":
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"clicked on transaction mode dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["TransactionMode"]),"Transaction mode clicked")
            self.page.keyboard.press("Escape")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"clicked on transaction type dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["TransactionType"]),"Transaction type clicked")
            self.page.keyboard.press("Escape")
            self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"clicked on payment instrument dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["PaymentInstrument"]),"Payment instrument clicked")
            self.page.keyboard.press("Escape")
            self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format(data["OutcomesStatus"]),"Status option clicked")
            self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"clicked on currency code dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_option.format(data["CurrencyCode"]),"Currency code clicked")
            self.page.keyboard.press("Escape")
            self.page.get_by_label("MCC").click()
            self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_option.format(data["MCC"]),"MCC option clicked")
            self.page.keyboard.press("Escape")
            self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"clicked on interchange dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_option.format(data["InterchangeCode"]),"Interchange option clicked")
            self.page.keyboard.press("Escape")
            self.click_by_locator(EcentricTxndetaiilReportlocators.customize_coloums_dropdown,"clicked on customize columns dropdown")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(data["CustomizeColumns"]), "UDF4 is clicked")
            self.page.keyboard.press("Escape")
            selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
            print(selected_values)
        self.click_by_locator(EcentricTxndetaiilReportlocators.update_button, "update button clicked")
        expected_message = "Template updated successfully."
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

        self.page.wait_for_timeout(5000)

        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "download button clicked")
        self.page.wait_for_timeout(4000)

        expected_message2 = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message2 = toast.text_content().strip()
        print(actual_message2)
        try:
            assert actual_message2 == expected_message2
            self._record(f"Toast message displayed: {actual_message2}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_download_report(self, data: dict):
        
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(4000)

        expected_message = data["ExpectedMessage"]
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def verify_save_filter(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox,data["New Template Name"],"Template Name")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"clicked on transaction mode dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["TransactionMode"]),"Transaction mode clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"clicked on transaction type dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["TransactionType"]),"Transaction type clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"clicked on payment instrument dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["PaymentInstrument"]),"Payment instrument clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format(data["OutcomesStatus"]),"Status option clicked")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"clicked on currency code dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_option.format(data["CurrencyCode"]),"Currency code clicked")
        self.page.keyboard.press("Escape")
        self.page.get_by_label("MCC").click()
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_option.format(data["MCC"]),"MCC option clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"clicked on interchange dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_option.format(data["InterchangeCode"]),"Interchange option clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_coloums_dropdown,"clicked on customize columns dropdown")
        if self.locator(EcentricTxndetaiilReportlocators.Customized_coloumns_select_all_checked).count() > 0:
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"unSelect All")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"clicked on select all checkbox")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"clicked to unselect all checkbox")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(data["CustomizeColumns"]), "UDF4 is clicked")
            self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "select category dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), "select category option")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]), data["category_textbox"], "fill the value")
        self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print ("Selected Values:", selected_values)
        saved_values = [value.strip() for value in selected_values]
        print(saved_values)
        saved_category_option = self.page.get_by_label("Category").text_content().strip()
        print(saved_category_option)
        saved_category_texbox_value = self.locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"])).input_value().strip()
        print(saved_category_texbox_value)
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_filtter_close_icon)
        self.click_by_locator(EcentricTxndetaiilReportlocators.confirm_button)
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Template dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_option.format(data["New Template Name"]), f"{data['New Template Name']} is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "clicked on manage preference button")
        self.page.wait_for_timeout(3000)
        displayed_values = self.locator(EcentricTxndetaiilReportlocators.manage_preference_selected_values).all_text_contents()
        print(displayed_values)
        print("Displayed Values:", displayed_values)
        displayed_values = [value.strip() for value in displayed_values]
        print("Displayed Values:", displayed_values)

        Actual_saved_category_option = self.page.get_by_label("Category").text_content().strip()
        print(Actual_saved_category_option)
        actual_saved_category_texbox_value = self.locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"])).input_value().strip()
        print(actual_saved_category_texbox_value)
        try:
            assert set(saved_values) == set(displayed_values)
            assert saved_category_option == Actual_saved_category_option
            assert saved_category_texbox_value == actual_saved_category_texbox_value
            self._record("All saved filter values are displayed correctly in Manage Preference", "pass")
        except AssertionError as e:
            self._record(f"Saved Values: {saved_values}, Displayed Values: {displayed_values}", "fail")
            raise
    

        

        


    def verify_save_download_button(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio,"Filter Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.add_new_template,"Add New Template")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown,"Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]),"Select Category option clicked")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]),data["category_textbox"],"Category textbox filled")
        template_name = (data.get("New Template Name") or "").strip()
        if template_name == "":
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_disabled(), "Save button should be disabled when template name is empty"
            assert self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button).is_disabled(), "download button should be disabled when template name is empty"
        else:
            self.fill_by_locator(EcentricTxndetaiilReportlocators.template_name_textbox, template_name, "fill the template name")
            assert self.locator(EcentricTxndetaiilReportlocators.Add_filter_save_button).is_enabled(), "Save button should be enabled when template name is provided"
            self.click_by_locator(EcentricTxndetaiilReportlocators.Add_filter_save_button, "Click save button")
            self.page.wait_for_timeout(3000)
            assert self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button).is_enabled(), "download button should be enabled when template name is provided"
            

    def verify_adhoc_search_option(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "Adhoc Search radio button")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.template_dropdown),"Transaction date and Time dropdown vsisble")
        assert self.locator(EcentricTxndetaiilReportlocators.manage_preference).is_disabled()
        assert self.locator(EcentricTxndetaiilReportlocators.download_button).is_disabled()
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Transaction date and Time dropdown vsisble")
        self.assert_not_visible(self.locator(EcentricTxndetaiilReportlocators.add_new_template),"Add Template not vsisble")

    def verify_adhoc_transaction_date_dropdown(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio,"adhoc search Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Transaction date and Time dropdown")
        expected_options = [
            "Today",
            "Yesterday",
            "Last 7 days",
            "Last 30 days",
            "Custom range"
        ]
        for option in expected_options:
            self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.date_option.format(option)),option)

    def verify_default_adhoc_search(self, data: dict):
        Transaction_date_time = data["Date Range"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio,"adhoc search Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Transaction date and Time dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(Transaction_date_time), f"{Transaction_date_time} is selected")
        if Transaction_date_time == "Custom range":
            from_date = data["FromDate"]
            to_date = data["ToDate"]
            self.click_by_locator(EcentricTxndetaiilReportlocators.calendar_date.format(from_date),f"{from_date} selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.calendar_date.format(to_date),f"{to_date} selected")
            self.click_by_locator(EcentricTxndetaiilReportlocators.apply_button, "click apply button")

        assert self.locator(EcentricTxndetaiilReportlocators.download_button).is_enabled()
        assert self.locator(EcentricTxndetaiilReportlocators.manage_preference).is_enabled()
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown, "click Transaction mode dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.dropdown_select_all_checked), "transaction mode by default all selected")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown, "click Transaction type dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.dropdown_select_all_checked), "transaction type by default all selected")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown, "click payment instrument dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.dropdown_select_all_checked), "payment instrument by default all selected")  
        self.page.keyboard.press("Escape")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.status_all_checked), "Status by default All selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown, "click currency code dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.currency_select_all_checked), "currency code by default all selected")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_dropdown, "click MCC type dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.MCC_select_all_checked), "MCC by default all selected")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown, "click Interchange type dropdown")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.interchange_select_all_checked), "Interchange by default all selected")
        self.page.keyboard.press("Escape")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.customize_coloums_dropdown), "customize coloumn dropdown visible")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.select_category_dropdown), "Category dropdown visible")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button), "Download button is visible")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.close_icon), "close icon is visible")

    def verify_custom_range_functionality(self, data: dict):
        Transaction_date_time = data["Date Range"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio,"adhoc search Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown, "Transaction date and Time dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(Transaction_date_time), f"{Transaction_date_time} is selected")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.start_date_field),"Start Date field visible")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.end_date_field),"End Date field visible")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.calendar_popup),"Calendar displayed")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.apply_button),"Apply button displayed")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.cancel_button),"Cancel button displayed")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.calendar_right_arrow)," Calendar right arrow displayed")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.calendar_left_arrow)," Calendar left arrow displayed")
        from_date = data["FromDate"]
        to_date = data["ToDate"]
        self.click_by_locator(EcentricTxndetaiilReportlocators.calendar_date.format(from_date),f"{from_date} selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.calendar_date.format(to_date),f"{to_date} selected")
        assert self.locator(EcentricTxndetaiilReportlocators.cancel_button).is_enabled()
        assert self.locator(EcentricTxndetaiilReportlocators.apply_button).is_enabled()

        if data["TestcaseID"] == "TC-TDR-199":
            self.click_by_locator(EcentricTxndetaiilReportlocators.cancel_button, "click cancel button")
            self.page.wait_for_timeout(2000)
            self.assert_not_visible(self.locator(EcentricTxndetaiilReportlocators.calendar_popup),"Calendar pop is closed")

        if data["TestcaseID"] == "TC-TDR-200":
            self.click_by_locator(EcentricTxndetaiilReportlocators.apply_button, "click apply button")
            actual_date_range = self.locator(EcentricTxndetaiilReportlocators.selected_date_range).text_content().strip()
            print(actual_date_range)
            expected_from = datetime.strptime(data["FromDate"],"%m/%d/%Y").strftime("%#d %b, %Y")
            print(expected_from)
            expected_to = datetime.strptime(data["ToDate"],"%m/%d/%Y").strftime("%#d %b, %Y")
            print(expected_to)
            assert expected_from in actual_date_range
            assert expected_to in actual_date_range
            assert self.locator(EcentricTxndetaiilReportlocators.manage_preference).is_enabled()
            assert self.locator(EcentricTxndetaiilReportlocators.download_button).is_enabled()

    def verify_category_textbox_adhoc_search(self, data:dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), f"{data["category_option"]} is selected")
        self.assert_visible(self.locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"])),f"{data['category_option']} textbox is visible")


    def verify_valid_category_name_adhoc_search(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), f"{data["category_option"]} is selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]), data["category_textbox"], "fill the value")
        try:
           self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button).is_enabled()
           self._record("valid Merchant name")
        except AssertionError as e:
           self._record("valid Merchant name but download button disable")
           raise

    def verify_Invalid_category_name_adhoc_search(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), f"{data["category_option"]} is selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]), data["category_textbox"], "fill the value")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_columns_section)
        expected_msg = data["ExpectedMessage"]
        actual_msg = self.locator(EcentricTxndetaiilReportlocators.validation_error_message).text_content().strip()
        try:
            assert actual_msg == expected_msg
            assert self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button).is_disabled()
            self._record("invalid input msg and download button not enabled", "pass")
        except AssertionError as e:
            self._record(str(e))

    def verify_category_report_adhoc_search(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio, "click adhoc search button")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), "Template option is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click on manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "Select Category Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), f"{data["category_option"]} is selected")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]), data["category_textbox"], "fill the value")
        self.click_by_locator(EcentricTxndetaiilReportlocators.mange_preference_download_button, "click download button")
        self.page.wait_for_timeout(3000)
        expected_message = "Transaction detail report has been successfully downloaded."
        toast = self.locator(EcentricTxndetaiilReportlocators.download_success_toast)
        toast.wait_for(state="visible", timeout=10000)
        actual_message = toast.text_content().strip()
        print(actual_message)
        try:
            assert actual_message == expected_message
            self._record(f"Toast message displayed: {actual_message}", "pass")
        except AssertionError as e:
            self._record(str(e))
            raise

    def delete_profile_template(self, data: dict):
        self.click_by_locator(EcentricTxndetaiilReportlocators.filter_template_radio, "select filter template radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_filter_templates, "click on manage filter templates")
        self.click_by_locator(EcentricTxndetaiilReportlocators.delete_template_icon.format(data["TemplateName"]), f"click {data["TemplateName"]} delete icon")
        self.click_by_locator(EcentricTxndetaiilReportlocators.yes_button, "click on yes button")
        expected_message = f'Template "{data["TemplateName"]}" deleted successfully.'
        actual_message = self.locator(EcentricTxndetaiilReportlocators.toast_message).text_content().strip()
        print("Expected:", expected_message)
        print("Actual:", actual_message)
        assert actual_message == expected_message
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_filter_templates, "click on manage filter templates")
        self.assert_not_visible(self.locator(EcentricTxndetaiilReportlocators.delete_template_icon.format(data["TemplateName"])), f"{data["TemplateName"]} Not visible after deleted successfully")

    def verify_adhoc_search_category_filter(self, data: dict):
        transaction_mode=data["TransactionMode"]
        print(transaction_mode)
        self.click_by_locator(EcentricTxndetaiilReportlocators.adhoc_search_radio,"adhoc Template Radio")
        self.click_by_locator(EcentricTxndetaiilReportlocators.template_dropdown,"Template Dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.date_option.format(data["Date Range"]), f"{data["Date Range"]} is selected")
        self.click_by_locator(EcentricTxndetaiilReportlocators.manage_preference, "click manage preference")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_dropdown,"clicked on transaction mode dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox, "Unselect all")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(transaction_mode), f"{transaction_mode} is selected")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_type_dropdown,"clicked on transaction type dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["TransactionType"]),"Transaction type clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.payment_insttrument_dropdown,"clicked on payment instrument dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.transaction_mode_option_select.format(data["PaymentInstrument"]),"Payment instrument clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.status_option.format(data["OutcomesStatus"]),"Status option clicked")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_dropdown,"clicked on currency code dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.currency_code_option.format(data["CurrencyCode"]),"Currency code clicked")
        self.page.keyboard.press("Escape")
        self.page.get_by_label("MCC").click()
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.MCC_option.format(data["MCC"]),"MCC option clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_dropdown,"clicked on interchange dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_all_checkbox,"clicked on select all checkbox")
        self.click_by_locator(EcentricTxndetaiilReportlocators.interchange_option.format(data["InterchangeCode"]),"Interchange option clicked")
        self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.customize_coloums_dropdown,"clicked on customize columns dropdown")
        if self.locator(EcentricTxndetaiilReportlocators.Customized_coloumns_select_all_checked).count() > 0:
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"unSelect All")
        else:
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"clicked on select all checkbox")
            self.page.wait_for_timeout(2000)
            self.click_by_locator(EcentricTxndetaiilReportlocators.customized_coloumns_select_all_checkbox,"clicked to unselect all checkbox")
            self.click_by_locator(EcentricTxndetaiilReportlocators.Customize_coloums_option.format(data["CustomizeColumns"]), "UDF4 is clicked")
            self.page.keyboard.press("Escape")
        self.click_by_locator(EcentricTxndetaiilReportlocators.select_category_dropdown, "select category dropdown")
        self.click_by_locator(EcentricTxndetaiilReportlocators.category_option.format(data["category_option"]), "select category option")
        self.fill_by_locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"]), data["category_textbox"], "fill the value")
        selected_values = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_realted_value).all_text_contents()
        print ("Selected Values:", selected_values)
        actual_text = " ".join(selected_values)
        print("Actual UI Values:", actual_text)
        actual_transaction_period = self.locator(EcentricTxndetaiilReportlocators.selected_transaction_period).text_content().strip()
        print(actual_transaction_period)
        actual_category_texbox_value = self.locator(EcentricTxndetaiilReportlocators.category_textbox.format(data["category_option"])).input_value().strip()
        print(actual_category_texbox_value)
        try:
            assert data["Date Range"] == actual_transaction_period
            assert data["TransactionMode"] in actual_text
            assert data["TransactionType"] in actual_text
            assert data["PaymentInstrument"] in actual_text
            assert data["CurrencyCode"] in actual_text
            assert data["MCC"] in actual_text
            assert data["InterchangeCode"] in actual_text
            assert data["category_textbox"] == actual_category_texbox_value
            assert self.locator(EcentricTxndetaiilReportlocators.mange_preference_download_button).is_enabled()
            self._record("All selected filter values are displayed successfully","pass")
        except AssertionError as e:
            self._record(str(e), "fail")
            raise
       

        







                

    # --- Bank‑specific role creation handlers ---
    def _add_role_neoleap(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.permission1, data["Permission1"], "Permission 1")
        self.fill_by_locator(loc.permission2, data["Permission2"], "Permission 2")
        self.click_by_locator(loc.filter_template_radio, "filter template radio button")
