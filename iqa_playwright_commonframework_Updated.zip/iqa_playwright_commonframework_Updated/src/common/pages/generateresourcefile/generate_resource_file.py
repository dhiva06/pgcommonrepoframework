from tkinter import dialog

from reference.sample_test import BANK_NAME
from src.banks.oab.locators.resourcefile_locators import ResourceFileLocators
from src.common.base.base_page import BasePage


class GenerateResourceFilePage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="GenerateResourceFile")
        
        self._dispatch = {
                    "oab": (self.navigate_to_resource_file, ResourceFileLocators),
                }
        self.loc = ResourceFileLocators
    

    def _flow(self, key: str):
        entry = self._bank_config().get(self.bank)
        if entry is None or key not in entry:
            raise NotImplementedError(
                f"RiskValidationsPage has no '{key}' steps implemented yet for bank '{self.bank}'"
            )
        return entry[key]

        
    # -------------------- Navigation --------------------
    def navigate_to_resource_file(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.Configuration, f"{bank}Configuration menu")
        self.click_by_locator(loc.generate_resource_file, f"{bank} generate_resource_file menu")
        self.assert_visible(self.locator(loc.page_marker), f"{bank} Negative Bin page")
        
    def generate_resource_file(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.select_custom_dropdown(loc.click_merchant_file, data["Merchant"])
        
    def click_generate_resource_file_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.generate_resource_file_button, "Generate Resource File Button")
        
    def AddAssert_message(self, bank: str, expected_message: str) -> None:
            """Assert the response/validation message text."""
            _, loc = self._dispatch[bank.lower()]
            self.assert_contains_text(self.locator(loc.message_container), expected_message, "Currency response message")
            
            
    def click_generate_resource_file_Negbutton(self, bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.generate_resource_file_button, "Generate Resource File Button")    
            
        self.accept_dialog() 
        print(data.keys())
        expected_message = data.get("ExpectedMessage")
        if expected_message:
            self.assert_text(self.page.locator(f"{loc.validation_message}[normalize-space()='{expected_message}']"),expected_message,"Negative Validation")
        else:
            raise Exception(f"ExpectedMessage column missing in test data: {data}")
                
        
    