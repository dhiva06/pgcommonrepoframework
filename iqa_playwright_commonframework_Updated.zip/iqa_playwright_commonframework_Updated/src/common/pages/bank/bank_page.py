# FIXME (self-review): this file calls invented method(s) that do NOT exist on BasePage - assert_text_by_locator. This WILL raise AttributeError at runtime. Check base_page.py for the real method name(s) to use instead and fix the call(s) below before running.

from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.bank_locators import BankLocators
import random


class BankPage(BasePage):
    def __init__(self, page, module_name="Bank"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_standard, BankLocators),
        }
        self._generated_bin = None

    def navigate_to_bin_management(self, bank: str) -> None:
        """Navigate to Administration > Bin Management menu."""
        _, loc = self._dispatch[bank.lower()]
        self.hover_by_getbytext(loc.administration_menu, "Administration menu", exact=False, timeout=10000)
        self.click_by_locator(loc.bin_management_submenu, "Bin Management submenu")

    def click_add_button(self, bank: str) -> None:
        """Click the Add button on BIN management listing page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_bin_form(self, bank: str, data: dict) -> None:
        """Fill the BIN form with provided data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Standard add flow for BIN management."""
        # Generate random 6-digit BIN
        generated_bin = str(random.randint(100000, 999999))
        self._generated_bin = generated_bin
        
        self.fill_by_locator(loc.bin_input, generated_bin, "BIN")
        self.fill_by_locator(loc.bin_low_range_input, data["BIN Low Range"], "BIN Low Range")
        self.fill_by_locator(loc.bin_high_range_input, data["BIN High Range"], "BIN High Range")
        
        self.click_by_locator(loc.interchange_code_dropdown, "Interchange Code dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Interchange Code']}')]", "Interchange Code option")
        
        self.click_by_locator(loc.card_type_dropdown, "Card Type dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Card Type']}')]", "Card Type option")
        
        self.click_by_locator(loc.card_product_dropdown, "Card Product dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Card Product']}')]", "Card Product option")
        
        self.click_by_locator(loc.country_dropdown, "Country dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Country']}')]", "Country option")
        
        self.click_by_locator(loc.acquiring_type_dropdown, "Acquiring Type dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Acquiring Type']}')]", "Acquiring Type option")
        
        self.click_by_locator(loc.message_type_dropdown, "Message Type dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['Message Type']}')]", "Message Type option")
        
        self.click_by_locator(loc.bin_status_dropdown, "BIN Status dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{data['BIN Status']}')]", "BIN Status option")

    def click_send_for_approval_button(self, bank: str) -> None:
        """Click Send for Approval button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.send_for_approval_button, "Send for Approval button")

    def assert_bin_in_listing(self, bank: str, expected_message: str) -> None:
        """Assert that new BIN appears in listing with correct Request type and status."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message")

    def fill_search_bin_field(self, bank: str, bin_value: str) -> None:
        """Fill the search BIN field."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_bin_field, bin_value, "Search BIN field")

    def click_search_button(self, bank: str) -> None:
        """Click the Search button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.search_button, "Search button")

    def click_row_expand_icon(self, bank: str, bin_value: str) -> None:
        """Click expand icon to open BIN details summary page."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.row_by_bin(bin_value)
        self.click_by_locator(f"{row_locator}{loc.expand_icon}", "Expand icon")

    def click_view_link(self, bank: str, bin_value: str) -> None:
        """Click View link in the row."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.row_by_bin(bin_value)
        self.click_by_locator(f"{row_locator}{loc.view_link}", "View link")

    def assert_bin_details_display(self, bank: str, data: dict) -> None:
        """Assert BIN details page displays all correct information."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.bin_display), data["BIN"], "BIN display")
        self.assert_text(self.locator(loc.bin_low_range_display), data["BIN Low Range"], "BIN Low Range display")
        self.assert_text(self.locator(loc.bin_high_range_display), data["BIN High Range"], "BIN High Range display")
        self.assert_text(self.locator(loc.interchange_code_display), data["Interchange Code"], "Interchange Code display")
        self.assert_text(self.locator(loc.card_type_display), data["Card Type"], "Card Type display")
        self.assert_text(self.locator(loc.card_product_display), data["Card Product"], "Card Product display")
        self.assert_text(self.locator(loc.country_display), data["Country"], "Country display")
        self.assert_text(self.locator(loc.acquiring_type_display), data["Acquiring Type"], "Acquiring Type display")
        self.assert_text(self.locator(loc.message_type_display), data["Message Type"], "Message Type display")

    def click_edit_button(self, bank: str) -> None:
        """Click the Edit button to open update form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button, "Edit button")

    def update_card_type(self, bank: str, new_value: str) -> None:
        """Change Card type to new value."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.card_type_dropdown, "Card Type dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{new_value}')]", "Card Type option")

    def update_country(self, bank: str, new_value: str) -> None:
        """Change Country to new value."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.country_dropdown, "Country dropdown")
        self.click_by_locator(f"//mat-option[contains(text(),'{new_value}')]", "Country option")

    def assert_edit_request_in_history(self, bank: str, expected_message: str) -> None:
        """Assert Request history shows Edit request with Approval pending status."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Edit success message")

    def assert_updated_values_displayed(self, bank: str, data: dict) -> None:
        """Assert updated Card type and Country are displayed on summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.card_type_display), data["Card Type Updated"], "Updated Card Type display")
        self.assert_text(self.locator(loc.country_display), data["Country Updated"], "Updated Country display")

    def click_delete_icon(self, bank: str, bin_value: str) -> None:
        """Click delete icon in the search results row."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.row_by_bin(bin_value)
        self.click_by_locator(f"{row_locator}{loc.delete_icon}", "Delete icon")

    def click_confirmation_send_for_approval(self, bank: str) -> None:
        """Click Send for approval in confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.confirmation_send_for_approval_button, "Confirmation Send for Approval button")

    def assert_delete_request_in_history(self, bank: str, expected_message: str) -> None:
        """Assert Request history shows DELETE request with Approval pending status."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Delete success message")

    def get_generated_bin(self) -> str:
        """Retrieve the generated BIN number from Add action."""
        return self._generated_bin
