from src.common.base.base_page import BasePage
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from src.banks.ecentric.locators.pg_information_locators import (
    BankInformationLocators as EcentricBankInformationLocators,
)
from playwright.sync_api import expect


class BankInformationPage(BasePage):
    def __init__(self, page, module_name="BankInformation"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": {
                "bank_info_menu": self._bank_info_menu,
                "assert_element_visible": self._assert_element_visible,
                "assert_validation_success_text": self._assert_validation_success_text,
                "fill_bank_name": self._fill_bank_name,
                "click_save": self._click_save,
                "fill_bank_short_Code": self._fill_bank_short_Code,
                "fill_contactperson_name": self._fill_contactperson_name,
                "fill_contactperson_mobile_number": self._fill_contactperson_mobile_number,
                "fill_contactperson_email": self._fill_contactperson_email,
                "fill_helpdesk_email": self._fill_helpdesk_email,
                "fill_helpdesk_mobile_number_1": self._fill_helpdesk_mobile_number_1,
                "fill_helpdesk_landline_number_1": self._fill_helpdesk_landline_number_1,
                "fill_helpdesk_toll_free_number_1": self._fill_helpdesk_toll_free_number_1,
                "click_addtionaltollfreenum": self._click_addtionaltollfreenum,
                "get_mobile_checkbox_enabled":self._get_mobile_checkbox_enabled,
                "get_landline_checkbox_enabled":self._get_landline_checkbox_enabled,
                "get_tollfree_checkbox_enabled":self._get_tollfree_checkbox_enabled,
                "fill_Helpdesk_Additional_Numbers":self._fill_Helpdesk_Additional_Numbers,
                "fill_building_name":self._fill_building_name,
                "fill_postalcode":self._fill_postalcode,
                "select_dropdown_value":self._select_dropdown_value,
                
                "click_delete_icon":self._click_delete_icon,
                "locators": EcentricBankInformationLocators,
            },
        }

    def bank_information_config(self, bank: str) -> None:
        config = self._dispatch[bank.lower()]
        config["bank_info_menu"](config["locators"])

    def _bank_info_menu(self, loc) -> None:
        locator = self.page.locator(loc.UNHIDE_MENU)
        locator.hover()
        locator.click()
        self.locator(loc.ADMINISTRATION).hover()
        self.page.wait_for_selector(loc.ADMINISTRATION, state="visible", timeout=90000)
        self.click_by_locator(loc.ADMINISTRATION, "Administration")
        self.page.wait_for_selector(loc.BANK_CONFIGURATION, state="visible", timeout=90000)
        self.click_by_locator(loc.BANK_CONFIGURATION, "Bank configuration")
        self.click_by_locator(loc.UNHIDE_MENU, "Collapse navigation menu")
        self.page.wait_for_selector(loc.BANK_INFORMATION, state="visible", timeout=90000)
        self.click_by_locator(loc.BANK_INFORMATION, "PG information")

    def assert_element_visible(self, bank: str, locator: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_element_visible"](locator, description)

    def _assert_element_visible(self, locator: str, description: str) -> None:
        self.assert_visible(self.locator(locator), description)

    def assert_validation_success_text(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_validation_success_text"](locator, data, description)

    def _assert_validation_success_text(self, locator: str, expected_message: str, description: str) -> None:
        self.page.wait_for_selector(locator, state="visible", timeout=90000)
        self.assert_text(self.locator(locator), expected_message, description)

    def fill_bank_name(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_bank_name"](locator, data, description)

    def _fill_bank_name(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_bank_short_Code(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_bank_short_Code"](locator, data, description)

    def _fill_bank_short_Code(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_contactperson_name(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_contactperson_name"](locator, data, description)

    def _fill_contactperson_name(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_contactperson_mobile_number(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_contactperson_mobile_number"](locator, data, description)

    def _fill_contactperson_mobile_number(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_contactperson_email(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_contactperson_email"](locator, data, description)

    def _fill_contactperson_email(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_helpdesk_email(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_helpdesk_email"](locator, data, description)

    def _fill_helpdesk_email(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_helpdesk_mobile_number_1(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_helpdesk_mobile_number_1"](locator, data, description)

    def _fill_helpdesk_mobile_number_1(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_helpdesk_landline_number_1(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_helpdesk_landline_number_1"](locator, data, description)

    def _fill_helpdesk_landline_number_1(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)

    def fill_helpdesk_toll_free_number_1(self, bank: str, locator: str, data: str, description: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_helpdesk_toll_free_number_1"](locator, data, description)

    def _fill_helpdesk_toll_free_number_1(self, locator: str, data: str, description: str) -> None:
        self.fill_by_locator(self.locator(locator), data, description)
    def fill_building_name(self, bank: str, locator: str, data: str, description: str) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["fill_building_name"](locator, data, description)
    def _fill_building_name(self, locator: str, data: str, description: str):
            self.fill_by_locator(self.locator(locator), data, description)
    def fill_postalcode(self, bank: str, locator: str, data: str, description: str) -> None:
                assert_method = self._dispatch[bank.lower()]
                assert_method["fill_building_name"](locator, data, description)
    def _fill_postalcode(self, locator: str, data: str, description: str):
                self.fill_by_locator(self.locator(locator), data, description)

    def click_save(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_save"](assert_method["locators"])

    def _click_save(self, loc) -> None:
        self.page.wait_for_selector(loc.SAVE, state="visible", timeout=30000)
        self.click_by_locator(loc.SAVE, "Click save button")

    def click_addtionaltollfreenum(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_addtionaltollfreenum"](assert_method["locators"])

    def _click_addtionaltollfreenum(self, loc) -> None:
        self.page.wait_for_selector(loc.ADDITIONAL_TOLL_FREE_NUMBER, state="visible", timeout=80000)
        self.click_by_locator(loc.ADDITIONAL_TOLL_FREE_NUMBER, "Click addtionaltollfreenum")
    
    def click_delete_icon(self, bank: str) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["click_delete_icon"](assert_method["locators"])
    def _click_delete_icon(self, loc) -> None:
        self.page.wait_for_selector(loc.DELETE_TOLL_FREE_NUMBER, state="visible", timeout=60000)
        self.click_by_locator(
            loc.DELETE_TOLL_FREE_NUMBER,
            "Click Additional Toll Free Number",
        )
        self.page.wait_for_selector(loc.DELETE_LANDLINE_NUMBER, state="visible", timeout=60000)
        self.click_by_locator(
            loc.DELETE_LANDLINE_NUMBER,
            "Click Additional Landline Number",
        )
        self.page.wait_for_selector(loc.DELETE_MOBILE_NUMBER, state="visible", timeout=60000)
        self.click_by_locator(
            loc.DELETE_MOBILE_NUMBER,
            "Click Additional Mobile Number",
        )

    def get_mobile_checkbox_enabled(self, bank:  str, data, num) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["get_mobile_checkbox_enabled"](assert_method["locators"], data["HELPDESK_MOBILE_SUC_MSG"], num["HELPDESK_MOBILE_NUMBER_1"])

    def _get_mobile_checkbox_enabled(self, loc, expected_text: str, helpdeskmobilenumber1: str):
        Mobile_Checkbox = self.page.get_attribute(loc.MOBILE_CLICK_CHECKBOX, "data-mat-icon-namespace")
        Value = Mobile_Checkbox.split("_")[1]
        if Value == "solid":
            self.assert_text(
                self.locator(loc.HELPDESK_MOBILE_NUMBER_1),
                expected_text,
                "Mobile checcbox already selected",
            )
        else:
            self.click_by_locator(loc.MOBILE_CLICK_CHECKBOX, "MOBILE_CLICK_CHECKBOX")
            self.fill_by_locator(
                loc.HELPDESK_MOBILE_NUMBER_1,
                helpdeskmobilenumber1,
                "Fill HELPDESK_MOBILE_NUMBER_1",
            )
            self.click_by_locator(loc.SAVE, "Save")

    def get_landline_checkbox_enabled( self, bank:  str, expected_text: str, helpdesklandlinenumber1: str) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["get_landline_checkbox_enabled"](assert_method["locators"], expected_text, helpdesklandlinenumber1)

    def _get_landline_checkbox_enabled(self, loc, expected_text: str, helpdesklandlinenumber1: str):
        Landline_Checkbox = self.page.get_attribute(
            loc.LANDLINE_CLICK_CHECKBOX, "data-mat-icon-namespace"
        )
        Value = Landline_Checkbox.split("_")[1]
        if Value == "solid":
            self.assert_text(
                self.locator(loc.HELPDESK_LANDLINE_NUMBER_1),
                expected_text,
                "Landline checcbox already selected",
            )
        else:
            self.click_by_locator(
                loc.LANDLINE_CLICK_CHECKBOX,
                "LANDLINE_CLICK_CHECKBOX",
            )
            self.fill_by_locator(
                loc.HELPDESK_LANDLINE_NUMBER_1,
                helpdesklandlinenumber1,
                "Fill HELPDESK_LANDLINE_NUMBER_1",
            )
            self.click_by_locator(loc.SAVE, "Save")

    def get_tollfree_checkbox_enabled(self, bank:  str, expected_text: str, helpdesktollfreenumber1: str
           ) -> None:
               assert_method = self._dispatch[bank.lower()]
               assert_method["get_tollfree_checkbox_enabled"](assert_method["locators"], expected_text, helpdesktollfreenumber1)
               
    def _get_tollfree_checkbox_enabled(self, loc, expected_text: str,helpdesktollfreenumber1: str):
        Tollfree_Checkbox = self.page.get_attribute(
            loc.TOLL_FREE_CLICK_CHECKBOX, "data-mat-icon-namespace"
        )
        Value = Tollfree_Checkbox.split("_")[1]
        if Value == "solid":
            self.assert_text(
                self.locator(loc.HELPDESK_TOLL_FREE_NUMBER_1),
                expected_text,
                "Tollfree checcbox already selected",
            )
        else:
            self.click_by_locator(
                loc.TOLL_FREE_CLICK_CHECKBOX,
                "TOLL_FREE_CLICK_CHECKBOX",
            )
            self.fill_by_locator(
                loc.HELPDESK_TOLL_FREE_NUMBER_1,
                helpdesktollfreenumber1,
                "Fill HELPDESK_TOLL_FREE_NUMBER_1",
            )
            self.click_by_locator(loc.SAVE, "Save")

    def fill_Helpdesk_Additional_Numbers(self, bank:  str,locator: str, field_locator: str, data: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["fill_Helpdesk_Additional_Numbers"]( locator, field_locator, data)

   
    def _fill_Helpdesk_Additional_Numbers(self, locator: str, field_locator: str, data: str):
            try:
                additional_mobile = self.locator(locator)
                
                if additional_mobile.is_visible():
                    self.click_by_locator(self.locator(locator),"Click Additional Mobile Number",timeout=40000,)
        
                    self.fill_by_locator(
                    self.locator(field_locator),
                    data,
                    "Fill Helpdesk Additional Number")
            except Exception as e:
                    print("Additional Number already added" , e)

    def select_dropdown_value(self, bank: str, locator: str, data: str, description: str) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["select_dropdown_value"](locator, data, description)
    def _select_dropdown_value(self,  locator: str, data: str,description:str):
        self.multi_select_material_options(locator, data, description)

    
    


