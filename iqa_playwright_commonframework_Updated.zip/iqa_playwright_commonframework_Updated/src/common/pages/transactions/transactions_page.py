"""
TransactionsPage - lightweight skeleton for the transactions module.

Mirrors LoginPage's conventions (BasePage subclass, module_name passed to
super().__init__(), bank-aware via self.bank) so real locators/steps can
be filled in per bank the same way LoginPage's _bank_config()/
_portal_config() dispatch does. No demo backend exists for this module
yet - every action method below is a TODO placeholder, not verified
against a live page. Follow LoginPage's pattern-method convention: one
method per distinct field/flow layout, reused across any bank that
shares it, rather than one method per bank.
"""
from src.banks.wio.locators.login_locators import WioLoginLocators
from src.banks.wio.locators.transaction_locators import WioTransactionLocators
from src.banks.pinelabs.locators.transaction_locators import PinelabsTransactionLocators
from src.banks.ecentric.locators.transaction_locators import EcentricTransactionLocators
from src.common.base.base_page import BasePage
from src.common.utilities.config_manager import ConfigManager
from src.banks.oab.locators.login_locators import OabLoginLocators
from src.banks.pinelabs.locators.login_locators import PinelabsLoginLocators
from src.common.pages.authentication.bank_login_page import BankLoginPage
import re
import time
from typing import Optional

class TransactionsPage(BasePage):
        def __init__(self, page):
                super().__init__(page, module_name="Transactions")
                self.payment_id: Optional[str] = None
                self.captured_dialog_messages: list[str] = []
                try:
                        def _on_dlg(dlg):
                                msg = dlg.message or ""
                                self.captured_dialog_messages.append(msg)
                                self.logger.info(f"Captured browser dialog: {msg}")
                                try:
                                        dlg.accept()
                                except Exception:
                                        pass
                        self.page.on("dialog", _on_dlg)
                except Exception:
                        pass
                self._dispatch = {
                        "wio": (self._purchasetransaction_wio, WioTransactionLocators.Hosted_TXN),
                        "pinelabs": (self._purchasetransaction_pinelabs, PinelabsTransactionLocators.Hosted_TXN),
                        "ecentric": (self._purchasetransaction_ecentric, EcentricTransactionLocators.Hosted_TXN),
                }
                self._dispatch_supporting = {
                        "wio": (self._supportingtransaction_wio, WioTransactionLocators.Hosted_TXN),
                        "pinelabs": (self._supportingtransaction_pinelabs, PinelabsTransactionLocators.Hosted_TXN),
                        "ecentric": (self._supportingtransaction_ecentric, EcentricTransactionLocators)
                }
                self._dispatch_negative = {
                        "wio": (self._PaymentpageNegative_wio, WioTransactionLocators.Hosted_TXN),
                        "pinelabs": (self._PaymentpageNegative_pinelabs, PinelabsTransactionLocators.Hosted_TXN)
                }

        def navigate_to_Transaction_url(self) -> dict:
                creds = dict(ConfigManager.load_portal_config("Hosted_TXN"))
                if not self.page.url.startswith(creds["url"]):
                        self.navigate(creds["url"])
                return creds

        navigate_to_portal = navigate_to_Transaction_url

        def navigate_to_Supporting_url(self) -> dict:
                creds = dict(ConfigManager.load_portal_config("Hosted_TXN"))
                self.navigate(creds["supporting_url"])
                return creds


        def get_payment_id(self) -> str:
                """Extract PaymentID from the URL (e.g. paymentpage.htm?PaymentID=202624698115186)."""
                current_url = self.page.url
                match = re.search(r"[?&]PaymentID=([^&#]+)", current_url, re.IGNORECASE)
                if match:
                        self.payment_id = match.group(1)
                        self.logger.info(f"Captured PaymentID from URL: {self.payment_id}")
                        self._record(f"Extracted PaymentID: {self.payment_id} from URL", "info")
                        return self.payment_id

                # If redirect is in progress, wait briefly for URL containing PaymentID
                try:
                        self.page.wait_for_url(re.compile(r".*[?&]PaymentID=.*", re.I), timeout=10000)
                        current_url = self.page.url
                        match = re.search(r"[?&]PaymentID=([^&#]+)", current_url, re.IGNORECASE)
                        if match:
                                self.payment_id = match.group(1)
                                self.logger.info(f"Captured PaymentID from URL: {self.payment_id}")
                                self._record(f"Extracted PaymentID: {self.payment_id} from URL", "info")
                                return self.payment_id
                except Exception:
                        pass

                # If already captured previously, return cached
                if self.payment_id:
                        self.logger.info(f"Returning cached PaymentID: {self.payment_id}")
                        return self.payment_id

                self.logger.warn(f"PaymentID not found in current URL: {current_url}")
                return ""

        take_payment_id = get_payment_id

        def PurchaseTransaction(self, bank: str, data: dict = None, txn_type: str = None) -> None: # type: ignore
                creds = self.navigate_to_Transaction_url()
                # merge portal creds with test data if provided so fields like amount/card are available
                merged = {**creds, **data} if data else creds
                if txn_type:
                        merged["txn_type"] = txn_type
                elif data and (data.get("Action_Type") or data.get("action_type")):
                        merged["txn_type"] = data.get("Action_Type") or data.get("action_type")
                method, loc = self._dispatch[bank.lower()]
                method(merged, loc)

        def AuthTransaction(self, bank: str, data: dict = None) -> None:
                """Execute Authorization transaction by selecting Authorize in the Action dropdown."""
                txn_type = (data.get("Action_Type") or data.get("action_type") or "Authorize") if data else "Authorize"
                self.PurchaseTransaction(bank, data, txn_type=txn_type)

        Authtransaction = AuthTransaction
        authtransaction = AuthTransaction
        purchasetransaction = PurchaseTransaction

        def SupportingTransaction(self, bank: str, data: dict = None, payment_id: str = None) -> None:
                creds = self.navigate_to_Supporting_url()
                merged = {**creds, **data} if data else creds
                if payment_id:
                        merged["payment_id"] = payment_id
                elif self.payment_id:
                        merged["payment_id"] = self.payment_id
                method, loc = self._dispatch_supporting[bank.lower()]
                method(merged, loc)

        supportingtransaction = SupportingTransaction
        Supportingtransaction = SupportingTransaction

        def PaymentpageNegative(self, bank: str, data: dict = None) -> None:
                """Execute Negative Payment Page transaction (e.g., declined card scenarios)."""
                creds = self.navigate_to_Transaction_url()
                merged = {**creds, **data} if data else creds
                method, loc = self._dispatch_negative[bank.lower()]
                method(merged, loc)

        paymentpagenegative = PaymentpageNegative
        Paymentpagenegative = PaymentpageNegative

        def PinelabsCtpTransaction(self, bank_or_data=None, data: dict = None) -> None:
                """Execute Pinelabs CTP (Click to Pay) checkout login transaction."""
                if isinstance(bank_or_data, dict):
                        test_data = bank_or_data
                else:
                        test_data = data or {}
                creds = self.navigate_to_Transaction_url()
                merged = {**creds, **test_data}
                loc = PinelabsTransactionLocators.Hosted_TXN
                self._ctp_transaction_pinelabs(merged, loc)

        pinelabs_ctp_transaction = PinelabsCtpTransaction
        PinelabsCtpLogin = PinelabsCtpTransaction
        pinelabs_ctp_login = PinelabsCtpTransaction

        def EcentricTransaction(self, bank_or_data=None, data: dict = None) -> None:
                """Execute Ecentric Food Cart purchase transaction."""
                if isinstance(bank_or_data, dict):
                        test_data = bank_or_data
                else:
                        test_data = data or {}
                creds = self.navigate_to_Transaction_url()
                merged = {**creds, **test_data}
                loc = EcentricTransactionLocators.Hosted_TXN
                self._purchasetransaction_ecentric(merged, loc)

        ecentric_transaction = EcentricTransaction
        Ecentrictransaction = EcentricTransaction

        def EcentricSupportingTransaction(self, bank_or_data=None, data: dict = None) -> None:
                """Execute Ecentric Supporting Transaction: login to portal, navigate to Transactions menu, and click Refunds tab."""
                if isinstance(bank_or_data, dict):
                        test_data = bank_or_data
                else:
                        test_data = data or {}
                self._supportingtransaction_ecentric(test_data, EcentricTransactionLocators)

        ecentric_supporting_transaction = EcentricSupportingTransaction
        Ecentricsupportingtransaction = EcentricSupportingTransaction



        def assert_transactionstatus(self, bank: str, expected_status: str = "CAPTURED") -> None:
                _, loc = self._dispatch[bank.lower()]
                status_locator = self.locator(loc.ActualStatus)
                self.assert_visible(status_locator, f"{bank.capitalize()} Transaction Status")
                actual_status = status_locator.inner_text().strip()
                self.logger.info(f"Actual Transaction Status: '{actual_status}', Expected: '{expected_status}'")
                self._record(f"Actual Transaction Status: '{actual_status}', Expected: '{expected_status}'")
                self.attach_screenshot("Transaction Status Result")
                assert expected_status.upper() in actual_status.upper(), (
                        f"Expected transaction status '{expected_status}' but got '{actual_status}'"
                )

        def _purchasetransaction_wio(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                txn_type = creds.get("txn_type") or creds.get("transaction_type") or creds.get("Action_Type") or creds.get("action_type")
                if txn_type:
                        action_map = {
                                "purchase": "1",
                                "1": "1",
                                "authorize": "4",
                                "authorization": "4",
                                "auth": "4",
                                "4": "4",
                        }
                        val = action_map.get(str(txn_type).strip().lower(), str(txn_type).strip())
                        try:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(value=val)
                        except Exception:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(label=str(txn_type).strip())
                        self.logger.info(f"Selected Transaction Action: {val} ({txn_type})")
                        self._record(f"Selected Transaction Action: {val} ({txn_type})")

                # Mobilenumber (udf6) is optional - fill it only when provided in the test data
                # (the AuthTxn sheet carries it; the Hosted_TXN sheet does not).
                
                self.fill_by_locator(loc.mobilenumber, str(creds["mobilenumber"]), "Mobilenumber")
                self.fill_by_locator(loc.amount, str(creds["amount"]), "Amount")
                self.click_by_locator(loc.click_buy_button, "Buy button")
                self.get_payment_id()
                self.fill_by_locator(loc.card_number, str(creds["card_number"]), "Card Number")
                self.fill_by_locator(loc.cardholder_name, str(creds["cardholder_name"]), "Cardholder Name")
                self.fill_by_locator(loc.expiry_date, str(creds["expiry_date"]), "Expiry Date")
                self.fill_by_locator(loc.cvv, str(creds["cvv"]), "CVV")
                self.click_by_locator(loc.pay_button, "Pay Button")
        
        def _purchasetransaction_pinelabs(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                txn_type = creds.get("txn_type") or creds.get("transaction_type") or creds.get("Action_Type") or creds.get("action_type")
                if txn_type:
                        action_map = {
                                "purchase": "1",
                                "1": "1",
                                "authorize": "4",
                                "authorization": "4",
                                "auth": "4",
                                "4": "4",
                        }
                        val = action_map.get(str(txn_type).strip().lower(), str(txn_type).strip())
                        try:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(value=val)
                        except Exception:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(label=str(txn_type).strip())
                        self.logger.info(f"Selected Transaction Action: {val} ({txn_type})")
                        self._record(f"Selected Transaction Action: {val} ({txn_type})")

                self.fill_by_locator(loc.amount, str(creds["amount"]), "Amount")
                self.click_by_locator(loc.click_buy_button, "Buy button")
                self.get_payment_id()
                self.fill_by_locator(loc.card_number, str(creds["card_number"]), "Card Number")
                self.fill_by_locator(loc.cardholder_name, str(creds["cardholder_name"]), "Cardholder Name")
                self.fill_by_locator(loc.expiry_date, str(creds["expiry_date"]), "Expiry Date")
                self.fill_by_locator(loc.cvv, str(creds["cvv"]), "CVV")
                self.click_by_locator(loc.pay_button, "Pay Button")

        def _purchasetransaction_ecentric(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                amount_val = str(creds.get("amount") or "80")
                card_val = str(creds.get("card_number") or creds.get("cardnumber") or "4985860310875073")
                self.fill_by_locator(loc.amount, amount_val, "Purchase Amount")
                self.fill_by_locator(loc.card_number, card_val, "Card Number")
                self.click_by_locator(loc.submit_button, "Submit Button")
        
        def _PaymentpageNegative_wio(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                self.fill_by_locator(loc.amount, str(creds["amount"]), "Amount")
                if creds.get("mobilenumber"):
                        self.fill_by_locator(loc.mobilenumber, str(creds["mobilenumber"]), "Mobilenumber")
                self.click_by_locator(loc.click_buy_button, "Buy button")
                self.get_payment_id()

                # After Buy, wait for hosted page to render card-payment form
                if self._is_card_form_visible(loc):
                        if creds.get("card_number") is not None:
                                self.fill_by_locator(loc.card_number, str(creds.get("card_number", "")), "Card Number")
                        if creds.get("cardholder_name") is not None:
                                self.fill_by_locator(loc.cardholder_name, str(creds.get("cardholder_name", "")), "Cardholder Name")
                        if creds.get("expiry_date") is not None:
                                self.fill_by_locator(loc.expiry_date, str(creds.get("expiry_date", "")), "Expiry Date")
                        if creds.get("cvv") is not None:
                                self.fill_by_locator(loc.cvv, str(creds.get("cvv", "")), "CVV")
                        try:
                                self.click_by_locator(loc.pay_button, "Pay Button")
                        except Exception:
                                pass
                        self.page.wait_for_load_state("domcontentloaded")
        
        def _PaymentpageNegative_pinelabs(self,creds:dict,loc)->None:
                self.page.wait_for_load_state("domcontentloaded")
                self.fill_by_locator(loc.amount, str(creds["amount"]), "Amount")
                self.click_by_locator(loc.click_buy_button, "Buy button")
                self.fill_by_locator(loc.card_number, str(creds["card_number"]), "Card Number")
                self.fill_by_locator(loc.cardholder_name, str(creds["cardholder_name"]), "Cardholder Name")
                self.fill_by_locator(loc.expiry_date, str(creds["expiry_date"]), "Expiry Date")
                self.fill_by_locator(loc.cvv, str(creds["cvv"]), "CVV")
                self.click_by_locator(loc.pay_button, "Pay Button")

        def _ctp_transaction_pinelabs(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                txn_type = creds.get("txn_type") or creds.get("transaction_type") or creds.get("Action_Type") or creds.get("action_type")
                if txn_type:
                        action_map = {
                                "purchase": "1",
                                "1": "1",
                                "authorize": "4",
                                "authorization": "4",
                                "auth": "4",
                                "4": "4",
                        }
                        val = action_map.get(str(txn_type).strip().lower(), str(txn_type).strip())
                        try:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(value=val)
                        except Exception:
                                self.page.locator(loc.ACTION_DROPDOWN).select_option(label=str(txn_type).strip())
                        self.logger.info(f"Selected Transaction Action: {val} ({txn_type})")
                        self._record(f"Selected Transaction Action: {val} ({txn_type})")

                self.fill_by_locator(loc.amount, str(creds["amount"]), "Amount")
                self.click_by_locator(loc.click_buy_button, "Buy button")

                mobile_number = creds.get("mobilenumber") or creds.get("mobile_number") or "9659854417"
                email_id = creds.get("email") or creds.get("email_id") or creds.get("mail_id") or "aravindans@fsstech.com"

                self.fill_by_locator(loc.ctp_mobile_input, str(mobile_number), "CTP Mobile Number")
                self.fill_by_locator(loc.ctp_email_input, str(email_id), "CTP Email ID")
                self.click_by_locator(loc.ctp_continue_btn, "CTP Continue Login Button")

                

        def _select_supporting_action(self, locator, action_raw: str) -> None:
                """Select the supporting transaction action dropdown.

                The ``action`` column in the Excel sheet can be a named action
                (``inquiry``, ``void purchase``) or a numeric code (``8``, ``3``, ``6``).
                Dropdown option values differ between WIO portal versions, so this method
                first tries the numeric value, then falls back to matching the option label
                (e.g. code ``6`` -> ``Void Authorization``).
                """
                action_map = {
                        "credit": "2",
                        "void purchase": "3",
                        "void": "3",
                        "capture": "5",
                        "void capture": "7",
                        "inquiry": "8",
                        "void authorization": "9",
                        "void auth": "9",
                        "recurring": "10",
                }
                numeric_label_aliases = {
                        "1": ["Purchase"],
                        "2": ["Credit"],
                        "3": ["Void Purchase"],
                        "4": ["Authorize"],
                        "5": ["Capture"],
                        "6": ["Void Authorization", "Void Auth"],
                        "7": ["Void Capture"],
                        "8": ["Inquiry"],
                        "9": ["Void Authorization", "Void Auth"],
                        "10": ["Recurring"],
                }

                action_val = action_map.get(action_raw.lower(), action_raw)
                # normalize float-like strings coming from Excel (e.g. "3.0")
                if isinstance(action_val, str) and action_val.endswith(".0"):
                        action_val = action_val[:-2]

                def _try_select(**opt):
                        try:
                                self.page.locator(locator).select_option(**opt)
                                return True
                        except Exception:
                                return False

                # 1) try the direct value first (works when dropdown value == numeric code)
                if _try_select(value=action_val):
                        self.logger.info(f"Selected action by value: {action_val}")
                        return

                # 2) numeric code not matched by value -> try descriptive label aliases
                if str(action_val).isdigit():
                        for label in numeric_label_aliases.get(str(action_val), []):
                                if _try_select(label=label):
                                        self.logger.info(f"Selected action by label (value {action_val}): {label}")
                                        return

                # 3) generic fallback: match the raw input against option labels
                if _try_select(label=str(action_raw).strip()):
                        self.logger.info(f"Selected action by raw label: {action_raw}")
                        return

                self.logger.error(
                        f"Could not select supporting transaction action: '{action_raw}' "
                        f"(mapped value: '{action_val}')"
                )
                raise ValueError(
                        f"Could not select action '{action_raw}' in the transaction action dropdown. "
                        f"Supported values: {', '.join(action_map.keys())}. "
                        f"Check that the portal's action dropdown contains a matching option."
                )

        def _supportingtransaction_wio(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                action_data = creds.get("action")
                if action_data is None or str(action_data).strip() == "":
                        raise ValueError("Action is required for Supporting Transaction but not provided in Transactions.xlsx")

                action_raw = str(action_data).strip()
                if action_raw.endswith(".0"):
                        action_raw = action_raw[:-2]

                self._select_supporting_action(loc.ACTION_DROPDOWN, action_raw)
                self.logger.info(f"Selected supporting action: {action_raw} (raw: {action_raw})")
                self._record(f"Selected supporting action: {action_raw} (raw: {action_raw})")

                # An amount is required for credit/void-purchase/capture/void-capture operations.
                if action_raw.lower() in ("credit", "void purchase", "void", "capture", "void capture") and creds.get("amount"):
                        self.fill_by_locator(loc.amount, str(creds["amount"]), "Supporting Amount")

                try:
                        self.page.locator(loc.UDF5_DROPDOWN).select_option("PaymentID")
                except Exception:
                        self.page.locator(loc.UDF5_DROPDOWN).select_option(label="PaymentID")
                self.logger.info("Selected UDF5: PaymentID")
                self._record("Selected UDF5: PaymentID")
                payment_id = creds.get("payment_id") or getattr(self, "payment_id", "") or self.get_payment_id()
                if payment_id:
                        self.fill_by_locator(loc.COMMENT_FIELD, str(payment_id), "Payment ID in Comment Field")
                        self.logger.info(f"Filled Comment with Payment ID: {payment_id}")
                        self._record(f"Filled Comment with Payment ID: {payment_id}")
                else:
                        self.logger.warn("No Payment ID available to fill in Comment field")
                try:
                        self.click_by_locator(loc.click_buy_button, "Buy button")
                except Exception:
                        self.click_by_role("button", "Buy")
                self.page.wait_for_load_state("networkidle")
        
        def _supportingtransaction_pinelabs(self, creds: dict, loc) -> None:
                self.page.wait_for_load_state("domcontentloaded")
                action_data = creds.get("action")
                if action_data is None or str(action_data).strip() == "":
                        raise ValueError("Action is required for Supporting Transaction but not provided in Transactions.xlsx")

                action_raw = str(action_data).strip()
                if action_raw.endswith(".0"):
                        action_raw = action_raw[:-2]

                self._select_supporting_action(loc.ACTION_DROPDOWN, action_raw)
                self.logger.info(f"Selected supporting action: {action_raw} (raw: {action_raw})")
                self._record(f"Selected supporting action: {action_raw} (raw: {action_raw})")

                # An amount is required for credit/void-purchase/capture/void-capture operations.
                if action_raw.lower() in ("credit", "void purchase", "void", "capture", "void capture") and creds.get("amount"):
                        self.fill_by_locator(loc.amount, str(creds["amount"]), "Supporting Amount")

                try:
                        self.page.locator(loc.UDF5_DROPDOWN).select_option("PaymentID")
                except Exception:
                        self.page.locator(loc.UDF5_DROPDOWN).select_option(label="PaymentID")
                self.logger.info("Selected UDF5: PaymentID")
                self._record("Selected UDF5: PaymentID")
                payment_id = creds.get("payment_id") or getattr(self, "payment_id", "") or self.get_payment_id()
                if payment_id:
                        self.fill_by_locator(loc.COMMENT_FIELD, str(payment_id), "Payment ID in Comment Field")
                        self.logger.info(f"Filled Comment with Payment ID: {payment_id}")
                        self._record(f"Filled Comment with Payment ID: {payment_id}")
                else:
                        self.logger.warn("No Payment ID available to fill in Comment field")
                try:
                        self.click_by_locator(loc.click_buy_button, "Buy button")
                except Exception:
                        self.click_by_role("button", "Buy")
                self.page.wait_for_load_state("networkidle")

        def _supportingtransaction_ecentric(self, creds: dict, loc=None) -> None:
                """Execute Ecentric supporting transaction:
                1. Login to Ecentric Bank portal (referring existing BankLoginPage login method with captcha).
                2. Navigate to Transactions menu from sidebar.
                3. Click Refunds tab.
                4. Search by Payment ID if available and attach screenshot.
                """
                portal_loc = EcentricTransactionLocators.Portal

                # 1. Login to Ecentric Portal using the existing bank login method
                self.logger.info("Logging into Ecentric Bank Portal for supporting transaction...")
                self._record("Logging into Ecentric Bank Portal for supporting transaction")
                login_page = BankLoginPage(self.page)
                login_page.login("ecentric")
                self.page.wait_for_load_state("networkidle")

                # 2. Expand menu if collapsed
                try:
                        unhide_btn = self.page.locator(portal_loc.unhide_menu_button)
                        if unhide_btn.count() > 0 and unhide_btn.first.is_visible():
                                self.click_by_locator(portal_loc.unhide_menu_button, "Unhide sidebar menu")
                                self.page.wait_for_timeout(500)
                except Exception as exc:
                        self.logger.debug(f"Sidebar unhide check: {exc}")

                # 3. Click Transactions menu
                self.logger.info("Clicking Transactions menu...")
                self._record("Clicking Transactions menu")
                self.click_by_locator(portal_loc.transactions_menu, "Transactions menu")
                self.page.wait_for_load_state("networkidle")

                # 4. Click Refunds tab
                self.logger.info("Clicking Refunds tab...")
                self._record("Clicking Refunds tab")
                self.click_by_locator(portal_loc.refunds_tab, "Refunds tab")
                self.page.wait_for_load_state("networkidle")

                # 5. Search by Payment ID if provided
                payment_id = creds.get("payment_id") or getattr(self, "payment_id", "") or self.get_payment_id()
                if payment_id:
                        search_input = self.page.locator(portal_loc.search_payment_id_input)
                        if search_input.count() > 0 and search_input.first.is_visible():
                                self.fill_by_locator(portal_loc.search_payment_id_input, str(payment_id), "Enter Payment ID")
                                self.click_by_locator(portal_loc.search_button, "Search button")
                                self.page.wait_for_load_state("networkidle")
                                self.logger.info(f"Searched Payment ID in Refunds tab: {payment_id}")
                                self._record(f"Searched Payment ID in Refunds tab: {payment_id}")

                self.assert_visible(self.locator(portal_loc.refunds_tab), "Ecentric Refunds tab")
                self.attach_screenshot("Ecentric_Refunds_Tab")
                self.logger.info("Successfully completed Ecentric supporting transaction on Refunds tab")
                self._record("Successfully completed Ecentric supporting transaction on Refunds tab", "pass")


        def _value_or_empty(self, value) -> str:
                """Return ``str(value)`` when not-None, else empty string. Avoids the 'None' -> 'None' trap."""
                return str(value) if value is not None else ""

        def _is_card_form_visible(self, loc) -> bool:
                """Return True if the card-payment form (credit card number field) is visible."""
                try:
                        self.page.locator(loc.card_number).wait_for(state="visible", timeout=8000)
                        return True
                except Exception:
                        return False

        def assert_page_contains(self, expected: str, timeout: int = 10000) -> None:
                """Wait for ``expected`` text to appear anywhere on the page or in browser dialogs and assert it.

                Used by negative-scenario tests to validate server-side validation/error messages
                that are not represented by the transaction-status table column.
                """
                timeout_sec = (timeout / 1000.0) if timeout > 60 else float(timeout)
                end = time.time() + timeout_sec
                text = ""
                expected_str = str(expected).strip()
                while time.time() < end:
                        # 1. Check any captured native dialog/alert messages
                        for dlg_msg in list(self.captured_dialog_messages):
                                if expected_str and expected_str.lower() in dlg_msg.lower():
                                        self.logger.info(f"PASS: dialog contains expected text: '{expected_str}'")
                                        self._record(f"PASS: dialog contains '{expected_str}'", "pass")
                                        self.attach_screenshot(f"expected_message_{expected_str[:24].replace(' ', '_')}")
                                        return

                        # 2. Check on-page text
                        try:
                                text = self.page.locator("body").inner_text()
                        except Exception:
                                try:
                                        all_texts = self.page.locator("body").all_text_contents()
                                        text = " ".join(all_texts) if isinstance(all_texts, list) else str(all_texts)
                                except Exception:
                                        text = ""

                        if expected_str and expected_str.lower() in text.lower():
                                self.logger.info(f"PASS: page contains expected text: '{expected_str}'")
                                self._record(f"PASS: page contains '{expected_str}'", "pass")
                                self.attach_screenshot(f"expected_message_{expected_str[:24].replace(' ', '_')}")
                                return
                        time.sleep(0.5)

                # Final check in captured dialog messages
                for dlg_msg in list(self.captured_dialog_messages):
                        if expected_str and expected_str.lower() in dlg_msg.lower():
                                self.logger.info(f"PASS: dialog contains expected text: '{expected_str}'")
                                self._record(f"PASS: dialog contains '{expected_str}'", "pass")
                                return

                self.logger.error(f"FAIL: expected text not found on page or dialog: '{expected_str}'")
                self._record(f"FAIL: page/dialog does not contain '{expected_str}'", "fail")
                self.attach_screenshot("error_page_screenshot")
                raise AssertionError(
                        f"Expected text '{expected_str}' not found on page or dialog. Page text: {text}. Dialogs: {self.captured_dialog_messages}"
                )

        def _clickbuy_pinelabs(self, creds: dict, loc) -> None:
                self.click_by_locator(loc.login_button, "Login button")
                self.page.wait_for_load_state("domcontentloaded")
                self.fill_by_locator(loc.username_field, creds["username"], "Username")
                self.fill_by_locator(loc.password_field, creds["password"], "Password")
                self.click_by_locator(loc.submit_button, "Login button")

        def handle_otp(self, otp: str, loc=None) -> None:
                """Handle OTP for the hosted WIO transaction flow.

                Handles both the 3DS Cardinal iframe (older WIO portals) and the
                WIO hosted-page OTP textbox (sandbox / full-page-3DS mode). If no OTP
                UI element is found it proceeds gracefully instead of blocking for 30s.
                """
                if loc is None:
                        loc = WioTransactionLocators.Hosted_TXN

                try:
                        # Strategy 1: 3DS Cardinal iframe (older WIO portals).
                        self.page.wait_for_selector(loc.OTP_IFRAME, timeout=15000)
                        frame = self.page.frame_locator(loc.OTP_IFRAME)

                        if otp is not None:
                                try:
                                        frame.get_by_role("textbox", name=re.compile("otp", re.I)).first.fill(str(otp), timeout=7000)
                                except Exception:
                                        frame.get_by_role("textbox").first.fill(str(otp), timeout=7000)

                        submit = frame.get_by_role("button", name=re.compile("submit|verify|continue", re.I)).first
                        try:
                                submit.click(timeout=7000)
                        except Exception:
                                frame.get_by_role("button").first.click(timeout=7000)

                        self.logger.info("OTP entered via 3DS iframe")
                        self._record("OTP entered via 3DS iframe", "info")
                except Exception as exc:
                        # Strategy 2: OTP textbox on the hosted page itself (sandbox / no-iframe).
                        self.logger.info(f"3DS iframe not found ({exc}); falling back to page-level OTP")
                        otp_locator = None
                        for candidate in [
                                self.page.locator('input[name="otp"]'),
                                self.page.locator('input[name="OTP"]'),
                                self.page.get_by_placeholder("Enter OTP"),
                                self.page.get_by_label("Enter OTP"),
                                self.page.locator("#otp"),
                                self.page.locator('input[type="tel"]'),
                        ]:
                                try:
                                        if candidate.count() > 0:
                                                otp_locator = candidate.first
                                                break
                                except Exception:
                                        continue

                        if otp_locator is not None:
                                if otp is not None:
                                        otp_locator.fill(str(otp))
                                submit = self.page.get_by_role("button", name=re.compile("submit|verify|enter", re.I)).first
                                if submit.count() > 0:
                                        submit.click()
                                self.logger.info("OTP entered via hosted-page textbox")
                                self._record("OTP entered via hosted-page textbox", "info")
                        else:
                                self.logger.info("No OTP UI element found - no OTP entry performed")
                                self._record("No OTP UI element found - no OTP entry performed", "info")

                # Handle post-OTP redirect, actively clicking 'Send anyway' or 'proceed-button' if shown
                self._handle_post_otp_redirect()
                self.attach_screenshot("OTP Submitted")

        def _handle_post_otp_redirect(self, timeout_sec: int = 30) -> None:
                """Wait for post-OTP redirect, actively detecting and clicking 'Send anyway' / 'proceed-button'."""
                end_time = time.time() + timeout_sec
                target_pattern = re.compile(
                        r"result|soapsBuy|chocolateBuy|paymentrouter|TranPortal", re.I
                )

                while time.time() < end_time:
                        # Check for Chromium "Send anyway" / proceed-button security warning
                        for btn in [
                                self.page.locator("#proceed-button"),
                                self.page.locator("//*[@id='proceed-button']"),
                                self.page.get_by_role("button", name=re.compile(r"send anyway|continue anyway", re.I)),
                                self.page.locator("button:has-text('Send anyway')"),
                                self.page.get_by_text(re.compile(r"^send anyway$", re.I)),
                        ]:
                                try:
                                        if btn.count() > 0 and btn.first.is_visible():
                                                self.logger.info("Detected 'Send anyway' / proceed button - clicking it")
                                                self._record("Clicked 'Send anyway' / proceed button", "info")
                                                try:
                                                        btn.first.click(timeout=3000)
                                                except Exception:
                                                        btn.first.click(force=True, timeout=3000)
                                                time.sleep(1)
                                                break
                                except Exception:
                                        pass

                        curr_url = self.page.url
                        if target_pattern.search(curr_url):
                                self.logger.info(f"Target URL reached after OTP: {curr_url}")
                                break

                        time.sleep(0.5)

                try:
                        self.page.wait_for_load_state("domcontentloaded", timeout=5000)
                except Exception:
                        pass

        def _todo_action(self, data: dict, loc) -> None:
                """TODO: replace with the real steps for this module."""
                raise NotImplementedError(
                        f"{self.__class__.__name__} has no steps implemented yet for bank '{self.bank}'"
                )
        
