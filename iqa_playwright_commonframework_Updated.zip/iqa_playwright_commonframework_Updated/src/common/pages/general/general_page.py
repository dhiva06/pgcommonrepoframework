from src.banks.ecentric.locators.general_locators import GeneralLocators as EcentricGeneralLocators, GeneralLocatorsNegative as EcentricGeneralLocatorsNegative
from src.common.base.base_page import BasePage


class GeneralPage(BasePage):
    def __init__(self, page, module_name="General"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_notification_standard, EcentricGeneralLocators),
        }

    # -------------------- ADD NOTIFICATION --------------------

    def navigate_to_general(self, bank: str) -> None:
        """Navigate to Administration > Notification > General menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_notification, "Notification submenu")
        self.click_by_locator(loc.menu_general, "General submenu")

    def click_add_button(self, bank: str) -> None:
        """Click the Add button to open Add notification form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def verify_add_notification_page_loaded(self, bank: str) -> None:
        """Verify the Add notification page is displayed with all expected elements."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.breadcrumb), "Breadcrumb navigation")
        self.assert_visible(self.locator(loc.event_dropdown), "Event dropdown")
        self.assert_visible(self.locator(loc.mode_radio_by_label.format(value="SMS")), "SMS radio button")
        self.assert_visible(self.locator(loc.mode_radio_by_label.format(value="Email")), "Email radio button")
        self.assert_visible(self.locator(loc.template_name_input), "Template name field")
        self.assert_visible(self.locator(loc.content_textarea), "Content textarea")
        self.assert_visible(self.locator(loc.preview_panel), "Preview panel")
        self.assert_not_visible(self.locator(loc.save_button), "Save button disabled")

    def fill_add_notification_form(self, bank: str, data: dict) -> None:
        """Fill the Add notification form with test data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_notification_standard(self, loc, data: dict) -> None:
        """Standard Add notification flow for Ecentric."""
        self.click_by_locator(loc.event_dropdown, "Event dropdown")
        self.click_by_locator(loc.event_option_by_text.format(value=data["Event"]), f"Event option: {data['Event']}")
        
        self.click_by_locator(loc.mode_radio_by_label.format(value=data["Mode of notification"]), f"Mode: {data['Mode of notification']}")
        
        self.fill_by_locator(loc.template_name_input, data["Template name"], "Template name")
        
        self.fill_by_locator(loc.content_textarea, data["Content"], "Content")

    def verify_character_counter(self, bank: str, expected_counter: str) -> None:
        """Verify the character counter displays the expected value."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.character_counter), expected_counter, "Character counter")

    def verify_preview_content(self, bank: str, expected_content: str) -> None:
        """Verify the preview panel displays the expected content."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.preview_panel), expected_content, "Preview panel content")

    def verify_save_button_enabled(self, bank: str) -> None:
        """Verify the Save button is now enabled."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.save_button), "Save button enabled")

    def click_save_button(self, bank: str) -> None:
        """Click the Save button to save the notification."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_success_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message.format(value=expected_message)), "Success message")

    # -------------------- SEARCH NOTIFICATION --------------------

    def search_notification(self, bank: str, search_value: str) -> None:
        """Search for a notification by Event code."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, search_value, "Search input")
        self.click_by_locator(loc.search_button, "Search button")

    def verify_search_result_single_row(self, bank: str, event_code: str, event_name: str, notification_type: str, template_name: str) -> None:
        """Verify search results show exactly one matching row with correct details."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.event_code_cell.format(value=event_code)), f"Event code cell: {event_code}")
        self.assert_visible(self.locator(loc.event_cell.format(value=event_code)), f"Event cell: {event_name}")
        self.assert_visible(self.locator(loc.notification_type_cell.format(value=event_code)), f"Notification type cell: {notification_type}")
        self.assert_visible(self.locator(loc.template_name_cell.format(value=event_code)), f"Template name cell: {template_name}")
        self.assert_text(self.locator(loc.total_items_label), "Total 1 items", "Total items")

    def extract_event_code_from_row(self, bank: str, row_identifier: str) -> str:
        """Extract the auto-generated Event code from the search result row."""
        _, loc = self._dispatch[bank.lower()]
        event_code = self.get_text(self.locator(loc.event_code_cell.format(value=row_identifier)), "Event code cell")
        return event_code.strip()

    # -------------------- EDIT NOTIFICATION --------------------

    def click_edit_button(self, bank: str, event_code: str) -> None:
        """Click the edit (pencil) icon for the specified notification."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button.format(value=event_code), "Edit button")

    def verify_update_notification_page_loaded(self, bank: str) -> None:
        """Verify the Update notification page is displayed with all expected elements."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.breadcrumb), "Breadcrumb navigation")
        self.assert_visible(self.locator(loc.event_dropdown), "Event dropdown (pre-selected)")
        self.assert_visible(self.locator(loc.mode_radio_by_label.format(value="SMS")), "Mode radio button (pre-selected)")
        self.assert_visible(self.locator(loc.template_name_input), "Template name field (pre-filled)")
        self.assert_visible(self.locator(loc.content_textarea), "Content textarea (pre-filled)")
        self.assert_visible(self.locator(loc.preview_panel), "Preview panel")
        self.assert_visible(self.locator(loc.update_button), "Update button")

    def update_notification_content(self, bank: str, data: dict) -> None:
        """Update the content field with new value."""
        _, loc = self._dispatch[bank.lower()]
        self.clear_field(loc.content_textarea, "Content textarea")
        self.fill_by_locator(loc.content_textarea, data["Updated Content"], "Updated Content")

    def verify_preview_updated_content(self, bank: str, expected_content: str) -> None:
        """Verify the preview panel shows the updated content."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.preview_panel), expected_content, "Updated preview content")

    def click_update_button(self, bank: str) -> None:
        """Click the Update button to save changes."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    # -------------------- DELETE NOTIFICATION --------------------

    def click_delete_button(self, bank: str, event_code: str) -> None:
        """Click the delete (trash) icon for the specified notification."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_button.format(value=event_code), "Delete button")

    def verify_delete_confirmation_dialog(self, bank: str) -> None:
        """Verify the delete confirmation dialog is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.delete_confirmation_dialog), "Delete confirmation dialog")
        self.assert_visible(self.locator(loc.delete_confirm_yes_button), "Delete confirm Yes button")
        self.assert_visible(self.locator(loc.delete_confirm_cancel_button), "Delete confirm Cancel button")

    def confirm_delete(self, bank: str) -> None:
        """Click Yes button to confirm deletion."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirm_yes_button, "Delete confirm Yes button")

    def verify_no_records_found(self, bank: str) -> None:
        """Verify no records are found after deletion."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.no_records_message), "No records found message")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
class GeneralPageNegative(GeneralPage):
    """Extends GeneralPage with negative test methods for Add and Edit flows."""

    def __init__(self, page, module_name="General"):
        super().__init__(page, module_name=module_name)
        # Add negative dispatch entry
        self._dispatch["ecentric"] = (self._add_notification_standard, EcentricGeneralLocatorsNegative)

    # -------------------- ADD NOTIFICATION NEGATIVE --------------------

    def add_notification_negative(self, bank: str, data: dict) -> None:
        """Add notification with one invalid field; verify error message."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")
        
        # Fill Event dropdown (always valid for these tests)
        event = data.get("Event", "").strip()
        if event:
            self.click_by_locator(loc.event_dropdown, "Event dropdown")
            self.click_by_locator(loc.event_option_by_text.format(value=event), f"Event option: {event}")
        
        # Fill Mode of notification with test value (may be invalid)
        mode = data.get("Mode of notification", "").strip()
        if mode:
            # Try to click as radio option (valid values: SMS, Email)
            # If invalid, the click will fail or no effect, but we proceed to fill others
            try:
                self.click_by_locator(loc.mode_radio_by_label.format(value=mode), f"Mode: {mode}")
            except Exception:
                # Invalid mode string; proceed to test error capture
                pass
        
        # Fill Template name with test value
        template_name = data.get("Template name", "").strip()
        if template_name is not None:  # Allow empty string to test "required"
            self.fill_by_locator(loc.template_name_input, template_name, "Template name")
        
        # Fill Content with test value
        content = data.get("Content", "").strip() if data.get("Content") else ""
        if content is not None:  # Allow empty string to test "required"
            self.fill_by_locator(loc.content_textarea, content, "Content")
        
        # Trigger validation by clicking Save or clicking elsewhere
        self.click_by_locator(loc.save_button, "Save button (to trigger validation)")
        
        # Assert the expected error message
        expected_msg = data.get("ExpectedMessage", "").strip()
        if expected_msg and expected_msg != "TBD-verify-message":
            self.assert_visible(
                self.locator(loc.field_error_message.format(value=expected_msg)),
                f"Error message: {expected_msg}"
            )

    # -------------------- EDIT NOTIFICATION NEGATIVE --------------------

    def edit_notification_negative(self, bank: str, data: dict) -> None:
        """Edit notification with one invalid field; verify error message."""
        _, loc = self._dispatch[bank.lower()]
        
        # Search for the record by Event Code
        event_code = data.get("Event Code", "").strip()
        if event_code:
            self.search_notification(bank, event_code)
            self.click_edit_button(bank, event_code)
        
        # Verify we're on the edit page
        self.assert_visible(self.locator(loc.update_button), "Update button visible on edit page")
        
        # Now modify ONE field with invalid data; fill others with valid baseline values
        # Mode of notification (may be invalid)
        mode = data.get("Notification Type", "").strip()
        if mode:
            try:
                self.click_by_locator(loc.mode_radio_by_label.format(value=mode), f"Mode: {mode}")
            except Exception:
                pass
        
        # Template name (may be invalid)
        template_name = data.get("Template name", "").strip()
        if template_name is not None:
            self.clear_field(loc.template_name_input, "Template name")
            self.fill_by_locator(loc.template_name_input, template_name, "Template name")
        
        # Updated Content (may be invalid)
        updated_content = data.get("Updated Content", "").strip() if data.get("Updated Content") else ""
        if updated_content is not None:
            self.clear_field(loc.content_textarea, "Content textarea")
            self.fill_by_locator(loc.content_textarea, updated_content, "Updated Content")
        
        # Trigger validation by clicking Update
        self.click_by_locator(loc.update_button, "Update button (to trigger validation)")
        
        # Assert the expected error message
        expected_msg = data.get("ExpectedMessage", "").strip()
        if expected_msg and expected_msg != "TBD-verify-message":
            self.assert_visible(
                self.locator(loc.field_error_message.format(value=expected_msg)),
                f"Error message: {expected_msg}"
            )
