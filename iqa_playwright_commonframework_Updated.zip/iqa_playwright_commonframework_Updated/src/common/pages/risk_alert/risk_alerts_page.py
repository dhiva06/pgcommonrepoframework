from src.common.base.base_page import BasePage
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from src.banks.ecentric.locators.risk_alerts_locators import RiskAlertsLocators as EcentricRiskAlertLocators
from playwright.sync_api import expect


class RiskAlertsPage(BasePage):
    def __init__(self, page, module_name="RiskAlert"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            
            "ecentric": {
                "locators": EcentricRiskAlertLocators,
                "riskalertmenu": self._risk_alert_menu,
                "assert_success_visible": self._assert_risk_alert_visible,
                "assert_success_text": self._assert_risk_alert_text,
                "assert_risk_details_element_visible": self._assert_risk_alert_details_element_visible,
                "existing_risk_alerts": self._click_existing_risk_alerts,
                "assert_terminalmsg": self._assert_terminal_msg,
                "status_dropdown": self._click_status_dropdown,
                "assert_inactive_dropdownmsg": self._assert_inactive_drodwon_msg,
                "enter_risk_profile_name_homepage": self._enter_risk_profile_name_homepage,
                "enter_multiple_risk_alert_name_homepage":self._enter_multiple_risk_alert_name_homepage,
                "existing_risk_profile": self._click_existing_risk_profile,
                "enter_risk_alert_name_homepage": self._enter_risk_alert_name_homepage,
                "enter_empty_risk_alert_name_homepage": self._enter_empty_risk_alert_name_homepage,
                "enter_invalid_risk_alert_name_homepage": self._enter_invalid_risk_alert_name_homepage,
                "add_button": self._click_add_button,
                "assert_add_msg": self._assert_add_msg,
                "click_yes_button": self._click_yes_button,
                "enter_risk_profile_alphanumeric_name": self._enter_risk_profile_alphanumeric_name,
                "assert_risk_alert_name_alphanumeric_msg": self._assert_risk_alert_name_alphanumeric_msg,
                "enter_risk_profile_20_digit_name": self._enter_risk_profile_20_digit_name,
                "enter_level_1_threshold_value": self._enter_level_1_threshold_value,
                "enter_level_2_threshold_value": self._enter_level_2_threshold_value,
                "enter_level_3_threshold_value": self._enter_level_3_threshold_value,
                "select_bank_risk_profile_dropdown": self._select_bank_risk_profile_dropdown,
                "click_save_button": self._click_save_button,
                "enter_level_1_mobilenumber_1": self._enter_level_1_mobilenumber_1,
                "enter_level_1_email_1": self._enter_level_1_email_1,
                "enter_level_2_mobilenumber_1": self._enter_level_2_mobilenumber_1,
                "enter_level_2_email_1": self._enter_level_2_email_1,
                "enter_level_3_mobilenumber_1": self._enter_level_3_mobilenumber_1,
                "enter_level_3_email_1": self._enter_level_3_email_1,
                "enter_risk_profile_1_digit_name": self._enter_risk_profile_1_digit_name,
                "enter_risk_profile_morethan_20_digit_name": self._enter_risk_profile_morethan_20_digit_name,
                "enter_duplicate_risk_alert_name": self._enter_duplicate_risk_alert_name,
                "assert_duplicate_risk_alert_name_msg": self._assert_duplicate_risk_alert_name_msg,
                "click_addlevel_button": self._click_addlevel_button,
                "click_user_addlevel_button": self._click_user_addlevel_button,
                "click_ip_addlevel_button": self._click_ip_addlevel_button,
                "assert_addanotherlevel_element_visble": self._assert_addanotherlevel_element_visble,
                "click_delete_level_2_button": self._click_delete_level_2_button,
                "click_delete_confirm_button": self._click_delete_confirm_button,
                "click_delete_level_1_button": self._click_delete_level_1_button,
                "assert_risk_20_digit_risk_alert_suc_msg": self._assert_risk_alert_name_20_digit_success_msg,
                "assert_risk_1_digit_risk_alert_suc_msg": self._assert_risk_alert_name_1_digit_success_msg,
                "assert_riskalert_morethan_20_digit_suc_msg": self._assert_riskalert_morethan_20_digit_suc_msg,
                "assert_mobilenumber_risk_alert_suc_msg": self._assert_mobilenumber_riskalert_msg,
                "assert_duplicate_risk_alert_name_msg": self._assert_duplicate_risk_alert_name_msg,
                "enter_level_2_10_digit_mobilenumber_1": self._enter_level_2_10_digit_mobilenumber_1,
                "enter_level_3_10_digit_mobilenumber_1": self._enter_level_3_10_digit_mobilenumber_1,
                "enter_level_1_invalid_email_1": self._enter_level_1_invalid_email_1,
                "enter_level_2_invalid_email_1": self._enter_level_2_invalid_email_1,
                "enter_level_3_invalid_email_1": self._enter_level_3_invalid_email_1,
                "assert_email_msg": self._assert_email_msg,
                "assert_mobiledeleteicon_visble": self._assert_mobiledeleteicon_visble,
                "click_mobiledeleteicon": self._click_mobiledeleteicon,
                "assert_emaildeleteicon_visble": self._assert_emaildeleteicon_visble,
                "click_emaildeleteicon": self._click_emaildeleteicon,
                "enter_level_1_mobilenumber_2": self._enter_level_1_mobilenumber_2,
                "enter_level_1_mobilenumber_3": self._enter_level_1_mobilenumber_3,
                "enter_level_1_email_2": self._enter_level_1_email_2,
                "enter_level_1_email_3": self._enter_level_1_email_3,
                "assert_threshold_error_msg": self._assert_threshold_error_msg,
                "enter_level_1_invalid_threshold_value": self._enter_level_1_invalid_threshold_value,
                "click_mobile_label": self._click_mobile_label,
                "enter_level_1_max_threshold_value": self._enter_level_1_max_threshold_value,
                "enter_level_1_min_threshold_value": self._enter_level_1_min_threshold_value,
                "assert_addmorebutton_visble_1": self._assert_addmorebutton_visble_1,
                "assert_addmorebutton_visble_2": self._assert_addmorebutton_visble_2,
                "click_addmorebutton_1": self._click_addmorebutton_1,
                "click_addmorebutton_2": self._click_addmorebutton_2,
                "assert_mobile_max_reach_msg": self._assert_mobile_max_reach_msg,
                "assert_email_max_reach_msg": self._assert_email_max_reach_msg,
                "assert_addlevel_button_visble": self._assert_addlevel_button_visble,
                "assert_duplicate_mobilenum_msg": self._assert_duplicate_mobilenum_msg,
                "assert_duplicate_email_msg": self._assert_duplicate_email_msg,
                "level1MobileNumberAlreadyEntered": self._level1MobileNumberAlreadyEntered,
                "level1EmailAlreadyEntered": self._level1EmailAlreadyEntered,
                "click_merchant_risk_profile_type": self._click_merchant_risk_profile_type,
                "select_merchant_risk_profile_dropdown": self._select_merchant_risk_profile_dropdown,
                "enter_user_level_1_threshold": self._enter_user_level_1_threshold,
                "enter_user_level_2_threshold": self._enter_user_level_2_threshold,
                "enter_user_level_3_threshold": self._enter_user_level_3_threshold,
                "enter_IP_level_1_threshold": self._enter_IP_level_1_threshold,
                "enter_IP_level_2_threshold": self._enter_IP_level_2_threshold,
                "enter_IP_level_3_threshold": self._enter_IP_level_3_threshold,
                "enter_user_level_1_email_1": self._enter_user_level_1_email_1,
                "enter_user_level_2_email_1": self._enter_user_level_2_email_1,
                "enter_user_level_3_email_1": self._enter_user_level_3_email_1,
                "enter_IP_level_1_email_1": self._enter_IP_level_1_email_1,
                "enter_IP_level_2_email_1": self._enter_IP_level_2_email_1,
                "enter_IP_level_3_email_1": self._enter_IP_level_3_email_1,
                "enter_user_level_1_mobilenum_1": self._enter_user_level_1_mobilenum_1,
                "enter_user_level_2_mobilenum_1": self._enter_user_level_2_mobilenum_1,
                "enter_user_level_3_mobilenum_1": self._enter_user_level_3_mobilenum_1,
                "enter_IP_level_1_mobilenum_1": self._enter_IP_level_1_mobilenum_1,
                "enter_IP_level_2_mobilenum_1": self._enter_IP_level_2_mobilenum_1,
                "enter_IP_level_3_mobilenum_1": self._enter_IP_level_3_mobilenum_1,
                "click_user_delete_level_1_button": self._click_user_delete_level_1_button,
                "click_ip_delete_level_1_button": self._click_ip_delete_level_1_button,
                "enter_user_level_1_invalid_email_1":self._enter_user_level_1_invalid_email_1,
                "enter_user_level_2_invalid_email_1":self._enter_user_level_2_invalid_email_1,
                "enter_user_level_3_invalid_email_1":self._enter_user_level_3_invalid_email_1,
                "enter_IP_level_1_invalid_email_1":self._enter_IP_level_1_invalid_email_1,
                "enter_IP_level_2_invalid_email_1":self._enter_IP_level_2_invalid_email_1,
                "enter_IP_level_3_invalid_email_1":self._enter_IP_level_3_invalid_email_1,
                "click_user":self._click_user,
                "click_ip":self._click_ip,
            },
        }

    def navigate_to_user_role(self, bank: str) -> None:
        _, _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_myaccount, f"{bank} My Account menu")
        self.click_by_locator(loc.menu_userrole, f"{bank} User Role menu")

    def add_role(self, bank: str, data: dict) -> None:
        add_method, _, loc = self._dispatch[bank.lower()]
        add_method(data, loc)

    def assert_suc_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_success_text"](
            data["EXISTING_RISK_ALERTS"],
            assert_method["locators"],
        )

    def assert_risk_visible(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_success_visible"](assert_method["locators"])

    def assert_risk_grid_element_visble(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_risk_details_element_visible"](assert_method["locators"])

    def assert_addanotherlevel_element_visble(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_addanotherlevel_element_visble"](assert_method["locators"])

    def assert_addlevel_button_visble(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_addlevel_button_visble"](assert_method["locators"])

    def click_existing_riskalerts(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["existing_risk_alerts"](assert_method["locators"])

    def risk_alert_config(self, bank: str) -> None:
        config = self._dispatch[bank.lower()]
        config["riskalertmenu"](config["locators"])

    def assert_terminal_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_terminalmsg"](
            data["TERMINAL_MSG"],
            assert_method["locators"],
        )

    def click_status_dropdown(self, bank: str) -> None:
        config = self._dispatch[bank.lower()]
        config["status_dropdown"](config["locators"])
    def click_user(self, bank: str) -> None:
            config = self._dispatch[bank.lower()]
            config["click_user"](config["locators"])
    def click_ip(self, bank: str) -> None:
                config = self._dispatch[bank.lower()]
                config["click_ip"](config["locators"])

    def assert_inactive_drodwon_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_inactive_dropdownmsg"](
            data["STATUS_DROPDOWN_MSG"],
            assert_method["locators"],
        )

    def enter_risk_profile_name_homepage(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_name_homepage"](
            data,
            assert_method["locators"],
        )

    def enter_risk_alert_name_homepage(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_alert_name_homepage"](
            data,
            assert_method["locators"],
        )
    def enter_multiple_risk_alert_name_homepage(self, bank: str, data) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["enter_multiple_risk_alert_name_homepage"](
                data,
                assert_method["locators"],
            )
    def enter_emptyrisk_alert_name_homepage(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_empty_risk_alert_name_homepage"](
            data,
            assert_method["locators"],
        )

    def enter_invalid_risk_alert_name_homepage(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_invalid_risk_alert_name_homepage"](
            data,
            assert_method["locators"],
        )

    def click_existing_riskprofilename(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["existing_risk_profile"](assert_method["locators"])

    def click_add_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["add_button"](assert_method["locators"])

    def assert_add_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_add_msg"](
            data["ADD_MSG"],
            assert_method["locators"],
        )

    def click_yes_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_yes_button"](assert_method["locators"])

    def enter_risk_profile_alphanumeric_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_alphanumeric_name"](
            data,
            assert_method["locators"],
        )

    def enter_risk_profile_20_digit_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_20_digit_name"](
            data,
            assert_method["locators"],
        )

    def enter_risk_profile_1_digit_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_1_digit_name"](
            data,
            assert_method["locators"],
        )

    def enter_risk_profile_morethan_20_digit_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_morethan_20_digit_name"](
            data,
            assert_method["locators"],
        )

    def enter_risk_profile_morethan_20_digit_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_risk_profile_morethan_20_digit_name"](
            data,
            assert_method["locators"],
        )

    def assert_risk_alert_name_alphanumeric_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_risk_alert_name_alphanumeric_msg"](
            data["AlPHANUMEIC_RISK_ALERT_NAME_MSG"],
            assert_method["locators"],
        )

    def enter_level_1_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_threshold_value"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_invalid_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_invalid_threshold_value"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_max_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_max_threshold_value"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_min_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_min_threshold_value"](
            data,
            assert_method["locators"],
        )

    def enter_level_2_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_2_threshold_value"](
            data,
            assert_method["locators"],
        )

    def enter_level_3_threshold_value(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_3_threshold_value"](
            data,
            assert_method["locators"],
        )

    def select_bank_risk_profile_dropdown(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["select_bank_risk_profile_dropdown"](
            data,
            assert_method["locators"],
        )

    def select_merchant_risk_profile_dropdown(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["select_merchant_risk_profile_dropdown"](
            data,
            assert_method["locators"],
        )

    def click_save_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_save_button"](assert_method["locators"])

    def click_addlevel_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_addlevel_button"](assert_method["locators"])

    def click_user_addlevel_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_user_addlevel_button"](assert_method["locators"])
    def click_ip_addlevel_button(self, bank: str) -> None:
            assert_method = self._dispatch[bank.lower()]
            assert_method["click_ip_addlevel_button"](assert_method["locators"])

    def click_merchant_risk_profile_type(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_merchant_risk_profile_type"](assert_method["locators"])

    def enter_level_1_mobilenumber_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_mobilenumber_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_mobilenumber_2(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_mobilenumber_2"](
            data,
            assert_method["locators"],
        )

    def verifyLevel1MobileNumberAlreadyEntered(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["level1MobileNumberAlreadyEntered"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_mobilenumber_3(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_mobilenumber_3"](
            data,
            assert_method["locators"],
        )

    def enter_level_2_mobilenumber_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_2_mobilenumber_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_2_10_digit_mobilenumber_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_2_10_digit_mobilenumber_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_2_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_2_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_3_mobilenumber_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_3_mobilenumber_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_3_10_digit_mobilenumber_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_3_10_digit_mobilenumber_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_3_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_3_email_1"](
            data,
            assert_method["locators"],
        )

    def click_delete_confirm_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_delete_confirm_button"](assert_method["locators"])

    def click_delete_level_1_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_delete_level_1_button"](assert_method["locators"])

    def enter_duplicate_risk_alert_name(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_duplicate_risk_alert_name"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_email_2(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_email_2"](
            data,
            assert_method["locators"],
        )

    def verifyLevel1EmailAlreadyEntered(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["level1EmailAlreadyEntered"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_email_3(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_email_3"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_1_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_1_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_2_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_2_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_3_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_3_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_1_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_1_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_2_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_2_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_1_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_1_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_2_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_2_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_3_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_3_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_1_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_1_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_2_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_2_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_3_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_3_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_3_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_3_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_1_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_1_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_2_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_2_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_3_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_3_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_1_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_1_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_2_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_2_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_3_mobilenum_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_3_mobilenum_1"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_1_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_1_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_2_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_2_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_user_level_3_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_user_level_3_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_1_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_1_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_2_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_2_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_IP_level_3_threshold(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_IP_level_3_threshold"](
            data,
            assert_method["locators"],
        )

    def enter_level_1_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_1_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_2_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_2_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def enter_level_3_invalid_email_1(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["enter_level_3_invalid_email_1"](
            data,
            assert_method["locators"],
        )

    def assert_riskalert_20_digit_suc_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_risk_20_digit_risk_alert_suc_msg"](
            data,
            assert_method["locators"],
        )

    def assert_email_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_email_msg"](
            data["EMAIL_ERROR_MSG"],
            assert_method["locators"],
        )

    def assert_riskalert_1_digit_suc_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_risk_1_digit_risk_alert_suc_msg"](
            data,
            assert_method["locators"],
        )

    def assert_riskalert_morethan_20_digit_suc_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_riskalert_morethan_20_digit_suc_msg"](
            data["RISK_ALERT_NAME_MAX_DATA_ERROR_MSG"],
            assert_method["locators"],
        )

    def assert_mobilenumber_risk_alert_suc_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_mobilenumber_risk_alert_suc_msg"](
            data,
            assert_method["locators"],
        )

    def assert_duplicate_risk_alert_name_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_duplicate_risk_alert_name_msg"](
            data["DUPLICATE_RISK_ALERT_NAME"],
            assert_method["locators"],
        )

    def assert_threshold_error_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_threshold_error_msg"](
            data["THRESHOLD_ERROR_MSG"],
            assert_method["locators"],
        )

    def assert_duplicate_mobile_number_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_duplicate_mobilenum_msg"](
            data["DUPLICATE_MOBILE_NUMBER_MSG"],
            assert_method["locators"],
        )

    def assert_duplicate_email_msg(self, bank: str, data) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_duplicate_email_msg"](
            data["DUPLICATE_EMAIL_MSG"],
            assert_method["locators"],
        )

    def click_delete_level_2_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_delete_level_2_button"](assert_method["locators"])

    def click_mobile_label(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_mobile_label"](assert_method["locators"])

    def click_user_delete_level_1_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_user_delete_level_1_button"](assert_method["locators"])

    def click_ip_delete_level_1_button(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_ip_delete_level_1_button"](assert_method["locators"])

    def click_addmorebutton_1(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_addmorebutton_1"](assert_method["locators"])

    def click_addmorebutton_2(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_addmorebutton_2"](assert_method["locators"])

    def assert_addmorebutton_visble_1(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_addmorebutton_visble_1"](assert_method["locators"])

    def assert_addmorebutton_visble_2(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_addmorebutton_visble_2"](assert_method["locators"])

    def assert_mobile_max_reach_msg(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_mobile_max_reach_msg"](assert_method["locators"])

    def assert_email_max_reach_msg(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_email_max_reach_msg"](assert_method["locators"])

    def assert_mobiledeleteicon_visble(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_mobiledeleteicon_visble"](assert_method["locators"])

    def click_mobiledeleteicon(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_mobiledeleteicon"](assert_method["locators"])

    def assert_emaildeleteicon_visble(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["assert_emaildeleteicon_visble"](assert_method["locators"])

    def click_emaildeleteicon(self, bank: str) -> None:
        assert_method = self._dispatch[bank.lower()]
        assert_method["click_emaildeleteicon"](assert_method["locators"])

    # --- Bank‑specific role creation handlers ---
    def _add_role_neoleap(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.permission1, data["Permission1"], "Permission 1")
        self.fill_by_locator(loc.permission2, data["Permission2"], "Permission 2")
        self.click_by_locator(loc.save_button, "Save Role")

    def _add_role_oab(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_code, data["RoleCode"], "Role Code")
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.extra_field, data["ExtraField"], "Extra Field")
        self.click_by_locator(loc.save_button, "Save Role")

    def _add_role_alrajhi(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.permission_level, data["PermissionLevel"], "Permission Level")
        self.click_by_locator(loc.save_button, "Save Role")

    def _add_role_wio(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.department, data["Department"], "Department")
        self.click_by_locator(loc.save_button, "Save Role")

    def _add_role_pinelabs(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.permission_group, data["PermissionGroup"], "Permission Group")
        self.click_by_locator(loc.save_button, "Save Role")

    def _add_role_ecentric(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.role_name, data["RoleName"], "Role Name")
        self.fill_by_locator(loc.role_desc, data["RoleDesc"], "Role Description")
        self.fill_by_locator(loc.risk_level, data["RiskLevel"], "Risk Level")
        self.click_by_locator(loc.save_button, "Save Role")

    def _risk_alert_menu(self, loc) -> None:
        locator = self.page.locator(loc.UNHIDE_MENU)
        locator.hover()
        locator.click()
        self.locator(loc.ADMINISTRATION).hover()
        self.page.wait_for_selector(loc.ADMINISTRATION, state="visible", timeout=90000)
        self.click_by_locator(loc.ADMINISTRATION, "Administration", timeout=50000)
        self.page.wait_for_selector(loc.RISK_SETUP, state="visible", timeout=90000)
        self.click_by_locator(loc.RISK_SETUP, "Risk setup", timeout=80000)
        self.page.wait_for_selector(loc.PG, state="visible", timeout=90000)
        pg_menu_item = self.page.locator(loc.PG).locator(
            "xpath=ancestor::div[contains(@class, 'cl-vertical-navigation-item')][1]"
        )
        self.click_by_locator(pg_menu_item, "PG", timeout=90000)
        self.page.wait_for_selector(loc.RISK_ALERTS, state="visible", timeout=90000)
        self.click_by_locator(loc.RISK_ALERTS, "Risk alerts", timeout=90000)

    def _assert_risk_alert_details_element_visible(self, loc) -> None:
        self.assert_visible(self.locator(loc.RISK_PROFILE_NAME), "Asserting Risk profile name label")
        self.assert_visible(self.locator(loc.ALERT_TYPE), "Asserting Alert type label")
        self.assert_visible(self.locator(loc.STATUS), "Asserting Status label")
        self.assert_visible(self.locator(loc.RISK_ALERT_NAME), "Asserting Risk alert name label")
        self.assert_visible(self.locator(loc.ACTION), "Asserting Action label")

    def _click_existing_risk_alerts(self, loc) -> None:
        self.click_by_locator(loc.EXISTING_RISK_ALERTS, "Click Existing Risk alerts")

    def _assert_terminal_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.TERMINAL), expected_text, "Asserting terminal message")

    def _assert_inactive_drodwon_msg(self, expected_text, loc) -> None:
        self.assert_text(
            self.locator(loc.INACTIVE_DROPDOWM_ASSERT), expected_text, "Asserting terminal message"
        )

    def _assert_risk_alert_name_maxdigit_msg(
        self,
        expected_text,
        loc,
    ) -> None:
        self.assert_text(
            loc.RISK_ALERT_NAME_MAX_DATA_ERROR,
            expected_text,
            "Asserting maximum Risk Alert Name",
        )

    def _click_status_dropdown(self, loc) -> None:
        self.click_by_locator(loc.STATUS_DROPDOWN, "Click Status dropdown")
        self.click_by_locator(
            loc.STATUS_DROPDOWN_INACTIVE,
            "Click Status dropdown Inactive",
        )
       

    def _enter_risk_profile_name_homepage(self, data, loc) -> None:
        self.fill_by_locator(loc.ENTER_RISK_ALERT_NAME, data["RISK_PROFILE_NAME"], "Fill Risk Profile Name")

    def _enter_risk_alert_name_homepage(self, data, loc) -> None:
        self.fill_by_locator(loc.ENTER_RISK_ALERT_NAME, data["RISK_ALERT_NAME"], "Fill Risk Alert Name")

    def _enter_multiple_risk_alert_name_homepage(self, data, loc) -> None:
            self.fill_by_locator(loc.ENTER_RISK_ALERT_NAME, data["MULTIPLERISK_PROFILE_NAME"], "Fill Risk Alert Name")

    def _enter_empty_risk_alert_name_homepage(self, data, loc) -> None:
        value = data.get("EMPTY_RISK_ALERT_NAME")
        if value is None:
            value = ""
        self.fill_by_locator(loc.ENTER_RISK_ALERT_NAME, str(value), "Fill empty Risk Alert Name")

    def _enter_invalid_risk_alert_name_homepage(self, data, loc) -> None:
        self.fill_by_locator(
            loc.ENTER_RISK_ALERT_NAME, data["INVALID_RISK_ALERT_NAME"], "Fill Invalid Risk Alert Name"
        )

    def _click_existing_risk_profile(self, loc) -> None:
        self.click_by_locator(loc.EXISTING_RISK_ALERTS_1, "Click Existing Risk alerts")

    def _click_mobile_label(self, loc) -> None:
        self.click_by_locator(loc.LEVEL_1_MOBILENUMBER_1, "Click mobile label")

    def _click_add_button(self, loc) -> None:
        self.click_by_locator(loc.ADD_BUTTON, "Click Add button")

    def _click_merchant_risk_profile_type(self, loc) -> None:
        self.click_by_locator(loc.CLICKMERCHANTRISKPROFILETYPE, "Click Merchant Risk Profile")

    def _click_addmorebutton_1(self, loc) -> None:
        self.click_by_locator(loc.ADD_MORE_BUTTON_1, "Click Add more button 1")
    def _click_user(self, loc) -> None:
            self.click_by_locator(loc.CLICK_USER, "Click User")
    def _click_ip(self, loc) -> None:
                self.click_by_locator(loc.CLICK_IP, "Click User")

    def _click_addmorebutton_2(self, loc) -> None:
        self.click_by_locator(loc.ADD_MORE_BUTTON_2, "Click Add more button 2")

    def _assert_add_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.ADD_ASSERT_MSG), expected_text, "Asserting add button")

    def _assert_duplicate_risk_alert_name_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.DUPLICATE_RISK_ALERT_NAME), expected_text, "Asserting add button")

    def _enter_risk_profile_alphanumeric_name(self, data, loc) -> None:
        self._handle_risk_alert_name(
            data["AlPHANUMEIC_RISK_ALERT_NAME"],
            loc,
            "Fill Risk Profile Name",
        )

    def _enter_risk_profile_20_digit_name(self, data, loc) -> None:
        self._handle_risk_alert_name(
            data["20_DIGIT_RISK_ALERT_NAME"],
            loc,
            "Fill Risk Profile Name",
        )

    def _enter_risk_profile_1_digit_name(self, data, loc) -> None:
        self._handle_risk_alert_name(
            data["1_DIGIT_RISK_ALERT_NAME"],
            loc,
            "Fill Risk Profile Name",
        )

    def _enter_risk_profile_morethan_20_digit_name(self, data, loc) -> None:
        self._handle_risk_alert_name(
            data["MORETHAN_20_DIGIT_RISK_ALERT_NAME"],
            loc,
            "Fill Risk Profile Name",
        )

    def _click_yes_button(self, loc) -> None:
        self.click_by_locator(
            loc.CLICK_YES_BUTTON,
            "Click Yes Button",
        )

    def _enter_level_1_threshold_value(self, data, loc) -> None:
        self.click_by_locator(
            loc.LEVEL_1_THRESHOLD,
            "Click Bank Select All Dropdwon",
        )

        self.fill_by_locator(
            loc.LEVEL_1_THRESHOLD,
            data["LEVEL_1_THRESHOLD"],
            "Fill level_1_threshold",
            timeout=40000,
        )

    def _enter_level_1_invalid_threshold_value(self, data, loc) -> None:
        self.click_by_locator(
            loc.LEVEL_1_THRESHOLD,
            "Click Bank Select All Dropdwon",
        )
        self.page.wait_for_selector(loc.LEVEL_1_THRESHOLD, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_THRESHOLD,
            data["INVALID_LEVEL_1_THRESHOLD"],
            "Fill level_1_threshold",
        )

    def _enter_level_1_max_threshold_value(self, data, loc) -> None:
        self.click_by_locator(
            loc.LEVEL_1_THRESHOLD,
            "Click Bank Select All Dropdwon",
        )
        self.page.wait_for_selector(loc.LEVEL_1_THRESHOLD, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_THRESHOLD,
            data["MAX_LEVEL_1_THRESHOLD"],
            "Fill level_1_threshold",
           
        )

    def _enter_level_1_min_threshold_value(self, data, loc) -> None:
        self.click_by_locator(
            loc.LEVEL_1_THRESHOLD,
            "Click Bank Select All Dropdwon",
        )
        self.page.wait_for_selector(loc.LEVEL_1_THRESHOLD, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_THRESHOLD,
            data["MIN_LEVEL_1_THRESHOLD"],
            "Fill level_1_threshold",
        )

    def _enter_level_2_threshold_value(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_2_THRESHOLD, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_2_THRESHOLD,
            data["LEVEL_2_THRESHOLD"],
            "Fill level_2_threshold",
        )

    def _enter_level_3_threshold_value(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_3_THRESHOLD, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_3_THRESHOLD,
            data["LEVEL_3_THRESHOLD"],
            "Fill level_3_threshold",
         
        )

    def _enter_level_1_mobilenumber_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill Level 1 Mobile Number 1",
    
        )

    def _enter_level_1_mobilenumber_2(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_MOBILENUMBER_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_MOBILENUMBER_2,
            data["LEVEL_1_MOBILENUMBER_2"],
            "Fill Level 1 Mobile Number 2",
        )

    def _level1MobileNumberAlreadyEntered(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_MOBILENUMBER_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_MOBILENUMBER_2,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill Level 1 Mobile Number 2",
           
        )

    def _enter_level_1_mobilenumber_3(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_MOBILENUMBER_3, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_MOBILENUMBER_3,
            data["LEVEL_1_MOBILENUMBER_3"],
            "Fill Level 1 Mobile Number 3",
        
        )

    def _enter_level_2_mobilenumber_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_2_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_2_MOBILENUMBER_1,
            data["LEVEL_2_MOBILENUMBER_1"],
            "Fill Level 2 Mobile Number 1",
           
        )

    def _enter_level_2_10_digit_mobilenumber_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_2_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_2_MOBILENUMBER_1,
            data["LEVEL_2_10_DIGIT_MOBILENUMBER_1"],
            "Fill Level 2 10-Digit Mobile Number 1",
          
        )

    def _enter_level_3_mobilenumber_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_3_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_3_MOBILENUMBER_1,
            data["LEVEL_3_MOBILENUMBER_1"],
            "Fill Level 3 10-Digit Mobile Number 1",
          
        )

    def _enter_level_3_10_digit_mobilenumber_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_3_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_3_MOBILENUMBER_1,
            data["LEVEL_3_10_DIGIT_MOBILENUMBER_1"],
            "Fill Level 3 10-Digit Mobile Number 1",
            
        )

    def _enter_duplicate_risk_alert_name(self, data, loc) -> None:
        self.fill_by_locator(
            loc.ENTER_RISK_ALERT_ADD,
            data["DUPLICATE_RISK_ALERT_NAME_MSG"],
            "Fill Duplicate Risk Alert Name",
        )

    def _enter_level_1_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill Level 1 Email 1",
          
        )

    def _enter_level_1_email_2(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_EMAIL_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_EMAIL_2,
            data["LEVEL_1_EMAIL_2"],
            "Fill Level 1 Email 2",
           
        )

    def _level1EmailAlreadyEntered(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_EMAIL_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_EMAIL_2,
            data["LEVEL_1_EMAIL_1"],
            "Fill Level 1 Email 2",
            
        )

    def _enter_level_1_email_3(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_EMAIL_3, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_EMAIL_3,
            data["LEVEL_1_EMAIL_3"],
            "Fill Level 1 Email 3",
          
        )

    def _enter_level_1_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_1_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill Level 1 Invalid Email 1",
            
        )

    def _enter_level_2_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_2_EMAIL_1,
            data["LEVEL_2_EMAIL_1"],
            "Fill Level 2 Email 1",
          
        )

    def _enter_level_2_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_2_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill Level 2 Email 1",
            
        )

    def _enter_level_3_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_3_EMAIL_1,
            data["LEVEL_3_EMAIL_1"],
            "Fill Level 3 Email 1",
            
        )

    def _enter_level_3_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.LEVEL_3_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill Level 3 Email 1",
            
        )

    def _enter_user_level_1_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_1_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill user Level 1 email id 1",
            
        )

    def _enter_user_level_2_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_2_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill user Level 2 email id 1",
            
        )

    def _enter_user_level_3_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_3_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill user Level 3 email id 1",
            
        )

    def _enter_IP_level_1_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_1_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill IP Level 1 email id 1",
            
        )

    def _enter_IP_level_2_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_2_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill IP Level 2 email id 1",
            
        )

    def _enter_IP_level_3_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_3_EMAIL_1,
            data["LEVEL_1_EMAIL_1"],
            "Fill IP Level 3 email id 1",
            
        )

    def _enter_IP_level_1_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_1_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_1_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill IP Level 1 Mobile Number id 1",
            
        )

    def _enter_IP_level_2_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_2_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_2_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill IP Level 2 Mobile Number id 1",
            
        )

    def _enter_IP_level_3_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_3_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_3_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill IP Level 3 10-Digit Mobile Number id 1",
            
        )

    def _enter_user_level_1_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_1_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_1_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill user Level 1 Mobile Number id 1",
            
        )

    def _enter_user_level_2_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_2_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_2_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill user Level 2 Mobile Number id 1",
            
        )

    def _enter_user_level_3_mobilenum_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_3_MOBILENUMBER_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_3_MOBILENUMBER_1,
            data["LEVEL_1_MOBILENUMBER_1"],
            "Fill user Level 3 Mobile Number id 1",
            
        )

    def _enter_user_level_1_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_1_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill user Level 1 invalid email id 1",
            
        )

    def _enter_user_level_2_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_2_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill user Level 2 email id 1",
            
        )

    def _enter_user_level_3_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_LEVEL_3_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill user Level 3 email id 1",
            
        )

    def _enter_IP_level_1_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_1_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_1_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill IP Level 1 invalid email id 1",
            
        )

    def _enter_IP_level_2_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_2_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_2_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill IP Level 2 invalid email id 1",
            
        )

    def _enter_IP_level_3_invalid_email_1(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_LEVEL_3_EMAIL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_LEVEL_3_EMAIL_1,
            data["INVALID_EMAIL"],
            "Fill IP Level 3 invalid email id 1",
            
        )

    def _enter_user_level_1_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_THRESHOLD_LEVEL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_THRESHOLD_LEVEL_1,
            data["LEVEL_1_THRESHOLD"],
            "Fill user Level 1 threshold",
            
        )

    def _enter_user_level_2_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_THRESHOLD_LEVEL_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_THRESHOLD_LEVEL_2,
            data["LEVEL_1_THRESHOLD"],
            "Fill user Level 2 threshold",
            
        )

    def _enter_user_level_3_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.USER_THRESHOLD_LEVEL_3, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.USER_THRESHOLD_LEVEL_3,
            data["LEVEL_3_THRESHOLD"],
            "Fill user Level 3 threshold",
            
        )

    def _enter_IP_level_1_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_THRESHOLD_LEVEL_1, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_THRESHOLD_LEVEL_1,
            data["LEVEL_3_THRESHOLD"],
            "Fill user Level 1 threshold",
            
        )

    def _enter_IP_level_2_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_THRESHOLD_LEVEL_2, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_THRESHOLD_LEVEL_2,
            data["LEVEL_3_THRESHOLD"],
            "Fill user Level 2 threshold",
            
        )

    def _enter_IP_level_3_threshold(self, data, loc) -> None:
        self.page.wait_for_selector(loc.IP_THRESHOLD_LEVEL_3, state="visible", timeout=90000)
        self.fill_by_locator(
            loc.IP_THRESHOLD_LEVEL_3,
            data["LEVEL_1_THRESHOLD"],
            "Fill user Level 3 threshold",
            
        )

    def _assert_email_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.EMAIL_ERROR_MSG), expected_text, "Asserting email error message")

    def _assert_threshold_error_msg(self, expected_text, loc) -> None:
        self.assert_text(
            self.locator(loc.THRESHOLD_DATA_ERROR), expected_text, "Asserting threshold error message"
        )

    def _select_bank_risk_profile_dropdown(self, data, loc) -> None:
        self.multi_select(
            loc.ADD_RISK_PROFILE_NAME, data["BANK_RISKPROFILE"], "Bank Risk Profile Name", 
        )

    def _select_merchant_risk_profile_dropdown(self, data, loc) -> None:
        self.page.wait_for_selector(loc.ADD_RISK_PROFILE_NAME, state="visible", timeout=90000)
        self.multi_select_material_options(
            loc.ADD_RISK_PROFILE_NAME, data["MERCHANT_RISKPROFILE"], "Merchant Risk Profile Name",
        )

    def _click_save_button(self, loc) -> None:
        self.click_by_locator(loc.SAVE_BUTTON, "Click Save Button")

    def _click_mobiledeleteicon(self, loc) -> None:
        self.click_by_locator(loc.LEVEL_1_MOBILENUMBER_3_DELETE_ICON, "Click Mobile Delete Icon")

    def _click_addlevel_button(self, loc) -> None:
        self.click_by_locator(loc.CLICK_ANOTHERLEVEL_BUTTON, "Click Add Level Button")

    def _click_user_addlevel_button(self, loc) -> None:
        self.click_by_locator(loc.USER_CLICK_ANOTHERLEVEL_BUTTON, "Click User Add Level Button")
    def _click_ip_addlevel_button(self, loc) -> None:
            self.click_by_locator(loc.IP_CLICK_ANOTHERLEVEL_BUTTON, "Click User Add Level Button")

    def _click_delete_level_2_button(self, loc) -> None:
        self.click_by_locator(loc.DELETE_LEVEL_2, "Click Delete Level 2 Button")

    def _click_user_delete_level_1_button(self, loc) -> None:
        self.click_by_locator(loc.USER_LEVEL_1_DELETE_ICON_1, "Click Delete Level 1 Button")

    def _click_ip_delete_level_1_button(self, loc) -> None:
        self.click_by_locator(loc.IP_LEVEL_1_DELETE_ICON_1, "Click Delete Level 1 Button")

    def _click_delete_confirm_button(self, loc) -> None:
        self.click_by_locator(loc.CLICK_CONFIRM_BUTTON, "Click Delete Confirm Button")

    def _click_delete_level_1_button(self, loc) -> None:
        self.click_by_locator(loc.DELETE_LEVEL_1, "Click Delete Level 1 Button")

    def _click_emaildeleteicon(self, loc) -> None:
        self.click_by_locator(loc.LEVEL_1_EMAIL_3_DELETE_ICON, "Click Delete Level 1 Button")

    def _assert_risk_alert_name_20_digit_success_msg(self, data, loc) -> None:
        self._assert_risk_alert_success_message(
            data["20_DIGIT_RISK_ALERT_NAME"],
            loc,
        )

    def _assert_risk_alert_name_1_digit_success_msg(self, data, loc) -> None:
        self._assert_risk_alert_success_message(
            data["1_DIGIT_RISK_ALERT_NAME"],
            loc,
        )

    def _assert_riskalert_morethan_20_digit_suc_msg(self, expected_text, loc) -> None:

        self.assert_text(
            self.locator(loc.RISK_ALERT_NAME_MAX_DATA_ERROR),
            expected_text,
            "Negative validation: Asserting maximum Risk alert name ",
        )

    def _assert_mobilenumber_riskalert_msg(self, data, loc) -> None:
        self._assert_risk_alert_success_message(
            data["MOBILE_RISK_ALERT_NAME"],
            loc,
        )

    def _assert_risk_alert_success_message(
        self,
        alert_name: str,
        loc,
    ) -> None:
        actual_locator = self.locator(loc.RISK_ALERT_SUC_MSG.format(ALERT_NAME=alert_name))
        expected_message = f'The risk alert named "{alert_name}" has been added successfully.'

        print(f"AC: {actual_locator}")
        print(f"EP: {expected_message}")

        self.assert_text(
            actual_locator,
            expected_message,
            "Positive validation: Asserting add button",
        )

    def _assert_risk_alert_name_alphanumeric_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.RISK_ALERT_NAME_DATA_ERROR), expected_text, "Asserting add button")

    def _assert_threshold_error_msg(self, expected_text, loc) -> None:
        self.assert_text(self.locator(loc.THRESHOLD_DATA_ERROR), expected_text, "Asserting threshold")

    def _assert_duplicate_mobilenum_msg(self, expected_text, loc) -> None:
        self.assert_text(
            self.locator(loc.DUPLICATE_MOBILE_NUMBER_MSG),
            expected_text,
            "Asserting duplicate mobile number message",
        )

    def _assert_duplicate_email_msg(self, expected_text, loc) -> None:
        self.assert_text(
            self.locator(loc.DUPLICATE_EMAIL_MSG), expected_text, "Asserting duplicate email message"
        )

    def _assert_addanotherlevel_element_visble(self, loc) -> None:
        self.assert_visible(
            self.locator(loc.ADDANOTHERLEVEL_BUTTON_MSG), "Asserting Add another level button"
        )

    def _handle_risk_alert_name(self, riskname, loc, description: str = "Fill Risk Alert Name") -> None:
        self.fill_by_locator(
            loc.ENTER_RISK_ALERT_NAME,
            riskname,
            description,
        )

        build_xpath = loc.ALERT_NAME.format(ALERT_NAME=riskname)
        alert_name = self.page.locator(build_xpath)

        # Search results are rendered asynchronously, but the row is optional.
        try:
            alert_name.first.wait_for(state="visible", timeout=5000)
        except PlaywrightTimeoutError:
            alert_name = None

        if alert_name is not None:
            self.click_by_locator(
                build_xpath,
                description="Deleting alert name if already available",
                
            )
            self._click_yes_button(loc)
            try:
                self.page.locator(build_xpath).wait_for(state="hidden", timeout=10000)
            except PlaywrightTimeoutError:
                raise AssertionError(f"Existing risk alert '{riskname}' was not deleted")

        self._click_add_button(loc)

        self.fill_by_locator(
            loc.ENTER_RISK_ALERT_ADD,
            riskname,
            "Risk Alert Name",
        )

    # --- Bank‑specific assertions ---
    def _assert_neoleap(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.error_message), expected_message, "Neoleap Role error")

    def _assert_oab(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.error_message), expected_message, "OAB Role error")

    def _assert_alrajhi(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.error_message), expected_message, "Alrajhi Role error")

    def _assert_wio(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.error_message), expected_message, "Wio Role error")

    def _assert_pinelabs(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.error_message), expected_message, "Pinelabs Role error")

    def _assert_risk_alert_text(self, expected_message: str, loc) -> None:
        self.assert_text(self.locator(loc.EXISTING_RISK_ALERTS), expected_message, "Ecentric Role error")

    def _assert_risk_alert_visible(self, loc) -> None:
        self.assert_visible(self.locator(loc.ADD_BUTTON), "Asserting Add button")

    def _assert_addmorebutton_visble_1(self, loc) -> None:
        self.assert_visible(self.locator(loc.ADD_MORE_BUTTON_1), "Asserting Add morebutton1")

    def _assert_addmorebutton_visble_2(self, loc) -> None:
        self.assert_visible(self.locator(loc.ADD_MORE_BUTTON_2), "Asserting Add morebutton2")

    def _assert_mobile_max_reach_msg(self, loc) -> None:
        expect(self.page.locator(loc.ADD_MORE_BUTTON_1)).to_be_disabled()

    def _assert_email_max_reach_msg(self, loc) -> None:
        expect(self.page.locator(loc.ADD_MORE_BUTTON_2)).to_be_disabled()

    def _assert_mobiledeleteicon_visble(self, loc) -> None:
        self.assert_visible(self.locator(loc.LEVEL_1_MOBILENUMBER_3_DELETE_ICON), "Asserting Delete Icon")

    def _assert_emaildeleteicon_visble(self, loc) -> None:
        self.assert_visible(self.locator(loc.LEVEL_1_EMAIL_3_DELETE_ICON), "Asserting Delete Icon")

    def _assert_addlevel_button_visble(self, loc) -> None:
        self.assert_visible(self.locator(loc.CLICK_ANOTHERLEVEL_BUTTON), "Asserting addlevel button")
