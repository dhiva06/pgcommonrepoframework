from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.selfconfiguration_locators import SelfconfigurationLocators as EcentricSelfconfigurationLocators, SelfconfigurationLocatorsNegative


class SelfconfigurationPage(BasePage):
    def __init__(self, page, module_name="Selfconfiguration"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._edit_standard, EcentricSelfconfigurationLocators),
        }

    # -------------------- Navigation --------------------

    def navigate_to_selfconfiguration(self, bank: str) -> None:
        """Navigate to Self configuration page via My account menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_my_account, "My account menu")
        self.click_by_locator(loc.menu_self_configuration, "Self configuration submenu")

    # -------------------- PG Template Tab Verification --------------------

    def verify_pg_template_tab_selected(self, bank: str) -> None:
        """Verify the PG Template tab is selected by default."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.pg_template_tab), "PG Template tab is selected")

    # -------------------- Logo Upload Section Verification --------------------

    def verify_logo_section_initial_state(self, bank: str, data: dict) -> None:
        """Verify the Upload logo section shows the uploaded logo, delete icon, and other initial fields."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.logo_image), "Uploaded logo image is displayed")
        self.assert_visible(self.locator(loc.logo_delete_button), "Logo delete (trash) icon is displayed")
        self.assert_text(self.locator(loc.terminal_id_dropdown), data["Terminal ID"], "Terminal ID shows TERM1222")
        self.assert_visible(self.locator(loc.choose_color_input), "Choose color field is displayed")
        self.assert_text(self.locator(loc.select_template_dropdown), data["Select Template"], "Select template shows Standard")
        self.assert_visible(self.locator(loc.default_language_note), "Default language note is displayed")
        self.assert_visible(self.locator(loc.preview_button), "Preview button is displayed")

    # -------------------- Delete and Upload Logo --------------------

    def delete_logo(self, bank: str) -> None:
        """Click the delete icon of the uploaded logo."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.logo_delete_button, "Logo delete button")

    def verify_logo_deleted(self, bank: str) -> None:
        """Verify the logo is removed and the upload option is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_not_visible(self.locator(loc.logo_image), "Logo image is removed", timeout=5000)
        self.assert_visible(self.locator(loc.file_upload_input), "File upload input is displayed")

    def upload_logo(self, bank: str, file_name: str) -> None:
        """Upload a new logo file."""
        _, loc = self._dispatch[bank.lower()]
        # Construct the file path from input folder
        import os
        file_path = os.path.join(os.path.dirname(__file__), "../../../input", file_name)
        self.upload_file(loc.file_upload_input, file_path, f"Upload {file_name}")

    def verify_logo_uploaded(self, bank: str) -> None:
        """Verify the new logo is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.logo_image), "New logo image is displayed")

    # -------------------- Terminal ID Selection --------------------

    def select_terminal_id(self, bank: str, terminal_id: str) -> None:
        """Select Terminal ID from dropdown."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.terminal_id_dropdown, "Terminal ID dropdown")
        self.click_by_locator(loc.terminal_id_option.format(value=terminal_id), f"Terminal ID option {terminal_id}")

    # -------------------- Choose Color Update --------------------

    def update_choose_color(self, bank: str, color: str) -> None:
        """Update the Choose color field."""
        _, loc = self._dispatch[bank.lower()]
        self.clear_field(loc.choose_color_input, "Choose color field")
        self.fill_by_locator(loc.choose_color_input, color, "Choose color")

    # -------------------- Select Template Update --------------------

    def select_template(self, bank: str, template: str) -> None:
        """Select a template from the Select template dropdown."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.select_template_dropdown, "Select template dropdown")
        self.click_by_locator(loc.select_template_option.format(value=template), f"Select template option {template}")

    # -------------------- Select Language Operations --------------------

    def add_language(self, bank: str, language: str) -> None:
        """Select a language from the Select language dropdown."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.select_language_dropdown, "Select language dropdown")
        self.click_by_locator(loc.select_language_option.format(value=language), f"Select language option {language}")

    def verify_languages_displayed(self, bank: str, languages: list) -> None:
        """Verify that specified language chips are displayed."""
        _, loc = self._dispatch[bank.lower()]
        for language in languages:
            self.assert_visible(self.locator(loc.language_chip.format(value=language)), f"{language} language chip is displayed")

    def remove_language_chip(self, bank: str, language: str) -> None:
        """Remove a language chip by clicking its X icon."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.language_chip_remove.format(value=language), f"Remove {language} chip")

    def verify_language_removed(self, bank: str, language: str) -> None:
        """Verify a language chip is removed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_not_visible(self.locator(loc.language_chip.format(value=language)), f"{language} language chip is removed", timeout=5000)

    # -------------------- Preview Button Click --------------------

    def click_preview_button(self, bank: str) -> None:
        """Click the Preview button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.preview_button, "Preview button")

    def verify_preview_content(self, bank: str, data: dict) -> None:
        """Verify the preview modal shows the new logo and color with selected template."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.preview_modal), "Preview modal is displayed")
        self.assert_visible(self.locator(loc.preview_logo), "Preview logo is displayed")
        # Verify color is applied in preview (color value in data)
        self.assert_text(self.locator(loc.preview_modal), data["Choose Color"], "Preview shows selected color")

    def close_preview(self, bank: str) -> None:
        """Close the preview modal."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.preview_modal_close, "Preview modal close button")

    # -------------------- Save Button and Success Message --------------------

    def click_save_button(self, bank: str) -> None:
        """Click the Save button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def verify_success_message(self, bank: str, expected_message: str) -> None:
        """Verify a success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message), "Success message is displayed")
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message text")

    # -------------------- Page Reload and Final Verification --------------------

    def reload_selfconfiguration_page(self, bank: str) -> None:
        """Reload the Self configuration page."""
        self.refresh_page("Self configuration page reload")

    def verify_pg_template_changes_retained(self, bank: str, data: dict) -> None:
        """Verify that Terminal ID, color, template, language, and logo are retained after reload."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.pg_template_tab, "Open PG Template tab")
        self.assert_text(self.locator(loc.terminal_id_dropdown), data["Terminal ID"], "Terminal ID is retained")
        self.assert_text(self.locator(loc.choose_color_input), data["Choose Color"], "Choose color is retained")
        self.assert_text(self.locator(loc.select_template_dropdown), data["Select Template"], "Select template is retained")
        self.assert_visible(self.locator(loc.language_chip.format(value=data["Select Language"])), "Language chip is retained")
        self.assert_visible(self.locator(loc.logo_image), "New logo is retained")

    # -------------------- Main Edit Flow --------------------

    def execute_edit_selfconfiguration(self, bank: str, data: dict) -> None:
        """Execute the full edit flow for Self configuration PG Template settings."""
        # Navigate to Self configuration
        self.navigate_to_selfconfiguration(bank)
        
        # Verify PG Template tab is selected by default
        self.verify_pg_template_tab_selected(bank)
        
        # Verify initial state of logo section and fields
        self.verify_logo_section_initial_state(bank, data)
        
        # Delete the existing logo
        self.delete_logo(bank)
        self.verify_logo_deleted(bank)
        
        # Upload a new logo
        self.upload_logo(bank, "logo_new.png")
        self.verify_logo_uploaded(bank)
        
        # Select Terminal ID
        self.select_terminal_id(bank, data["Terminal ID"])
        
        # Update Choose color
        self.update_choose_color(bank, data["Choose Color"])
        
        # Select Template
        self.select_template(bank, data["Select Template"])
        
        # Add language
        self.add_language(bank, data["Select Language"])
        self.verify_languages_displayed(bank, ["English", data["Select Language"]])
        
        # Remove the added language
        self.remove_language_chip(bank, data["Select Language"])
        self.verify_language_removed(bank, data["Select Language"])
        self.verify_languages_displayed(bank, ["English"])
        
        # Click Preview and verify
        self.click_preview_button(bank)
        self.verify_preview_content(bank, data)
        self.close_preview(bank)
        
        # Click Save
        self.click_save_button(bank)
        self.verify_success_message(bank, data["ExpectedMessage"])
        
        # Reload and verify retention
        self.reload_selfconfiguration_page(bank)
        self.verify_pg_template_changes_retained(bank, data)

    def execute_add_selfconfiguration_negative(self, bank: str, data: dict) -> None:
        """
        Execute add flow with one invalid field and verify error message.
        Fills all other fields with valid baseline values except the field under test.
        """
        _, loc = self._dispatch[bank.lower()]
        
        # Navigate to Self configuration
        self.navigate_to_selfconfiguration(bank)
        self.verify_pg_template_tab_selected(bank)
        
        # Determine which field is being tested and fill accordingly
        negative_type = data.get("NegativeType", "")
        
        # Terminal ID negative cases
        if self._is_field_under_test(data, "Terminal ID"):
            self.fill_by_locator(loc.terminal_id_dropdown, data.get("Terminal ID", ""), "Terminal ID")
            self.fill_by_locator(loc.choose_color_input, data.get("Choose Color", ""), "Choose Color")
            self.select_template(bank, data.get("Select Template", ""))
            self.add_language(bank, data.get("Select Language", ""))
            self.click_save_button(bank)
            self._verify_error_message(bank, data, loc.terminal_id_error)
        
        # Choose Color negative cases
        elif self._is_field_under_test(data, "Choose Color"):
            self.select_terminal_id(bank, data.get("Terminal ID", ""))
            self.update_choose_color(bank, data.get("Choose Color", ""))
            self.select_template(bank, data.get("Select Template", ""))
            self.add_language(bank, data.get("Select Language", ""))
            self.click_save_button(bank)
            self._verify_error_message(bank, data, loc.choose_color_error)
        
        # Select Template negative cases
        elif self._is_field_under_test(data, "Select Template"):
            self.select_terminal_id(bank, data.get("Terminal ID", ""))
            self.update_choose_color(bank, data.get("Choose Color", ""))
            if data.get("Select Template", "").strip():
                self.select_template(bank, data.get("Select Template", ""))
            self.add_language(bank, data.get("Select Language", ""))
            self.click_save_button(bank)
            self._verify_error_message(bank, data, loc.select_template_error)
        
        # Select Language negative cases
        elif self._is_field_under_test(data, "Select Language"):
            self.select_terminal_id(bank, data.get("Terminal ID", ""))
            self.update_choose_color(bank, data.get("Choose Color", ""))
            self.select_template(bank, data.get("Select Template", ""))
            if data.get("Select Language", "").strip():
                self.add_language(bank, data.get("Select Language", ""))
            self.click_save_button(bank)
            self._verify_error_message(bank, data, loc.select_language_error)

    def execute_edit_selfconfiguration_negative(self, bank: str, data: dict) -> None:
        """
        Execute edit flow with one invalid field and verify error message.
        Locates the record by Terminal ID, opens it, modifies one field with bad value,
        and verifies the error message on save.
        """
        _, loc = self._dispatch[bank.lower()]
        
        # Navigate to Self configuration
        self.navigate_to_selfconfiguration(bank)
        self.verify_pg_template_tab_selected(bank)
        
        # Identify which field is under test
        negative_type = data.get("NegativeType", "")
        
        # Choose Color negative cases (Edit)
        if self._is_field_under_test(data, "Choose Color"):
            # Terminal ID should be valid baseline (used to find the record)
            terminal_id = data.get("Terminal ID", "")
            self.select_terminal_id(bank, terminal_id)
            # Apply bad color value
            self.update_choose_color(bank, data.get("Choose Color", ""))
            self.select_template(bank, data.get("Select Template", ""))
            self.add_language(bank, data.get("Select Language", ""))
            self.click_save_button(bank)
            self._verify_error_message(bank, data, loc.choose_color_error)

    def _is_field_under_test(self, data: dict, field_name: str) -> bool:
        """
        Determine if a specific field is the one being tested by examining the Description.
        Returns True if the Description mentions the field name and a negative type.
        """
        description = data.get("Description", "").lower()
        return field_name.lower() in description

    def _verify_error_message(self, bank: str, data: dict, error_locator: str) -> None:
        """
        Verify the error message is displayed for the given field.
        Checks both field-level errors and generic toast messages.
        """
        _, loc = self._dispatch[bank.lower()]
        expected_msg = data.get("ExpectedMessage", "")
        
        if not expected_msg or expected_msg == "TBD-verify-message":
            # If no specific message expected, just verify any error is shown
            self.assert_visible(self.locator(error_locator), f"Error message displayed for {error_locator}")
        else:
            # Try field-level error first, fall back to toast if not found
            try:
                self.assert_text(self.locator(error_locator), expected_msg, f"Error message: {expected_msg}")
            except:
                # Fall back to toast message if field error not found
                self.assert_text(self.locator(loc.toast_message), expected_msg, f"Toast message: {expected_msg}")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
class SelfconfigurationPageNegative(SelfconfigurationPage):
    """Negative test page extending SelfconfigurationPage with validation error flows."""

    def __init__(self, page, module_name="Selfconfiguration"):
        super().__init__(page, module_name=module_name)
        # Override dispatch to use negative locators
        self._dispatch = {
            "ecentric": (self._edit_selfconfiguration_negative, SelfconfigurationLocatorsNegative),
        }

    # -------------------- Negative Add Flow --------------------

    # -------------------- Negative Edit Flow --------------------

    # -------------------- Helper Methods --------------------
