from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.menumanagement_locators import MenumanagementLocators as EcentricMenumanagementLocators


class MenumanagementPage(BasePage):
    def __init__(self, page, module_name="Menumanagement"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_standard, EcentricMenumanagementLocators),
        }

    def navigate_to_menumanagement(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_user_administration, "User administration sub-menu")
        self.click_by_locator(loc.menu_menu_management, "Menu management sub-menu")

    def click_add_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add new menu button")

    def fill_menumanagement_form(self, bank: str, data: dict) -> None:
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        self.select_by_locator(loc.product_dropdown, data["Product"], "Product")
        self.select_by_locator(loc.sub_product_dropdown, data["Sub Product"], "Sub Product")
        self.fill_by_locator(loc.menu_code_input, data["Menu Code"], "Menu Code")
        self.fill_by_locator(loc.menu_name_input, data["Menu Name"], "Menu Name")
        self.fill_by_locator(loc.menu_description_input, data["Menu Description"], "Menu Description")
        self.fill_by_locator(loc.access_url_input, data["Access URL"], "Access URL")
        self.select_by_locator(loc.parent_menu_dropdown, data["Parent Menu"], "Parent Menu")
        self.select_by_locator(loc.menu_type_dropdown, data["Menu Type"], "Menu Type")
        self.fill_by_locator(loc.display_sequence_input, data["Display Sequence"], "Display Sequence")
        self.fill_by_locator(loc.api_module_input, data["API Module"], "API Module")

    def click_active_status_radio(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.status_active_radio, "Active status radio button")

    def click_save_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_menumanagement_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Menu Management response message")

    def select_product_and_sub_product_filters(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.select_by_locator(loc.product_dropdown, data["Product"], "Product")
        self.select_by_locator(loc.sub_product_dropdown, data["Sub Product"], "Sub Product")

    def _find_row_menumanagement(self, bank: str, identifier_value: str) -> str:
        _, loc = self._dispatch[bank.lower()]
        return loc.row_by_menu_code(identifier_value)

    def click_edit_icon(self, bank: str, identifier_value: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        row = self._find_row_menumanagement(bank, identifier_value)
        self.click_by_locator(f"{row}{loc.row_edit_icon_suffix}", "Edit icon on menu row")

    def update_menumanagement_form(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.menu_name_input, data["Menu Name"], "Menu Name")
        self.fill_by_locator(loc.menu_description_input, data["Menu Description"], "Menu Description")

    def click_update_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    def click_delete_icon(self, bank: str, identifier_value: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        row = self._find_row_menumanagement(bank, identifier_value)
        self.click_by_locator(f"{row}{loc.row_delete_icon_suffix}", "Delete icon on menu row")

    def confirm_delete(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirm_button, "Confirm delete button")

    def assert_menu_removed(self, bank: str, identifier_value: str) -> None:
        row = self._find_row_menumanagement(bank, identifier_value)
        self.assert_not_visible(self.locator(row), "Deleted menu row")
