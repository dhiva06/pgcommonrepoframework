from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.goconnect_locators import GoconnectLocators as EcentricGoconnectLocators, GoconnectLocatorsNegative
from src.common.utilities.dropdown_helper import select_mat_option


class GoconnectPage(BasePage):
    def __init__(self, page, module_name="Goconnect"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_connection_standard, EcentricGoconnectLocators),
        }

    # -------------------- ADD ACTION --------------------

    def navigate_to_goconnect(self, bank: str) -> None:
        """Navigate to GoConnect module via Administration menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_goconnect, "GoConnect submenu")
        self.assert_visible(self.locator(loc.page_marker), "GoConnect listing page")

    def click_add_button(self, bank: str) -> None:
        """Click the Add button to create new connection."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")
        self.assert_visible(self.locator(loc.page_title_add), "Add connection page")

    def fill_product_network_segmentation(self, bank: str, data: dict) -> None:
        """Fill Product network segmentation section."""
        _, loc = self._dispatch[bank.lower()]
        select_mat_option(self.page, loc.product_dropdown, data["Product"], 'Product')
        select_mat_option(self.page, loc.network_dropdown, data["Network"], 'Network')

    def fill_connection_details(self, bank: str, data: dict) -> None:
        """Fill Connection details section."""
        _, loc = self._dispatch[bank.lower()]
        self._add_connection_standard(loc, data)

    def click_save_button(self, bank: str) -> None:
        """Click the Save button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_add_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message is displayed after adding connection."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message), expected_message)

    def assert_goconnect_listing_displayed(self, bank: str) -> None:
        """Assert page navigated back to GoConnect listing."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.page_marker), "GoConnect listing page")

    def search_connection(self, bank: str, connection_name: str) -> None:
        """Search for a connection by name."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, connection_name, "Search text box")
        self.click_by_locator(loc.search_button, "Search button")

    def assert_listing_shows_connection(self, bank: str, connection_name: str, product: str, 
                                       network: str, mode: str, status: str) -> None:
        """Assert the listing shows the expected connection with all details."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.row_by_connection_name.format(connection_name=connection_name)
        self.assert_visible(self.locator(row_locator), f"Connection row with name {connection_name}")
        # Verify each column value is present in the row
        self.assert_visible(
            self.locator(row_locator + f"//td[contains(normalize-space(),'{product}')]"),
            f"Product {product} in row"
        )
        self.assert_visible(
            self.locator(row_locator + f"//td[contains(normalize-space(),'{network}')]"),
            f"Network {network} in row"
        )
        self.assert_visible(
            self.locator(row_locator + f"//td[contains(normalize-space(),'{mode}')]"),
            f"Mode {mode} in row"
        )
        self.assert_visible(
            self.locator(row_locator + f"//td[contains(normalize-space(),'{status}')]"),
            f"Status {status} in row"
        )

    # -------------------- EDIT ACTION --------------------

    def navigate_to_goconnect_edit(self, bank: str) -> None:
        """Navigate to GoConnect listing for edit flow."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_goconnect, "GoConnect submenu")
        self.assert_visible(self.locator(loc.page_marker), "GoConnect listing page")

    def search_and_open_connection_summary(self, bank: str, connection_name: str) -> None:
        """Search for connection and click to open summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, connection_name, "Search text box")
        self.click_by_locator(loc.search_button, "Search button")
        # Click the connection name link to open summary
        self.click_by_locator(
            loc.connection_name_link.format(connection_name=connection_name),
            f"Connection name link {connection_name}"
        )

    def assert_connection_summary_page_displayed(self, bank: str, connection_name: str, 
                                                 product: str, network: str, mode: str,
                                                 login_required: str, auto_login: str,
                                                 echo_required: str, echo_frequency: str,
                                                 echo_retry: str, ip_address: str, port: str,
                                                 status: str) -> None:
        """Assert connection summary page shows all expected values."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.summary_page_title), "Connection summary page")
        self.assert_visible(self.locator(loc.summary_breadcrumb), "Breadcrumb with Go connect")
        # Assert connection name and status are displayed
        self.assert_visible(
            self.locator(loc.inline_selector.format(value=connection_name)),
            f"Connection name {connection_name}"
        )
        # Assert all action buttons present
        self.assert_visible(self.locator(loc.edit_icon), "Edit icon")
        self.assert_visible(self.locator(loc.delete_button), "Delete button")
        self.assert_visible(self.locator(loc.stop_button), "Stop button")
        self.assert_visible(self.locator(loc.start_button), "Start button")

    def click_edit_icon(self, bank: str) -> None:
        """Click the edit icon to open edit form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_icon, "Edit icon")
        self.assert_visible(self.locator(loc.edit_page_title), "Edit connection page")

    def assert_edit_page_prepopulated(self, bank: str, connection_name: str, product: str,
                                      network: str, echo_frequency: str, echo_retry: str,
                                      ip_address: str, port: str) -> None:
        """Assert edit page displays non-editable fields and prepopulated values."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.edit_page_title), "Edit connection page")
        # Product and Network shown as non-editable
        self.assert_visible(self.locator(loc.inline_selector_2.format(value=product)), f"Product {product} non-editable")
        self.assert_visible(self.locator(loc.inline_selector_2.format(value=network)), f"Network {network} non-editable")
        self.assert_visible(self.locator(loc.inline_selector_2.format(value=connection_name)), f"Connection name non-editable")
        # Verify form fields are pre-filled
        self.assert_visible(self.locator(loc.update_button), "Update button")

    def update_connection_details(self, bank: str, data: dict) -> None:
        """Update connection details fields on edit form."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.echo_frequency_input, data["Echo frequency"], "Echo frequency")
        self.fill_by_locator(loc.echo_retry_attempts_input, data["Echo retry attempts"], "Echo retry attempts")
        self.fill_by_locator(loc.ip_address_input, data["IP address"], "IP address")
        self.fill_by_locator(loc.port_input, data["Port"], "Port")

    def click_update_button(self, bank: str) -> None:
        """Click the Update button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    def assert_edit_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message after update."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message), expected_message)

    def verify_updated_values_in_summary(self, bank: str, connection_name: str,
                                        echo_frequency: str, echo_retry: str,
                                        ip_address: str, port: str) -> None:
        """Navigate back to listing, search and verify updated values in summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_goconnect, "GoConnect submenu")
        self.fill_by_locator(loc.search_input, connection_name, "Search text box")
        self.click_by_locator(loc.search_button, "Search button")
        self.click_by_locator(
            loc.connection_name_link.format(connection_name=connection_name),
            f"Connection name link {connection_name}"
        )
        # Verify updated values are displayed
        self.assert_visible(
            self.locator(loc.inline_selector.format(value=echo_frequency)),
            f"Echo frequency {echo_frequency}"
        )
        self.assert_visible(
            self.locator(loc.inline_selector.format(value=echo_retry)),
            f"Echo retry {echo_retry}"
        )
        self.assert_visible(
            self.locator(loc.inline_selector.format(value=ip_address)),
            f"IP address {ip_address}"
        )
        self.assert_visible(
            self.locator(loc.inline_selector.format(value=port)),
            f"Port {port}"
        )

    # -------------------- DELETE ACTION --------------------

    def navigate_to_goconnect_delete(self, bank: str) -> None:
        """Navigate to GoConnect listing for delete flow."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_goconnect, "GoConnect submenu")
        self.assert_visible(self.locator(loc.page_marker), "GoConnect listing page")

    def search_and_open_connection_for_delete(self, bank: str, connection_name: str) -> None:
        """Search for connection and open summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, connection_name, "Search text box")
        self.click_by_locator(loc.search_button, "Search button")
        self.click_by_locator(
            loc.connection_name_link.format(connection_name=connection_name),
            f"Connection name link {connection_name}"
        )

    def assert_listing_shows_one_connection(self, bank: str, connection_name: str, status: str) -> None:
        """Assert listing shows only one row with expected connection."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.row_by_connection_name.format(connection_name=connection_name)
        self.assert_visible(self.locator(row_locator), f"Connection row {connection_name}")

    def click_delete_button(self, bank: str) -> None:
        """Click the Delete button on connection summary."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_button, "Delete button")

    def assert_delete_confirmation_dialog_displayed(self, bank: str) -> None:
        """Assert delete confirmation dialog is displayed with expected messages."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.delete_dialog), "Delete confirmation dialog")
        self.assert_visible(
            self.locator(loc.delete_confirmation_message),
            "Delete confirmation message"
        )
        self.assert_visible(self.locator(loc.delete_dialog_cancel_button), "Cancel button")
        self.assert_visible(self.locator(loc.delete_dialog_yes_button), "Yes button")

    def click_delete_confirmation_yes(self, bank: str) -> None:
        """Click Yes button to confirm deletion."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_dialog_yes_button, "Yes button in delete dialog")

    def assert_delete_success_message(self, bank: str, expected_message: str) -> None:
        """Assert success message after deletion."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.success_message), expected_message)

    def verify_connection_not_found_after_delete(self, bank: str, connection_name: str) -> None:
        """Verify connection no longer exists by searching for it."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, connection_name, "Search text box")
        self.click_by_locator(loc.search_button, "Search button")
        # Assert no records found message or empty listing

    # -------------------- PRIVATE HELPERS --------------------

    def _add_connection_standard(self, loc, data: dict) -> None:
        """Fill all connection detail fields."""
        self.fill_by_locator(loc.connection_name_input, data["Connection name"], "Connection name")
        # Select Connection mode radio button
        mode_radio = f"//input[@value='{data['Connection mode']}']"
        self.click_by_locator(mode_radio, f"Connection mode {data['Connection mode']}")
        # Select Login required radio button
        login_radio = f"//input[@value='{data['Login required']}']"
        self.click_by_locator(login_radio, f"Login required {data['Login required']}")
        # Auto login flag should be disabled when Login required is No
        # Select Echo required radio button
        echo_radio = f"//input[@value='{data['Echo required']}']"
        self.click_by_locator(echo_radio, f"Echo required {data['Echo required']}")
        self.fill_by_locator(loc.echo_frequency_input, data["Echo frequency"], "Echo frequency")
        self.fill_by_locator(loc.echo_retry_attempts_input, data["Echo retry attempts"], "Echo retry attempts")
        self.fill_by_locator(loc.ip_address_input, data["IP address"], "IP address")
        self.fill_by_locator(loc.port_input, data["Port"], "Port")

    def add_goconnect_negative(self, bank: str, data: dict) -> None:
        """Fill form with baseline values except one field (under test), click Save, assert error."""
        _, loc_parent = self._dispatch[bank.lower()]
        loc = self._dispatch_negative[bank.lower()]
        
        # Navigate to Add page
        self.click_by_locator(loc_parent.add_button, "Add button")
        self.assert_visible(self.locator(loc_parent.page_title_add), "Add connection page")
        
        # Fill Product and Network with valid baseline values
        product = _v(data, "product", "Product") or "PG"
        network = _v(data, "network", "Network") or "MASTERCARD"
        select_mat_option(self.page, loc_parent.product_dropdown, product, 'Product')
        select_mat_option(self.page, loc_parent.network_dropdown, network, 'Network')
        
        # Fill all connection detail fields with data (one field will have negative value)
        self._fill_all_connection_fields_with_negatives(loc_parent, data)
        
        # Click Save and expect validation error
        self.click_by_locator(loc_parent.save_button, "Save button")
        
        # Assert expected error message
        self._assert_negative_error_message(loc, data)

    def _fill_all_connection_fields_with_negatives(self, loc, data: dict) -> None:
        """Fill all connection detail fields, allowing negative values from data."""
        connection_name = _v(data, "connection_name", "Connection name")
        self.fill_by_locator(loc.connection_name_input, connection_name, "Connection name")
        
        # Connection mode - if present and not empty, select it
        connection_mode = _v(data, "connection_mode", "Connection mode")
        if connection_mode:
            mode_radio = f"//input[@value='{connection_mode}']"
            self.click_by_locator(mode_radio, f"Connection mode {connection_mode}")
        
        # Login required - if present and not empty, select it
        login_required = _v(data, "login_required", "Login required")
        if login_required:
            login_radio = f"//input[@value='{login_required}']"
            self.click_by_locator(login_radio, f"Login required {login_required}")
        
        # Echo required - if present and not empty, select it
        echo_required = _v(data, "echo_required", "Echo required")
        if echo_required:
            echo_radio = f"//input[@value='{echo_required}']"
            self.click_by_locator(echo_radio, f"Echo required {echo_required}")
        
        # Fill numeric/text fields
        echo_frequency = _v(data, "echo_frequency", "Echo frequency")
        if echo_frequency:
            self.fill_by_locator(loc.echo_frequency_input, echo_frequency, "Echo frequency")
        
        echo_retry = _v(data, "echo_retry_attempts", "Echo retry attempts")
        if echo_retry:
            self.fill_by_locator(loc.echo_retry_attempts_input, echo_retry, "Echo retry attempts")
        
        ip_address = _v(data, "ip_address", "IP address")
        if ip_address:
            self.fill_by_locator(loc.ip_address_input, ip_address, "IP address")
        
        port = _v(data, "port", "Port")
        if port:
            self.fill_by_locator(loc.port_input, port, "Port")

    def _assert_negative_error_message(self, loc, data: dict) -> None:
        """Assert that the expected error message is displayed."""
        expected_msg = _v(data, "expected_message", "ExpectedMessage")
        if not expected_msg or expected_msg.startswith("TBD"):
            # If message is TBD, just verify some error is shown
            self.assert_visible(self.locator(loc.any_error_message), "Validation error displayed")
        else:
            # Try to find the specific error message
            error_locator = loc.error_message_by_text.format(value=expected_msg)
            self.assert_visible(self.locator(error_locator), f"Error message: {expected_msg}")

    def edit_goconnect_negative(self, bank: str, data: dict) -> None:
        """Search for connection, open summary, click edit, fill form with one bad value, click Update, assert error."""
        _, loc_parent = self._dispatch[bank.lower()]
        loc = self._dispatch_negative[bank.lower()]
        
        # Search and open connection summary
        connection_name = _v(data, "connection_name", "Connection name")
        self.fill_by_locator(loc_parent.search_input, connection_name, "Search text box")
        self.click_by_locator(loc_parent.search_button, "Search button")
        self.click_by_locator(
            loc_parent.connection_name_link.format(connection_name=connection_name),
            f"Connection name link {connection_name}"
        )
        
        # Click edit icon
        self.click_by_locator(loc_parent.edit_icon, "Edit icon")
        self.assert_visible(self.locator(loc_parent.edit_page_title), "Edit connection page")
        
        # Fill editable fields with data (one field will have negative value)
        self._fill_all_editable_fields_with_negatives(loc_parent, data)
        
        # Click Update and expect validation error
        self.click_by_locator(loc_parent.update_button, "Update button")
        
        # Assert expected error message
        self._assert_negative_error_message(loc, data)

    def _fill_all_editable_fields_with_negatives(self, loc, data: dict) -> None:
        """Fill editable connection detail fields (non-editable fields are skipped)."""
        # Product and Network are non-editable on edit page, so skip them
        
        # Connection name is non-editable on edit page (displayed as read-only), skip it
        
        # Connection mode - if present and not empty, select it
        connection_mode = _v(data, "connection_mode", "Connection mode")
        if connection_mode:
            mode_radio = f"//input[@value='{connection_mode}']"
            try:
                self.click_by_locator(mode_radio, f"Connection mode {connection_mode}")
            except Exception:
                # Field may not be present or clickable on edit page
                pass
        
        # Login required - if present and not empty, select it
        login_required = _v(data, "login_required", "Login required")
        if login_required:
            login_radio = f"//input[@value='{login_required}']"
            try:
                self.click_by_locator(login_radio, f"Login required {login_required}")
            except Exception:
                pass
        
        # Echo required - if present and not empty, select it
        echo_required = _v(data, "echo_required", "Echo required")
        if echo_required:
            echo_radio = f"//input[@value='{echo_required}']"
            try:
                self.click_by_locator(echo_radio, f"Echo required {echo_required}")
            except Exception:
                pass
        
        # Fill numeric/text fields
        echo_frequency = _v(data, "echo_frequency", "Echo frequency")
        if echo_frequency:
            self.fill_by_locator(loc.echo_frequency_input, echo_frequency, "Echo frequency")
        
        echo_retry = _v(data, "echo_retry_attempts", "Echo retry attempts")
        if echo_retry:
            self.fill_by_locator(loc.echo_retry_attempts_input, echo_retry, "Echo retry attempts")
        
        ip_address = _v(data, "ip_address", "IP address")
        if ip_address:
            self.fill_by_locator(loc.ip_address_input, ip_address, "IP address")
        
        port = _v(data, "port", "Port")
        if port:
            self.fill_by_locator(loc.port_input, port, "Port")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
def _v(data: dict, snake_key: str, pascal_key: str = "") -> str:
    """Helper to extract and strip values from data dict, handling both naming conventions."""
    if snake_key in data and data[snake_key] is not None:
        return str(data[snake_key]).strip()
    if pascal_key and pascal_key in data and data[pascal_key] is not None:
        return str(data[pascal_key]).strip()
    return ""


class GoconnectPageNegative(GoconnectPage):
    """Negative test page for GoConnect - inherits positive page, adds negative-specific methods."""

    def __init__(self, page, module_name="Goconnect"):
        super().__init__(page, module_name=module_name)
        self._dispatch_negative = {
            "ecentric": GoconnectLocatorsNegative,
        }

    # -------------------- ADD NEGATIVE --------------------

    # -------------------- EDIT NEGATIVE --------------------
