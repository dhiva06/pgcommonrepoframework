"""Page-object class for the User Role module (all actions: Add / View / Edit / AssignMenu / ChangeStatus)."""

from src.common.base.base_page import BasePage
from src.banks.wio.locators.userrole_locators import UserroleLocators as WioUserroleLocators
from src.banks.pinelabs.locators.userrole_locators import UserroleLocators as PinelabsUserroleLocators


class UserrolePage(BasePage):
    """Covers Add, View, Edit, AssignMenu and ChangeStatus flows for the User Role module."""

    def __init__(self, page, module_name: str = "Userrole"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "wio": (self._add_standard, WioUserroleLocators),
            "pinelabs": (self._add_standard, PinelabsUserroleLocators),
        }

    # ── Navigation ────────────────────────────────────────────────────────────

    def navigate_to_userrole(self, bank: str) -> None:
        """Click My Accounts then User Role in the top navigation."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_myaccount, "My Accounts menu")
        self.click_by_locator(loc.menu_userrole, "User Role submenu")

    # ── Listing page assertions ───────────────────────────────────────────────

    def assert_listing_page_visible(self, bank: str) -> None:
        """Assert the User Role listing page header is visible."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.listing_page_header, "User Role listing page header")

    def assert_role_in_list(self, bank: str, role_name: str) -> None:
        """Assert a role row containing role_name is visible in the listing table."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.row_by_name(role_name), f"Row for role '{role_name}'")

    # ── Search helper ─────────────────────────────────────────────────────────

    def search_userrole(self, bank: str, role_name: str) -> None:
        """Type role_name into the search box and submit to narrow the grid."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_input, role_name, "Search input")
        self.click_by_locator(loc.search_button, "Search button")

    # ── Add action ────────────────────────────────────────────────────────────

    def click_add_button(self, bank: str) -> None:
        """Click the Add button on the User Role listing page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def assert_add_page_visible(self, bank: str) -> None:
        """Assert the Add User Role form page header is visible."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.add_page_header, "Add User Role page header")

    def fill_userrole_form(self, bank: str, data: dict) -> None:
        """Delegate to the bank-specific form-fill method."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Fill Role Name, Role Type and Description fields (standard layout)."""
        self.fill_by_locator(loc.role_name_input, data["Role Name"], "Role Name")
        self.select_by_locator(loc.role_type_dropdown, data["Role Type"], "Role Type")
        self.fill_by_locator(loc.description_input, data["Description Value"], "Description")

    def click_save_button(self, bank: str) -> None:
        """Click the Save button on the Add / Edit / AssignMenu form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_userrole_message(self, bank: str, expected_message: str) -> None:
        """Assert the success / error message shown after a Save action."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.success_message,
            expected_message,
            "User Role response message",
        )

    def assert_userrole_error(self, bank: str, expected_message: str) -> None:
        """Assert the validation / error message shown after a failed Save."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.error_message,
            expected_message,
            "User Role error message",
        )

    # ── Shared row-finder helper ───────────────────────────────────────────────

    def _find_row_userrole(self, bank: str, role_name: str) -> str:
        """Return the XPath for the listing-table row that contains role_name."""
        _, loc = self._dispatch[bank.lower()]
        return loc.row_by_name(role_name)

    # ── View action ───────────────────────────────────────────────────────────

    def click_view_for_role(self, bank: str, role_name: str) -> None:
        """Click the per-row View link for the role identified by role_name."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.view_link_in_row(role_name), f"View link for '{role_name}'")

    def assert_view_page_visible(self, bank: str) -> None:
        """Assert the View User Role detail page header is visible."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.view_page_header, "View User Role page header")

    def assert_view_role_name(self, bank: str, expected_name: str) -> None:
        """Assert the Role Name value displayed on the View detail page."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.view_role_name_label,
            expected_name,
            "View - Role Name label",
        )

    def click_back_button(self, bank: str) -> None:
        """Click the Back / Close button to return to the listing page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.back_button, "Back button")

    # ── Edit action ───────────────────────────────────────────────────────────

    def click_edit_for_role(self, bank: str, role_name: str) -> None:
        """Click the per-row Edit link for the role identified by role_name."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_link_in_row(role_name), f"Edit link for '{role_name}'")

    def fill_edit_userrole_form(self, bank: str, data: dict) -> None:
        """Clear and re-fill the Description field with the updated value."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.description_input, data["Description Value"], "Description")

    def assert_userrole_updated_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message shown after an Edit save."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.success_message,
            expected_message,
            "User Role updated message",
        )

    # ── Assign Menu action ────────────────────────────────────────────────────

    def click_assignmenu_for_role(self, bank: str, role_name: str) -> None:
        """Click the per-row Assign Menu link for the role identified by role_name."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.assignmenu_link_in_row(role_name), f"Assign Menu link for '{role_name}'")

    def assert_assignmenu_page_visible(self, bank: str) -> None:
        """Assert the Assign Menu page header is visible."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(loc.assignmenu_page_header, "Assign Menu page header")

    def select_menu_permissions(self, bank: str) -> None:
        """Check the first available menu permission checkbox on the Assign Menu page."""
        _, loc = self._dispatch[bank.lower()]
        self.check_by_locator(loc.menu_permission_checkbox, "Menu permission checkbox")

    def assert_assignmenu_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message shown after assigning menus."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.success_message,
            expected_message,
            "Assign Menu response message",
        )

    # ── Change Status action ───────────────────────────────────────────────────

    def select_row_checkbox(self, bank: str, role_name: str) -> None:
        """Tick the checkbox on the row matching role_name."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.row_checkbox(role_name), f"Checkbox for '{role_name}'")

    def click_changestatus_button(self, bank: str) -> None:
        """Click the global Change Status button (applies to the ticked row)."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.changestatus_button, "Change Status button")

    def assert_changestatus_message(self, bank: str, expected_message: str) -> None:
        """Assert the message shown after a Change Status action."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(
            loc.status_message,
            expected_message,
            "User Role status-changed message",
        )
