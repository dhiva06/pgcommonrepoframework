import random
from src.common.base.base_page import BasePage
from src.banks.oab.locators.Currency_locators import currencyLocators
from src.common.base.base_page import ActionFailedError, BasePage
from src.common.fixtures.browser_fixtures import page


BANK_LOCATORS = {
    "oab": currencyLocators,
}


class CurrencyPage(BasePage):
    def __init__(self, page, module_name="Currency"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "oab": (self._add_standard, currencyLocators),
        }

    def navigate_to_currency(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_configuration, "Configuration")
        self.click_by_locator(loc.menu_currency, "Currency submenu")

    def click_add_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_currency_form(self, bank: str, data: dict) -> None:
        """Fill the currency form with provided data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Fill all currency fields for add operation."""
        self.fill_by_locator(loc.currency_code_input, data["Currency Code"], "Currency Code")
        self.fill_by_locator(loc.currency_description_input, data["Currency Description"], "Currency Description")
        
        self.fill_by_locator(loc.minor_digits_input, data["Minor Digits"], "Minor Digits")
        self.fill_by_locator(loc.currency_symbol_input, data["Currency Symbol"], "Currency Symbol")
        
    
    def click_save_button(self, bank: str) -> None:
            """Click the Save button on the Add/Edit form."""
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.Currency_save_button, "Save button")  
        
    def click__Negative_save_button(self, bank: str,data: dict) -> None:
        """Click the Save button on the Add/Edit form."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.Currency_save_button, "Save button")
        # self.page.wait_for_selector(loc.message_container, state="visible", timeout=30000)
        print(data.keys())
        expected_message = data.get("ExpectedMessage")
        if expected_message:
            self.assert_text(self.page.locator(loc.validation_message.format(expected_message)),expected_message,"Negative Validation")
        else:
            raise Exception(f"ExpectedMessage column missing in test data: {data}")
        
    def assert_currency_message(self, bank: str, expected_message: str) -> None:
        """Assert the response/validation message text."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_contains_text(self.locator(loc.message_container), expected_message, "Currency response message")
 
    def assert_validation_error(self, bank: str, locator: str, expected_message: str, description: str) -> None:
        """Assert a validation error message for a specific field."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.loc(locator), expected_message, description)
        
    def assert_currency_message_view_CC(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_contains_text(self.locator(loc.message_container_CC), expected_message, "Currency response message")
        
    def assert_currency_message_Edit(self, bank: str, expected_message: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.assert_contains_text(self.locator(loc.message_container_Edit), expected_message, "Currency response message")
            
    def assert_currency_message_Edit(self, bank: str, expected_message: str) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.assert_contains_text(self.locator(loc.message_container_ChangeStatus), expected_message, "Currency response message")
                
    def assert_currency_message_NegativeCases(self, bank: str, expected_message: str) -> None:
            """Assert the response/validation message text."""
            _, loc = self._dispatch[bank.lower()]
            self.assert_contains_text(self.locator(loc.message_container_NegativeCases.format(expected_message)),expected_message, "Currency response message")



    def find_and_view_row(self, bank: str, currency_code: str) -> None:
    
        _, loc = self._dispatch[bank.lower()]
        view_link = loc.view_link_in_row(currency_code)
 
        if self.page.locator(view_link).count() == 0:
            self.logger.info(f"'{currency_code}' not found on page 1 - checking page 2")
            # self.click_by_locator(loc.navigate_to_next_page,"Page 2 link")
            # self.navigate_to_next_page(bank)
            self.page.wait_for_load_state("networkidle", timeout=10000)
            view_link = loc.view_link_in_row(currency_code)
            if self.page.locator(view_link).count() == 0:
                raise ActionFailedError(f"Currency row '{currency_code}' not found on page 1 or page 2")
 
        self.click_by_locator(view_link, f"View link for {currency_code}")
        
        
    def find_and_edit_row(self, bank: str, currency_code: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        edit_link = loc.Edit_link_in_row(currency_code)
 
        if self.page.locator(edit_link).count() == 0:
            self.logger.info(f"'{currency_code}' not found on page 1 - checking page 2")
            # self.click_by_locator(loc.navigate_to_next_page, "Page 2 link")
            self.page.wait_for_load_state("networkidle", timeout=10000)
            edit_link = loc.Edit_link_in_row(currency_code)
            if self.page.locator(edit_link).count() == 0:
                raise ActionFailedError(f"Currency row '{currency_code}' not found on page 1 or page 2")
 
        self.click_by_locator(edit_link, f"Edit link for {currency_code}")
        self.fill_by_locator(loc.currency_description_input, data["Currency Description"], "Currency Description")
        


    def find_and_check_row(self, bank: str, currency_code: str) -> None:
        """Find currency row by code and check its checkbox."""
        _, loc = self._dispatch[bank.lower()]
        checkbox = loc.checkbox_in_row(currency_code)
        self.click_by_locator(checkbox, f"Checkbox for {currency_code}")

    def click_change_status_button(self, bank: str) -> None:
        """Click the Change Status button."""
        _, loc = self._dispatch[bank.lower()]
        self.accept_dialog() 
        self.click_by_locator(loc.change_status_button, "Change Status button")
    

    def click_back_button(self, bank: str) -> None:
        """Click the Back button to return to currency list."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.back_button, "Back button")


    def navigate_to_next_page(self, bank: str) -> None:
        """Navigate to page 2 of the currency list."""
        _, loc = self._dispatch[bank.lower()]
        next_page_link = "//a[contains(@onclick,'currPage('2')')]"  
        self.click_by_locator(next_page_link, "Page 2 link")


  
        


# =========================================================================================================



    