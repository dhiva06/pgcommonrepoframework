from typing import Protocol
from src.banks.ecentric.locators.ExternalConnection_Locators import EcentricExternalConnectionLocators
from src.common.base.base_page import BasePage
from src.common.fixtures.browser_fixtures import page
from src.common.pages.authentication.bank_login_page import ActionFailedError


def _v(data: dict, snake_key: str, pascal_key: str = "") -> str:

    if snake_key in data and data[snake_key] is not None:
        return str(data[snake_key]).strip()
    if pascal_key and pascal_key in data and data[pascal_key] is not None:
        return str(data[pascal_key]).strip()
    return ""


class ExternalConnectionPage(BasePage):
    def __init__(self, page, module_name="ExternalConnection"):
        super().__init__(page, module_name=module_name)
        

        self._dispatch = {
            "ecentric": (self._add_external_connection, EcentricExternalConnectionLocators),

        }
        self.loc = EcentricExternalConnectionLocators
        
        # -------------------- Add external Connection --------------------

    def add_external_connection(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self._add_external_connection(data, loc)
        self._select_protocol(data, loc)

    # -------------------- Navigation --------------------

    def navigate_to_external_connection(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, f"{bank} Administration menu")
        self.click_by_locator(loc.menu_routing_configuration, f"{bank} Routing Configuration menu")
        self.click_by_locator(loc.menu_setup_routing_plan, f"{bank} Setup Routing Plan menu")
        self.assert_visible(self.locator(loc.page_marker), f"{bank} Setup Routing Plan page")


    # -------------------- Private flow orchestration --------------------

    def _add_external_connection(self, data: dict, loc) -> None:
        self.click_by_locator(loc.add_button, "Add button")
        self.fill_by_locator(loc.external_connection_name_field,data["ConnectionName"], "External connection name")
        # self.click_by_locator(EcentricExternalConnectionLocators.dummy_locator,"click dummy locator")
      
# label
    # -------------------- Protocol selection --------------------

    def _select_protocol(self, data: dict, loc) -> None:
        self.select_custom_dropdown(loc.protocol_field, data["Protocol"])
        protocol = _v(data, "protocol", "Protocol").lower()
        if protocol == "https":
            self._fill_https_fields(data, loc)
        elif protocol in ("go-connect", "goconnect"):
            self._select_goconnect_flow(data, loc)

    # -------------------- Protocol-specific field fillers --------------------

    def _fill_https_fields(self, data: dict, loc) -> None:
            self.fill_by_locator(loc.timeout_field,data["Timeout"], "Timeout")
            self.fill_by_locator(loc.retry_attempts_field, data["RetryAttempts"], "Retry attempts")
            self.fill_by_locator(loc.url_field, data["URL"], "URL")
           
            method = _v(data, "method_type", "MethodType").lower()
            if not method:
                return
            if method == "post":
                self.click_by_locator(loc.method_type_post, "Method type: Post")
            else:
                self.click_by_locator(loc.method_type_get, "Method type: Get")
            
            
# ----------------------------Go Connect----------------------------------


    def _select_goconnect_flow(self, data: dict, loc) -> None:
        self.select_custom_dropdown(loc.goconnect_connection_name_field, data["GoConnectConnectionName"])
        self.select_custom_dropdown(loc.Authorization_entity, data["AuthEntry"])
        self.select_custom_dropdown(loc.Authorization_type, data["AuthType"])
        self.fill_by_locator(loc.content_type_field,data["ContextPath"],"ContextPath")
        

    # -------------------- save methods --------------------

    def click_save_button(self, bank: str,data) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "click Save button")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
        
    def click_save_button2(self, bank: str,data) -> None:
            self.click_by_locator(self.loc.save_button, "click Save button")
            # actual_msg = self.locator(EcentricExternalConnectionLocators.toast_message).text_content().strip()
            # print(f"Actual message: {actual_msg}")
            self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")

         
        
# ============================EDIT========================================================

    def edit_external_connection(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.search_connection(data["ConnectionName"])
        self.click_by_locator(loc.edit_button,"click edit button")
        self._select_protocol_Edit(data, loc)
         
         
    def _select_protocol_Edit(self, data: dict, loc) -> None:
            self.select_custom_dropdown_Edit(loc.protocol_field, data["Protocol"])
            protocol = _v(data, "protocol", "Protocol").lower()
            if protocol == "https":
                self._fill_https_fields(data, loc)
            elif protocol in ("go-connect", "goconnect"):
                self._select_goconnect_flow_Edit(data, loc)  
                
    def _select_goconnect_flow_Edit(self, data: dict, loc) -> None:
            self.select_custom_dropdown(loc.goconnect_connection_name_field, data["GoConnectConnectionName"])
            self.select_custom_dropdown(loc.Authorization_entity, data["AuthEntry"])
            self.select_custom_dropdown(loc.Authorization_type, data["AuthType"])
            self.fill_by_locator(loc.content_type_field,data["ContextPath"],"ContextPath")         

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------
    def delete_connection(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.search_connection(data["ConnectionName"])
        self.click_by_locator(loc.delete_button,"click delete button")
        self.click_by_locator(loc.delete_yes_dialog_handle,"click yes button")
        # self.click_by_locator(loc.delete_cancel_dialog_handle,"click cancel button")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
        
            
     # ------------------------------------------------------------------
    # Search (list page) - shared by Add-verify / Edit / Delete flows
    # ------------------------------------------------------------------
    def search_connection(self, connection_name: str) -> None:
        self.fill_by_locator(self.locator(self.loc.SEARCH_INPUT), connection_name, "Search box")
        self.click_by_locator(self.loc.SEARCH_BUTTON, "Search button")
        
        
        
        
    # ================================================================================
    
    
    
    def add_external_connection_NegativeCases(self, bank: str, data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self._add_external_connection_NegativeCases(data, loc)
            self._select_protocol_NegativeCases(data, loc)
    
    
        # -------------------- Private flow orchestration --------------------
    
    def _add_external_connection_NegativeCases(self, data: dict, loc) -> None:
            self.click_by_locator(loc.add_button, "Add button")
            self.fill_by_locator(loc.external_connection_name_field,data["ConnectionName"], "External connection name")
            # self.click_by_locator(EcentricExternalConnectionLocators.dummy_locator,"click dummy locator")
    
    def _select_protocol_NegativeCases(self, data: dict, loc) -> None:
            self.select_custom_dropdown(loc.protocol_field, data["Protocol"])
            protocol = _v(data, "protocol", "Protocol").lower()
            if protocol == "https":
                self._fill_https_fields_NegativeCases(data, loc)
            elif protocol in ("go-connect", "goconnect"):
                self._select_goconnect_flow_NegativeCases(data, loc)
    
    def _fill_https_fields_NegativeCases(self, data: dict, loc) -> None:
                self.fill_by_locator(loc.timeout_field,data["Timeout"], "Timeout")
                self.fill_by_locator(loc.retry_attempts_field, data["RetryAttempts"], "Retry attempts")
                self.fill_by_locator(loc.url_field, data["URL"], "URL")
                self.click_by_locator(EcentricExternalConnectionLocators.dummy_locator,"click dummy locator")
                
                # self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
                
                if self.page.locator(f"//mat-error[contains(text(),'{data['ExpectedMessage']}')]").count() > 0:
                    locator = self.page.locator(f"//mat-error[contains(text(),'{data['ExpectedMessage']}')]")
                else:
                    locator = self.page.locator(f"//mat-label[contains(text(),'{data['ExpectedMessage']}')]")
                             
                    self.assert_text(locator,data["ExpectedMessage"],"Error Message Validation")
                              
                method = _v(data, "method_type", "MethodType").lower()
                if not method:
                    return
                if method == "post":
                    self.click_by_locator(loc.method_type_post, "Method type: Post")
                else:
                    self.click_by_locator(loc.method_type_get, "Method type: Get")
                
    def _select_goconnect_flow_NegativeCases(self, data: dict, loc) -> None:
            self.select_custom_dropdown(loc.goconnect_connection_name_field, data["GoConnectConnectionName"])
            self.select_custom_dropdown(loc.Authorization_entity, data["AuthEntry"])
            self.select_custom_dropdown(loc.Authorization_type, data["AuthType"])
            self.fill_by_locator(loc.content_type_field,data["ContextPath"],"ContextPath")
            self.click_by_locator(EcentricExternalConnectionLocators.dummy_locator,"click dummy locator")
            # self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
                          
            if self.page.locator(f"//mat-error[contains(text(),'{data['ExpectedMessage']}')]").count() > 0:
             locator = self.page.locator(f"//mat-error[contains(text(),'{data['ExpectedMessage']}')]")
            else:
              locator = self.page.locator(f"//mat-label[contains(text(),'{data['ExpectedMessage']}')]")
              
              self.assert_text(locator,data["ExpectedMessage"],"Error Message Validation")
              
              
# ================================================================================================================================
# =========================================================================================================
              
              
              
    def navigate_to_setuproutingplan(self, bank: str) -> None:
            
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, f"{bank} Administration menu")
        self.click_by_locator(loc.menu_routing_configuration, f"{bank} Routing Configuration menu")
        self.click_by_locator(loc.menu_setup_routing_plan, f"{bank} Setup Routing Plan menu")
        self.click_by_locator(loc.setup_routing_plan_menu, "Setup routing plan")
        
        

    def click_add_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.setup_add_button, "Add button")

    def fill_setuproutingplan_form(self, bank: str, data: dict) -> None:
        """Fill the Add/Edit routing plan form based on the data provided."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_rounting_plan(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.routing_plan_name_input, data["Routing plan name"], "Routing plan name")
        auto_rounting=str(data["Auto BIN routing"]).strip().lower()
        if auto_rounting== "yes":
         self.select_radio_by_locator(loc.auto_bin_routing_yes, "Auto bin as YES")
         activate_plan = str(data["Activate this plan"]).strip().lower()

         if activate_plan == "yes":
          self.select_radio_by_locator(loc.activate_this_plan_yes,"Activate this plan YES")
          self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"])
          on_us_routing_value = str(data["On-Us routing"]).strip().lower()
          if on_us_routing_value== "yes":
           self.select_radio_by_locator(loc.on_us_routing_yes,"On-Us routing Yes")
           self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
           self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
          else:
            self.select_radio_by_locator(loc.on_us_routing_no,"On-Us routing No")
            print("clicked on-us")
            self.select_custom_dropdown(loc.scheme_routing_dropdown, data["Scheme routing"])
            print("clicked dropdown on-us")
            self.select_custom_dropdown(loc.card_type_dropdown, data["Card type"])
            self.click_by_locator(loc.rounting_save_button,"If No means rounting plan created with on-us NO")
            self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")  

             
         else:
           self.select_radio_by_locator(loc.activate_this_plan_no,"Activate this plan NO")
           self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"],"External dropdown clicked")
           self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
           self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
        else:
          self.select_radio_by_locator(loc.auto_bin_routing_no, "Auto bin as NO")
          self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
          self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
          self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
          self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
          
          
    # =======================EDIT====================================================
    
    
    def search_routing_plan(self, routing_plan: str) -> None:
            self.fill_by_locator(self.locator(self.loc.SEARCH_INPUT), routing_plan, "Search box")
            self.click_by_locator(self.loc.SEARCH_BUTTON, "Search button")
    
    def edit_routing_plan(self, bank: str, data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.search_connection(data["Routing plan name"])
            self.click_by_locator(loc.edit_button,"click edit button")
            self.select_radio_by_locator(loc.activate_this_plan_no,"Activate this plan NO")
            self.click_by_locator(loc.rounting_save_button,"Active got edited")
            self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
            
    
    def editing_routing_plan(self, bank: str, data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.search_connection(data["Routing plan name"])
                self.click_by_locator(loc.edit_button,"click edit button")
                auto_rounting=str(data["Auto BIN routing"]).strip().lower()
                if auto_rounting== "yes":
                     self.select_radio_by_locator(loc.auto_bin_routing_yes, "Auto bin as YES")
                     self.click_by_locator(loc.add_connection,"click another add connection")
                     self.select_custom_dropdown(loc.external_connection_id_dropdown2, data["External connection ID1"])
                     self.click_by_locator(loc.rounting_save_button,"Active got edited")
                     self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
                                 
                else:
                     self.select_radio_by_locator(loc.auto_bin_routing_no, "Auto bin as NO")
                     self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
                     self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
                     self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
     
             
               
            
           
#  =======================================DELETE==========================================
   
    def delete_routing_plan(self, bank: str, data: dict) -> None:
           _, loc = self._dispatch[bank.lower()]
           self.search_connection(data["Routing plan name"])
           self.click_by_locator(loc.delete_button,"click delete button")
           self.click_by_locator(loc.delete_yes_dialog_handle,"click yes button")
           # self.click_by_locator(loc.delete_cancel_dialog_handle,"click cancel button")
           self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
            
        
        
    # ==================================================================================================
    
    def _add_rounting_plan_Negative(self, bank: str, data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.fill_by_locator(loc.routing_plan_name_input, data["Routing plan name"], "Routing plan name")
            auto_rounting=str(data["Auto BIN routing"]).strip().lower()
            if auto_rounting== "yes":
             self.select_radio_by_locator(loc.auto_bin_routing_yes, "Auto bin as YES")
             activate_plan = str(data["Activate this plan"]).strip().lower()
    
             if activate_plan == "yes":
              self.select_radio_by_locator(loc.activate_this_plan_yes,"Activate this plan YES")
              self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"])
              on_us_routing_value = str(data["On-Us routing"]).strip().lower()
              if on_us_routing_value== "yes":
               self.select_radio_by_locator(loc.on_us_routing_yes,"On-Us routing Yes")
            #    self.click_by_locator(loc.rounting_save_button,"If yes means save button clicked")
               self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
              else:
                self.select_radio_by_locator(loc.on_us_routing_no,"On-Us routing No")
                print("clicked on-us")
                self.select_custom_dropdown(loc.scheme_routing_dropdown, data["Scheme routing"])
                print("clicked dropdown on-us")
                self.select_custom_dropdown(loc.card_type_dropdown, data["Card type"])
                self.click_by_locator(loc.rounting_save_button,"If No means rounting plan created with on-us NO")
                self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation") 
    
                 
             else:
               self.select_radio_by_locator(loc.activate_this_plan_no,"Activate this plan NO")
               self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"],"External dropdown clicked")
               self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
               self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
            else:
              self.select_radio_by_locator(loc.auto_bin_routing_no, "Auto bin as NO")
              self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
              self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
              self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
              self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
             
    def _add_rounting_plan_Negative1(self, bank: str, data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.fill_by_locator(loc.routing_plan_name_input, data["Routing plan name"], "Routing plan name")
                auto_rounting=str(data["Auto BIN routing"]).strip().lower()
                if auto_rounting== "yes":
                 self.select_radio_by_locator(loc.auto_bin_routing_yes, "Auto bin as YES")
                 activate_plan = str(data["Activate this plan"]).strip().lower()
        
                 if activate_plan == "yes":
                  self.select_radio_by_locator(loc.activate_this_plan_yes,"Activate this plan YES")
                #   self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"])
                  on_us_routing_value = str(data["On-Us routing"]).strip().lower()
                  if on_us_routing_value== "yes":
                   self.select_radio_by_locator(loc.on_us_routing_yes,"On-Us routing Yes")
                   self.click_by_locator(loc.rounting_save_button,"If yes means save button clicked")
                   self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
                  else:
                    self.select_radio_by_locator(loc.on_us_routing_no,"On-Us routing No")
                    print("clicked on-us")
                    self.select_custom_dropdown(loc.scheme_routing_dropdown, data["Scheme routing"])
                    print("clicked dropdown on-us")
                    self.select_custom_dropdown(loc.card_type_dropdown, data["Card type"])
                    self.click_by_locator(loc.rounting_save_button,"If No means rounting plan created with on-us NO")
                    self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation") 
        
                     
                 else:
                   self.select_radio_by_locator(loc.activate_this_plan_no,"Activate this plan NO")
                   self.select_custom_dropdown(loc.external_connection_id_dropdown, data["External connection ID"],"External dropdown clicked")
                   self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
                   self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
                else:
                  self.select_radio_by_locator(loc.auto_bin_routing_no, "Auto bin as NO")
                  self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
                  self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage"]}')]"),data["ExpectedMessage"]," Error Message Validation")
                  self.click_by_locator(loc.rounting_save_button,"If No means file uploaded")
                  self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["ExpectedMessage1"]}')]"),data["ExpectedMessage1"]," Error Message Validation")
                 
                 
    def click_add_connection_button(self, bank: str) -> None:
        """Click the 'Add connection' button to add another connection row."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_connection_button, "Add connection button")

    # def click_save_button1(self, bank: str) -> None:
    #     """Click the Save button to save the routing plan."""
    #     _, loc = self._dispatch[bank.lower()]
    #     self.click_by_locator(loc.save_button, "Save button")

    def click_cancel_button(self, bank: str) -> None:
        """Click the Cancel button to discard changes."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.cancel_button, "Cancel button")
        
        
    def click_edit_button(self, bank: str, plan_name: str) -> None:
            """Click the edit (pencil) icon for a routing plan row."""
            _, loc = self._dispatch[bank.lower()]
            row_locator = self._find_row_setuproutingplan(bank, plan_name)
            edit_btn = row_locator + "//button[contains(@aria-label,'edit') or .//mat-icon[contains(text(),'edit')]]"
            self.click_by_locator(edit_btn, "Edit button")
            
            
            
            # ===============================================================

    def assert_success_message(self, bank: str, expected_message: str) -> None:
        """Assert that the success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message")

    def assert_error_message(self, bank: str, expected_message: str) -> None:
        """Assert that an error/validation message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.error_message), expected_message, "Error message")

    # ========== EDIT ACTION ==========
    def search_routing_plan(self, bank: str, plan_name: str) -> None:
        """Search for a routing plan by name in the list page."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_field, plan_name, "Search field")
        self.click_by_locator(loc.search_button, "Search button")

    def _find_row_setuproutingplan(self, bank: str, plan_name: str) -> str:
        """Helper: returns the row locator for a routing plan by name."""
        _, loc = self._dispatch[bank.lower()]
        return f"//tr[td[contains(normalize-space(text()),'{plan_name}')]]"

    def click_edit_button(self, bank: str, plan_name: str) -> None:
        """Click the edit (pencil) icon for a routing plan row."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = self._find_row_setuproutingplan(bank, plan_name)
        edit_btn = row_locator + "//button[contains(@aria-label,'edit') or .//mat-icon[contains(text(),'edit')]]"
        self.click_by_locator(edit_btn, "Edit button")

    # ========== DELETE ACTION ==========
    def click_delete_button(self, bank: str, plan_name: str) -> None:
        """Click the delete (trash) icon for a routing plan row."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = self._find_row_setuproutingplan(bank, plan_name)
        delete_btn = row_locator + "//button[contains(@aria-label,'delete') or .//mat-icon[contains(text(),'delete')]]"
        self.click_by_locator(delete_btn, "Delete button")

    def assert_delete_confirmation_visible(self, bank: str) -> None:
        """Assert that the delete confirmation dialog is visible."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.delete_confirmation_dialog), "Delete confirmation dialog")

    def assert_delete_confirmation_message(self, bank: str, plan_name: str) -> None:
        """Assert the delete confirmation message includes the plan name."""
        _, loc = self._dispatch[bank.lower()]
        expected_msg = f"Are you sure you want to delete the routing plan? The selected routing plan {plan_name} will be deleted permanently"
        self.assert_text(self.locator(loc.delete_confirmation_message), expected_msg, "Delete confirmation message")

    def click_delete_confirmation_yes(self, bank: str) -> None:
        """Click 'Yes' on the delete confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirmation_yes, "Delete confirmation Yes button")

    def click_delete_confirmation_cancel(self, bank: str) -> None:
        """Click 'Cancel' on the delete confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirmation_cancel, "Delete confirmation Cancel button")

    def assert_delete_success_message(self, bank: str, expected_message: str) -> None:
        """Assert that the delete success message is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.delete_success_message), expected_message, "Delete success message")

    def assert_row_not_visible(self, bank: str, plan_name: str) -> None:
        """Assert that a routing plan row is no longer visible in the list."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = self._find_row_setuproutingplan(bank, plan_name)
        self.assert_not_visible(self.locator(row_locator), f"Routing plan row for {plan_name}", timeout=5000)

    def assert_row_visible(self, bank: str, plan_name: str) -> None:
        """Assert that a routing plan row is visible in the list."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = self._find_row_setuproutingplan(bank, plan_name)
        self.assert_visible(self.locator(row_locator), f"Routing plan row for {plan_name}")         
              
    

  
            
