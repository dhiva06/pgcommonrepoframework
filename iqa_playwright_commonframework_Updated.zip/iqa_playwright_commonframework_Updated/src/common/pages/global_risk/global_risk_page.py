
from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.global_risk_locators import GlobalRiskLocators as EcentricGlobalRiskLocators


class GlobalRiskPage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="GlobalRisk")

    def __init__(self, page, module_name="Login"):
            super().__init__(page, module_name=module_name)
            self._dispatch = {
                
                "ecentric": (self._navigate_to_riskprofile,self._navigate_to_risk_configuration,self._delete_bin_blocking,self._Validate_error_message_bin,self._add_card_blocking,self._delete_card_blocking,self._Validate_error_message_card,self._add_ip_blocking,self._delete_ip_blocking,self._Validate_error_message_ip,self._add_country_blocking,self._delete_country_blocking,self._Validate_error_message_country, EcentricGlobalRiskLocators),
            }
            
       
    def  _navigate_to_riskprofile(self):
        self.click_by_locator(EcentricGlobalRiskLocators.UNHIDE_MENU)
        self.click_by_locator(EcentricGlobalRiskLocators.ADMINISTRATION,"Administration")
        self.click_by_locator(EcentricGlobalRiskLocators.RISK_SETUP,"Risk Setup")
        self.click_by_locator(EcentricGlobalRiskLocators.SELECT_PG,"PG")
        self.click_by_locator(EcentricGlobalRiskLocators.RISK_CONFIGURATION,"Risk Configuration")
        
    def _navigate_to_risk_configuration(self):
        self.click_by_locator(EcentricGlobalRiskLocators.UNHIDE_MENU)
        self.click_by_locator(EcentricGlobalRiskLocators.ADMINISTRATION,"Administration")
        self.click_by_locator(EcentricGlobalRiskLocators.RISK_SETUP,"Risk Setup")
        self.click_by_locator(EcentricGlobalRiskLocators.SELECT_PG,"PG")
       
    def _add_bin_blocking(self, data):       
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_BUTTON,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_BIN,"Add BIN")
        self.fill_by_locator(EcentricGlobalRiskLocators.BIN_NUMBER,data["BinNumber"],"BIN Number")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.click_by_locator(EcentricGlobalRiskLocators.SAVE_BUTTON,"Save")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"Block BIN Success Message")
        
    def _delete_bin_blocking(self, data):       
        self.click_by_locator(EcentricGlobalRiskLocators.CARD_BLOCKING_TAB, "Card Blocking")
        self.click_by_locator(EcentricGlobalRiskLocators.BIN_BLOCKING_TAB, "BIN Blocking")
        self.fill_by_locator(EcentricGlobalRiskLocators.SEARCH_BOX_BIN, data["BinNumber"], "Search BIN")
        self.click_by_locator(EcentricGlobalRiskLocators.SEARCH_BUTTON, "Search")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_ICON, "Delete")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_BUTTON, "Delete")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["delete_message"]}')]"),data["delete_message"],"Unblock BIN Success Message")
        
    def _Validate_error_message_bin(self,data):
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_BUTTON,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_BIN,"Add BIN")
        self.fill_by_locator(EcentricGlobalRiskLocators.BIN_NUMBER,data["BinNumber"],"BIN Number")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"BIN BLOCKING Error Message Validation")
    
    def _add_card_blocking(self, data):
        self.click_by_locator(EcentricGlobalRiskLocators.CARD_BLOCKING_TAB)
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_CARD,"Add Card")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_CARD_BLOCKING,"Add Card")
        self.fill_by_locator(EcentricGlobalRiskLocators.ADD_CARD_NUMBER,data["CardNumber"],"Card Number")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.click_by_locator(EcentricGlobalRiskLocators.SAVE_BUTTON,"Save")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"Block Card Success Message")
        
    def _delete_card_blocking(self, data):       
        self.click_by_locator(EcentricGlobalRiskLocators.BIN_BLOCKING_TAB, "BIN Blocking")
        self.click_by_locator(EcentricGlobalRiskLocators.CARD_BLOCKING_TAB, "Card Blocking")       
        self.fill_by_locator(EcentricGlobalRiskLocators.SEARCH_BOX_CARD, data["CardNumber"], "Search Card")
        self.click_by_locator(EcentricGlobalRiskLocators.SEARCH_BUTTON, "Search")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_ICON, "Delete")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_BUTTON, "Delete")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["delete_message"]}')]"),data["delete_message"],"Unblock CARD Success Message")
                
    def _Validate_error_message_card(self,data):        
        self.click_by_locator(EcentricGlobalRiskLocators.CARD_BLOCKING_TAB)
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_CARD,"Add Card")
        self.fill_by_locator(EcentricGlobalRiskLocators.ADD_CARD_NUMBER,data["CardNumber"],"Card Number")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"CARD BLOCKING Error Message Validation")    

    def _add_ip_blocking(self, data):
        self.click_by_locator(EcentricGlobalRiskLocators.IP_BLOCKING_TAB)
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_IP,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_IP_BLOCKING,"Add IP")
        self.fill_by_locator(EcentricGlobalRiskLocators.ADD_IP_ADDRESS,data["IPAddress"],"IP Address")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.click_by_locator(EcentricGlobalRiskLocators.SAVE_BUTTON,"Save")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"Block ip Success Message")
    
    def _delete_ip_blocking(self, data):       
        self.click_by_locator(EcentricGlobalRiskLocators.BIN_BLOCKING_TAB, "BIN Blocking")
        self.click_by_locator(EcentricGlobalRiskLocators.IP_BLOCKING_TAB, "IP Blocking")   
        self.fill_by_locator(EcentricGlobalRiskLocators.SEARCH_BOX_IP, data["IPAddress"], "Search IP")    
        self.click_by_locator(EcentricGlobalRiskLocators.SEARCH_BUTTON, "Search")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_ICON, "Delete")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_BUTTON, "Delete")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["delete_message"]}')]"),data["delete_message"],"Unblock IP Success Message")
    
    def _Validate_error_message_ip(self,data):
        self.click_by_locator(EcentricGlobalRiskLocators.IP_BLOCKING_TAB)
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_IP,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_IP_BLOCKING,"Add IP")
        self.fill_by_locator(EcentricGlobalRiskLocators.ADD_IP_ADDRESS,data["IPAddress"],"IP Address")
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"IP BLOCKING Error Message Validation")                     
    
    def _add_country_blocking(self, data):        
        self.click_by_locator(EcentricGlobalRiskLocators.COUNTRY_BLOCKING_TAB)
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY_BLOCKING,"Add Country")
        self.select_custom_dropdown(EcentricGlobalRiskLocators.SELECT_COUNTRY,data["countryName"])
        # self.click_by_locator(EcentricGlobalRiskLocators.SELECT_COUNTRY,"Country Dropdown")
        # self.select_single_option_dropdown(EcentricGlobalRiskLocators.SELECT_COUNTRY,data["countryName"],"Country Dropdown")      
        # self.fill_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY_NAME,data["countryName"],"Country Name")
        # self.click_by_locator(f"//span[normalize-space()='{data['countryName']}']",data["countryName"])
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.click_by_locator(EcentricGlobalRiskLocators.SAVE_BUTTON,"Save")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"Block Country Success Message")

    def _delete_country_blocking(self, data):       
        self.click_by_locator(EcentricGlobalRiskLocators.BIN_BLOCKING_TAB, "BIN Blocking")
        self.click_by_locator(EcentricGlobalRiskLocators.COUNTRY_BLOCKING_TAB, "Country Blocking")       
        self.fill_by_locator(EcentricGlobalRiskLocators.SEARCH_BOX_COUNTRY, data["countryName"], "Search Country")
        self.click_by_locator(EcentricGlobalRiskLocators.SEARCH_BUTTON, "Search")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_ICON, "Delete")
        self.click_by_locator(EcentricGlobalRiskLocators.DELETE_BUTTON, "Delete")
        self.assert_text(self.page.locator(f"//mat-label[contains(text(),'{data["delete_message"]}')]"),data["delete_message"],"Unblock COUNTRY Success Message")
    
    def _Validate_error_message_country(self, data):
        self.click_by_locator(EcentricGlobalRiskLocators.COUNTRY_BLOCKING_TAB)        
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY,"Add")
        self.click_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY_BLOCKING,"Add Country")
        self.select_single_option_dropdown(EcentricGlobalRiskLocators.SELECT_COUNTRY,data["countryName"],"Country Dropdown")
        # self.fill_by_locator(EcentricGlobalRiskLocators.ADD_COUNTRY_NAME,data["countryName"],"Country Name")
        # self.click_by_locator(f"//span[normalize-space()='{data['countryName']}']",data["countryName"])
        self.fill_by_locator(EcentricGlobalRiskLocators.REASON_FOR_BLOCKING,data["Reason"],"Reason")
        self.page.keyboard.press("Tab")
        self.click_by_locator(EcentricGlobalRiskLocators.SAVE_BUTTON,"Save")
        self.assert_text(self.page.locator(f"//mat-error[contains(text(),'{data["expected_message"]}')]"),data["expected_message"],"COUNTRY BLOCKING Error Message Validation")                     
    
    
    
    def assert_success_message(self,data,expected_message: str) -> None:

        self.assert_text(self.page.locator(f"//*[contains(text(),'{data["expected_message"]}')]"),data["expected_message"], data["expected_message"]+" text is Validated Successfully")                     
           
    def assert_validation_message(self,expected_message: str) -> None:

        self.assert_text(
        self.page.locator(f"//*[contains(text(),'{expected_message}')]"),expected_message,
        f"{expected_message} text is Validated Successfully"
    )