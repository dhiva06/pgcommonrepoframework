# FIXME (self-review): this file calls invented method(s) that do NOT exist on BasePage - assert_checked. This WILL raise AttributeError at runtime. Check base_page.py for the real method name(s) to use instead and fix the call(s) below before running.

from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.bankriskprofile_locators import BankriskprofileLocators as EcentricBankriskprofileLocators

class BankriskprofilePage(BasePage):
    def __init__(self, page, module_name="Bankriskprofile"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self.fill_bankriskprofile_form, EcentricBankriskprofileLocators),
        }

    def navigate_to_bankriskprofile(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.unhide_menu_button, "Unhide menu button")
        self.click_by_locator(loc.administration, "Administration menu")
        self.click_by_locator(loc.risk_setup, "Risk setup menu")
        self.click_by_locator(loc.pg_configuration, "pg_configuration")
        self.click_by_locator(loc.risk_configuration, "Risk configuration menu")
        self.click_by_locator(loc.bank_risk_profile_tab, "Bank Risk Profile tab")
        self.page.wait_for_timeout(2000)
        
    def click_add_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    # def verify_add_bankriskprofile_page_displayed(self, bank: str) -> None:
    #     _, loc = self._dispatch[bank.lower()]
    #     self.assert_text(self.locator(loc.add_bank_risk_profile_page_header), "Add Bank Risk Profile", "Add Bank Risk Profile page header")

    def fill_domestic_bankriskprofile_form(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.risk_profile_name_input, data["Risk Profile Name"], "Risk Profile Name")
        self.select_single_option_dropdown(loc.country_codes_dropdown, data["Country Code 1"], "Country Code 1")
        self.click_by_locator(loc.visa_checkbox, "Visa checkbox")
        self.click_by_locator(loc.mastercard_checkbox, "Mastercard checkbox")
        self.click_by_locator(loc.max_transactions_allowed_daily, "Max Transactions Allowed Daily")
        self.click_by_locator(loc.max_transactions_allowed_weekly, "Max Transactions Allowed Weekly")
        self.click_by_locator(loc.max_transactions_allowed_monthly, "Max Transactions Allowed Monthly")
        self.fill_by_locator(loc.max_transaction_count_daily, data["Visa Max Transactions Daily"], "Visa Max Transactions Daily")
        self.fill_by_locator(loc.max_transaction_count_weekly, data["Visa Max Transactions Weekly"], "Visa Max Transactions Weekly")
        self.fill_by_locator(loc.max_transaction_count_monthly, data["Visa Max Transactions Monthly"], "Visa Max Transactions Monthly")
        self.click_by_locator(loc.cumulative_transaction_amount_daily, "Cumulative Transaction Amount Daily")
        self.click_by_locator(loc.cumulative_transaction_amount_weekly, "Cumulative Transaction Amount Weekly")
        self.click_by_locator(loc.cumulative_transaction_amount_monthly, "Cumulative Transaction Amount Monthly")
        self.fill_by_locator(loc.max_transaction_amount_daily, data["Visa Cumulative Amount Daily"], "Visa Cumulative Amount Daily")
        self.fill_by_locator(loc.max_transaction_amount_weekly, data["Visa Cumulative Amount Weekly"], "Visa Cumulative Amount Weekly")
        self.fill_by_locator(loc.max_transaction_amount_monthly, data["Visa Cumulative Amount Monthly"], "Visa Cumulative Amount Monthly")
        # self.click_by_locator(loc.decline_transaction_visa_no, "Visa Decline Transaction No")
        self.click_by_locator(loc.max_transactions_allotted_daily_mastercard, "Max Transactions Allotted Daily Mastercard")
        self.click_by_locator(loc.max_transactions_allotted_weekly_mastercard, "Max Transactions Allotted Weekly Mastercard")
        self.click_by_locator(loc.max_transactions_allotted_monthly_mastercard, "Max Transactions Allotted Monthly Mastercard")
        self.fill_by_locator(loc.max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], "Mastercard Max Transactions Daily")
        self.fill_by_locator(loc.max_transaction_count_weekly_mastercard, data["Mastercard Max Transactions Weekly"], "Mastercard Max Transactions Weekly")
        self.fill_by_locator(loc.max_transaction_count_monthly_mastercard, data["Mastercard Max Transactions Monthly"], "Mastercard Max Transactions Monthly")               
        self.click_by_locator(loc.cumulative_transaction_amount_daily_mastercard, "Cumulative Transaction Amount Daily Mastercard")
        self.click_by_locator(loc.cumulative_transaction_amount_weekly_mastercard, "Cumulative Transaction Amount Weekly Mastercard")
        self.click_by_locator(loc.cumulative_transaction_amount_monthly_mastercard, "Cumulative Transaction Amount Monthly Mastercard")    
        self.fill_by_locator(loc.max_transaction_amount_daily_mastercard, data["Mastercard Cumulative Amount Daily"], "Mastercard Cumulative Amount Daily")
        self.fill_by_locator(loc.max_transaction_amount_weekly_mastercard, data["Mastercard Cumulative Amount Weekly"], "Mastercard Cumulative Amount Weekly")
        self.fill_by_locator(loc.max_transaction_amount_monthly_mastercard, data["Mastercard Cumulative Amount Monthly"], "Mastercard Cumulative Amount Monthly")
        # self.click_by_locator(loc.decline_transaction_mastercard_no, "Mastercard Decline Transaction No")
        self.fill_and_check(loc.max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], data["ExpectedMessage"])
    
    def fill_international_bankriskprofile_form(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.risk_profile_name_input, data["Risk Profile Name"], "Risk Profile Name")
        self.select_single_option_dropdown(loc.country_codes_dropdown, data["Country Code 1"], "Country Code 1")
        self.click_by_locator(loc.International_visa_checkbox, "Visa checkbox")
        self.click_by_locator(loc.International_mastercard_checkbox, "Mastercard checkbox")
        self.click_by_locator(loc.International_max_transactions_allowed_daily, "Max Transactions Allowed Daily")
        self.click_by_locator(loc.International_max_transactions_allowed_weekly, "Max Transactions Allowed Weekly")
        self.click_by_locator(loc.International_max_transactions_allowed_monthly, "Max Transactions Allowed Monthly")
        self.fill_by_locator(loc.International_max_transaction_count_daily, data["Visa Max Transactions Daily"], "Visa Max Transactions Daily")
        self.fill_by_locator(loc.International_max_transaction_count_weekly, data["Visa Max Transactions Weekly"], "Visa Max Transactions Weekly")
        self.fill_by_locator(loc.International_max_transaction_count_monthly, data["Visa Max Transactions Monthly"], "Visa Max Transactions Monthly")
        self.click_by_locator(loc.International_cumulative_transaction_amount_daily, "Cumulative Transaction Amount Daily")
        self.click_by_locator(loc.International_cumulative_transaction_amount_weekly, "Cumulative Transaction Amount Weekly")
        self.click_by_locator(loc.International_cumulative_transaction_amount_monthly, "Cumulative Transaction Amount Monthly")
        self.fill_by_locator(loc.International_max_transaction_amount_daily, data["Visa Cumulative Amount Daily"], "Visa Cumulative Amount Daily")
        self.fill_by_locator(loc.International_max_transaction_amount_weekly, data["Visa Cumulative Amount Weekly"], "Visa Cumulative Amount Weekly")
        self.fill_by_locator(loc.International_max_transaction_amount_monthly, data["Visa Cumulative Amount Monthly"], "Visa Cumulative Amount Monthly")
        # self.click_by_locator(loc.decline_transaction_visa_no, "Visa Decline Transaction No")
        self.click_by_locator(loc.International_max_transactions_allotted_daily_mastercard, "Max Transactions Allotted Daily Mastercard")
        self.click_by_locator(loc.International_max_transactions_allotted_weekly_mastercard, "Max Transactions Allotted Weekly Mastercard")
        self.click_by_locator(loc.International_max_transactions_allotted_monthly_mastercard, "Max Transactions Allotted Monthly Mastercard")
        self.fill_by_locator(loc.International_max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], "Mastercard Max Transactions Daily")
        self.fill_by_locator(loc.International_max_transaction_count_weekly_mastercard, data["Mastercard Max Transactions Weekly"], "Mastercard Max Transactions Weekly")
        self.fill_by_locator(loc.International_max_transaction_count_monthly_mastercard, data["Mastercard Max Transactions Monthly"], "Mastercard Max Transactions Monthly")               
        self.click_by_locator(loc.International_cumulative_transaction_amount_daily_mastercard, "Cumulative Transaction Amount Daily Mastercard")
        self.click_by_locator(loc.International_cumulative_transaction_amount_weekly_mastercard, "Cumulative Transaction Amount Weekly Mastercard")
        self.click_by_locator(loc.International_cumulative_transaction_amount_monthly_mastercard, "Cumulative Transaction Amount Monthly Mastercard")    
        self.fill_by_locator(loc.International_max_transaction_amount_daily_mastercard, data["Mastercard Cumulative Amount Daily"], "Mastercard Cumulative Amount Daily")
        self.fill_by_locator(loc.International_max_transaction_amount_weekly_mastercard, data["Mastercard Cumulative Amount Weekly"], "Mastercard Cumulative Amount Weekly")
        self.fill_by_locator(loc.International_max_transaction_amount_monthly_mastercard, data["Mastercard Cumulative Amount Monthly"], "Mastercard Cumulative Amount Monthly")
        # self.click_by_locator(loc.decline_transaction_mastercard_no, "Mastercard Decline Transaction No")
        self.fill_and_check(loc.International_max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], data["ExpectedMessage"])
    

    def assert_risk_profile_details_displayed(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.risk_profile_name_input), data["Risk Profile Name"], "Risk Profile Name")
        # Assuming country codes are displayed in a specific way; adjust as needed
        self.assert_text(self.locator(loc.country_codes_dropdown), f"{data['Country Code 1']}, {data['Country Code 2']}", "Country Codes")
        # Visa section
        self.assert_checked(self.locator(loc.visa_checkbox), "Visa checkbox")
        self.assert_text(self.locator(loc.max_transactions_allotted_daily), data["Visa Max Transactions Daily"], "Visa Max Transactions Daily")
        self.assert_text(self.locator(loc.max_transactions_allotted_weekly), data["Visa Max Transactions Weekly"], "Visa Max Transactions Weekly")
        self.assert_text(self.locator(loc.max_transactions_allotted_monthly), data["Visa Max Transactions Monthly"], "Visa Max Transactions Monthly")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_daily), data["Visa Cumulative Amount Daily"], "Visa Cumulative Amount Daily")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_weekly), data["Visa Cumulative Amount Weekly"], "Visa Cumulative Amount Weekly")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_monthly), data["Visa Cumulative Amount Monthly"], "Visa Cumulative Amount Monthly")
        self.assert_checked(self.locator(loc.decline_transaction_visa_no), "Visa Decline Transaction No")
        # Mastercard section
        self.assert_checked(self.locator(loc.mastercard_checkbox), "Mastercard checkbox")
        self.assert_text(self.locator(loc.max_transactions_allotted_daily_mastercard), data["Mastercard Max Transactions Daily"], "Mastercard Max Transactions Daily")
        self.assert_text(self.locator(loc.max_transactions_allotted_weekly_mastercard), data["Mastercard Max Transactions Weekly"], "Mastercard Max Transactions Weekly")
        self.assert_text(self.locator(loc.max_transactions_allotted_monthly_mastercard), data["Mastercard Max Transactions Monthly"], "Mastercard Max Transactions Monthly")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_daily_mastercard), data["Mastercard Cumulative Amount Daily"], "Mastercard Cumulative Amount Daily")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_weekly_mastercard), data["Mastercard Cumulative Amount Weekly"], "Mastercard Cumulative Amount Weekly")
        self.assert_text(self.locator(loc.cumulative_transaction_amount_monthly_mastercard), data["Mastercard Cumulative Amount Monthly"], "Mastercard Cumulative Amount Monthly")
        self.assert_checked(self.locator(loc.decline_transaction_mastercard_no), "Mastercard Decline Transaction No")
        
    def fill_domestic_bankriskprofile_Detail(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.visa_checkbox, "Visa checkbox")
        self.click_by_locator(loc.mastercard_checkbox, "Mastercard checkbox")
        if not self.fill_and_check(loc.risk_profile_name_input, data["Risk Profile Name"],"Riskprofile Name", data):return
        if not self.select_single_option_dropdown(loc.country_codes_dropdown, data["Country Code 1"], "Country Code 1"):return
        self.click_by_locator(loc.max_transactions_allowed_daily, "Max Transactions Allowed Daily")
        self.click_by_locator(loc.max_transactions_allowed_weekly, "Max Transactions Allowed Weekly")
        self.click_by_locator(loc.max_transactions_allowed_monthly, "Max Transactions Allowed Monthly")
        if not self.fill_and_check(loc.max_transaction_count_daily, data["Visa Max Transactions Daily"],"Visa Max Transactions Daily", data):return
        if not self.fill_and_check(loc.max_transaction_count_weekly, data["Visa Max Transactions Weekly"], "Visa Max Transactions Weekly", data):return
        if not self.fill_and_check(loc.max_transaction_count_monthly, data["Visa Max Transactions Monthly"], "Visa Max Transactions Monthly", data):return
        self.click_by_locator(loc.cumulative_transaction_amount_daily, "Cumulative Transaction Amount Daily")
        self.click_by_locator(loc.cumulative_transaction_amount_weekly, "Cumulative Transaction Amount Weekly")
        self.click_by_locator(loc.cumulative_transaction_amount_monthly, "Cumulative Transaction Amount Monthly")
        if not self.fill_and_check(loc.max_transaction_amount_daily, data["Visa Cumulative Amount Daily"], "Visa Cumulative Amount Daily", data):return
        if not self.fill_and_check(loc.max_transaction_amount_weekly, data["Visa Cumulative Amount Weekly"], "Visa Cumulative Amount Weekly", data):return
        if not self.fill_and_check(loc.max_transaction_amount_monthly, data["Visa Cumulative Amount Monthly"], "Visa Cumulative Amount Monthly", data):return
        # self.click_by_locator(loc.decline_transaction_visa_no, "Visa Decline Transaction No")
        self.click_by_locator(loc.max_transactions_allotted_daily_mastercard, "Max Transactions Allotted Daily Mastercard")
        self.click_by_locator(loc.max_transactions_allotted_weekly_mastercard, "Max Transactions Allotted Weekly Mastercard")
        self.click_by_locator(loc.max_transactions_allotted_monthly_mastercard, "Max Transactions Allotted Monthly Mastercard")
        if not self.fill_and_check(loc.max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], "Mastercard Max Transactions Daily", data):return
        if not self.fill_and_check(loc.max_transaction_count_weekly_mastercard, data["Mastercard Max Transactions Weekly"], "Mastercard Max Transactions Weekly", data):return
        if not self.fill_and_check(loc.max_transaction_count_monthly_mastercard, data["Mastercard Max Transactions Monthly"], "Mastercard Max Transactions Monthly", data):return           
        self.click_by_locator(loc.cumulative_transaction_amount_daily_mastercard, "Cumulative Transaction Amount Daily Mastercard")
        self.click_by_locator(loc.cumulative_transaction_amount_weekly_mastercard, "Cumulative Transaction Amount Weekly Mastercard")
        self.click_by_locator(loc.cumulative_transaction_amount_monthly_mastercard, "Cumulative Transaction Amount Monthly Mastercard")    
        if not self.fill_and_check(loc.max_transaction_amount_daily_mastercard, data["Mastercard Cumulative Amount Daily"], "Mastercard Cumulative Amount Daily", data):return
        if not self.fill_and_check(loc.max_transaction_amount_weekly_mastercard, data["Mastercard Cumulative Amount Weekly"], "Mastercard Cumulative Amount Weekly", data):return
        if not self.fill_and_check(loc.max_transaction_amount_monthly_mastercard, data["Mastercard Cumulative Amount Monthly"], "Mastercard Cumulative Amount Monthly", data):return
        # self.click_by_locator(loc.decline_transaction_mastercard_no, "Mastercard Decline Transaction No")
        
    def fill_international_bankriskprofile_Detail(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.International_transaction_yes.format(value="Yes"), "BIN Status - Active")
        # self.select_radio_by_locator(loc.International_transaction_yes, "International Transaction Yes")
        # self.click_by_locator(loc.International_transaction_yes, "International Transaction Yes")
        self.click_by_locator(loc.International_visa_checkbox, "International Visa checkbox")
        self.click_by_locator(loc.International_mastercard_checkbox, "International Mastercard checkbox")
        if not self.fill_and_check(loc.risk_profile_name_input, data["Risk Profile Name"],"Riskprofile Name", data):return
        if not self.select_single_option_dropdown(loc.country_codes_dropdown, data["Country Code 1"], "Country Code 1"):return
        self.click_by_locator(loc.International_max_transactions_allowed_daily, "International Max Transactions Allowed Daily")
        self.click_by_locator(loc.International_max_transactions_allowed_weekly, "International Max Transactions Allowed Weekly")
        self.click_by_locator(loc.International_max_transactions_allowed_monthly, "International Max Transactions Allowed Monthly")
        if not self.fill_and_check(loc.International_max_transaction_count_daily, data["Visa Max Transactions Daily"],"Visa Max Transactions Daily", data):return
        if not self.fill_and_check(loc.International_max_transaction_count_weekly, data["Visa Max Transactions Weekly"], "Visa Max Transactions Weekly", data):return
        if not self.fill_and_check(loc.International_max_transaction_count_monthly, data["Visa Max Transactions Monthly"], "Visa Max Transactions Monthly", data):return
        self.click_by_locator(loc.International_cumulative_transaction_amount_daily, "International Cumulative Transaction Amount Daily")
        self.click_by_locator(loc.International_cumulative_transaction_amount_weekly, "International Cumulative Transaction Amount Weekly")
        self.click_by_locator(loc.International_cumulative_transaction_amount_monthly, "International Cumulative Transaction Amount Monthly")
        if not self.fill_and_check(loc.International_max_transaction_amount_daily, data["Visa Cumulative Amount Daily"], "Visa Cumulative Amount Daily", data):return
        if not self.fill_and_check(loc.International_max_transaction_amount_weekly, data["Visa Cumulative Amount Weekly"], "Visa Cumulative Amount Weekly", data):return
        if not self.fill_and_check(loc.International_max_transaction_amount_monthly, data["Visa Cumulative Amount Monthly"], "Visa Cumulative Amount Monthly", data):return
        # self.click_by_locator(loc.decline_transaction_visa_no, "Visa Decline Transaction No")
        self.click_by_locator(loc.International_max_transactions_allowed_daily_mastercard, "International Max Transactions Allowed Daily Mastercard")
        self.click_by_locator(loc.International_max_transactions_allowed_weekly_mastercard, "International Max Transactions Allowed Weekly Mastercard")
        self.click_by_locator(loc.International_max_transactions_allowed_monthly_mastercard, "International Max Transactions Allowed Monthly Mastercard")
        if not self.fill_and_check(loc.International_max_transaction_count_daily_mastercard, data["Mastercard Max Transactions Daily"], "Mastercard Max Transactions Daily", data):return
        if not self.fill_and_check(loc.International_max_transaction_count_weekly_mastercard, data["Mastercard Max Transactions Weekly"], "Mastercard Max Transactions Weekly", data):return
        if not self.fill_and_check(loc.International_max_transaction_count_monthly_mastercard, data["Mastercard Max Transactions Monthly"], "Mastercard Max Transactions Monthly", data):return           
        self.click_by_locator(loc.International_cumulative_transaction_amount_daily_mastercard, "International Cumulative Transaction Amount Daily Mastercard")
        self.click_by_locator(loc.International_cumulative_transaction_amount_weekly_mastercard, "International Cumulative Transaction Amount Weekly Mastercard")
        self.click_by_locator(loc.International_cumulative_transaction_amount_monthly_mastercard, "International Cumulative Transaction Amount Monthly Mastercard")    
        if not self.fill_and_check(loc.International_max_transaction_amount_daily_mastercard, data["Mastercard Cumulative Amount Daily"], "Mastercard Cumulative Amount Daily", data):return
        if not self.fill_and_check(loc.International_max_transaction_amount_weekly_mastercard, data["Mastercard Cumulative Amount Weekly"], "Mastercard Cumulative Amount Weekly", data):return
        if not self.fill_and_check(loc.International_max_transaction_amount_monthly_mastercard, data["Mastercard Cumulative Amount Monthly"], "Mastercard Cumulative Amount Monthly", data):return
        # self.click_by_locator(loc.decline_transaction_mastercard_no, "Mastercard Decline Transaction No")
        
    def search_and_delete_bankriskprofile(self,bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]

        self.fill_by_locator(loc.search_risk_profile,data["Risk Profile Name"],"Search Risk Profile")
        self.click_by_locator(loc.search_button,"Search")
        self.click_by_locator(loc.delete_icon,"Delete")
        self.click_by_locator(loc.delete_button,"Confirm Delete")
        self.logger.info(f"Risk Profile Deleted : {data['Risk Profile Name']}")
         
    def click_proceed_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.proceed_button, "Proceed button")

    def assert_bankriskprofile_success_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message")

    def search_risk_profile_by_name(self, bank: str, risk_profile_name: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_field, risk_profile_name, "Search field")
        # Assuming search happens on enter or button click; if needed, add search button click here

    def select_risk_profile_row(self, bank: str, risk_profile_name: str) -> str:
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.risk_profile_row_template.format(risk_profile_name=risk_profile_name)
        self.click_by_locator(self.locator(row_locator), f"Risk profile row for {risk_profile_name}")
        return row_locator

    def click_view_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.view_button_in_row, "View button in row")
        
    def click_edit_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button_in_row, "Edit button in row")

    def click_change_status_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.check_by_locator(loc.row_checkbox, "Row checkbox")
        self.click_by_locator(loc.change_status_button, "Change Status button")

    def click_change_status_confirm_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.change_status_confirm_button, "Change Status confirm button")

    def assert_status_changed_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.status_changed_message), expected_message, "Status changed message")