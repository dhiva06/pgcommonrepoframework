import logging
import random
from src.banks.ecentric.locators.binmanagement_locators import BinmanagementLocators, BinmanagementLocatorsNegative
from src.common.base.base_page import BasePage
from src.common.utilities.dropdown_helper import select_mat_option

logger = logging.getLogger(__name__)


class BinmanagementPage(BasePage):
    def __init__(self, page, module_name="Binmanagement"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_bin_standard, BinmanagementLocators),
        }

    # -------------------- Navigation --------------------

    def navigate_to_bin_management(self, bank: str) -> None:
        """Navigate to BIN Management menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_bin_management, "BIN Management submenu")
        
    

    def navigate_to_bin_management_approval(self, bank: str) -> None:
        """Navigate to BIN Management Approval menu."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_bin_management_approval, "BIN Management Approval submenu")

    # -------------------- ADD ACTION --------------------

    def click_add_button(self, bank: str) -> None:
        """Click the Add button on BIN management listing page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_bin_form(self, bank: str, data: dict) -> None:
        """Fill BIN form with data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_bin_standard(self, loc, data: dict) -> None:
        """Fill the BIN form fields."""
        # Generate random BIN if not provided
        if "BIN" in data and data["BIN"].startswith("{{RANDOM"):
            bin_value = str(random.randint(100000, 999999))
            data["BIN"] = bin_value
        else:
            bin_value = data.get("BIN", str(random.randint(100000, 999999)))

        # Generate random BIN low range if not provided
        if "BIN low range" in data and data["BIN low range"].startswith("{{LOW"):
            bin_low = bin_value.ljust(19, '0')
            data["BIN low range"] = bin_low
        else:
            bin_low = data.get("BIN low range", bin_value.ljust(19, '0'))

        # Generate random BIN high range if not provided
        if "BIN high range" in data and data["BIN high range"].startswith("{{HIGH"):
            bin_high = bin_value.ljust(19, '9')
            data["BIN high range"] = bin_high
        else:
            bin_high = data.get("BIN high range", bin_value.ljust(19, '9'))

        self.fill_by_locator(loc.bin_input, bin_value, "BIN")
        self.fill_by_locator(loc.bin_low_range_input, bin_low, "BIN low range")
        self.fill_by_locator(loc.bin_high_range_input, bin_high, "BIN high range")
        
        # Select dropdowns
        self._select_interchange_code(loc, data.get("Interchange code", "Visa"))
        self._select_card_type(loc, data.get("Card type", "Credit card"))
        self._select_card_product(loc, data.get("Card product", "Visa Classic"))
        self._select_country(loc, data.get("Country", "South Africa"))
        self._select_acquiring_type(loc, data.get("Acquiring type", "ONUS"))
        self._select_message_type(loc, data.get("Message type", "Dual Message system"))
        
        # Select BIN status radio button
        self.click_by_locator(loc.bin_status_radio.format(value="ACTIVE"), "BIN Status - Active")

    def _select_interchange_code(self, loc, value: str) -> None:
        """Select Interchange code from dropdown."""
        select_mat_option(self.page, loc.interchange_code_dropdown, value, 'Interchange code')

    def _select_card_type(self, loc, value: str) -> None:
        """Select Card type from dropdown."""
        select_mat_option(self.page, loc.card_type_dropdown, value, 'Card type')

    def _select_card_product(self, loc, value: str) -> None:
        """Select Card product from dropdown."""
        select_mat_option(self.page, loc.card_product_dropdown, value, 'Card product')

    def _select_country(self, loc, value: str) -> None:
        """Select Country from dropdown."""
        select_mat_option(self.page, loc.country_dropdown, value, 'Country')

    def _select_acquiring_type(self, loc, value: str) -> None:
        """Select Acquiring type from dropdown."""
        select_mat_option(self.page, loc.acquiring_type_dropdown, value, 'Acquiring type')

    def _select_message_type(self, loc, value: str) -> None:
        """Select Message type from dropdown."""
        select_mat_option(self.page, loc.message_type_dropdown, value, 'Message type')

    def click_send_for_approval_button(self, bank: str) -> None:
        """Click Send for approval button."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.send_for_approval_button, "Send for approval button")

    def assert_bin_in_listing(self, bank: str, bin_value: str) -> None:
        """Assert BIN appears in listing with Request type 'New' and status 'Approval pending'."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.bin_row_by_value.format(value=bin_value)
        self.assert_visible(self.locator(row_locator), f"BIN {bin_value} in listing")

    # -------------------- VIEW ACTION --------------------

    def search_for_bin(self, bank: str, bin_value: str) -> None:
        """Search for a BIN in the listing."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_bin_input, bin_value, "Search BIN field")
        self.click_by_locator(loc.search_button, "Search button")

    def click_bin_in_results(self, bank: str, bin_value: str) -> None:
        """Click a BIN record in search results."""
        _, loc = self._dispatch[bank.lower()]
        row_locator = loc.bin_row_by_value.format(value=bin_value)
        self.click_by_locator(self.locator(row_locator), f"BIN {bin_value} in results")
        expand_locator = loc.expand_icon.format(value=bin_value)
        print(f"Final locator = {expand_locator}")
        self.click_by_locator(expand_locator, "Expand icon")

    def assert_view_bin_details(self, bank: str, data: dict) -> None:
        """Assert BIN details page displays correct values."""
        _, loc = self._dispatch[bank.lower()]
        # Verify BIN number
        self.assert_visible(self.locator(loc.bin_number_display), "BIN number display")
        # Additional field assertions would go here as per scenario requirements

    # -------------------- EDIT ACTION --------------------

    def click_edit_button(self, bank: str) -> None:
        """Click the Edit button on BIN Details Summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button, "Edit button")

    def edit_bin_form(self, bank: str, data: dict) -> None:
        """Edit BIN form fields (Card type and Country)."""
        _, loc = self._dispatch[bank.lower()]
        # Change Card type
        select_mat_option(self.page, loc.card_type_dropdown, data.get("Card type", "Debit card"), 'Card type')
        
        # Change Country
        select_mat_option(self.page, loc.country_dropdown, data.get("Country", "Nigeria"), 'Country')

    def assert_edit_in_request_history(self, bank: str) -> None:
        """Assert Request history shows new row with Request type 'Edit' and status 'Approval pending'."""
        _, loc = self._dispatch[bank.lower()]
        # This assertion would verify the request history table

    # -------------------- DELETE ACTION --------------------

    def click_delete_button(self, bank: str) -> None:
        """Click the Delete button on BIN Details Summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_button, "Delete button")

    def confirm_delete(self, bank: str) -> None:
        """Click Delete in confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.confirm_delete_button, "Confirm Delete button")

    def assert_delete_success(self, bank: str, bin_value: str) -> None:
        """Assert page redirects or success message displayed after delete."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.message_container), "Delete success message")

    # -------------------- APPROVAL ACTION --------------------

    def search_bin_in_approval(self, bank: str, bin_value: str) -> None:
        """Search for BIN in Approval listing."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_bin_input, bin_value, "Search BIN field")
        self.click_by_locator(loc.search_button, "Search button")

    def expand_request_details(self, bank: str) -> None:
        """Click expand icon to open BIN details summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.expand_icon, "Expand icon")

    def click_approve_button(self, bank: str) -> None:
        """Click Approve button on request details page."""
        _, loc = self._dispatch[bank.lower()]
        
        try:
            approve_btn = self.page.locator(loc.approve_button).first
            approve_btn.first.wait_for(state="attached", timeout=30000)
            approve_btn.first.scroll_into_view_if_needed()
            approve_btn.first.wait_for(state="visible", timeout=30000)
            logger.info(f"Approve button count: {approve_btn.count()}")
            logger.info(f"Visible: {approve_btn.first.is_visible()}")
            logger.info(f"Enabled: {approve_btn.first.is_enabled()}")
            approve_btn.first.click(timeout=10000)
            logger.info("Successfully clicked Approve button")
        except Exception as e:
            self.page.screenshot(path="approve_button_failure.png")
            logger.error(f"Failed to click Approve button: {e}")
            raise
        
       
   
    def confirm_approval(self, bank: str) -> None:
        """Click Approve button in confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.confirm_approve_button, "Confirm Approve button")

    def assert_bin_approved(self, bank: str) -> None:
        """Assert BIN Request status changes to 'Approved'."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.request_status_display), "Request status display")
        
    def click_expand_icons(self, bank: str, bin_value: str) -> None:
                """Click the Expand icon on BIN Details Summary page."""
    
                _, loc = self._dispatch[bank.lower()]
                self.click_by_locator(loc.expand_icon.format(value=bin_value), "Expand icon")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
class BinmanagementPageNegative(BinmanagementPage):
    """Extends BinmanagementPage with negative test methods."""

    def __init__(self, page, module_name="Binmanagement"):
        super().__init__(page, module_name=module_name)
        # Override dispatch to use negative locators
        self._dispatch_negative = {
            "ecentric": (self._add_bin_negative, BinmanagementLocatorsNegative),
        }

    # -------------------- NEGATIVE: ADD BIN --------------------

    def add_bin_negative(self, bank: str, data: dict) -> None:
        """Add BIN with negative values and assert validation error."""
        _, loc = self._dispatch_negative[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")
        self._add_bin_negative(loc, data)
        self.click_by_locator(loc.send_for_approval_button, "Send for approval button")
        self._assert_negative_message(loc, data)

    def _add_bin_negative(self, loc, data: dict) -> None:
        """Fill BIN form with baseline values, but override the field under test with the negative value."""
        
        # Generate a valid baseline BIN if needed
        baseline_bin = str(random.randint(100000, 999999))
        baseline_bin_low = baseline_bin.ljust(19, '0')
        baseline_bin_high = baseline_bin.ljust(19, '9')
        
        # Determine which field is under test and fill all others with valid baseline values
        bin_value = data.get("BIN", baseline_bin)
        bin_low_value = data.get("BIN low range", baseline_bin_low)
        bin_high_value = data.get("BIN high range", baseline_bin_high)
        
        # Fill BIN field (or leave blank if that's the test)
        if bin_value and bin_value.strip():
            self.fill_by_locator(loc.bin_input, bin_value, "BIN")
        # else: leave blank (no fill call)
        
        # Fill BIN low range field (or leave blank if that's the test)
        if bin_low_value and bin_low_value.strip():
            self.fill_by_locator(loc.bin_low_range_input, bin_low_value, "BIN low range")
        # else: leave blank (no fill call)
        
        # Fill BIN high range field (or leave blank if that's the test)
        if bin_high_value and bin_high_value.strip():
            self.fill_by_locator(loc.bin_high_range_input, bin_high_value, "BIN high range")
        # else: leave blank (no fill call)
        
        # Fill dropdown fields with baseline or test values
        interchange_code = data.get("Interchange code", "Visa")
        if interchange_code and interchange_code.strip() and not any(c in interchange_code for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.interchange_code_dropdown, interchange_code, 'Interchange code')
        
        card_type = data.get("Card type", "Credit card")
        if card_type and card_type.strip() and not any(c in card_type for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.card_type_dropdown, card_type, 'Card type')
        
        card_product = data.get("Card product", "Visa Classic")
        if card_product and card_product.strip() and not any(c in card_product for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.card_product_dropdown, card_product, 'Card product')
        
        country = data.get("Country", "South Africa")
        if country and country.strip() and not any(c in country for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.country_dropdown, country, 'Country')
        
        acquiring_type = data.get("Acquiring type", "ONUS")
        if acquiring_type and acquiring_type.strip() and not any(c in acquiring_type for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.acquiring_type_dropdown, acquiring_type, 'Acquiring type')
        
        message_type = data.get("Message type", "Dual Message system")
        if message_type and message_type.strip() and not any(c in message_type for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.message_type_dropdown, message_type, 'Message type')
        
        # Select BIN status (only if not testing the status field with invalid values)
        bin_status = data.get("BIN status", "Active")
        if bin_status and bin_status.strip() and bin_status == "Active":
            self.click_by_locator(loc.bin_status_radio, "BIN Status - Active")

    def _assert_negative_message(self, loc, data: dict) -> None:
        """Assert the expected error message appears on the form."""
        expected_msg = data.get("ExpectedMessage", "")
        
        if expected_msg and expected_msg != "TBD-verify-message":
            # Try to find the error message in mat-error elements first
            if self.page.locator(loc.any_field_error).count() > 0:
                self.assert_visible(
                    self.locator(loc.error_message_by_text.format(value=expected_msg)),
                    f"Expected error message: {expected_msg}"
                )
            else:
                # Fall back to generic message search if no field errors
                self.assert_visible(
                    self.locator(loc.message_by_text.format(value=expected_msg)),
                    f"Expected error message: {expected_msg}"
                )

    # -------------------- NEGATIVE: EDIT BIN --------------------

    def edit_bin_negative(self, bank: str, data: dict) -> None:
        """Edit BIN with negative values and assert validation error."""
        _, loc = self._dispatch_negative[bank.lower()]
        
        # Search for and open the BIN record
        bin_value = data.get("BIN", "")
        self.search_for_bin(bank, bin_value)
        self.click_bin_in_results(bank, bin_value)
        self.click_edit_button(bank)
        
        # Fill the form with baseline values except the field under test
        self._edit_bin_negative_form(loc, data)
        
        # Click Send for approval
        self.click_by_locator(loc.send_for_approval_button, "Send for approval button")
        
        # Assert the expected error message
        self._assert_negative_message(loc, data)

    def _edit_bin_negative_form(self, loc, data: dict) -> None:
        """Fill edit form with baseline values, override the field under test with the negative value."""
        
        # For Edit, only Card type and Country can be changed
        card_type = data.get("Card type", "Debit card")
        if card_type and card_type.strip() and not any(c in card_type for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.card_type_dropdown, card_type, 'Card type')
        
        country = data.get("Country", "Nigeria")
        if country and country.strip() and not any(c in country for c in '@#$%^&*<>'):
            select_mat_option(self.page, loc.country_dropdown, country, 'Country')
            
    

