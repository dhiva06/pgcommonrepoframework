from src.banks.ecentric.locators.useraccountsecurity_locators import UseraccountsecurityLocators as EcentricUseraccountsecurityLocators
from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.useraccountsecurity_locators import UseraccountsecurityLocatorsNegative as EcentricUseraccountsecurityLocatorsNegative


class UseraccountsecurityPage(BasePage):
    def __init__(self, page, module_name="Useraccountsecurity"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._add_standard, EcentricUseraccountsecurityLocators),
        }

    # -------------------- Navigation --------------------

    def navigate_to_useraccountsecurity(self, bank: str) -> None:
        """Navigate to User account security listing page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_user_administration, "User administration submenu")
        self.click_by_locator(loc.menu_user_account_security, "User account security submenu")

    # -------------------- Add Action --------------------

    def click_add_button(self, bank: str) -> None:
        """Click the Add button to create a new user account security policy."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_useraccountsecurity_form(self, bank: str, data: dict) -> None:
        """Fill the user account security form with provided data."""
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)

    def _add_standard(self, loc, data: dict) -> None:
        """Fill all fields for Add or Edit user account security policy."""
        # Policy name
        self.fill_by_locator(loc.policy_name_input, data["Policy Name"], "Policy Name")
        
        # Primary configuration
        self.fill_by_locator(loc.idle_session_timeout_input, data["Idle Session Timeout"], "Idle Session Timeout")
        self.fill_by_locator(loc.login_attempts_input, data["Login Attempts"], "Login Attempts")
        self.fill_by_locator(loc.user_inactive_period_input, data["User Inactive Period"], "User Inactive Period")
        
        # Password policy - Password configuration
        self.fill_by_locator(loc.password_min_length_input, data["Password Minimum Length"], "Password Minimum Length")
        self.fill_by_locator(loc.password_max_length_input, data["Password Maximum Length"], "Password Maximum Length")
        
        # Character restrictions
        self.fill_by_locator(loc.min_capital_letter_input, data["Minimum Capital Letter"], "Minimum Capital Letter")
        self.fill_by_locator(loc.min_digit_input, data["Minimum Digit"], "Minimum Digit")
        self.fill_by_locator(loc.min_special_char_input, data["Minimum Special Character"], "Minimum Special Character")
        
        # Disallowed commonly used passwords - add first entry
        self.fill_by_locator(loc.disallowed_password_input, data["Disallowed Password 1"], "Disallowed Password 1")
        
        # Other restrictions
        if data["Reused Passwords Allowed"].upper() == "NO":
            self.click_by_locator(loc.reused_password_radio_no, "Previously reused passwords - No")
        else:
            self.click_by_locator(loc.reused_password_radio_yes, "Previously reused passwords - Yes")
        
        self.fill_by_locator(loc.frequency_input, data["Frequency"], "Frequency")
        
        if data["Force Change Password"].upper() == "YES":
            self.click_by_locator(loc.force_change_password_radio_yes, "Force change password - Yes")
        else:
            self.click_by_locator(loc.force_change_password_radio_no, "Force change password - No")
        
        self.fill_by_locator(loc.change_password_period_input, data["Change Password Period"], "Change Password Period")

    def click_save_button(self, bank: str) -> None:
        """Click the Save button to save the policy."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_add_success_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message after adding a policy."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.message_container), expected_message, "Success message")

    # -------------------- Search/Find Row Helper --------------------

    def _find_row_by_policy_id(self, bank: str, policy_id: str) -> str:
        """Build the row locator for a policy by its ID."""
        _, loc = self._dispatch[bank.lower()]
        return loc.row_by_policy_id.format(policy_id=policy_id)

    # -------------------- View Action --------------------

    def search_and_verify_policy(self, bank: str, data: dict) -> None:
        """Search for a policy and verify it appears in the listing."""
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.search_policy_input, data["Search Policy Name"], "Search Policy Name")
        self.click_by_locator(loc.search_button, "Search button")

    def click_policy_id_link(self, bank: str, policy_id: str) -> None:
        """Click the Policy ID link to open the policy summary page."""
        _, loc = self._dispatch[bank.lower()]
        link_locator = loc.policy_id_link.format(policy_id=policy_id)
        self.click_by_locator(link_locator, "Policy ID link")

    def assert_summary_page_visible(self, bank: str) -> None:
        """Assert the policy summary page is displayed."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.summary_page_header), "Policy summary page header")

    def assert_view_policy_details(self, bank: str, data: dict) -> None:
        """Assert the viewed policy details match expected values."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.view_policy_id), data["Expected Policy ID"], "Policy ID")
        self.assert_text(self.locator(loc.view_policy_name), data["Expected Policy Name"], "Policy Name")
        self.assert_text(self.locator(loc.view_product), data["Expected Product"], "Product")
        self.assert_text(self.locator(loc.view_portal), data["Expected Portal"], "Portal")

    def assert_view_primary_config(self, bank: str, data: dict) -> None:
        """Assert primary configuration values in view mode."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.view_idle_timeout), data["Expected Idle Timeout"], "Idle Session Timeout")
        self.assert_text(self.locator(loc.view_login_attempts), data["Expected Login Attempts"], "Login Attempts")
        self.assert_text(self.locator(loc.view_user_inactive), data["Expected User Inactive"], "User Inactive Period")

    def assert_view_password_policy(self, bank: str, data: dict) -> None:
        """Assert password policy configuration in view mode."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.view_password_min_length), data["Expected Min Length"], "Password Minimum Length")
        self.assert_text(self.locator(loc.view_password_max_length), data["Expected Max Length"], "Password Maximum Length")
        self.assert_text(self.locator(loc.view_min_capital_letters), data["Expected Min Capital"], "Minimum Capital Letters")
        self.assert_text(self.locator(loc.view_min_digits), data["Expected Min Digits"], "Minimum Digits")
        self.assert_text(self.locator(loc.view_min_special_chars), data["Expected Min Special"], "Minimum Special Characters")
        self.assert_text(self.locator(loc.view_disallowed_passwords), data["Expected Disallowed"], "Disallowed Passwords")
        self.assert_text(self.locator(loc.view_reused_passwords), data["Expected Reused"], "Previously Reused Passwords")
        self.assert_text(self.locator(loc.view_frequency), data["Expected Frequency"], "Frequency")
        self.assert_text(self.locator(loc.view_force_change), data["Expected Force Change"], "Force Change Password")
        self.assert_text(self.locator(loc.view_change_period), data["Expected Change Period"], "Change Password Period")

    # -------------------- Edit Action --------------------

    def click_edit_button(self, bank: str) -> None:
        """Click the Edit button on the policy summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.edit_button_in_summary, "Edit button")

    def assert_edit_form_prefilled(self, bank: str, data: dict) -> None:
        """Assert the Edit form is displayed with previously saved values."""
        _, loc = self._dispatch[bank.lower()]
        # Verify form fields are prefilled by checking a sample field value
        self.assert_visible(self.locator(loc.update_button), "Update button visible")

    def click_update_button(self, bank: str) -> None:
        """Click the Update button to save edited policy."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.update_button, "Update button")

    def assert_edit_success_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message after editing a policy."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.message_container), expected_message, "Success message")

    def assert_updated_policy_details(self, bank: str, data: dict) -> None:
        """Assert the updated policy details match expected values after edit."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.view_idle_timeout), data["Expected Updated Idle Timeout"], "Idle Session Timeout")
        self.assert_text(self.locator(loc.view_login_attempts), data["Expected Updated Login Attempts"], "Login Attempts")
        self.assert_text(self.locator(loc.view_user_inactive), data["Expected Updated User Inactive"], "User Inactive Period")
        self.assert_text(self.locator(loc.view_password_min_length), data["Expected Updated Min Length"], "Password Minimum Length")
        self.assert_text(self.locator(loc.view_password_max_length), data["Expected Updated Max Length"], "Password Maximum Length")

    # -------------------- Delete Action --------------------

    def click_delete_button(self, bank: str) -> None:
        """Click the Delete button on the policy summary page."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_button_in_summary, "Delete button")

    def assert_delete_confirmation_dialog(self, bank: str, expected_message: str) -> None:
        """Assert the delete confirmation dialog is displayed with correct message."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_visible(self.locator(loc.delete_confirm_dialog), "Delete confirmation dialog")
        self.assert_text(self.locator(loc.delete_confirm_message), expected_message, "Delete confirmation message")

    def confirm_delete(self, bank: str) -> None:
        """Click the Delete button in the confirmation dialog."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.delete_confirm_button, "Delete confirmation button")

    def assert_delete_success_message(self, bank: str, expected_message: str) -> None:
        """Assert the success message after deleting a policy."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.message_container), expected_message, "Success message")

    def assert_no_records_found(self, bank: str) -> None:
        """Assert the listing shows no records after deletion."""
        _, loc = self._dispatch[bank.lower()]
        # Check for "no records" message or empty list
        self.assert_visible(self.locator("//div[contains(text(),'No records found')]"), "No records message")

    def add_useraccountsecurity_negative(self, bank: str, data: dict) -> None:
        """
        Add a user account security policy with one invalid field value and assert error message.
        Fills all fields with valid baseline values except the one under test (bad value from data).
        """
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")
        self._fill_form_with_one_invalid_field(bank, loc, data)
        self.click_by_locator(loc.save_button, "Save button")
        self._assert_field_error_message(bank, loc, data)

    def _fill_form_with_one_invalid_field(self, bank: str, loc, data: dict) -> None:
        """
        Fill the form by changing exactly ONE field from baseline to the bad value.
        All other fields use their positive baseline values.
        """
        # Use baseline values for all fields, then override the one under test
        baseline = {
            "Policy Name": "{{RANDOM:8:alpha}}",
            "Idle Session Timeout": "6",
            "Login Attempts": "3",
            "User Inactive Period": "8",
            "Password Minimum Length": "10",
            "Password Maximum Length": "14",
            "Minimum Capital Letter": "9",
            "Minimum Digit": "7",
            "Minimum Special Character": "9",
            "Disallowed Password 1": "Manisk@1233",
            "Reused Passwords Allowed": "No",
            "Frequency": "6",
            "Force Change Password": "Yes",
            "Change Password Period": "24",
        }

        # Determine which field is being tested and use the bad value from data
        test_field_map = {
            "Policy Name": "policy_name_input",
            "Idle Session Timeout": "idle_session_timeout_input",
            "Login Attempts": "login_attempts_input",
            "User Inactive Period": "user_inactive_period_input",
            "Password Minimum Length": "password_min_length_input",
            "Password Maximum Length": "password_max_length_input",
            "Minimum Capital Letter": "min_capital_letter_input",
            "Minimum Digit": "min_digit_input",
            "Minimum Special Character": "min_special_char_input",
            "Disallowed Password 1": "disallowed_password_input",
            "Reused Passwords Allowed": "reused_password_radio_no",
            "Frequency": "frequency_input",
            "Force Change Password": "force_change_password_radio_yes",
            "Change Password Period": "change_password_period_input",
        }

        # Fill Policy Name
        policy_name_value = data.get("Policy Name", baseline["Policy Name"])
        self.fill_by_locator(loc.policy_name_input, policy_name_value, "Policy Name")

        # Fill Primary configuration
        idle_timeout_value = data.get("Idle Session Timeout", baseline["Idle Session Timeout"])
        self.fill_by_locator(loc.idle_session_timeout_input, idle_timeout_value, "Idle Session Timeout")

        login_attempts_value = data.get("Login Attempts", baseline["Login Attempts"])
        self.fill_by_locator(loc.login_attempts_input, login_attempts_value, "Login Attempts")

        user_inactive_value = data.get("User Inactive Period", baseline["User Inactive Period"])
        self.fill_by_locator(loc.user_inactive_period_input, user_inactive_value, "User Inactive Period")

        # Fill Password policy - Password configuration
        pwd_min_value = data.get("Password Minimum Length", baseline["Password Minimum Length"])
        self.fill_by_locator(loc.password_min_length_input, pwd_min_value, "Password Minimum Length")

        pwd_max_value = data.get("Password Maximum Length", baseline["Password Maximum Length"])
        self.fill_by_locator(loc.password_max_length_input, pwd_max_value, "Password Maximum Length")

        # Character restrictions
        min_capital_value = data.get("Minimum Capital Letter", baseline["Minimum Capital Letter"])
        self.fill_by_locator(loc.min_capital_letter_input, min_capital_value, "Minimum Capital Letter")

        min_digit_value = data.get("Minimum Digit", baseline["Minimum Digit"])
        self.fill_by_locator(loc.min_digit_input, min_digit_value, "Minimum Digit")

        min_special_value = data.get("Minimum Special Character", baseline["Minimum Special Character"])
        self.fill_by_locator(loc.min_special_char_input, min_special_value, "Minimum Special Character")

        # Disallowed commonly used passwords
        disallowed_pwd_value = data.get("Disallowed Password 1", baseline["Disallowed Password 1"])
        self.fill_by_locator(loc.disallowed_password_input, disallowed_pwd_value, "Disallowed Password 1")

        # Other restrictions
        reused_pwd_value = data.get("Reused Passwords Allowed", baseline["Reused Passwords Allowed"]).upper()
        if reused_pwd_value == "NO":
            self.click_by_locator(loc.reused_password_radio_no, "Previously reused passwords - No")
        else:
            self.click_by_locator(loc.reused_password_radio_yes, "Previously reused passwords - Yes")

        frequency_value = data.get("Frequency", baseline["Frequency"])
        self.fill_by_locator(loc.frequency_input, frequency_value, "Frequency")

        force_change_value = data.get("Force Change Password", baseline["Force Change Password"]).upper()
        if force_change_value == "YES":
            self.click_by_locator(loc.force_change_password_radio_yes, "Force change password - Yes")
        else:
            self.click_by_locator(loc.force_change_password_radio_no, "Force change password - No")

        change_period_value = data.get("Change Password Period", baseline["Change Password Period"])
        self.fill_by_locator(loc.change_password_period_input, change_period_value, "Change Password Period")

    def _assert_field_error_message(self, bank: str, loc, data: dict) -> None:
        """Assert the expected error message is displayed for the invalid field."""
        expected_message = data.get("ExpectedMessage", "")
        if not expected_message or expected_message == "TBD-verify-message":
            return

        # Try to find the error message in field-level errors first, then generic mat-error
        error_locator = loc.error_message_by_text.format(value=expected_message)
        self.assert_visible(
            self.locator(error_locator),
            f"Error message: {expected_message}",
        )

    def edit_useraccountsecurity_negative(self, bank: str, data: dict) -> None:
        """
        Search for a policy, click edit, fill form with one invalid field, and assert error.
        """
        _, loc = self._dispatch[bank.lower()]

        # Search for the policy
        search_name = data.get("Search Policy Name", "")
        if search_name and search_name.strip():
            self.fill_by_locator(loc.search_policy_input, search_name, "Search Policy Name")
            self.click_by_locator(loc.search_button, "Search button")

        # Click edit button
        self.click_by_locator(loc.edit_button_in_summary, "Edit button")

        # Fill form with one bad value
        self._fill_form_with_one_invalid_field_edit(bank, loc, data)

        # Click update button
        self.click_by_locator(loc.update_button, "Update button")

        # Assert error message
        self._assert_field_error_message(bank, loc, data)

    def _fill_form_with_one_invalid_field_edit(self, bank: str, loc, data: dict) -> None:
        """
        Fill the edit form by changing exactly ONE field from its current value to the bad value.
        All other fields use their positive baseline values.
        """
        baseline = {
            "Idle Session Timeout": "10",
            "Login Attempts": "4",
            "User Inactive Period": "10",
            "Password Minimum Length": "8",
            "Password Maximum Length": "20",
            "Minimum Capital Letter": "2",
            "Minimum Digit": "2",
            "Minimum Special Character": "2",
            "Disallowed Password 1": "Test@1234",
            "Reused Passwords Allowed": "Yes",
            "Frequency": "6",
            "Force Change Password": "No",
            "Change Password Period": "24",
        }

        # Fill Primary configuration
        idle_timeout_value = data.get("Idle Session Timeout", baseline["Idle Session Timeout"])
        self.fill_by_locator(loc.idle_session_timeout_input, idle_timeout_value, "Idle Session Timeout")

        login_attempts_value = data.get("Login Attempts", baseline["Login Attempts"])
        self.fill_by_locator(loc.login_attempts_input, login_attempts_value, "Login Attempts")

        user_inactive_value = data.get("User Inactive Period", baseline["User Inactive Period"])
        self.fill_by_locator(loc.user_inactive_period_input, user_inactive_value, "User Inactive Period")

        # Fill Password policy - Password configuration
        pwd_min_value = data.get("Password Minimum Length", baseline["Password Minimum Length"])
        self.fill_by_locator(loc.password_min_length_input, pwd_min_value, "Password Minimum Length")

        pwd_max_value = data.get("Password Maximum Length", baseline["Password Maximum Length"])
        self.fill_by_locator(loc.password_max_length_input, pwd_max_value, "Password Maximum Length")

        # Character restrictions
        min_capital_value = data.get("Minimum Capital Letter", baseline["Minimum Capital Letter"])
        self.fill_by_locator(loc.min_capital_letter_input, min_capital_value, "Minimum Capital Letter")

        min_digit_value = data.get("Minimum Digit", baseline["Minimum Digit"])
        self.fill_by_locator(loc.min_digit_input, min_digit_value, "Minimum Digit")

        min_special_value = data.get("Minimum Special Character", baseline["Minimum Special Character"])
        self.fill_by_locator(loc.min_special_char_input, min_special_value, "Minimum Special Character")

        # Disallowed commonly used passwords
        disallowed_pwd_value = data.get("Disallowed Password 1", baseline["Disallowed Password 1"])
        self.fill_by_locator(loc.disallowed_password_input, disallowed_pwd_value, "Disallowed Password 1")

        # Other restrictions
        reused_pwd_value = data.get("Reused Passwords Allowed", baseline["Reused Passwords Allowed"]).upper()
        if reused_pwd_value == "NO":
            self.click_by_locator(loc.reused_password_radio_no, "Previously reused passwords - No")
        else:
            self.click_by_locator(loc.reused_password_radio_yes, "Previously reused passwords - Yes")

        frequency_value = data.get("Frequency", baseline["Frequency"])
        self.fill_by_locator(loc.frequency_input, frequency_value, "Frequency")

        force_change_value = data.get("Force Change Password", baseline["Force Change Password"]).upper()
        if force_change_value == "YES":
            self.click_by_locator(loc.force_change_password_radio_yes, "Force change password - Yes")
        else:
            self.click_by_locator(loc.force_change_password_radio_no, "Force change password - No")

        change_period_value = data.get("Change Password Period", baseline["Change Password Period"])
        self.fill_by_locator(loc.change_password_period_input, change_period_value, "Change Password Period")


# ==================================================================
# NEGATIVE PAGE
# ==================================================================
class UseraccountsecurityPageNegative(UseraccountsecurityPage):
    """Negative test page for User Account Security policies."""

    def __init__(self, page, module_name="Useraccountsecurity"):
        super().__init__(page, module_name=module_name)
        # Update dispatch to use negative locators
        self._dispatch["ecentric"] = (self._add_standard, EcentricUseraccountsecurityLocatorsNegative)

    # -------------------- Add Negative Tests --------------------

    # -------------------- Edit Negative Tests --------------------
