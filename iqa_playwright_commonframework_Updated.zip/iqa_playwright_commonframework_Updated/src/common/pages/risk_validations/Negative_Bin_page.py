from tkinter import dialog

from reference.sample_test import BANK_NAME
from src.banks.oab.locators.Negative_Bin_locators import OabNegativeBinLocators
from src.common.base.base_page import BasePage


class NegativeBinPage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="RiskValidations")
        
        self._dispatch = {
                    "oab": (self.add_negative_bin, OabNegativeBinLocators),
                }
        self.loc = OabNegativeBinLocators
    

    def _flow(self, key: str):
        entry = self._bank_config().get(self.bank)
        if entry is None or key not in entry:
            raise NotImplementedError(
                f"RiskValidationsPage has no '{key}' steps implemented yet for bank '{self.bank}'"
            )
        return entry[key]

        
    # -------------------- Navigation --------------------
    def navigate_to_negative_Bin(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.risk_congiguration, f"{bank} risk Configuration menu")
        self.click_by_locator(loc.negative_bin, f"{bank} click negative bin menu")
        self.assert_visible(self.locator(loc.page_marker), f"{bank} Negative Bin page")
       

    # ------------------------------------------------------------------ #
    #  ADD BUTTON
    # ------------------------------------------------------------------ #
    def add_card(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.negative_Bin_add_button, "Add button")
  # ------------------------------------------------------------------ #
    #  FILL NEGATIVE BIN FIELDS DETAILS
    # ------------------------------------------------------------------ #
    
    def _fill_negative_bin_fields(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.negative_Bin_field, data["BinNumber"], "Negative Bin Number")
        self.fill_by_locator(loc.negative_Bin_reason_field, data["Reason"], "Negative Bin Reason")
        
      # ------------------------------------------------------------------ #
    #  MAIN METHOD
    # ------------------------------------------------------------------ #
    
    def add_negative_bin(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.add_card(bank)
        self._fill_negative_bin_fields(data, loc)
        
    def add_Mutiple_bin(self, loc, data) -> None:
        # _, loc = self._dispatch[bank.lower()]
        self.add_card(loc)
        self.add_multiple_bin(BANK_NAME)
        self._fill_multiple_bin_fields(loc,data)
        self.click_minus_button(loc)

  # ------------------------------------------------------------------ #
    #  SAVE METHOD
    # ------------------------------------------------------------------ #
    
        
    def click_save_button(self, bank: str) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.click_by_locator(loc.negative_Bin_save_button, "Negative IP Save Button")
                self.accept_dialog("Are you sure to change the status?")
                self.page.wait_for_timeout(1000)
                         
    def click_NegSave_button(self, bank: str,data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.click_by_locator(loc.negative_Bin_save_button, "Negative IP Save Button")
                self.accept_dialog() 
                print(data.keys())
                expected_message = data.get("ExpectedMessage")
                if expected_message:
                    self.assert_text(self.page.locator(f"{loc.validation_message}[normalize-space()='{expected_message}']"),expected_message,"Negative Validation")
                else:
                    raise Exception(f"ExpectedMessage column missing in test data: {data}")
                
                
    def AddAssert_message(self, bank: str, expected_message: str) -> None:
        """Assert the response/validation message text."""
        _, loc = self._dispatch[bank.lower()]
        self.assert_contains_text(self.locator(loc.message_container), expected_message, "Currency response message")
            
                
                
                
# ===============mutiple add==================================

    def add_multiple_bin(self,bank: str, times=3):
            _, loc = self._dispatch[bank.lower()]
            for i in range(times):
                self.click_by_locator(loc.bin_addRow_button, description=f"Click Add row {i+1}/{times}")
                
                
    def _fill_multiple_bin_fields(self,bank: str,data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.fill_by_locator(loc.negative_Bin_field,data["BinNumber"],"Negative BIN Number")
                self.fill_by_locator(loc.negative_Bin_reason_field,data["Reason"],"Negative Reason")
                self.fill_by_locator(loc.negative_Bin_field1,data["BinNumber1"],"BIN Search Text Feild")       
                self.fill_by_locator(loc.negative_Bin_reason_field1,data["Reason1"],"BIN Reason")        
                self.fill_by_locator(loc.negative_Bin_field2,data["BinNumber2"],"BIN Search Text Feild")
                self.fill_by_locator(loc.negative_Bin_reason_field2,data["Reason2"],"BIN Reason")
                
                
                
# ==================MINUS BUTTON==============================

    def click_minus_button(self, bank: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.minus_button, "Add button")
            
            
# ==================UPLOAD FILE=========================================

    def click_upload_button(self, bank: str,data: dict) -> None:
           _, loc = self._dispatch[bank.lower()]
           self.click_by_locator(loc.upload_button, description="Upload Button")
           self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
           self.click_by_locator(loc.upload_button, "file uploaded")
           
    def UploadAssert_message(self, bank: str, expected_message: str) -> None:
    
        actual_message = self.page.locator("#msgcodediv").text_content().strip()

        assert ("See the log to view the details" in actual_message or "Please Upload Valid Text File" in actual_message), f"Unexpected message: {actual_message}"
                
    
    def view_sample_format(self, bank: str, data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.upload_button, description="Upload Button")
            self.click_by_locator(loc.sample_format_button, description="Sample Format Button")
            self.assert_visible(self.page.locator("//h4[normalize-space()='Negative BIN Sample Format']"),"Negative BIN Sample Format Popup")
            self.click_by_locator(loc.x_click, description="Close Popup")
            
            
            
# =====================SEARCH FUNCTIONALITY=========================================

    def select_Bin(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.Bin_search_textfeild,data["search_text"],"IP Search Text Feild") 
        self.click_by_locator(loc.search_button, "Negative IP Button")
        self.assert_visible(self.page.locator(f"//table[@id='NegativeBin']//td[normalize-space()='{data['search_text']}']"),"BIN Number Present In Grid")
        

# =====================CHANGE STATUS FUNCTIONALITY=========================================


    def select_row_checkbox(self, bank: str, bin_value: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        checkbox_ui = (f"//input[@name='binNumber' and @value='{bin_value}']""/following-sibling::a")
        self.click_by_locator(checkbox_ui,f"Select BIN checkbox {bin_value}")
    
    def click_change_status_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.change_status_button, "Change Status button")
            
    
    def accept_status_change_alert(self, bank: str) -> None:
        """Accept the browser alert for changing status."""
        self.accept_dialog("Are you sure to change the status?")
        self.page.wait_for_timeout(1000)
            
    def ChangeStatusAssert_message(self, bank: str, expected_message: str) -> None:
    
        self.assert_contains_text(self.page.locator("#msgcodediv"),expected_message,"Change Status Message Validation")

            
    
    
            
        