from pyexpat.errors import messages

from reference.sample_test import BANK_NAME
from src.banks.oab.locators.Negative_Card_locators import OabNegativeCardLocators
from src.common.base.base_page import BasePage
from playwright.sync_api import expect


class NegativeCardPage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="RiskValidations")
        
        self._dispatch = {
                    "oab": (self.add_negative_card, OabNegativeCardLocators),
                }
        self.loc = OabNegativeCardLocators

    

    def _flow(self, key: str):
        entry = self._bank_config().get(self.bank)
        if entry is None or key not in entry:
            raise NotImplementedError(
                f"RiskValidationsPage has no '{key}' steps implemented yet for bank '{self.bank}'"
            )
        return entry[key]

        
    # -------------------- Navigation --------------------
    def navigate_to_negative_card(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.risk_congiguration, f"{bank} risk Configuration menu")
        self.click_by_locator(loc.negative_card, f"{bank} click negative card menu")
        self.assert_visible(self.locator(loc.page_marker), f"{bank} Negative Card page")
       

    # ------------------------------------------------------------------ #
    #  ADD BUTTON
    # ------------------------------------------------------------------ #
    def add_card(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.negative_add_button, "Add button")
        
        

    def add_multiple_IP(self,bank: str, times=2):
            _, loc = self._dispatch[bank.lower()]
            for i in range(times):
                self.click_by_locator(loc.IP_addRow_button, description=f"Click Add row {i+1}/{times}")
  # ------------------------------------------------------------------ #
    #  FILL NEGATIVE CARD FIELDS DETAILS
    # ------------------------------------------------------------------ #
    
    def _fill_negative_card_fields(self,bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.negative_card_field, data["CardNumber"], "Negative Card Number")
        self.fill_by_locator(loc.negative_reason_field, data["Reason"], "Negative Reason")
        
    def _fill_multiple_card_fields(self,bank: str,data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.fill_by_locator(loc.negative_card_field,data["CardNumber"],"Negative IP Number")
            self.fill_by_locator(loc.negative_reason_field,data["Reason"],"Negative Reason")
            self.fill_by_locator(loc.negative_card_field1,data["CardNumber1"],"IP Search Text Feild")       
            self.fill_by_locator(loc.negative_reason_field1,data["Reason1"],"IP Reason")        
            self.fill_by_locator(loc.negative_card_field2,data["CardNumber2"],"IP Search Text Feild")
            self.fill_by_locator(loc.negative_reason_field2,data["Reason2"],"IP Reason")  
        
      # ------------------------------------------------------------------ #
    #  MAIN METHOD
    # ------------------------------------------------------------------ #
    
    def add_negative_card(self, loc, data) -> None:
        self.add_card(loc)
        self._fill_negative_card_fields(loc, data)
    
    def add_Mutiple_card(self, loc, data) -> None:
            # _, loc = self._dispatch[bank.lower()]
            self.add_card(loc)
            self.add_multiple_IP(BANK_NAME)
            self._fill_multiple_card_fields(loc,data)
        

  # ------------------------------------------------------------------ #
    #  SAVE METHOD
    # ------------------------------------------------------------------ #
    

        
    def click_Add_save_button(self, bank: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.negative_save_button, "Negative IP Save Button")
        
    def AddAssert_message(self, bank: str, expected_message: str) -> None:
        
            if expected_message == "See the log to view the details":
    
                self.assert_contains_text(
                self.page.locator("#msgcodediv"),
                "See the log to view the details",
                "Upload Success Message"
            )
                    
    def click_NegativeCard_save_button(self, bank: str,data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.click_by_locator(loc.negative_save_button, "Negative IP Save Button")
                self.accept_dialog() 
                print(data.keys())
                expected_message = data.get("ExpectedMessage")
                if expected_message:
                    self.assert_text(self.page.locator(f"{loc.validation_message}[normalize-space()='{expected_message}']"),expected_message,"Negative Validation")
                else:
                    raise Exception(f"ExpectedMessage column missing in test data: {data}")
                
                
                
                
                # ========================upload functionality=========================
                
    def view_sample_format(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.upload_button, description="Upload Button")
        self.click_by_locator(loc.sample_format_button, description="Sample Format Button")
        self.assert_visible(self.page.locator("//h4[text()='Negative Card Sample Format']"),"Negative Card Sample Format Popup")
        self.click_by_locator(loc.x_click, description="Close Popup")
        

    def click_upload_button(self, bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.upload_button, description="Upload Button")
        self.upload_file(loc.file_upload,data["Upload file"], "file uploaded")
        self.click_by_locator(loc.upload_button, "file uploaded")
        
        
    def UploadAssert_message(self, bank: str, expected_message: str) -> None:
    
        if expected_message == "See the log to view the details":

            self.assert_contains_text(
            self.page.locator("#msgcodediv"),
            "See the log to view the details",
            "Upload Success Message"
        )

        elif expected_message == "Please Upload Valid Text File":

            self.assert_contains_text(
            self.page.locator("#msgcodediv"),
            "Please Upload Valid Text File",
            "Invalid File Message"
        )

        else:
            self.assert_contains_text(
            self.page.locator("#msgcodediv"),
            "Browsed File is Empty",
            "Browsed File is Empty"
        )
   
#    =====================SEARCH FUNCTIONALITY=========================

    def select_Card(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.SearchTextFeild,data["search_text"],"Card Search Text Feild") 
        self.click_by_locator(loc.SearchButton, "Negative card Button")
                
        expected_message = data.get("ExpectedMessage")
        if expected_message == "No records found":
            actual_text = self.page.locator(loc.no_records_message).inner_text().strip()
            assert actual_text == expected_message,f"Expected '{expected_message}' but got '{actual_text}'"
                
        else:
        #  self.assert_text(self.page.locator(f"//table[@id='IPBlock']//td[normalize-space()='{data['search_text']}']"),data["search_text"],"Searched IP Address Verification")
            print(f"Searching for card number: {data['search_text']}")
            # self.assert_text(self.page.locator(f"//table[@id='negativecard']//td[normalize-space()='{data['search_text']}']"),data["search_text"],"Searched Card Number Verification")

    
    

        