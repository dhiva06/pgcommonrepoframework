
from os import times

from reference.sample_test import BANK_NAME
from src.banks.oab.locators.Negative_Card_locators import OabNegativeCardLocators
from src.banks.oab.locators.Negative_IP_locators import NegativeIPLocators
from src.common.base.base_page import BasePage



class NegativeIPPage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="RiskValidations")
        
        self._dispatch = {
                    "oab": (self.add_negative_IP, NegativeIPLocators),
                }
        # self.loc = NegativeIPLocators

    

    def _flow(self, key: str):
        entry = self._bank_config().get(self.bank)
        if entry is None or key not in entry:
            raise NotImplementedError(
                f"RiskValidationsPage has no '{key}' steps implemented yet for bank '{self.bank}'"
            )
        return entry[key]

        
    # -------------------- Navigation --------------------
    def navigate_to_negative_IP(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.risk_congiguration, f"{bank} risk Configuration menu")
        self.click_by_locator(loc.negative_IP, f"{bank} click negative IP menu")
        self.assert_visible(self.locator(loc.page_marker), f"{bank} Negative IP page")
       

    # ------------------------------------------------------------------ #
    #  ADD BUTTON
    # ------------------------------------------------------------------ #
    def add_IP(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.negative_IP_add_button, "Add button")
            
    def add_multiple_IP(self,bank: str, times=2):
        _, loc = self._dispatch[bank.lower()]
        for i in range(times):
            self.click_by_locator(loc.IP_addRow_button, description=f"Click Add row {i+1}/{times}")
        
  # ------------------------------------------------------------------ #
    #  FILL NEGATIVE IP FIELDS DETAILS
    # ------------------------------------------------------------------ #
    
    def _fill_negative_ip_fields(self,bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.fill_by_locator(loc.negative_IP_field,data["IPAddress"],"Negative IP Number")
        self.fill_by_locator(loc.negative_IP_reason_field,data["Reason"],"Negative Reason")
        
    def _fill_multiple_ip_fields(self,bank: str,data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.fill_by_locator(loc.negative_IP_field,data["IPAddress"],"Negative IP Number")
            self.fill_by_locator(loc.negative_IP_reason_field,data["Reason"],"Negative Reason")
            self.fill_by_locator(loc.IP_textfeild1,data["IPAddress1"],"IP Search Text Feild")       
            self.fill_by_locator(loc.ip_reasonfeild1,data["Reason1"],"IP Reason")        
            self.fill_by_locator(loc.IP_textfeild2,data["IPAddress2"],"IP Search Text Feild")
            self.fill_by_locator(loc.ip_reasonfeild2,data["Reason2"],"IP Reason")    
    
        
      # ------------------------------------------------------------------ #
    #  MAIN METHOD
    # ------------------------------------------------------------------ #
    
    def add_negative_IP(self, loc, data) -> None:
        # _, loc = self._dispatch[bank.lower()]
        self.add_IP(BANK_NAME)
        self._fill_negative_ip_fields(loc,data)
        
    def add_multiple_negative_IP(self, loc, data) -> None:
            # _, loc = self._dispatch[bank.lower()]
            self.add_IP(BANK_NAME)
            self.add_multiple_IP(BANK_NAME)
            self._fill_multiple_ip_fields(loc,data)
            
    def select_IP(self, bank: str, data: dict) -> None:
                _, loc = self._dispatch[bank.lower()]
                self.select_custom_dropdown(loc.ip_dropdown,data["dropdown_value"])
                self.fill_by_locator(loc.IP_search_textfeild,data["search_text"],"IP Search Text Feild") 
                self.click_by_locator(loc.search_button, "Negative IP Button")
                
                expected_message = data.get("ExpectedMessage")
                if expected_message == "No records found":
                    actual_text = self.page.locator(loc.no_records_message).inner_text().strip()
                    assert actual_text == expected_message,f"Expected '{expected_message}' but got '{actual_text}'"
                
                else:
                    self.assert_text(self.page.locator(f"//table[@id='IPBlock']//td[normalize-space()='{data['search_text']}']"),data["search_text"],"Searched IP Address Verification")

    # ------------------------------------------------------------------ #
    #  SAVE METHOD
    # ------------------------------------------------------------------ #
    
        
    def click_Add_save_button(self, bank: str,data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.negative_IP_save_button, "Negative IP Save Button")
        
    def click_Negative_save_button(self, bank: str,data: dict) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.negative_IP_save_button, "Negative IP Save Button")
            self.accept_dialog() 
            print(data.keys())
            expected_message = data.get("ExpectedMessage")
            if expected_message:
                # self.assert_text(self.page.locator(loc.validation_message.format(expected_message)),expected_message,"Negative Validation")
                self.assert_text(self.page.locator(f"{loc.validation_message}[normalize-space()='{expected_message}']"),expected_message,"Negative Validation")
            else:
                raise Exception(f"ExpectedMessage column missing in test data: {data}")
            
        
        
    def AddAssert_message(self, bank: str, expected_message: str) -> None:
                """Assert the response/validation message text."""
                _, loc = self._dispatch[bank.lower()]
                self.assert_contains_text(self.locator(loc.message_container), expected_message, "Currency response message")
        
        
        
        

        