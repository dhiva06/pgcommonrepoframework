from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.pgconfiguration_locators import PgconfigurationLocators as EcentricPgconfigurationLocators

class PgconfigurationPage(BasePage):
    def __init__(self, page, module_name="Pgconfiguration"):
        super().__init__(page, module_name=module_name)
        self._dispatch = {
            "ecentric": (self._update_standard, EcentricPgconfigurationLocators)
        }

    def navigate_to_pg_information(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.administration_menu, "Administration menu")
        self.click_by_locator(loc.pg_configuration_submenu, "PG configuration submenu")
        self.click_by_locator(loc.pg_information_title, "PG information title")

    def execute_update_pgconfiguration(self, bank: str, data: dict) -> None:
        self.navigate_to_pg_information(bank)
        method, loc = self._dispatch[bank.lower()]
        method(loc, data)
        self.click_save_button(bank)
        self.assert_pgconfiguration_message(bank, data["ExpectedMessage"])

    def execute_addlogo_pgconfiguration(self, bank: str, data: dict) -> None:
        self.navigate_to_pg_information(bank)
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.pg_logos_section_add_upload_button, "Add/Upload logo button")
        self.upload_file(loc.pg_logos_section_add_upload_button, data["Logo File Path"], "Logo file upload")
        self.assert_pgconfiguration_message(bank, data["ExpectedMessage"])

    def execute_deletelogo_pgconfiguration(self, bank: str, data: dict) -> None:
        self.navigate_to_pg_information(bank)
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.pg_logo_delete_trash_icon, "Delete logo trash icon")
        self.click_by_locator(loc.pg_logo_confirmation_button, "Confirm deletion button")
        self.assert_pgconfiguration_message(bank, data["ExpectedMessage"])

    def execute_addappicon_pgconfiguration(self, bank: str, data: dict) -> None:
        self.navigate_to_pg_information(bank)
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.pg_app_icon_section_add_upload_button, "Add/Upload app icon button")
        self.upload_file(loc.pg_app_icon_section_add_upload_button, data["App Icon File Path"], "App icon file upload")
        self.assert_pgconfiguration_message(bank, data["ExpectedMessage"])

    def execute_deleteappicon_pgconfiguration(self, bank: str, data: dict) -> None:
        self.navigate_to_pg_information(bank)
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.pg_app_icon_delete_trash_icon, "Delete app icon trash icon")
        self.click_by_locator(loc.pg_app_icon_confirmation_button, "Confirm deletion button")
        self.assert_pgconfiguration_message(bank, data["ExpectedMessage"])

    def click_save_button(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_pgconfiguration_message(self, bank: str, expected_message: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.locator(loc.message_container), expected_message, "Response message")

    def _update_standard(self, loc, data: dict) -> None:
        self.fill_by_locator(loc.gateway_fi_name_input, data["Gateway/FI Name"], "Gateway/FI Name")
        self.fill_by_locator(loc.gateway_fi_short_code_input, data["Gateway/FI Short Code"], "Gateway/FI Short Code")
        self.select_by_locator(loc.gateway_fi_country_dropdown, data["Gateway/FI Country"], "Gateway/FI Country")
        self.select_by_locator(loc.gateway_fi_language_dropdown, data["Gateway/FI Language"], "Gateway/FI Language")
        self.select_by_locator(loc.gateway_fi_base_currency_dropdown, data["Gateway/FI Base Currency"], "Gateway/FI Base Currency")
        self.select_by_locator(loc.gateway_fi_permitted_currency_multi_select, data["Gateway/FI Permitted Currency"], "Gateway/FI Permitted Currency")
        self.fill_by_locator(loc.contact_person_name_input, data["Contact Person Name"], "Contact Person Name")
        self.fill_by_locator(loc.mobile_number_input, data["Mobile Number"], "Mobile Number")
        self.fill_by_locator(loc.email_input, data["Email"], "Email")
        self.fill_by_locator(loc.address_input, data["Address"], "Address")
        self.select_by_locator(loc.city_dropdown, data["City"], "City")
        self.select_by_locator(loc.state_province_dropdown, data["State/Province"], "State/Province")
        self.fill_by_locator(loc.postal_code_input, data["Postal Code"], "Postal Code")
        self.select_by_locator(loc.country_dropdown, data["Country"], "Country")
        self.fill_by_locator(loc.helpdesk_email_input, data["Helpdesk Email"], "Helpdesk Email")
        if data.get("Mobile Checkbox", "").lower() == "true":
            self.check_by_locator(loc.mobile_checkbox, "Mobile checkbox")
        if data.get("Landline Checkbox", "").lower() == "true":
            self.check_by_locator(loc.landline_checkbox, "Landline checkbox")
        if data.get("Toll Free Checkbox", "").lower() == "true":
            self.check_by_locator(loc.toll_free_checkbox, "Toll free checkbox")
        self.fill_by_locator(loc.helpdesk_mobile_number_1_input, data["Helpdesk Mobile Number 1"], "Helpdesk Mobile Number 1")
        self.fill_by_locator(loc.helpdesk_landline_number_1_input, data["Helpdesk Landline Number 1"], "Helpdesk Landline Number 1")
        self.fill_by_locator(loc.helpdesk_toll_free_number_1_input, data["Helpdesk Toll Free Number 1"], "Helpdesk Toll Free Number 1")
        self.click_by_locator(loc.additional_toll_free_plus_icon, "Additional toll free plus icon")
        self.fill_by_locator(loc.additional_toll_free_number_input, data["Additional Toll Free Number"], "Additional Toll Free Number")
