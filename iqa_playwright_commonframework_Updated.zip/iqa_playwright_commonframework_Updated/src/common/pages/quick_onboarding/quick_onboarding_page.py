from playwright.sync_api import expect, TimeoutError as PlaywrightTimeoutError, Error as PlaywrightError

from src.banks.ecentric.locators.quick_onboarding_locator import (
    QuickOnboardingLocator as EcentricQuickOnboardingLocator,
)
from src.common.base.base_page import BasePage
import re


class QuickOnboardingPage(BasePage):
    def __init__(self, page):
        super().__init__(page, module_name="QuickOnboarding")

        self._dispatch = {"ecentric": (self._quick_onboarding, EcentricQuickOnboardingLocator)}

    def navigate_to_quick_onboarding(self, bank: str, data: dict) -> None:
        """Navigate to the Quick Onboarding section for the given bank."""
        _, loc = self._dispatch[bank.lower()]
        self.click_by_locator(loc.menu_sidebar, f"{bank} Sidebar menu")
        self.click_by_locator(loc.onboarding_menu, f"{bank} Onboarding menu")
        self.click_by_locator(loc.quick_onboarding_menu, f"{bank} Quick Onboarding menu")
        self.page.wait_for_timeout(1000)
        self.click_by_locator(loc.menu_sidebar, f"{bank} Sidebar menu")
        self.page.wait_for_timeout(1000)
        
    def assert_cards_visible(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.assert_text(self.page.locator(loc.new_card_text), data["new_card_text"], "New card")
        self.assert_text(self.page.locator(loc.pending_card_text), data["pending_card_text"], "Pending card")
        self.assert_text(self.page.locator(loc.rejected_card_text), data["rejected_card_text"], "Rejected card")
        self.assert_text(self.page.locator(loc.approved_card_text), data["approved_card_text"], "Approved card")
        self.assert_text(self.page.locator(loc.application_no), data["application_no"], "Application no")
        self.assert_text(self.page.locator(loc.contact_person), data["contact_person"], "Contact person")
        self.assert_text(self.page.locator(loc.updated_on), data["updated_on"], "Updated on")
        self.assert_text(self.page.locator(loc.reviewer), data["reviewer"], "Reviewer")
        self.assert_text(self.page.locator(loc.application_status), data["application_status"], "Application status")
        self.assert_text(self.page.locator(loc.search_button), data["search_button"], "Search button")
        self.assert_text(self.page.locator(loc.updated_on_dropdown), data["updated_on_dropdown"], "Updated on dropdown")
        self.assert_text(self.page.locator(loc.application_status_dropdown), data["application_status_dropdown"], "Application status dropdown")

    def add_quick_onboarding(self, bank: str) -> None:
        _, loc = self._dispatch[bank.lower()]
        self.page.wait_for_timeout(1000)
        self.click_by_locator(loc.add_button, "Add button")
        self.page.wait_for_timeout(1000)
    
    def verify_landing_page_functionality(self, bank: str, data: dict) -> dict:
        _, loc = self._dispatch[bank.lower()]
        
        testcase = data.get("TestcaseID")
        
        if testcase == ("TC_Quick onboarding_007, TC_Quick onboarding_018, TC_Quick onboarding_029") :
            return self._verify_updated_on_dropdown_functionality(data, loc)
        
        elif testcase == ("TC_Quick onboarding_008, TC_Quick onboarding_031, TC_Quick onboarding_032"):
            return self._verify_application_status_dropdown_functionality(data, loc)
        
        elif testcase in ("TC_Quick onboarding_003", "TC_Quick onboarding_004", "TC_Quick onboarding_005", "TC_Quick onboarding_006"):
            return self._verify_search_bar_functionality(data, loc)
        
        elif testcase == ("TC_Quick onboarding_009, TC_Quick onboarding_010, TC_Quick onboarding_012, TC_Quick onboarding_014"):
            return self._verify_hyperlink_for_first_approved(bank, data)
        
        return {}

    def _verify_hyperlink_for_first_approved(self, bank: str, data: dict) -> dict:
        """
        Finds the first Approved row in the results table, clicks the
        Application No hyperlink, and verifies the detail page opens.

        Returns the application number that was clicked.
        """
        _, loc = self._dispatch[bank.lower()]

        rows = self.page.locator(loc.result_table_rows)
        row_count = rows.count()
        self.logger.info(f"Checking {row_count} rows for first Approved record")
        self._record(f"Scanning {row_count} rows for first Approved record", "info")

        for i in range(row_count):
            row = rows.nth(i)
            status_cell = row.locator(loc.result_table_cells).nth(5)
            status = status_cell.inner_text().strip()

            if status.lower() == "approved":
                app_no_cell = row.locator(loc.result_table_cells).nth(0)
                app_no = app_no_cell.inner_text().strip()

                # Record the found value before clicking
                self.logger.info(f"First approved record found: {app_no}")
                self._record(f"First approved record: {app_no}", "pass")

                # Capture URL before click so we can verify navigation
                url_before = self.page.url

                app_no_cell.click()
                self.page.wait_for_load_state("networkidle")
                self.page.wait_for_timeout(2000)

                # Verify navigation occurred (URL changed or detail content appeared)
                url_after = self.page.url
                navigated = url_after != url_before

                if navigated:
                    self.logger.info(
                        f"Hyperlink worked: navigated to {url_after}"
                    )
                    self._record(
                        f"Hyperlink for {app_no} navigated to detail page",
                        "pass",
                    )
                else:
                    self.logger.info(
                        f"Hyperlink clicked but URL unchanged: {url_after}"
                    )
                    self._record(
                        f"Hyperlink for {app_no} clicked (URL unchanged)",
                        "info",
                    )

                return {
                    "application_no": app_no,
                    "status": status,
                    "navigated": navigated,
                    "url_before": url_before,
                    "url_after": url_after,
                }

        raise AssertionError("No Approved records found in the table.")

    def _find_column_index(self, keyword: str, default_index: int) -> int:
        header_locators = self.page.locator("table thead th, thead th, [role='columnheader'], mat-header-cell, table th")
        for idx in range(header_locators.count()):
            txt = header_locators.nth(idx).inner_text().strip().lower()
            if keyword.lower() in txt:
                return idx
        return default_index

    def _extract_column_cells(self, rows, col_index: int) -> list[str]:
        values = []
        for i in range(rows.count()):
            cells = rows.nth(i).locator("td")
            if cells.count() > col_index:
                values.append(cells.nth(col_index).inner_text().strip())
        return values

    def _verify_application_status_dropdown_functionality(self, data: dict, loc) -> dict:
        """
        Verifies the functionality of the "Application status" dropdown filter in the quick-onboarding table.
        """
        self.click_by_locator(loc.application_status_dropdown, "Application status dropdown")
        self.page.wait_for_timeout(1000)

        # Extract the options from the dropdown
        dropdown_options = [opt.strip() for opt in self.page.locator("//mat-option").all_inner_texts() if opt.strip()]
        self.logger.info(f"Dropdown options found: {dropdown_options}")

        # Check if the expected option is present in the dropdown
        expected_option = str(data.get("landing_page_functions", "")).strip()
        matched_option = next((opt for opt in dropdown_options if opt.lower() == expected_option.lower()), None)
        if not matched_option:
            err_msg = f"Expected option '{expected_option}' not found in 'Application status' dropdown. Available options: {dropdown_options}"
            self._record(f"FAIL: {err_msg}", "fail")
            raise AssertionError(err_msg)

        # Select the expected option
        self.click_by_locator(f"//mat-option[normalize-space()='{matched_option}']", f"Select '{matched_option}' from Application status dropdown")
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(1000)

        # Verify that the table is filtered correctly based on the selected option
        rows = self.page.locator("tbody tr")
        row_count = rows.count()
        self.logger.info(f"Row count after selecting '{expected_option}': {row_count}")

        # Check if table has 0 rows or displays "No matching records found"
        is_empty_or_no_records = False
        if row_count == 0:
            is_empty_or_no_records = True
        elif row_count == 1:
            first_row_text = rows.first.inner_text().strip().lower()
            if any(phrase in first_row_text for phrase in ["no matching records found", "no record", "no data", "no match"]):
                is_empty_or_no_records = True

        if is_empty_or_no_records:
            self.logger.info(f"No records found for filter '{expected_option}'. Asserting 'No matching records found.' message.")
            return self._assert_no_matching_records(expected_option, loc)

        # Extract column values for Application status
        status_col_idx = self._find_column_index("status", default_index=5)
        column_values = self._extract_column_cells(rows, status_col_idx)
        self.logger.info(f"Application status column values: {column_values}")

        if expected_option.lower() == "all":
            assert row_count > 0, "No records found when filtering by 'All'"
            msg = f"Filter 'All' in Application status dropdown verified: {row_count} rows displayed"
        else:
            matching_vals = [v for v in column_values if expected_option.lower() in v.lower()]
            assert matching_vals, (
                f"Expected status '{expected_option}' not found in Application status column. "
                f"Actual values were: {column_values}"
            )
            msg = f"Filter '{expected_option}' in Application status column verified for {len(matching_vals)} rows: {column_values}"

        self.logger.info(msg)
        self._record(msg, "pass")

        return {
            "selected_filter": expected_option,
            "row_count": row_count,
            "column": "Application status",
            "matching_values": column_values,
            "status": "filter_applied",
            "message": msg,
        }

    def _verify_updated_on_dropdown_functionality(self, data: dict, loc) -> dict:
        """
        Verifies the functionality of the "Updated on" dropdown filter in the quick-onboarding table.
        """
        self.click_by_locator(loc.updated_on_dropdown, "Updated on dropdown")
        self.page.wait_for_timeout(1000)

        # Extract the options from the dropdown
        dropdown_options = [opt.strip() for opt in self.page.locator("//mat-option").all_inner_texts() if opt.strip()]
        self.logger.info(f"Dropdown options found: {dropdown_options}")

        # Check if the expected option is present in the dropdown
        expected_option = str(data.get("landing_page_functions", "")).strip()
        matched_option = next((opt for opt in dropdown_options if opt.lower() == expected_option.lower()), None)
        if not matched_option:
            err_msg = f"Expected option '{expected_option}' not found in 'Updated on' dropdown. Available options: {dropdown_options}"
            self._record(f"FAIL: {err_msg}", "fail")
            raise AssertionError(err_msg)

        # Select the expected option
        self.click_by_locator(f"//mat-option[normalize-space()='{matched_option}']", f"Select '{matched_option}' from Updated on dropdown")
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(1000)

        # Verify that the table is filtered correctly based on the selected option
        rows = self.page.locator("tbody tr")
        row_count = rows.count()
        self.logger.info(f"Row count after selecting '{expected_option}': {row_count}")

        # Check if table has 0 rows or displays "No matching records found"
        is_empty_or_no_records = False
        if row_count == 0:
            is_empty_or_no_records = True
        elif row_count == 1:
            first_row_text = rows.first.inner_text().strip().lower()
            if any(phrase in first_row_text for phrase in ["no matching records found", "no record", "no data", "no match"]):
                is_empty_or_no_records = True

        if is_empty_or_no_records:
            self.logger.info(f"No records found for filter '{expected_option}'. Asserting 'No matching records found.' message.")
            return self._assert_no_matching_records(expected_option, loc)

        # Extract column values for Updated on
        updated_col_idx = self._find_column_index("updated", default_index=3)
        column_values = self._extract_column_cells(rows, updated_col_idx)
        self.logger.info(f"Updated on column values: {column_values}")

        assert row_count > 0, f"No records displayed after applying 'Updated on' filter '{expected_option}'"
        sample_dates = column_values[:5] if len(column_values) > 5 else column_values
        msg = f"Filter '{expected_option}' in Updated on dropdown verified for {row_count} rows: {sample_dates}"

        self.logger.info(msg)
        self._record(msg, "pass")

        return {
            "selected_filter": expected_option,
            "row_count": row_count,
            "column": "Updated on",
            "matching_values": column_values,
            "status": "filter_applied",
            "message": msg,
        }
    
    def _verify_search_bar_functionality(self, data: dict, loc) -> dict:
        """
        Dynamically searches the quick-onboarding table for search_box_value
        and identifies which column(s) (Application No, Business Name, Contact Person, etc.)
        contain the searched value.
        """
        search_text = str(data.get("landing_page_functions") or data.get("search_box_value", "")).strip()
        self.fill_by_locator(loc.search_textbox, search_text, "Search Textbox")
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(1000)

        rows = self.page.locator("tbody tr")
        row_count = rows.count()
        self.logger.info(f"Search results rows found for '{search_text}': {row_count}")

        # Check if table has 0 rows or if the only row displays "No matching records found"
        is_empty_or_no_records = False
        if row_count == 0:
            is_empty_or_no_records = True
        elif row_count == 1:
            first_row_text = rows.first.inner_text().strip().lower()
            if any(phrase in first_row_text for phrase in ["no matching records found", "no record", "no data", "no match"]):
                is_empty_or_no_records = True

        if is_empty_or_no_records:
            self.logger.info(
                f"Table has no matching rows for '{search_text}'. Asserting 'No matching records found.' message."
            )
            return self._assert_no_matching_records(search_text, loc)

        # Extract column headers if available in the DOM or fallback to known positions
        fallback_headers = {
            0: "Application No",
            1: "Business Name",
            2: "Contact Person",
            3: "Updated On",
            4: "Reviewer",
            5: "Application Status",
        }

        # Attempt to read header text from the table
        header_names: dict[int, str] = {}
        header_locators = self.page.locator("table thead th, thead th, [role='columnheader'], mat-header-cell, table th")
        header_count = header_locators.count()
        for idx in range(header_count):
            txt = header_locators.nth(idx).inner_text().strip()
            first_line = txt.split("\n")[0].strip() if txt else ""
            if first_line:
                header_names[idx] = first_line

        def get_column_name(col_idx: int) -> str:
            if col_idx in header_names and header_names[col_idx]:
                return header_names[col_idx]
            return fallback_headers.get(col_idx, f"Column {col_idx}")

        # Collect cell values per column across all rows
        column_cells: dict[int, list[str]] = {}
        for i in range(row_count):
            cells = rows.nth(i).locator("td")
            cell_count = cells.count()
            for j in range(cell_count):
                cell_text = cells.nth(j).inner_text().strip()
                column_cells.setdefault(j, []).append(cell_text)

        for col_idx, values in column_cells.items():
            self.logger.info(f"{get_column_name(col_idx)} (index {col_idx}): {values}")

        # Search across all columns for search_text (case-insensitive substring match)
        matched_columns: dict[str, list[str]] = {}
        for col_idx, values in column_cells.items():
            col_name = get_column_name(col_idx)
            matching_vals = [v for v in values if search_text.lower() in v.lower()]
            if matching_vals:
                matched_columns[col_name] = matching_vals

        # If the search value was not found in any column, assert "No matching records found."
        if not matched_columns:
            self.logger.info(
                f"Search value '{search_text}' not present in table columns. Asserting 'No matching records found.' message."
            )
            return self._assert_no_matching_records(search_text, loc)

        for col_name, matching_vals in matched_columns.items():
            msg = f"The value '{search_text}' is present in '{col_name}' column: {matching_vals}"
            self.logger.info(msg)
            self._record(msg, "pass")

        primary_col = list(matched_columns.keys())[0]
        return {
            "search_text": search_text,
            "status": "found",
            "column": primary_col,
            "matching_values": matched_columns[primary_col],
            "matched_columns": matched_columns,
            "message": f"The value '{search_text}' is present in '{primary_col}' column",
        }

    def _assert_no_matching_records(self, search_text: str, loc) -> dict:
        """
        Asserts that the 'No matching records found.' message is displayed when
        the searched value is not present in the table.
        """
        no_records_selector = getattr(
            loc,
            "no_matching_records",
            "//*[contains(normalize-space(), 'No matching records found') and not(.//*[contains(normalize-space(), 'No matching records found')])]",
        )
        no_records_locator = self.page.locator(no_records_selector).first
        try:
            no_records_locator.wait_for(state="visible", timeout=10000)
            raw_text = no_records_locator.inner_text().strip()
            assert "no matching records found" in raw_text.lower(), (
                f"Expected 'No matching records found.' message for search '{search_text}', but got '{raw_text}'"
            )

            # Extract the clean message line
            actual_msg = "No matching records found."
            for line in raw_text.splitlines():
                line_clean = line.strip()
                if "no matching records found" in line_clean.lower():
                    actual_msg = line_clean
                    break

            self.logger.info(
                f"Assertion passed: '{actual_msg}' is displayed for search value '{search_text}'"
            )
            shot = self.attach_screenshot(f"no_matching_records_{search_text}")
            self._record(
                f"Assertion passed: '{actual_msg}' is displayed for search value '{search_text}'",
                "pass",
                shot,
            )
            return {
                "search_text": search_text,
                "status": "no_records_found",
                "message": actual_msg,
            }
        except (PlaywrightTimeoutError, PlaywrightError, AssertionError) as e:
            self.logger.error(
                f"Assertion failed: 'No matching records found.' message not displayed for '{search_text}': {e}"
            )
            fail_shot = self.attach_screenshot(f"no_matching_records_failed_{search_text}")
            self._record(
                f"FAIL: 'No matching records found.' message not displayed for search '{search_text}'",
                "fail",
                fail_shot,
            )
            raise AssertionError(
                f"Search value '{search_text}' was not present in table, and 'No matching records found.' message was not displayed."
            ) from e
    
    def _quick_onboarding(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]

        # self.click_by_locator(loc.add_button, "Add button")
        self._fill_basic_info(data, loc)
        self.click_by_locator(loc.save_basic_info_button, "Save & Continue")
        self._assert_success_message(data)
        self.page.wait_for_timeout(1000)  # wait for Business Info tab to load
        
        self._fill_business_info(data, loc)
        self.click_by_locator(loc.save_business_info_button, "Save & Continue")
        self._assert_success_message(data)

        self.page.wait_for_timeout(1000)  # wait for Store Details tab to load
        self._fill_store_details(data, loc)
        self.click_by_locator(loc.save_store_details_button, "Save & Continue")
        self._assert_success_message(data)
        
        self.page.wait_for_timeout(1000)  # wait for Terminal Details tab to load
        self._fill_terminal_details(data, loc)
        self.page.wait_for_timeout(1000)  # wait for Additional Settings section
        self._fill_terminal_additional_settings(data, loc)
        self.click_by_locator(loc.additional_settings_save_button, "Additional Settings Save")
        self.page.wait_for_timeout(5000)  # wait for save to complete
        self.click_by_locator(loc.save_terminal_details_button, "Save & Continue")
        self.page.wait_for_timeout(5000)  # wait for save to complete

    def _fill_basic_info(self, data: dict, loc) -> None:
        # self.click_by_locator(loc.contact_name, "Contact name field")
        self.fill_by_locator(loc.contact_name, data["contact_name"], "Contact name")
        self.fill_by_locator(loc.business_name, data["business_name"], "Business name")
        self.fill_by_locator(loc.merchant_id, data["merchant_id"], "Merchant ID")
        self.select_custom_dropdown(loc.mcc_description_dropdown, data["mcc_description"])
        self.fill_by_locator(loc.mobile_number, data["mobile_number"], "Mobile number")
        self.fill_by_locator(loc.email, data["email"], "Email")
        self.select_custom_dropdown(loc.organization_name, data["organization_name"])
         
    def _assert_success_message(self,data: dict):
        self.assert_visible(self.page.get_by_text(data["assert_save_toast_message"]), "Success message")
        
    def _fill_business_info(self, data: dict, loc) -> None:
        self.fill_by_locator(loc.merchant_legal_name, data["merchant_legal_name"], "Merchant legal name")
        self.fill_by_locator(loc.business_info_website_address,data["website_address1"],"Website address")
        self.select_custom_dropdown(loc.incorporation_status, data["incorporation_status"])
        self.fill_by_locator(loc.office_address, data["office_address"], "Office address")
        self.fill_by_locator(loc.postal_code, data["postal_code"], "Postal code")
        self.select_custom_dropdown(loc.country, data["country"])
        self.select_custom_dropdown(loc.state_province, data["state_province"])
        self.select_custom_dropdown(loc.city, data["city"])

    def _fill_store_details(self, data: dict, loc) -> None:

        self.wait_for_field_populated(loc.store_id, description="Store ID auto-populated")
        self.page.wait_for_timeout(1000) 
        self.clear_field(loc.store_id, "Store ID")
        self.clear_field(loc.store_website_address, "Store Website Address")
        self.fill_by_locator(loc.store_id, data["store_id"], "Store ID")

        # Store type is a radio button: pick based on data value
        store_type = str(data["store_type"]).strip().lower()
        if store_type == "online":
            self.select_radio_by_locator(loc.store_type_online, "Store Type - Online")
            self.page.wait_for_timeout(1000)
            self.fill_by_locator(loc.store_website_address, data["website_address2"], "Website address")
        else:
            self.select_radio_by_locator(loc.store_type_offline, "Store Type - Offline")
            self.page.wait_for_timeout(1000)
            self.fill_by_locator(loc.store_website_address, data["website_address2"], "Website address")
        
        self.clear_field(loc.number_of_terminals_allocated, "Number of terminals allocated")
        self.fill_by_locator(loc.number_of_terminals_allocated,data["number_of_terminals"],"Number of terminals")

        self.fill_by_locator(loc.store_name, data["store_name"], "Store name")
        self.fill_by_locator(loc.store_email_id, data["store_email"], "Store email")
        self.fill_by_locator(loc.store_contact_number,data["store_contact_number"],"Store contact number")
        self.clear_field(loc.store_address, "Store Address")
        self.page.wait_for_timeout(1000)
        self.fill_by_locator(loc.store_address, data["store_address"], "Store Address")
        
    def _fill_terminal_details(self, data: dict, loc) -> None:

        self.select_custom_dropdown(loc.service_type, data["service_type"])
        self.select_custom_dropdown(loc.authentication_service_provider, data["authentication_service_provider"])
        self.select_custom_dropdown(loc.integration_method, data["integration_method"])
        self.fill_by_locator(loc.terminal_id, data["terminal_id"], "Terminal ID")
        self.fill_by_locator(loc.terminal_name, data["terminal_name"], "Terminal name")
        self.select_custom_dropdown(loc.select_store_to_add, data["select_store_to_add"])
        self.fill_by_locator(loc.merchant_auth_url, data["merchant_auth_url"], "Merchant Auth URL")

        status = str(data["status"]).strip().lower()
        if status == "active":
            self.check_by_locator(loc.status_active, "Status - Active")
        else:
            self.check_by_locator(loc.status_inactive, "Status - Inactive")

        self.select_custom_dropdown(loc.payment_gateway, data["payment_gateway"])
        self.multi_select(loc.accepted_scheme_brands, data["accepted_scheme_brands"], "Accepted scheme brands")
        self.multi_select(loc.accepted_transaction_types, data["accepted_transaction_types"], "Accepted transaction types")
        self.multi_select(loc.permitted_acquiring_currency, data["permitted_acquiring_currency"], "Permitted acquiring currency")
        self.multi_select(loc.accepted_payment_methods, data["accepted_payment_methods"], "Accepted payment methods")

        transaction_via_base_24 = str(data["transaction_via_base_24"]).strip().lower()
        if transaction_via_base_24 == "yes":
            self.select_radio_by_locator(loc.transaction_via_base_24_yes, "Transaction via base24 - Yes")
            self.wait_for_field_populated(loc.acquirer_institution_id, description="Acquirer institution ID auto-populated")
            self.page.wait_for_timeout(1000)
            self.clear_field(loc.acquirer_institution_id, "Acquirer institution ID")
            self.fill_by_locator(loc.acquirer_institution_id,data["acquirer_institution_id"],"Acquirer institution ID")
            self.clear_field(loc.terminal_data, "Terminal data")
            self.fill_by_locator(loc.terminal_data, data["terminal_data"], "Terminal data")
            self.clear_field(loc.retailer_id, "Retailer ID")
            self.fill_by_locator(loc.retailer_id, data["retailer_id"], "Retailer ID")
            self.clear_field(loc.retailer_group, "Retailer group")
            self.fill_by_locator(loc.retailer_group, data["retailer_group"], "Retailer group")
            self.clear_field(loc.retailer_region, "Retailer region")
            self.fill_by_locator(loc.retailer_region, data["retailer_region"], "Retailer region")
            self.select_custom_dropdown(loc.routing_plan, data["routing_plan"])
            # self.select_custom_dropdown(loc.payment_page_template, data["payment_page_template"])
            self.select_custom_dropdown(loc.merchant_acquiring_bank, data["merchant_acquiring_bank"])
            self.fill_by_locator(loc.merchant_terms_and_conditions_url,data["merchant_terms_and_conditions_url"],"Merchant terms and conditions URL")
        else:
            self.select_radio_by_locator(loc.transaction_via_base_24_no, "Transaction via base24 - No")
            self.select_custom_dropdown(loc.routing_plan, data["routing_plan"])
            # self.select_custom_dropdown(loc.payment_page_template, data["payment_page_template"])
            self.select_custom_dropdown(loc.merchant_acquiring_bank, data["merchant_acquiring_bank"])
            self.fill_by_locator(loc.merchant_terms_and_conditions_url,data["merchant_terms_and_conditions_url"],"Merchant terms and conditions URL")

    def _fill_terminal_additional_settings(self, data: dict, loc) -> None:

        self.click_by_locator(loc.view_update_settings, "View/update settings")
        self.page.wait_for_timeout(2000)
        
        #multiple_refund — only applies if Integration method is Hosted Payment Page
        if "hosted payment page" in str(data["integration_method"]).strip().lower():
            multiple_refund = str(data["multiple_refund"]).strip().lower()
            if multiple_refund == "yes":
                self.select_radio_by_locator(loc.multiple_refund_yes, "Multiple refunds - Yes")
            else:
                self.select_radio_by_locator(loc.multiple_refund_no, "Multiple refunds - No")

        # Card capture screen expiry time — only required if Integration method is Hosted Payment Page
        integration_method = str(data["integration_method"]).strip().lower()
        if "hosted payment page" in integration_method:
            self.fill_by_locator(loc.card_capture_screen_expiry_time, data["card_capture_screen_expiry_time"], "Card capture screen expiry time")
            
        self.fill_by_locator(loc.page_time_out, data["page_time_out"], "Page time out")

        # key_expiry_period: yes -> fill expiry_time, no -> nothing
        key_expiry = str(data["key_expiry_period"]).strip().lower()
        if key_expiry == "yes":
            self.select_radio_by_locator(loc.key_expiry_period_yes, "Key expiry period - Yes")
            self.clear_field(loc.expiry_period, "Expiry period")
            self.fill_by_locator(loc.expiry_period, data["expiry_period"], "Expiry period")
        else:
            self.select_radio_by_locator(loc.key_expiry_period_no, "Key expiry period - No")

        # enable_international_transactions
        intl = str(data["enable_international_transactions"]).strip().lower()
        if intl == "yes":
            self.select_radio_by_locator(loc.enable_international_transactions_yes,"Enable international transactions - Yes")
        else:
            self.select_radio_by_locator(loc.enable_international_transactions_no,"Enable international transactions - No")

        self.select_custom_dropdown(loc.message_type, data["message_type"])

        # recon_file_required
        recon = str(data["recon_file_required"]).strip().lower()
        if recon == "yes":
            self.select_radio_by_locator(loc.recon_file_required_yes, "Recon file required - Yes")
        else:
            self.select_radio_by_locator(loc.recon_file_required_no, "Recon file required - No")

        # merchant_markoff_file_required
        markoff = str(data["merchant_markoff_file_required"]).strip().lower()
        if markoff == "yes":
            self.select_radio_by_locator(loc.merchant_markoff_file_required_yes,"Merchant markoff file required - Yes")
        else:
            self.select_radio_by_locator(loc.merchant_markoff_file_required_no,"Merchant markoff file required - No")

        # success_failure_page
        sfp = str(data["success_failure_page"]).strip().lower()
        if sfp == "yes":
            self.select_radio_by_locator(loc.success_failure_page_yes, "Success failure page - Yes")
        else:
            self.select_radio_by_locator(loc.success_failure_page_no, "Success failure page - No")
            
        # enable_webhook — only applies if Integration method is Hosted Payment Page
        if "hosted payment page" in str(data["integration_method"]).strip().lower():
            webhook = str(data["enable_webhook"]).strip().lower()
            if webhook == "yes":
                self.select_radio_by_locator(loc.enable_webhook_yes, "Enable webhook - Yes")
            else:
                self.select_radio_by_locator(loc.enable_webhook_no, "Enable webhook - No")

    def add_quick_onboarding_negative(self, bank: str, data: dict) -> None:
        _, loc = self._dispatch[bank.lower()]
        
        if data["TestcaseID"] == ("TC_Quick_Onboarding_019, TC_Quick_Onboarding_020, TC_Quick_Onboarding_021, TC_Quick_Onboarding_022, TC_Quick_Onboarding_023, TC_Quick_Onboarding_024, TC_Quick_Onboarding_025, TC_Quick_Onboarding_026, TC_Quick_Onboarding_027, TC_Quick_Onboarding_028"):
            self._fill_basic_info_negative(data, loc)
            
        if data["TestcaseID"] == ("TC_Quick_onboarding_038, TC_Quick_onboarding_039, TC_Quick_onboarding_040, TC_Quick onboarding_044, TC_Quick onboarding_045, TC_Quick_onboarding_046, TC_Quick_onboarding_047, TC_Quick onboarding_050, TC_Quick onboarding_051, TC_Quick onboarding_052, TC_Quick onboarding_055"):
            self._fill_business_info_negative(data, loc)
            
        if data["TestcaseID"] == ("TC_Quick onboarding_037, TC_Quick onboarding_041, TC_Quick onboarding_042, TC_Quick_onboarding_056 to TC_Quick_onboarding_060, TC_Quick_onboarding_062 to TC_Quick_onboarding_064, TC_Quick_onboarding_068, TC_Quick_onboarding_069, TC_Quick_onboarding_072"):
            self._fill_store_details_negative(data, loc)
            
        if data["TestcaseID"] == ("TC_Quick onboarding_080, TC_Quick onboarding_081, TC_Quick onboarding_083, TC_Quick onboarding_093, TC_Quick onboarding_094, TC_Quick onboarding_095"):
            self._fill_terminal_details_negative(data, loc)
            
        if data["TestcaseID"] ==("TC_Quick onboarding_089"):
            self._fill_terminal_additional_settings_negative(data, loc)

    def _fill_basic_info_negative(self, data: dict, loc) -> None:
            self._fill_basic_info(data, loc)
            
            self.assert_text(self.page.locator(loc.assert_contact_name_error),data["assert_contact_name"],"Contact name error")
            self.assert_text(self.page.locator(loc.assert_business_name_error),data["assert_business_name"],"Business name error")
            self.assert_text(self.page.locator(loc.assert_merchant_id_error),data["assert_merchant_id"],"Merchant ID error")
            self.assert_text(self.page.locator(loc.assert_mobile_number_error),data["assert_mobile_no"],"Mobile number error")
            self.assert_text(self.page.locator(loc.assert_email_error),data["assert_email"],"Email error")
            
    def _fill_business_info_negative(self, data: dict, loc) -> None:
        self._fill_basic_info(data, loc)
        self.click_by_locator(loc.save_basic_info_button, "Save & Continue")
        self.page.wait_for_timeout(1000)
        self._fill_business_info(data, loc)
        
        self.assert_text(self.page.locator(loc.assert_merchant_legal_name),data["assert_merchant_legal_name"],"Merchant legal name error")
        self.assert_text(self.page.locator(loc.assert_website_address),data["assert_website_address1"],"Website address error")
        self.assert_text(self.page.locator(loc.assert_office_address),data["assert_office_address"],"Office address error")
        self.assert_text(self.page.locator(loc.assert_postal_code),data["assert_postal_code"],"Postal code error")

    def _fill_store_details_negative(self, data: dict, loc) -> None:
        
        self._fill_basic_info(data, loc)
        self.click_by_locator(loc.save_basic_info_button, "Save & Continue")
        self.page.wait_for_timeout(1000)
        
        self._fill_business_info(data, loc)
        self.click_by_locator(loc.save_business_info_button, "Save & Continue")
        self.page.wait_for_timeout(1000)
        
        self._fill_store_details(data, loc)
                    
        self.assert_text(self.page.locator(loc.assert_store_id), data["assert_store_id"], "assert_store_id")
        self.assert_text(self.page.locator(loc.assert_website_address), data["assert_website_address"], "assert_website_address")
        self.assert_text(self.page.locator(loc.assert_store_email_id), data["assert_store_email_id"], "assert_store_email_id")
        self.assert_text(self.page.locator(loc.assert_store_contact), data["assert_store_contact"], "assert_store_contact")
        self.assert_text(self.page.locator(loc.assert_store_address), data["assert_store_address"], "assert_store_address")
        
    def _fill_terminal_details_negative(self, data: dict, loc) -> None:

        # self.click_by_locator(loc.add_button, "Add button")
        self._fill_basic_info(data, loc)
        self.click_by_locator(loc.save_basic_info_button, "Save & Continue")
        self._assert_success_message(data)
        self.page.wait_for_timeout(1000)  # wait for Business Info tab to load
        
        self._fill_business_info(data, loc)
        self.click_by_locator(loc.save_business_info_button, "Save & Continue")
        self._assert_success_message(data)

        self.page.wait_for_timeout(1000)  # wait for Store Details tab to load
        self._fill_store_details(data, loc)
        self.click_by_locator(loc.save_store_details_button, "Save & Continue")
        self._assert_success_message(data)
        
        self.page.wait_for_timeout(1000)  # wait for Terminal Details tab to load
        self._fill_terminal_details(data, loc)
        self.page.wait_for_timeout(1000)  # wait for Additional Settings section
        
        self.assert_text(self.page.locator(loc.assert_terminal_id), data["assert_terminal_id"], "assert_terminal_id")
        self.assert_text(self.page.locator(loc.assert_terminal_name), data["assert_terminal_name"], "assert_terminal_name")
        self.assert_text(self.page.locator(loc.assert_mrch_auth_url), data["assert_mrch_auth_url"], "assert_mrch_auth_url")
        
        
    def _fill_terminal_additional_settings_negative(self, data: dict, loc) -> None:
        self._fill_basic_info(data, loc)
        self.click_by_locator(loc.save_basic_info_button, "Save & Continue")
        self._assert_success_message(data)
        self.page.wait_for_timeout(1000)  # wait for Business Info tab to load
                
        self._fill_business_info(data, loc)
        self.click_by_locator(loc.save_business_info_button, "Save & Continue")
        self._assert_success_message(data)
        
        self.page.wait_for_timeout(1000)  # wait for Store Details tab to load
        self._fill_store_details(data, loc)
        self.click_by_locator(loc.save_store_details_button, "Save & Continue")
        self._assert_success_message(data)
                
        self.page.wait_for_timeout(1000)  # wait for Terminal Details tab to load
        self._fill_terminal_details(data, loc)
        self.page.wait_for_timeout(1000)  # wait for Additional Settings section
        
        self._fill_terminal_additional_settings(data, loc)
        
        self.assert_text(self.page.locator(loc.assert_cardCaptureScreenExpiryTime), data["assert_cardCaptureScreenExpiryTime"], "assert_cardCaptureScreenExpiryTime")
        self.assert_text(self.page.locator(loc.assert_keyExpiryPeriodInDay), data["assert_keyExpiryPeriodInDay"], "assert_keyExpiryPeriodInDay")
        
                