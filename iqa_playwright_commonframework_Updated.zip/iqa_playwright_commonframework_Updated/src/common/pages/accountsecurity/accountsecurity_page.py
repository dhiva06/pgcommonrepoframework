from src.common.base.base_page import BasePage
from src.banks.ecentric.locators.accountsecurity_locators import AccountsecurityLocators as EcentricAccountsecurityLocators

BANK_LOCATORS = {
    "ecentric": EcentricAccountsecurityLocators,
}

class AccountsecurityPage(BasePage):
    def __init__(self, page, module_name="Accountsecurity"):
        super().__init__(page, module_name=module_name)

    def navigate_to_accountsecurity(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.menu_administration, "Administration menu")
        self.click_by_locator(loc.menu_user_administration, "User administration submenu")
        self.click_by_locator(loc.menu_user_account_security, "User account security submenu")

    def click_add_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.add_button, "Add button")

    def fill_accountsecurity_form(self, bank: str, data: dict) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.fill_by_locator(loc.policy_name_input, data["Policy Name"], "Policy name")
        self.select_by_locator(loc.product_dropdown, data["Product"], "Product")
        self.select_by_locator(loc.portal_dropdown, data["Portal"], "Portal")
        self.fill_by_locator(loc.idle_session_timeout_input, data["Idle Session Timeout"], "Idle session timeout")
        self.fill_by_locator(loc.login_attempts_input, data["Login Attempts"], "Login attempts")
        self.fill_by_locator(loc.user_inactive_period_input, data["User Inactive Period"], "User inactive period")
        self.fill_by_locator(loc.password_min_length_input, data["Password Minimum Length"], "Password minimum length")
        self.fill_by_locator(loc.password_max_length_input, data["Password Maximum Length"], "Password maximum length")
        self.select_by_locator(loc.allowed_special_chars_dropdown, data["Allowed Special Character Set"], "Allowed special character set")
        self.fill_by_locator(loc.min_capital_letters_input, data["Minimum Capital Letters"], "Minimum capital letters")
        self.fill_by_locator(loc.min_digits_input, data["Minimum Digits"], "Minimum digits")
        self.fill_by_locator(loc.min_special_chars_input, data["Minimum Special Characters"], "Minimum special characters")
        self.fill_by_locator(loc.disallowed_common_passwords_input, data["Disallowed Common Passwords"], "Disallowed common passwords")
        self.click_by_locator(loc.previously_reused_no_radio, "Previously reused passwords - No radio")
        self.click_by_locator(loc.force_change_password_yes_radio, "Force change password - Yes radio")
        self.fill_by_locator(loc.frequency_input, data["Frequency"], "Frequency")
        self.fill_by_locator(loc.change_password_period_input, data["Change Password Period"], "Change password period")

    def click_save_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.save_button, "Save button")

    def assert_success_message(self, bank: str, expected_message: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.assert_text(self.locator(loc.success_message), expected_message, "Success message")

    def fill_search_policy_field(self, bank: str, policy_name: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.fill_by_locator(loc.search_policy_field, policy_name, "Search policy field")

    def select_created_on_dropdown(self, bank: str, value: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.select_by_locator(loc.created_on_dropdown, value, "Created on dropdown")

    def click_search_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.search_button, "Search button")

    def assert_policy_row_displayed(self, bank: str, policy_name: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        row_locator = loc.policy_row_by_name.format(policy_name=policy_name)
        self.assert_visible(self.locator(row_locator), f"Policy row with name '{policy_name}'")
