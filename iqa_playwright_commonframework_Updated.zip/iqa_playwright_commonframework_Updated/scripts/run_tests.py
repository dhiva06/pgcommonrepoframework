"""run_tests.py - run a module's tests in the right order with numbers that belong together, and retry Add with new numbers.

    python scripts\\run_tests.py binmanagement
    python scripts\\run_tests.py binmanagement --retries 3        (how many NEW BIN / range sets Add may try; default 3)
    python scripts\\run_tests.py binmanagement --headed -s          (any pytest option can simply follow: --headed, -s, -x ...)

 1. writes fresh real numbers into the workbook (BIN passes Luhn, 19-digit low / high range, same BIN for View/Edit/Delete/negatives)
 2. runs the ADD tests. If Add is rejected ("already exists", "overlap", ...) it writes NEW numbers and runs Add again
 3. when Add passed: runs the APPROVE tests (the checker step), if the module has any
 4. then View, Edit, Delete and every negative test (they all use the record Add just created)"""
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from scripts.generate_scenario import ensure_module_conftest, materialize_testdata_numbers  # noqa: E402

REJECTED_RE = re.compile(r"already exist|overlap|duplicate|exists", re.I)


def _bank_from_config() -> str | None:
    """The bank comes from src\\config.yaml (the same file the framework uses) - there is no built-in default."""
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def run_pytest(args: list[str], phase: str = "") -> tuple[int, str]:
    """Runs pytest, shows its output live, returns (exit code, the whole output). phase 'add' / 'rest' is applied by the module's
    conftest.py by TEST FUNCTION NAME."""
    # PYTHONUNBUFFERED: pytest writes into a PIPE here, and Python buffers a pipe - without it nothing after the line
    # "collected N items" reaches the screen until every test has finished (it looks as if nothing runs).
    env = dict(os.environ, AI_PREPARE_DATA="0", AI_TEST_PHASE=phase, PYTHONUNBUFFERED="1")   # this script writes the values itself
    if not any(a in ("-v", "-vv", "-q", "-qq") or a.startswith("-v") for a in args):
        args = args + ["-v"]                                  # one line per test, printed as soon as it finishes
    print(f"\n  $ python -m pytest {' '.join(args)}   (AI_TEST_PHASE={phase or '-'})\n", flush=True)
    proc = subprocess.Popen([sys.executable, "-u", "-m", "pytest"] + args, cwd=str(ROOT), env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    lines: list[str] = []
    for line in proc.stdout:                              # type: ignore[union-attr]
        print(line, end="", flush=True)
        lines.append(line)
    proc.wait()
    return proc.returncode, "".join(lines)


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 0
    module = argv[0].lower()
    bank, retries, extra = None, 3, []
    rest, i = argv[1:], 0
    while i < len(rest):                      # --bank X, --retries N; EVERYTHING else is handed to pytest (--headed, -s, -x ...)
        a = rest[i]
        if a == "--bank" and i + 1 < len(rest):
            bank, i = rest[i + 1], i + 2
        elif a == "--retries" and i + 1 < len(rest):
            retries, i = int(rest[i + 1]), i + 2
        elif a == "--pytest-args":            # old style: --pytest-args "--headed -s"  (a missing value is simply ignored)
            for v in rest[i + 1:]:
                extra += shlex.split(v)
            if not rest[i + 1:]:
                print("(--pytest-args needs a value, e.g.  --pytest-args \"--headed -s\"  - or just write the options:  --headed -s)")
            break
        else:
            extra.append(a)
            i += 1
    bank = bank or _bank_from_config()
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return 1
    folder = ROOT / "src" / "testcase" / module
    if not folder.exists():
        print(f"Folder not found: {folder}")
        return 1
    ensure_module_conftest(ROOT, module, log=lambda m: None)
    attempt = 0
    while True:
        attempt += 1
        print(f"\n=== numbers (attempt {attempt}) ===")
        info = materialize_testdata_numbers(ROOT, bank, module)
        if info and info.get("problems"):
            print("The numbers do not belong together - stopping.")
            return 1
        print(f"\n=== ADD tests ===")
        rc, out = run_pytest([str(folder)] + extra, phase="add")
        if rc == 5:
            print("\n(no Add test was selected - the test names contain no 'add' / 'create' - running everything in one go)")
            return run_pytest([str(folder)] + extra)[0]
        if rc == 0:
            break
        if REJECTED_RE.search(out) and attempt <= retries:
            print(f"\nAdd was REJECTED (BIN / range already exists or overlaps) -> trying again with NEW numbers "
                  f"({attempt}/{retries})")
            continue
        print("\nAdd FAILED - View / Edit / Delete / negative tests were NOT run (they need the BIN that Add creates).")
        return rc
    print("\n=== APPROVE tests (the checker step: it approves the record Add just created) ===")
    rc_ap, _out_ap = run_pytest([str(folder)] + extra, phase="approve")
    if rc_ap not in (0, 5):
        print("\nApprove FAILED - View / Edit / Delete / negative tests were NOT run (they need the approved record).")
        return rc_ap
    if rc_ap == 5:
        print("(no approve test in this module - continuing)")
    print("\n=== VIEW / EDIT / DELETE / NEGATIVE tests (they use the value Add just created) ===")
    rc2 = run_pytest([str(folder)] + extra, phase="rest")[0]
    if rc2 == 5:
        print("\n(Add passed and there is nothing after it: no View / Edit / Delete / negative test in this module)")
    return rc2


if __name__ == "__main__":
    sys.exit(main())
