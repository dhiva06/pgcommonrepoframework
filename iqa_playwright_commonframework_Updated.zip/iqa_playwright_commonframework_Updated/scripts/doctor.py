"""doctor.py - find out WHY a module's pytest run misbehaves, and fix what can be fixed safely. Run it from the repo root:

    python scripts\\doctor.py binmanagement                 check + safe fixes
    python scripts\\doctor.py binmanagement --negatives     ... and re-generate the negative TESTS if only the data exists
    python scripts\\doctor.py binmanagement --bank ecentric

What it checks (and fixes where it says FIXED):
  1. runtime_data.py         the helper that makes the BIN / ranges at run time           -> created / upgraded
  2. conftest.py             replaces {{FROM_ADD}}, {{LUHN:6}}, {{LOW:BIN:19}} ... BEFORE each test -> created / appended
  3. test file(s)            self.<attr> that nothing sets, bare RuntimeData.resolve(...), duplicate fixtures -> repaired
  4. Excel workbook          sheets, rows, tokens (View/Edit/Delete BIN must be {{FROM_ADD}}), negative messages
  5. test functions          which tests exist: add / view / edit / delete / NEGATIVE (data without tests = nothing runs)
  6. pytest --collect-only   what pytest REALLY collects (import errors, empty sheets)
  8. --filters              (add it) lists the pytest.ini options / conftest hooks that can drop tests silently
  7. numbers                 BIN passes Luhn, ranges are 19 digits and start with the BIN, View/Edit/Delete use Add's BIN
"""
import os
import re
import shutil
import subprocess
import sys
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from scripts.generate_scenario import (  # noqa: E402
    CONFTEST_MARKER, RUNTIME_DATA_MARKER, _RUN_TAG_RE, _STD_COLS, _mark_names, _plausible_time_tag, ensure_module_conftest,
    ensure_runtime_data_util, find_hardcoding_in_page, harden_module_files, normalize_test_self_usage, repair_option_xpaths,
    repair_option_xpaths_in_module, strip_run_tags_in_workbook,
)

OK, BAD, WARN, FIX = "  [ OK  ]", "  [FAIL ]", "  [ !!  ]", "  [FIXED]"


def _bank_from_config() -> str | None:
    """The bank comes from src\\config.yaml (the same file the framework uses) - there is no built-in default."""
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def kind_of(name: str) -> str:
    low = name.lower()
    if "negative" in low:
        return "negative-edit" if "edit" in low else "negative"
    for k in ("delete", "edit", "view", "add", "status", "search"):
        if k in low:
            return k
    return "other"


def scan_test_functions(files: list[Path]) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in files:
        try:
            tree = ast.parse(f.read_text(encoding="utf-8"))
        except SyntaxError as exc:
            print(f"{BAD} {f.name} has a SYNTAX ERROR: {exc} - pytest cannot even import it")
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                out.setdefault(kind_of(node.name), []).append(node.name)
    return out


def _load_dp():
    import importlib.util
    path = ROOT / "src" / "common" / "utilities" / "data_prepare.py"
    if not path.exists():
        return None
    spec = importlib.util.spec_from_file_location("dp_doctor", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def check_option_xpaths(module: str, bank: str) -> None:
    """//mat-option[contains(text(),'Visa')] never matches an Angular Material option (its text sits in a child <span>): the dropdown
    opens, the option click times out, nothing is selected and the test never gets further."""
    files = sorted((ROOT / "src" / "banks" / bank / "locators").glob(f"{module}*.py")) \
        + sorted((ROOT / "src" / "common" / "pages" / module).glob("*.py")) + sorted((ROOT / "src" / "testcase" / module).glob("test_*.py"))
    hits = []
    for f in files:
        _new, n = repair_option_xpaths(f.read_text(encoding="utf-8", errors="ignore"))
        if n:
            hits.append((f.name, n))
    if not hits:
        print(f"{OK} no mat-option XPath of the form contains(text(), ..) in the module's locators / page / test files")
        return
    print(f"{BAD} {sum(n for _f, n in hits)} dropdown-option XPath(s) can never match (contains(text(),..) on a mat-option): "
          + ", ".join(f"{f} x{n}" for f, n in hits))
    fixed = repair_option_xpaths_in_module(ROOT, bank, module, log=lambda m: None)
    print(f"{FIX} {fixed} XPath(s) now use contains(normalize-space(.),..) (copies of the old files: debug_logs\\backups\\*.before_option_fix)")


_DATA_KEY_RE = re.compile(r"""\bdata\[\s*(['"])(.+?)\1\s*\]""")


def check_data_keys(module: str, bank: str, xlsx: Path, repair: bool = True) -> None:
    """The page / test code reads  data["Card Type"]  - the key must be spelled EXACTLY like the Excel header (a 'Card type' header =
    KeyError), in every sheet. Shows header spellings that differ between sheets and keys that match no header; with repair the headers
    of all sheets (and the template) take the spelling of the Add sheet and the code keys follow."""
    try:
        import openpyxl
    except ImportError:
        return
    if not xlsx.exists():
        return
    norm = lambda s: re.sub(r"\s+", " ", str(s).strip()).lower()
    files = sorted((ROOT / "src" / "common" / "pages" / module).glob("*.py")) + sorted((ROOT / "src" / "testcase" / module).glob("test_*.py"))
    keys: dict[str, set[str]] = {}
    for f in files:
        for m in _DATA_KEY_RE.finditer(f.read_text(encoding="utf-8", errors="ignore")):
            keys.setdefault(m.group(2), set()).add(f.name)
    wb = openpyxl.load_workbook(xlsx, read_only=True)
    sheets = {ws.title: [str(c).strip() for c in next(ws.iter_rows(values_only=True), []) if c is not None] for ws in wb.worksheets}
    wb.close()
    groups: dict[str, dict[str, list[str]]] = {}
    for sh, hdr in sheets.items():
        for h in hdr:
            groups.setdefault(norm(h), {}).setdefault(h, []).append(sh)
    canonical: dict[str, str] = {}
    for n, spell in groups.items():
        add_spell = next((h for h, shs in spell.items() if any(s.lower() == "add" for s in shs)), None)
        canonical[n] = add_spell or max(spell, key=lambda h: len(spell[h]))
    inconsistent = {n: sp for n, sp in groups.items() if len(sp) > 1}
    all_headers = {h for hdr in sheets.values() for h in hdr}
    wrong_keys = {k: fs for k, fs in keys.items() if k not in all_headers}
    if not inconsistent and not wrong_keys:
        print(f"{OK} every data[\"..\"] key in the code is spelled exactly like an Excel header, and the sheets spell their headers alike")
        return
    for n, sp in list(inconsistent.items())[:8]:
        print(f"{WARN} header spelled differently per sheet: " + "  |  ".join(f"'{h}' in {', '.join(shs)}" for h, shs in sp.items())
              + f"   -> '{canonical[n]}'")
    for k, fs in list(wrong_keys.items())[:8]:
        target = canonical.get(norm(k))
        print(f"{BAD} the code reads data[\"{k}\"] ({', '.join(sorted(fs))}) but no Excel header is spelled like that"
              + (f" - the header is '{target}'" if target else " - no similar header exists (KeyError at run time)"))
    if not repair:
        return
    try:
        changed_cells = 0
        for f in (xlsx, xlsx.with_name(xlsx.stem + ".template.xlsx")):
            if not f.exists():
                continue
            wb = openpyxl.load_workbook(f)
            for ws in wb.worksheets:
                for c in ws[1]:
                    if c.value is not None and norm(c.value) in canonical and str(c.value).strip() != canonical[norm(c.value)]:
                        c.value = canonical[norm(c.value)]
                        changed_cells += 1
            if changed_cells:
                bak = f.with_name(f.stem + ".headers.bak.xlsx")
                if not bak.exists():
                    shutil.copy2(f, bak)
                wb.save(f)
            wb.close()
        fixed_keys = 0
        for f in files:
            text = f.read_text(encoding="utf-8")

            def sub(m):
                nonlocal fixed_keys
                k = m.group(2)
                tgt = canonical.get(norm(k))
                if tgt and tgt != k:          # a key that is only another spelling of a header (also of one that was just renamed)
                    fixed_keys += 1
                    return m.group(0).replace(k, tgt, 1)
                return m.group(0)
            new = _DATA_KEY_RE.sub(sub, text)
            if new != text:
                shutil.copy2(f, f.with_suffix(".py.bak"))
                f.write_text(new, encoding="utf-8")
        print(f"{FIX} headers unified ({changed_cells} cell(s), copy: *.headers.bak.xlsx) and {fixed_keys} data[..] key(s) in the code spelled like the headers")
    except PermissionError:
        print(f"{BAD} the workbook is OPEN in Excel - close it and run again")


def check_hardcoding(module: str, bank: str) -> None:
    """A page method must hold no selector and no fixed value: selectors live in the locators class (templates with {value}), values
    come from data[...]. Inline selectors are moved into the locators class; what cannot be fixed safely by a script (a radio option
    fixed in the locator's name, a typed literal) is listed - the new prompt makes the AI write those data-driven when the module is
    generated again (fresh_start.py + run_scenario.py)."""
    pages = sorted((ROOT / "src" / "common" / "pages" / module).glob("*_page.py"))
    if not pages:
        return
    n = harden_module_files(ROOT, bank, module, log=lambda m: None)
    if n:
        print(f"{FIX} {n} fix(es) in the page / locators code: inline selectors moved into the locators class, the dropdown option "
              f"template upgraded, dropdowns now call select_mat_option (old files: debug_logs\\backups\\*.before_*)")
    else:
        print(f"{OK} the page code holds no inline XPath / CSS selector")
    left = []
    for f in pages:
        left += [(f.name, i) for i in find_hardcoding_in_page(f.read_text(encoding="utf-8", errors="ignore"))]
    for fname, issue in left[:10]:
        print(f"{WARN} hard-coded: {issue}   [{fname}]")
    if left:
        print("          -> to get these data-driven: python scripts\\fresh_start.py " + module + "  then  python scripts\\run_scenario.py")


def check_run_tags(xlsx: Path, repair: bool = True) -> None:
    """Values like 'Visa_144400' / 'Active_144400': the OLD uniqueness guard appended a run tag (the time) to columns whose name had
    'code' / 'bin' / 'id' ... - also to DROPDOWN columns. The portal has no option 'Visa_144400', so the selection fails and the
    test never runs. Finds them in the workbook and its template and strips the tag (the original is kept as <name>.bak.xlsx)."""
    try:
        import openpyxl
    except ImportError:
        return
    found: list[tuple[str, str, str]] = []
    for f in (xlsx, xlsx.with_name(xlsx.stem + ".template.xlsx")):
        if not f.exists():
            continue
        wb = openpyxl.load_workbook(f, read_only=True)
        for ws in wb.worksheets:
            it = ws.iter_rows(values_only=True)
            header = [str(c).strip() if c is not None else "" for c in next(it, [])]
            for row in it:
                for col, v in zip(header, row):
                    if col and col.lower().replace(" ", "") not in _STD_COLS and isinstance(v, str) and "@" not in v \
                            and not v.startswith("{{"):
                        m = _RUN_TAG_RE.match(v)
                        if m and _plausible_time_tag(m.group(2)):
                            found.append((ws.title, col, v))
        wb.close()
    if not found:
        print(f"{OK} no run tag (_144400 ...) in any test-data value")
        return
    uniq = sorted({(c, v) for _s, c, v in found})
    print(f"{BAD} {len(found)} test-data value(s) end with a run tag - a dropdown option like that does not exist in the portal, "
          f"so the selection fails and the test never runs:")
    for col, v in uniq[:8]:
        print(f"          - {col}: '{v}'")
    if not repair:
        return
    try:
        total = 0
        for f in (xlsx, xlsx.with_name(xlsx.stem + ".template.xlsx")):
            total += len(strip_run_tags_in_workbook(f))
        print(f"{FIX} removed the run tags ({total} cell(s); original kept as {xlsx.stem}.bak.xlsx). New runs no longer add them.")
    except RuntimeError as exc:
        print(f"{BAD} {exc}")


def check_workbook(xlsx: Path) -> dict[str, int]:
    rows_by_sheet: dict[str, int] = {}
    try:
        import openpyxl
    except ImportError:
        print(f"{WARN} openpyxl is not installed - workbook not checked")
        return rows_by_sheet
    if not xlsx.exists():
        print(f"{BAD} workbook not found: {xlsx}")
        return rows_by_sheet
    dp = _load_dp()
    id_cols = dp.remembered_columns(xlsx) if dp else []
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    print(f"{OK} workbook {xlsx.name}: sheets {wb.sheetnames}")
    print(f"       the value(s) Add generates and the other sheets refer to: {id_cols or '(none found - no {{RANDOM}}/{{LUHN}} token in Add)'}")
    for ws in wb.worksheets:
        it = ws.iter_rows(values_only=True)
        header = [str(c).strip() if c is not None else "" for c in next(it, [])]
        rows = [dict(zip(header, ["" if v is None else str(v) for v in r])) for r in it if any(v not in (None, "") for v in r)]
        rows_by_sheet[ws.title] = len(rows)
        if not rows:
            print(f"{WARN} sheet '{ws.title}' has NO data rows -> its tests run 0 cases (pytest reports 'empty parameter set')")
            continue
        low = ws.title.lower()
        notes = []
        for c in id_cols:
            if low.startswith("negative"):
                continue
            vals = sorted({r.get(c, "") for r in rows})
            if all("{{" in v for v in vals):
                notes.append(f"{c} = {vals[:2]} (a TEMPLATE token: the real value is written before a run)")
            else:
                notes.append(f"{c} = {vals[:2]} (real value)")
        if low.startswith("negative"):
            tbd = sum(1 for r in rows if "TBD-verify-message" in r.get("ExpectedMessage", ""))
            login = sum(1 for r in rows if re.search(r"username|password|captcha", r.get("ExpectedMessage", ""), re.I))
            notes.append(f"{tbd} of {len(rows)} ExpectedMessage still 'TBD-verify-message'" + (f", {login} are LOGIN-page messages (wrong)" if login else ""))
        print(f"       - {ws.title}: {len(rows)} row(s). " + "; ".join(notes))
    wb.close()
    try:                                       # do the values BELONG TOGETHER? (only meaningful once they are real values)
        if dp:
            wb2 = openpyxl.load_workbook(xlsx, read_only=True)
            tokens = any(isinstance(c, str) and "{{" in c for ws in wb2.worksheets for row in ws.iter_rows(values_only=True) for c in row)
            wb2.close()
            if tokens:
                print(f"{WARN} the workbook still holds {{{{...}}}} tokens -> run  python scripts\\prepare_data.py <module>  (or a full pytest run) to write real values")
            else:
                problems = dp.check_consistency(xlsx, id_cols)
                print(OK + " the values belong together (what Add generates is what View/Edit/Delete use; ranges start with their identifier)"
                      if not problems else BAD + " the values do NOT belong together:")
                for pr in problems[:8]:
                    print("          -", pr)
    except Exception as exc:
        print(f"{WARN} consistency check skipped: {str(exc)[:120]}")
    return rows_by_sheet


def scan_filters() -> None:
    """WHY can 'collected 80 items' end in 'no tests ran'? pytest only says '... N deselected' when it deselects by itself. A
    conftest hook that edits `items` directly, an addopts -m / -k / --deselect, ... removes tests silently. Shows every such line."""
    print(f"\n  --- what can DROP tests before they run (copy these lines if the run says 'no tests ran') ---")
    ini_files = [ROOT / n for n in ("pytest.ini", "tox.ini", "setup.cfg", "pyproject.toml")]
    ini_pat = re.compile(r"^\s*(addopts|testpaths|markers|python_files|python_functions|python_classes)\b|(^|\s)-(m|k|n|x)\b|--deselect|--ignore|--reruns|--lf\b|--ff\b|--maxfail|-p\s+no:")
    shown = 0
    for f in ini_files:
        if f.exists():
            for no, ln in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if ini_pat.search(ln):
                    print(f"       {f.name}:{no}: {ln.strip()[:150]}")
                    shown += 1
    conf_pat = re.compile(r"pytest_collection_modifyitems|items\[:\]|items\.clear|items\.remove|deselect|markexpr|getoption\(|pytest_runtestloop|"
                          r"pytest_runtest_protocol|pytest_ignore_collect|collect_ignore|mark\.skip\(|pytest\.skip\(|\.add_marker\(.*skip")
    confs = [ROOT / "conftest.py", ROOT / "src" / "conftest.py", ROOT / "src" / "testcase" / "conftest.py"]
    confs += sorted((ROOT / "src" / "testcase").glob("*/conftest.py"))
    for f in confs:
        if f.exists():
            for no, ln in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if conf_pat.search(ln) and not ln.strip().startswith("#"):
                    print(f"       {f.relative_to(ROOT)}:{no}: {ln.strip()[:150]}")
                    shown += 1
                    if shown > 40:
                        print("       ... (more)")
                        return
    if not shown:
        print("       (nothing found in pytest.ini / conftest.py files)")


def check_marker_filter(files: list[Path], bank: str) -> None:
    """Re-plays the rule of the repo's ROOT conftest (pytest_collection_modifyitems), which DROPS tests SILENTLY - no 'N
    deselected' - when  (a) a test has a bank marker but not the configured bank, or (b) test_type in src/config.yaml is not 'all'
    and the test lacks that marker. Shows which tests it would drop and why."""
    cfg = ROOT / "src" / "config.yaml"
    text = cfg.read_text(encoding="utf-8", errors="ignore") if cfg.exists() else ""
    m_bank = re.search(r"^bank:\s*['\"]?([A-Za-z0-9_\-]+)", text, re.M)
    m_type = re.search(r"^test_type:\s*['\"]?([A-Za-z0-9_\-]+)", text, re.M)
    cfg_bank = m_bank.group(1) if m_bank else bank
    test_type = m_type.group(1) if m_type else "all"
    banks_dir = ROOT / "src" / "banks"
    known = {p.name for p in banks_dir.iterdir() if p.is_dir()} if banks_dir.exists() else set()
    print(f"{OK} src\\config.yaml: bank={cfg_bank}, test_type={test_type}  -> the root conftest keeps a test only if it has "
          f"{'a bank marker for ' + cfg_bank + ' (or none)' }" + (f" AND the marker '{test_type}'" if test_type != "all" else ""))
    dropped: dict[str, list[str]] = {"bank": [], "type": []}
    total = 0
    for f in files:
        try:
            tree = ast.parse(f.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        mod_marks: set[str] = set()
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "pytestmark" for t in node.targets):
                vals = node.value.elts if isinstance(node.value, (ast.List, ast.Tuple)) else [node.value]
                mod_marks |= _mark_names(vals)
        for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
            cm = _mark_names(cls.decorator_list) | mod_marks
            for fn in cls.body:
                if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and fn.name.startswith("test_"):
                    total += 1
                    marks = cm | _mark_names(fn.decorator_list)
                    item_banks = {b for b in known if b in marks}
                    if item_banks and cfg_bank not in item_banks:
                        dropped["bank"].append(f"{fn.name} (has bank marker {sorted(item_banks)}, not '{cfg_bank}')")
                    elif test_type != "all" and test_type not in marks:
                        dropped["type"].append(f"{fn.name} (no @pytest.mark.{test_type})")
    n_drop = len(dropped["bank"]) + len(dropped["type"])
    if not total:
        return
    if n_drop:
        print(f"{BAD} the root conftest would DROP {n_drop} of {total} test function(s) SILENTLY (that is why 'no tests ran'):")
        for why, items in dropped.items():
            for it in items[:6]:
                print(f"          - {it}")
            if len(items) > 6:
                print(f"          ... and {len(items) - 6} more ({why})")
        print("          -> this script adds the missing class-level markers when it repairs the test file (see below); or add "
              f"@pytest.mark.{test_type if test_type != 'all' else cfg_bank} above the class by hand.")
    else:
        print(f"{OK} every test function has the markers the root conftest needs ({total} checked)")


def run_checks(module: str, bank: str, repair: bool = True) -> dict:
    folder = ROOT / "src" / "testcase" / module
    module_title = module[:1].upper() + module[1:]
    result = {"negative_tests": 0}
    print(f"\n=== {module} / {bank} ===")
    # 1. runtime_data.py
    rd = ROOT / "src" / "common" / "utilities" / "runtime_data.py"
    had = rd.exists() and RUNTIME_DATA_MARKER in rd.read_text(encoding="utf-8", errors="ignore")[:200]
    p = ensure_runtime_data_util(ROOT, log=lambda m: None)
    print((OK + " runtime_data.py is current") if had else (FIX + f" runtime_data.py created / upgraded: {p}"))
    # 2. conftest.py
    conf = folder / "conftest.py"
    had = conf.exists() and CONFTEST_MARKER in conf.read_text(encoding="utf-8", errors="ignore")
    if folder.exists():
        c = ensure_module_conftest(ROOT, module, log=lambda m: None)
        print((OK + f" {conf.relative_to(ROOT)} resolves the {{{{...}}}} tokens before every test") if had else
              (FIX + f" {conf.relative_to(ROOT)} written - View/Edit/Delete now get the value Add generated instead of the text {{{{FROM_ADD}}}}"))
    else:
        print(f"{BAD} folder {folder} does not exist - generate the module first (python scripts\\run_scenario.py)")
        return result
    # 3. test files
    files = sorted(folder.glob("test_*.py"))
    if not files:
        print(f"{BAD} no test_*.py in {folder}")
    if files:                                  # BEFORE the repair, so the problem is shown (and not only fixed silently)
        check_marker_filter(files, bank)
    repaired_any = False
    for f in files:
        src = f.read_text(encoding="utf-8")
        fixed, notes = normalize_test_self_usage(src, module, bank)
        if fixed != src and repair:
            repaired_any = True
            shutil.copy2(f, f.with_suffix(".py.bak"))
            f.write_text(fixed, encoding="utf-8")
            print(FIX + f" {f.name} repaired (backup .py.bak):")
            for n in notes:
                print("          -", n)
        else:
            print(OK + f" {f.name}: no missing self.<attribute> / bare RuntimeData.resolve")
    if repaired_any and files:                 # after the repair: do the tests now survive the root conftest's filter?
        print("       re-check after the repair:")
        check_marker_filter(files, bank)
    # 4. workbook
    xlsx_path = ROOT / "src" / "banks" / bank / "testdata" / f"{module_title}.xlsx"
    check_option_xpaths(module, bank)
    check_hardcoding(module, bank)
    if xlsx_path.exists():
        check_run_tags(xlsx_path)
        check_data_keys(module, bank, xlsx_path)
    rows = check_workbook(xlsx_path)
    # 5. which tests exist
    funcs = scan_test_functions(files)
    print(f"{OK} test functions found: " + ", ".join(f"{k}={len(v)}" for k, v in sorted(funcs.items())) if funcs else f"{BAD} no test functions found")
    neg_rows = rows.get("Negative", 0) + rows.get("NegativeEdit", 0)
    n_neg = len(funcs.get("negative", [])) + len(funcs.get("negative-edit", []))
    result["negative_tests"] = n_neg
    if neg_rows and not n_neg:
        print(f"{BAD} {neg_rows} negative row(s) exist in the workbook but NO negative test function exists in {folder.name}\\ - "
              f"that is why no negative case runs (only the data sheet was written; the negative code generation did not finish)."
              f"\n          -> python scripts\\doctor.py {module} --negatives")
    elif neg_rows and rows.get("NegativeEdit", 0) and not funcs.get("negative-edit"):
        print(f"{WARN} sheet 'NegativeEdit' has rows but no Edit-negative test function exists (Add negatives only)")
    # 6. what pytest collects
    try:
        proc = subprocess.run([sys.executable, "-m", "pytest", str(folder), "--collect-only", "-q"],
                              cwd=str(ROOT), capture_output=True, text=True, timeout=240, env=dict(os.environ, AI_PREPARE_DATA="0"))
        out = (proc.stdout or "") + "\n" + (proc.stderr or "")
        if "No module named pytest" in out:
            print(f"{WARN} pytest is not installed in this Python ({sys.executable}) - collection not checked")
        else:
            ids = [ln.strip() for ln in out.splitlines() if "::" in ln and not ln.startswith(("=", "_", " ", "E "))]
            counts: dict[str, int] = {}
            for i in ids:
                counts[kind_of(i.split("::")[-1])] = counts.get(kind_of(i.split("::")[-1]), 0) + 1
            if "error" in out.lower() and "collecting" in out.lower():
                print(f"{BAD} pytest could NOT import the tests:")
                for ln in [l for l in out.splitlines() if l.startswith(("E ", "ERROR")) or "Error" in l][:8]:
                    print("          ", ln.strip()[:170])
            print((OK if ids else BAD) + " pytest collects " + (", ".join(f"{k}={v}" for k, v in sorted(counts.items())) or "NOTHING")
                  + f" ({len(ids)} test case(s))")
            for ph in ("add", "rest"):
                pr = subprocess.run([sys.executable, "-m", "pytest", str(folder), "--collect-only", "-q"], cwd=str(ROOT), capture_output=True,
                                    text=True, timeout=240, env=dict(os.environ, AI_PREPARE_DATA="0", AI_TEST_PHASE=ph))
                sel = [ln for ln in (pr.stdout or "").splitlines() if "::" in ln and not ln.startswith(("=", "_", " "))]
                print((OK if sel else WARN) + f" run_tests.py phase '{ph}' selects {len(sel)} of {len(ids)} test case(s)"
                      + ("" if sel or ph == "rest" else "  <- NO Add test (name must contain 'add' / 'create')"))
            ddesel = [ln for ln in out.splitlines() if "deselected" in ln.lower()]
            if ddesel:
                print(f"{WARN} pytest itself deselects tests (a marker / -k filter in pytest.ini or addopts?): {ddesel[0].strip()[:120]}")
            raw_collected = re.search(r"(\d+)\s+tests?\s+collected", out) or re.search(r"collected\s+(\d+)\s+items?", out)
            if not ids:
                print(f"{BAD} pytest selected NO test to run" + (f" (it says: {raw_collected.group(0)})" if raw_collected else "")
                      + " - a pytest.ini option or a conftest hook removes them silently:")
                scan_filters()
            elif "--filters" in sys.argv:
                scan_filters()
            if any("NOTSET" in i for i in ids):
                print(f"{WARN} some tests have an EMPTY parameter set ([NOTSET]): their Excel sheet is empty / unreadable -> skipped")
            fx = subprocess.run([sys.executable, "-m", "pytest", "--fixtures", "-v", str(folder)],
                                cwd=str(ROOT), capture_output=True, text=True, timeout=240, env=dict(os.environ, AI_PREPARE_DATA="0"))
            loaded = "_resolve_runtime_tokens" in (fx.stdout or "")
            print((OK + " pytest LOADS the token-resolving fixture (_resolve_runtime_tokens)") if loaded else
                  (BAD + " pytest does NOT load _resolve_runtime_tokens - View/Edit/Delete would type the text {{FROM_ADD}}"))
    except subprocess.TimeoutExpired:
        print(f"{WARN} pytest --collect-only timed out")
    # 7. what Add has stored for View/Edit/Delete
    js = ROOT / "runtime_data.json"
    if js.exists():
        try:
            import json
            stored = {k: v for k, v in json.loads(js.read_text(encoding="utf-8")).items() if f".{module}." in k}
            print((OK + f" runtime_data.json holds: {stored}") if stored else
                  (WARN + " runtime_data.json has no value for this module yet - run the Add test first (pytest ... -k add)"))
        except Exception:
            print(f"{WARN} runtime_data.json could not be read")
    else:
        print(f"{WARN} runtime_data.json does not exist yet - it is created by the first Add test")
    return result


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return
    module = argv[0].lower()
    bank = (argv[argv.index("--bank") + 1] if "--bank" in argv and argv.index("--bank") + 1 < len(argv) else _bank_from_config())
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return
    res = run_checks(module, bank)
    if "--negatives" in argv:
        if res["negative_tests"]:
            print(f"\nNegative tests already exist ({res['negative_tests']}) - nothing to re-generate.")
        else:
            print("\nRe-generating the negative TESTS (locators + page + test + the Negative / NegativeEdit data) ...")
            from scripts.run_scenario import _maybe_generate_negative_suite
            folder = ROOT / "src" / "testcase" / module
            written = {
                "locators": next(iter((ROOT / "src" / "banks" / bank / "locators").glob(f"{module}_locators.py")), None),
                "page": next(iter((ROOT / "src" / "common" / "pages" / module).glob(f"{module}_page.py")), None),
                "test": next(iter(sorted(f for f in folder.glob("test_*.py") if "negative" not in f.name)), None),
            }
            _maybe_generate_negative_suite(ROOT, bank, module, f"Add, edit, view and delete a {module} record", written, None,
                                           ask=False, live=False)
            run_checks(module, bank)
    print("\nNext:  python scripts\\run_tests.py " + module + "      (new numbers -> Add (retries with new numbers) -> View -> Edit -> Delete -> negatives)")
    print("   or: pytest src/testcase/" + module + " -s          (a full run writes new numbers at the start by itself)")


if __name__ == "__main__":
    main()
