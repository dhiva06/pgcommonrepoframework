"""capture_negative.py - run the NEGATIVE cases FOR REAL on the live portal and write the portal's own message into ExpectedMessage.

For every row of the 'Negative' sheet (Add form) and the 'NegativeEdit' sheet (Edit form): open the form, fill EVERY field (dropdowns and
radios too), click the final button (Send for approval ...), answer a confirmation popup (Yes), then read what the portal shows - a field
error, a popup, a toast, a snackbar - and save that text in ExpectedMessage (the workbook AND its template).

    python scripts\\capture_negative.py binmanagement
    python scripts\\capture_negative.py binmanagement --max 20          (only the first 20 rows of each sheet)
    python scripts\\capture_negative.py binmanagement --add-only        (or --edit-only)
    python scripts\\capture_negative.py binmanagement --refresh         (also REPLACE messages that are already filled)
    python scripts\\capture_negative.py binmanagement --headless        (no browser window)

It uses the scenario texts saved by the last run_scenario.py. Without them give the menu path and the final button:
    --nav "<menu> > <submenu> > Add"  [--final "<the button that ends the form>"]
    --edit-nav "<menu> > <submenu>"                                      (Edit negatives: search the record, click its edit icon)
    --portal admin|bank|merchant|superadmin                              (default: the one saved by run_scenario.py, else bank)
A row the portal ACCEPTS creates a real record (it is listed in reports\\<module>_negative_capture.txt). Close the Excel file first."""
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from scripts.generate_scenario import ensure_module_conftest, load_module_scenarios, run_negative_cases  # noqa: E402


def _bank_from_config() -> str | None:
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def _opt(argv: list[str], name: str) -> str | None:
    return argv[argv.index(name) + 1] if name in argv and argv.index(name) + 1 < len(argv) else None


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 0
    module = argv[0].lower()
    bank = _opt(argv, "--bank") or _bank_from_config()
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return 1
    if _opt(argv, "--max"):
        os.environ["AI_NEGATIVE_RUN_MAX"] = _opt(argv, "--max")
    if "--refresh" in argv:
        os.environ["AI_NEGATIVE_REFRESH"] = "1"
    if "--headless" in argv:
        os.environ["AI_HEADED"] = "0"
    else:
        os.environ.setdefault("AI_HEADED", "1")
    saved = load_module_scenarios(ROOT, module)
    final = _opt(argv, "--final")                     # None: the usual buttons are tried (Submit / Save / Send for approval ...)
    final_clause = f' Click "{final}".' if final else ""
    add_scenario = saved.get("add", "")
    if _opt(argv, "--nav"):
        add_scenario = f'Navigate to {_opt(argv, "--nav")}.{final_clause}'
    edit_scenario = (saved.get("explicit") or {}).get("edit")
    if _opt(argv, "--edit-nav"):                      # the record Add created is searched by its identifier, whatever its name
        edit_scenario = (f'Navigate to {_opt(argv, "--edit-nav")}. Search for the record. '
                         f'Click the edit icon in the row for that record.{final_clause}')
    portal = _opt(argv, "--portal") or saved.get("portal_type") or "bank"
    if not add_scenario and not edit_scenario:
        print("No saved scenario for this module. Give the menu path:  --nav \"<menu> > <submenu> > Add\"  "
              "[--final \"<final button>\"]  [--edit-nav \"<menu> > <submenu>\"]  [--portal admin|bank|merchant|superadmin]")
        return 1
    identifier = None                                   # the record Add created (Edit negatives edit it; the duplicate row repeats it)
    store = ROOT / "runtime_data.json"
    if store.exists():
        try:
            for k, v in json.loads(store.read_text(encoding="utf-8")).items():
                parts = k.split(".", 2)
                if len(parts) == 3 and parts[0] == bank and parts[1] == module:
                    identifier = {"label": parts[2], "value": str(v)}
                    break
        except Exception:
            pass
    if identifier:
        print(f"Record from the last Add: {identifier['label']} = {identifier['value']}")
    else:
        print("No record from an Add run was found in runtime_data.json: Edit negatives are skipped, the duplicate row cannot be tested.")
    only = "add" if "--add-only" in argv else ("edit" if "--edit-only" in argv else None)
    res = run_negative_cases(ROOT, bank, portal, module, add_scenario, edit_scenario, identifier, only=only)
    if res.get("error"):
        print("Stopped:", res["error"])
        return 1
    print(f"\n{res['captured']} message(s) captured of {res['rows']} row(s); {res['accepted']} row(s) were ACCEPTED by the portal "
          f"(a record was created / changed - see reports\\{module}_negative_capture.txt).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
