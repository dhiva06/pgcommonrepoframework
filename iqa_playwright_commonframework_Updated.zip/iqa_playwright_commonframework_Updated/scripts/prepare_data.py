"""prepare_data.py - write REAL NUMBERS into a module's test-data workbook (no {{...}} tokens).

    python scripts\\prepare_data.py binmanagement
    python scripts\\prepare_data.py binmanagement --bank ecentric

Works for ANY module: the column(s) that Add generates (a {{RANDOM..}} / {{LUHN..}} token in the Add sheet: a BIN, a Merchant ID,
a Name ...) get NEW values, everything derived from them (e.g. 'BIN low range' = BIN + zeros) follows, and View, Edit, Delete and every
negative / negative-edit row get values that belong to them - so the record Add creates is exactly the record that is searched later. Run it before a test run whenever you want fresh numbers (a full `pytest <file>` run
does the same automatically at start). Close the workbook in Excel first. The token version of the sheets is kept as
<Module>.template.xlsx."""
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from scripts.generate_scenario import ensure_module_conftest, materialize_testdata_numbers  # noqa: E402


def _bank_from_config() -> str | None:
    """The bank comes from src\\config.yaml (the same file the framework uses) - there is no built-in default."""
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def show(xlsx: Path, id_cols: list[str]) -> None:
    import importlib.util
    import openpyxl
    spec = importlib.util.spec_from_file_location("dp_show", ROOT / "src" / "common" / "utilities" / "data_prepare.py")
    dp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(dp)
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    print("\nValues now in the workbook (first row of each sheet; the generated value(s) and what is derived from them):")
    for name in wb.sheetnames:
        it = wb[name].iter_rows(values_only=True)
        header = [str(c).strip() if c is not None else "" for c in next(it, [])]
        row = dict(zip(header, next(it, [])))
        cols = [h for h in header if h in id_cols or any(dp._range_kind(h, c) for c in id_cols)]
        if cols:
            print(f"  {name:13} " + "   ".join(f"{c}={row.get(c)}" for c in cols))
    wb.close()


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 0
    module = argv[0].lower()
    bank = (argv[argv.index("--bank") + 1] if "--bank" in argv and argv.index("--bank") + 1 < len(argv) else _bank_from_config())
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return 1
    xlsx = ROOT / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    if not xlsx.exists():
        print(f"Workbook not found: {xlsx}")
        return 1
    ensure_module_conftest(ROOT, module, log=lambda m: None)
    info = materialize_testdata_numbers(ROOT, bank, module)
    if not info:
        print("Nothing was written (see the message above). Is the workbook open in Excel?")
        return 1
    show(xlsx, info.get("id_columns", []))
    if info.get("problems"):
        print("\nThe numbers do NOT belong together:")
        for p in info["problems"]:
            print("  -", p)
        return 1
    print("\nAll values belong together (what Add generates is what View/Edit/Delete use; a Luhn column passes the check; ranges start with their identifier).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
