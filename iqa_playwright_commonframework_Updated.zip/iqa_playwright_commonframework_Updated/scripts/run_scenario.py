"""
run_scenario.py - FULL AUTO mode.

You give: bank, module, scenario, target URL, and the path to your REAL
framework repo. This script then, with NO manual copy-paste step:

  1. Inspects the live URL for real selectors (if given).
  2. Calls the AI to generate locators/page/test/testdata, using your
     real base_page.py + sample files as read-only reference (base_page.py
     itself is never written to or changed).
  3. Writes the generated files DIRECTLY into the real repo's real paths:
       src/banks/<bank>/locators/<module>_locators.py
       src/common/pages/<module>/<module>_page.py
       src/testcase/<module>/test_<module>.py
       src/banks/<bank>/testdata/<Module>.xlsx   (built automatically from CSV)
     creating any missing folders/__init__.py needed.
  4. Runs `pytest -k <module>` automatically inside that repo and shows
     you the result.

Just run it and answer the prompts - that's the only place you type
anything:

    python scripts/run_scenario.py

First time, it will ask for your repo path once; after that it remembers
it for the session (or pass --root to skip the question every time).
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.common.utilities.ai_backend import ask_ai  # noqa: E402
from scripts.generate_scenario import (  # noqa: E402
    _log_exception, dry_run_scenario_execution, generate_negative_suite, validate_negative_suite,
    merge_module_into_single_file, negative_generation_enabled, restore_negative_seed_sheets,
    negative_layout, rewrite_negative_imports, merge_negative_into_positive_files, dry_run_negative_cases, materialize_testdata_numbers, clean_choice_suffixes, harden_module_files, save_module_scenarios, is_commit_action,
    load_reference_files, inspect_url, capture_login_session, perform_logout, build_user_prompt,
    auto_write_into_repo, parse_and_write, find_existing_locators, find_existing_page_class,
    find_existing_test_file, extract_action_from_scenario, load_real_login_files,
    login_via_real_framework, verify_and_heal_locators_file, guess_portal_type,
    detect_bank_from_url, run_with_auto_fix, update_module_readme, analyze_coverage_gaps,
    attempt_user_guided_fix, run_pytest, visually_verify_latest_screenshot, SYSTEM_PROMPT,
    run_full_module_pipeline, parse_batch_file, parse_url_list_file, read_multiline_scenario_block,
    run_guided_scenario_collection, run_multibank_discovery, review_scenario_for_gaps,
    dry_run_verify_interactions, read_first_testdata_row, deep_triage_single_failure,
    generate_locator_confidence_report,
    explore_module_via_menu, explore_module_via_url,
    extract_add_form_fields_detailed, collect_field_values_interactively,
    load_bank_notes,
    discover_full_menu_tree, write_discovered_urls_file, triage_pytest_failures,
    check_module_staleness, audit_dispatch_grouping, generate_regression_summary,
    run_pytest_multi, record_test_run_result, detect_flaky_modules,
    extract_failed_modules_from_pytest_output,
    collect_fields_manually,
)

ADDON_ROOT = Path(__file__).resolve().parents[1]


def cleanup_stray_files(repo_root: Path) -> None:
    """Automatically removes leftover broken files from earlier failed runs
    (e.g. a stray src/testcase/test_.py left behind when a module name was
    accidentally typed empty/wrong) - this is what stops the SAME collection
    error from blocking every future run. Every proper test file lives in
    its own src/testcase/<module>/ subfolder per this framework's
    convention, so any .py file sitting directly at the testcase root
    (other than __init__.py) is always a stray leftover, never legitimate."""
    testcase_root = repo_root / "src" / "testcase"
    if not testcase_root.exists():
        return
    removed = []
    for f in testcase_root.glob("*.py"):
        if f.name != "__init__.py":
            f.unlink()
            removed.append(f.name)
    if removed:
        print(f"Cleaned up stray leftover file(s) from testcase root: {removed}")
    # Also clear bytecode cache so a stale compiled version of a removed
    # file can never be picked up by pytest.
    for cache_dir in repo_root.rglob("__pycache__"):
        import shutil
        shutil.rmtree(cache_dir, ignore_errors=True)


def _run_scenario_dry_runs(repo_root, bank, portal_type, module, scenario, explicit_scenarios, written):
    """Scenario-driven dry run for EVERY action given. Order: Add first, View / Search / Edit / ChangeStatus next, Delete LAST.
    The Add dry run is really SAVED when View/Edit/Delete scenarios follow (AI_DRYRUN_COMMIT_ADD=0 turns that off): they all
    search for THAT record, so the BIN Add generated is handed to them. Opening an edit / delete icon is never destructive -
    only the final confirmation (Yes / Send for approval) is left unclicked."""
    if os.environ.get("AI_DRY_RUN_INTERACTIONS", "1") == "0" or os.environ.get("AI_DRY_RUN_SCENARIO", "1") == "0":
        print("  [SKIPPED] scenario dry-run: disabled via AI_DRY_RUN_INTERACTIONS=0 / AI_DRY_RUN_SCENARIO=0")
        return {}
    jobs = []
    if (scenario or "").strip():
        jobs.append(("add", scenario))
    later = [(k, t) for k, t in (explicit_scenarios or {}).items() if (t or "").strip()]
    order = {"view": 1, "search": 1, "edit": 2, "update": 2, "modify": 2, "change": 2, "changestatus": 3, "status": 3, "delete": 9}

    def rank(key: str) -> float:
        k = key.lower()
        if k != "add" and is_commit_action(k):
            return 0                                              # the checker step (approve ...) comes right after Add
        return order.get(k, 5)
    later.sort(key=lambda kt: rank(kt[0]))                        # stable: unknown actions keep their order, Delete is last
    jobs += later
    if not jobs:
        print("  [SKIPPED] scenario dry-run: no scenario text was given (DOM/FILE/SCREENSHOT mode) - nothing to execute.")
        return {}
    follow_ups = any(rank(k) != 5 for k, _ in later)
    commit_add = follow_ups and os.environ.get("AI_DRYRUN_COMMIT_ADD", "1").strip().lower() not in ("0", "false", "no")
    if commit_add:
        print("  [scenario-run] NOTE: the Add dry run will really SAVE its record (a pending BIN in the test environment) - "
              "View / Edit / Delete need a real record to search for. AI_DRYRUN_COMMIT_ADD=0 turns this off.")
    outcomes, identifier = {}, None
    for action, text in jobs:
        td_path = (written or {}).get(f"testdata_{action}") or (written or {}).get("testdata_add") or (written or {}).get("testdata")
        row = read_first_testdata_row(td_path, sheet_name=action.capitalize()) if td_path else {}
        if action != "add" and not (identifier and outcomes.get("add", {}).get("committed")):
            print(f"  [scenario-run] NOTE: no saved record is available for '{action}' (Add "
                  f"{'was not saved' if 'add' in outcomes else 'did not run'}) - its search step will report that.")
        outcomes[action] = dry_run_scenario_execution(repo_root, bank, portal_type, module, action, text, testdata_values=row,
                                                      identifier=identifier, commit_final=(is_commit_action(action) and commit_add))
        if action == "add":
            identifier = outcomes[action].get("identifier")
            if identifier:
                print(f"  [scenario-run] Add generated {identifier['label']} = {identifier['value']}"
                      f"{' and saved it' if outcomes[action].get('committed') else ' (NOT saved)'}")
    print(f"\n  [scenario-run] SUMMARY for module '{module}':")
    for action, o in outcomes.items():
        ran = o.get("ok", 0) + o.get("warned", 0) + o.get("failed", 0)
        if o.get("error"):
            state = "RUN ERROR"
        elif not ran:
            state = "NOTHING RAN - no step of the scenario was recognised (see the wording hints above)"
        else:
            state = "FAILED STEPS" if o.get("failed") else "OK"
        print(f"    {action}: {state} ({o.get('ok', 0)} ok, {o.get('warned', 0)} warning, {o.get('failed', 0)} failed)")
    print(f"  Per-step reports: {repo_root / 'reports'}  |  filled-form screenshots: {repo_root / 'ai_debug_dom'}")
    return outcomes


def _merge_scenario_status(outcomes) -> dict:
    """Combines every action's per-locator result (worst result wins) for the confidence report."""
    order = ["FAILED", "HEALED_path", "HEALED_attr", "FINAL_FOUND", "OK"]
    merged: dict[str, str] = {}
    for o in (outcomes or {}).values():
        for attr, st in (o.get("locator_status") or {}).items():
            if attr not in merged or order.index(st) < order.index(merged[attr]):
                merged[attr] = st
    return merged


_EDIT_KEYS = ("edit", "update", "modify", "change", "amend")        # a scenario labelled 'Update:' is the module's EDIT form


def _edit_scenario_text(explicit_scenarios) -> str | None:
    for k, t in (explicit_scenarios or {}).items():
        if k.lower() in _EDIT_KEYS and (t or "").strip():
            return t
    return None


def _maybe_generate_negative_suite(repo_root, bank, module, scenario, written, outcomes=None, ask=True,
                                   explicit_scenarios=None, portal_type=None, live=False):
    """The negative step, then: the workbook gets REAL numbers (BIN, low / high range) in every sheet."""
    save_module_scenarios(repo_root, module, scenario, explicit_scenarios, portal_type)       # so the negative run can be repeated later
    out = _negative_step(repo_root, bank, module, scenario, written, outcomes, ask, explicit_scenarios, portal_type, live)
    try:
        harden_module_files(repo_root, bank, module)         # negative code may carry the same inline option XPath
    except Exception as exc:
        _log_exception("repairing mat-option XPaths", exc)
    try:
        all_facts = [f for o in (outcomes or {}).values() for f in (o.get("field_facts") or [])]
        clean_choice_suffixes(repo_root, bank, module, all_facts)      # dropdown values keep the portal's exact option text
    except Exception as exc:
        _log_exception("cleaning dropdown values", exc)
    try:
        materialize_testdata_numbers(repo_root, bank, module)
    except Exception as exc:
        _log_exception("writing real numbers into the workbook", exc)
    return out


def _negative_step(repo_root, bank, module, scenario, written, outcomes=None, ask=True,
                   explicit_scenarios=None, portal_type=None, live=False):
    """Negative cases are generated BY DEFAULT now (no y/n question): ONE negative file (negative locators + page +
    test classes) and ONE 'Negative' sheet. AI_GENERATE_NEGATIVE=0 turns it off. If it cannot be generated, the negative
    rows already moved out of the positive sheets are written back as a 'Negative' sheet, so nothing is lost."""
    if not negative_generation_enabled():
        print("  [negative] skipped: AI_GENERATE_NEGATIVE=0 in your env/.env")
        return {}
    print("\n  [negative] generating the negative cases (" +
          {"single": "ONE file with negative locators + page + test classes",
           "separate": "THREE separate files: negative locators, negative page, negative test",
           "inline": "negative locators/page/test go INTO the same locators/page/test files as the positive ones"}[negative_layout()]
          + ")...")
    facts = {"add": [], "edit": []}                   # each form has its OWN fields / limits
    for act_, o in (outcomes or {}).items():
        if act_ == "add" and o.get("field_facts"):
            facts["add"] = o["field_facts"]
        elif act_.lower() in _EDIT_KEYS and o.get("field_facts"):
            facts["edit"] = o["field_facts"]
        elif o.get("field_facts") and not facts["add"]:
            facts["add"] = o["field_facts"]
    out = {}
    try:
        out = generate_negative_suite(repo_root, bank, module, scenario or "", written or {}, field_facts=facts)
    except Exception as exc:
        _log_exception("negative suite generation", exc)
    if not out.get("negative_test"):
        print("  [negative] !!! the negative file was NOT generated (reason printed above).")
        try:
            restore_negative_seed_sheets(repo_root, bank, module)
        except Exception as exc:
            _log_exception("restoring negative seed rows", exc)
        return out
    if live and out.get("negative_testdata") and os.environ.get("AI_NEGATIVE_DRYRUN", "1").strip().lower() not in ("0", "false", "no"):
        # the negative rows run on the LIVE portal like Add / View / Edit / Delete: real validation messages are captured
        try:
            add_o = (outcomes or {}).get("add", {})
            dry_run_negative_cases(repo_root, bank, portal_type or "bank", module, scenario or "",
                                   _edit_scenario_text(explicit_scenarios), add_o.get("identifier"))
        except Exception as exc:
            _log_exception("negative dry run", exc)
    vflag = os.environ.get("AI_VALIDATE_NEGATIVE", "").strip().lower()
    run_it = vflag in ("1", "true", "yes")
    if not run_it and vflag not in ("0", "false", "no") and ask:
        run_it = input("\nRun the negative tests now to VALIDATE them (shows exactly which rows pass / why others fail)? "
                       "(y/n) [n]: ").strip().lower() in ("y", "yes")
    if run_it:
        try:
            validate_negative_suite(repo_root, module)
        except Exception as exc:
            _log_exception("negative validation", exc)
    if negative_layout() == "inline" and all(out.get(k) for k in ("negative_locators", "negative_page", "negative_test")):
        try:
            merge_negative_into_positive_files(repo_root, bank, module, written or {})
        except Exception as exc:
            _log_exception("folding the negative files into the positive files", exc)
    return out


def _maybe_merge_single_file(repo_root, bank, module, written_dicts):
    """ONE-FILE MODE (default ON, AI_SINGLE_FILE=0 turns it off): as the very LAST step - after heal, dry run,
    negative generation and validation - merge locators + page + tests (+ the negative file) into
    src/testcase/<module>/test_<module>_<bank>.py. Every 'written' dict is updated in place so the pytest /
    auto-fix step that follows works on the merged file."""
    if os.environ.get("AI_SINGLE_FILE", "0").strip().lower() not in ("1", "true", "yes"):
        return None
    combined: dict = {}
    for w in written_dicts:
        combined.update(w or {})
    try:
        dest = merge_module_into_single_file(repo_root, bank, module, combined)
    except Exception as exc:
        _log_exception("one-file merge", exc)
        return None
    if dest:
        for w in written_dicts:
            for k in ("locators", "page", "test") + (("negative_test",) if negative_layout() == "single" else ()):
                if w is not None and k in w:
                    w[k] = dest
        if negative_layout() == "separate":
            try:
                rewrite_negative_imports(repo_root, bank, module, dest)
            except Exception as exc:
                _log_exception("rewriting the negative files' imports", exc)
    return dest


def _verify_and_dry_run(repo_root, bank, portal_type, module, scenario, explicit_scenarios, written, heal=True):
    """Post-generation verification for INTERACTIVE mode (same stages batch mode already had):
    locator auto-heal -> field-by-field dry run -> scenario-driven dry run -> confidence report."""
    if "locators" not in (written or {}):
        print("  [SKIPPED] verification + dry-run: no locators file was written, nothing to verify.")
        return {}
    _outcomes = {}
    healed_attrs, agentic_healed_attrs, dry_warnings = {}, {}, []
    if heal and os.environ.get("AI_AUTO_HEAL_LOCATORS", "1") != "0":
        print("\nVerifying every locator against the live page...")
        healed, healed_attrs, agentic_healed_attrs = verify_and_heal_locators_file(
            repo_root, bank, portal_type, module, scenario or "",
            extra_scenarios=list((explicit_scenarios or {}).items()))
        print(f"  Healed {healed} locator(s)." if healed else "  All locators already resolve correctly on the live page.")
    if os.environ.get("AI_DRY_RUN_INTERACTIONS", "1") != "0":
        td_path = written.get("testdata_add") or written.get("testdata")
        row = read_first_testdata_row(td_path) if td_path else {}
        print("\nDry-running each field's real interaction (stopping before Save/Submit)...")
        if os.environ.get("AI_FIELD_DRYRUN", "0") == "1":
            dry_warnings = dry_run_verify_interactions(repo_root, bank, portal_type, module, scenario or "", testdata_values=row)
            for w in dry_warnings:
                print(f"    WARNING (dry-run): {w}")
            if not dry_warnings:
                print("  Every field's real fill/select/check interaction succeeded.")
        else:
            print("  (field-by-field pass skipped - the scenario dry run below exercises the real steps; "
                  "set AI_FIELD_DRYRUN=1 to also run it)")
        _outcomes = _run_scenario_dry_runs(repo_root, bank, portal_type, module, scenario, explicit_scenarios, written)
        try:
            report = generate_locator_confidence_report(repo_root, bank, module, healed_attrs, agentic_healed_attrs,
                                                        dry_warnings, scenario_status=_merge_scenario_status(_outcomes),
                                                        field_dryrun_ran=os.environ.get("AI_FIELD_DRYRUN", "0") == "1")
            print(f"\n{report}")
            rd = repo_root / "reports"
            rd.mkdir(exist_ok=True)
            (rd / f"{module}_locator_confidence.txt").write_text(report, encoding="utf-8")
        except Exception as exc:
            _log_exception("confidence report", exc)
    return _outcomes


def run_one_scenario(repo_root):
    """Runs one full scenario -> code -> write -> test cycle. Extracted
    from main() so multiple scenarios/modules can be processed in a
    single BATCH session without restarting the script or re-entering
    the repo path each time - see main()'s batch loop below."""
    cleanup_stray_files(repo_root)

    url = input("Login URL (optional - only used to help detect the bank, "
                "press Enter to skip): ").strip() or None

    portal_type = ""
    while portal_type not in ("admin", "bank", "merchant", "superadmin"):
        portal_type = input("Portal type (admin/bank/merchant/superadmin): ").strip().lower()
        if portal_type not in ("admin", "bank", "merchant", "superadmin"):
            print("Please type exactly one of: admin, bank, merchant, superadmin")

    menu_name = input(
        "Menu / Submenu path this module sits under (e.g. 'Configuration > Brand Type') - "
        "press Enter to skip if your scenario already describes navigation, or if you're "
        "using DOM mode below: "
    ).strip()

    ref_dir = ADDON_ROOT / "reference"
    if not ref_dir.exists() or not any(ref_dir.glob("*.py")):
        print(f"ERROR: put your real base_page.py + sample locators/page/test files into {ref_dir} first.")
        sys.exit(1)
    ref_text = load_reference_files(ref_dir)

    # Bank: try to auto-detect from the URL (matches against every bank's
    # real credentials.yaml) before falling back to asking.
    bank = detect_bank_from_url(repo_root, url)
    if bank:
        confirm_bank = input(f"Detected bank '{bank}' from the URL - use this? "
                              f"(y/n, press Enter for y): ").strip().lower()
        if confirm_bank not in ("", "y", "yes"):
            bank = None
    if not bank:
        bank = ""
        while not bank:
            bank = input("Bank name (e.g. wio): ").strip().lower()
            if not bank:
                print("Bank name cannot be empty - please type it.")

    module = ""
    while not module or " " in module:
        module = input("Module name (e.g. brand, merchant - NO spaces): ").strip().lower()
        if not module:
            print("Module name cannot be empty - please type it.")
        elif " " in module:
            print(f"Module name cannot contain spaces. You typed '{module}' - "
                  f"try again as one word, e.g. '{module.replace(' ', '')}'")
            module = ""

    def _with_menu(text: str) -> str:
        """Prepends the menu/submenu path given above, unless the text
        already describes navigation itself - this is what lets the
        scenario/MULTI text stay focused on just the action steps
        instead of repeating 'Navigate to X menu' every single time."""
        if not menu_name or not text:
            return text
        if text.strip().lower().startswith(("navigate", "login", "go to")):
            return text
        return f"Navigate to {menu_name}, then {text[0].lower()}{text[1:]}"

    print("\nScenario - describe the test steps in plain English:")
    print("(Or type MULTI to describe View/Edit/ChangeStatus yourself too instead of letting AI "
          "derive them. Or type GUIDED to answer simple y/n questions about which actions this "
          "module has instead of typing labels yourself - also asks about a 'Search by' "
          "dropdown if this module has one. Or type DOM to skip describing anything - AI logs "
          "in and reads the module's live page itself. Or type FILE if live browser automation "
          "keeps failing for you - paste HTML you copied yourself from your own browser "
          "instead. Or type SCREENSHOT - the simplest option if automation keeps failing - just "
          "give 1-2 screenshot images (listing page + the Add form) and AI reads them directly, "
          "no Playwright, no DOM copy-paste at all.)")
    first_line = input("> ").strip()
    used_multi_mode = (first_line.upper() == "MULTI")
    used_guided_mode = (first_line.upper() == "GUIDED")
    used_dom_mode = (first_line.upper() == "DOM")
    used_file_mode = (first_line.upper() == "FILE")
    used_screenshot_mode = (first_line.upper() == "SCREENSHOT")
    pre_supplied_explicit: dict[str, str] = {}
    dom_module_url = None
    dom_pre_scanned_html = None
    dom_field_values: dict[str, str] = {}
    dom_field_constraints: dict[str, str] = {}
    manual_html_path = None
    screenshot_paths: list[str] = []
    search_by_fields: list[str] | None = None
    if used_multi_mode:
        # Add is always optional here - either the module already has it
        # (existing page file found), or this module simply has no
        # Add/create flow at all in the real application (e.g. a
        # settings screen that only configures pre-existing records) -
        # either way, the person types only the action(s) that actually
        # apply and run_full_module_pipeline figures out which case it
        # is from whether an existing page file is found.
        parsed = read_multiline_scenario_block(require_add=False)
        scenario = _with_menu(parsed.pop("add", "").strip())
        pre_supplied_explicit = {k: _with_menu(v) for k, v in parsed.items()}
    elif used_guided_mode:
        parsed, search_by_fields = run_guided_scenario_collection()
        scenario = _with_menu(parsed.pop("add", "").strip())
        pre_supplied_explicit = {k: _with_menu(v) for k, v in parsed.items()}
        if not scenario and not pre_supplied_explicit:
            print("Nothing was confirmed for this module - nothing to generate. Try again.")
            return
        # Automatic DOM scanning has been unreliable for some real
        # portals (iframes, legacy JS widgets it can't see through) -
        # offers a SEPARATE, ALTERNATIVE way to give field-level detail
        # for Edit/Add - this is an EITHER/OR with the scenario text
        # above, never an AND: if that scenario already spelled out
        # every field name and value (as a detailed one describes),
        # answering "n" here is correct and expected - saying "y" on
        # top of an already-detailed scenario just repeats the same
        # information a second time. Only useful when the scenario was
        # brief/high-level (e.g. "update the fields, click Save") and
        # didn't itself name which fields or values to use.
        guided_action_for_fields = "Edit" if "edit" in pre_supplied_explicit else ("Add" if scenario else None)
        if guided_action_for_fields and input(
            f"\nDescribe the {guided_action_for_fields} form's fields ONE MORE TIME, field-by-"
            f"field (y), or skip this - press Enter for n - if your scenario above ALREADY "
            f"named every field/value you need (most detailed scenarios already do, so Enter/n "
            f"is usually the right answer here): "
        ).strip().lower() in ("y", "yes"):
            manual_fields = collect_fields_manually(guided_action_for_fields)
            if manual_fields:
                dom_field_values = collect_field_values_interactively(manual_fields)
                dom_field_constraints = {f["label"]: f["constraint"] for f in manual_fields if f.get("constraint")}
    elif used_screenshot_mode:
        scenario = ""
        print("\nGive the path to a screenshot of the module's LISTING page. Then, if you have "
              "one, the path to a screenshot of the Add FORM (after clicking Add) - this second "
              "one is optional but helps AI get the exact field names right. Press Enter on an "
              "empty line when done (at least one image is required).")
        while True:
            p = input(f"Screenshot path {len(screenshot_paths) + 1} (Enter to finish): ").strip()
            if not p:
                if screenshot_paths:
                    break
                print("At least one screenshot is required in SCREENSHOT mode.")
                continue
            screenshot_paths.append(p)
    elif used_file_mode:
        scenario = ""
        print("\nIn your OWN browser (already logged in, like you were just using): open the "
              "module's listing page, press Ctrl+U (View Source) or right-click -> Inspect on "
              "the table and 'Copy outerHTML'. Also do the same after clicking Add, for that "
              "form. Paste both into ONE .txt file (either order, doesn't matter) and save it.")
        while not manual_html_path:
            manual_html_path = input("Path to that saved .txt/.html file: ").strip()
            if not manual_html_path:
                print("This is required in FILE mode - please type the file path.")
    elif used_dom_mode:
        scenario = ""
        if not menu_name:
            # No menu path was given above, so there's no way to click
            # through to the module - need the raw URL instead.
            while not dom_module_url:
                dom_module_url = input(
                    "No menu path was given above, so paste the module's own URL instead - the "
                    "address bar URL when you're actually looking at that module's listing page "
                    "(e.g. .../Currency.htm?pgconfig=prcsCurr), NOT the login page: "
                ).strip()
                if not dom_module_url:
                    print("This is required in DOM mode when no menu path was given.")
            # Explore ONCE here too (same as the menu-path branch below) -
            # this was previously ONLY wired into the menu-path branch,
            # so choosing the URL fallback silently skipped field-value
            # collection entirely. Both paths now behave identically.
            print(f"\nLogging in and navigating to {dom_module_url} to check what's there...")
            dom_pre_scanned_html, _ = explore_module_via_url(repo_root, bank, portal_type, dom_module_url)
            if dom_pre_scanned_html:
                detected_fields = extract_add_form_fields_detailed(dom_pre_scanned_html)
                dom_field_values = collect_field_values_interactively(detected_fields)
                dom_field_constraints = {f["label"]: f["constraint"] for f in detected_fields if f.get("constraint")}
            else:
                print("  Scan returned nothing - proceeding without field values (AI will guess).")
        else:
            # Explore ONCE here (not later inside run_full_module_pipeline)
            # so the Add form's real field names can be extracted and the
            # person can supply REAL values for them - those exact values
            # (not AI-guessed testdata) then get used for Add, and the
            # SAME values for View/Edit/ChangeStatus to search by.
            print(f"\nLogging in and navigating to '{menu_name}' to check what's there...")
            dom_pre_scanned_html, _ = explore_module_via_menu(repo_root, bank, portal_type, menu_name)
            if dom_pre_scanned_html:
                detected_fields = extract_add_form_fields_detailed(dom_pre_scanned_html)
                dom_field_values = collect_field_values_interactively(detected_fields)
                dom_field_constraints = {f["label"]: f["constraint"] for f in detected_fields if f.get("constraint")}
            else:
                print("  Scan returned nothing - proceeding without field values (AI will guess).")
    else:
        scenario = _with_menu(first_line)

    if used_multi_mode or used_guided_mode:
        # Already got everything we need up front (typed block or
        # guided y/n walkthrough) - don't ask the same questions again.
        explicit_scenarios = pre_supplied_explicit
        print(f"\n(Using the actions you already confirmed above - "
              f"{len(explicit_scenarios)} action(s) given explicitly"
              f"{', rest auto-derived from Add' if scenario and len(explicit_scenarios) < 3 else ''}.)")
        expand_answer = "y"
    elif used_screenshot_mode:
        print(f"\n(SCREENSHOT mode - AI will read {len(screenshot_paths)} image(s) directly and "
              f"derive Add/View/Edit/ChangeStatus from what's visible in them. No Playwright, "
              f"no DOM capture.)")
        explicit_scenarios = {}
        expand_answer = "y"
    elif used_file_mode:
        print(f"\n(FILE mode - no live browser automation for DOM capture. AI will derive "
              f"Add/View/Edit/ChangeStatus from the HTML you saved at {manual_html_path}.)")
        explicit_scenarios = {}
        expand_answer = "y"
    elif used_dom_mode:
        # No scenario at all was given - explore_module_via_menu (using
        # the menu path already given above) or explore_module_via_url
        # (fallback, when no menu path was given) reads the live DOM
        # instead. None of the scenario-based questions (expand/write-
        # own/inspect-choice) apply here.
        reached_via = f"the menu path '{menu_name}'" if menu_name else f"{dom_module_url}"
        print(f"\n(DOM mode - no scenario given. AI will navigate via {reached_via}, "
              f"read the listing page and the Add form, and derive Add/View/Edit/ChangeStatus "
              f"from what it finds there.)")
        explicit_scenarios = {}
        expand_answer = "y"
    else:
        expand_answer = input(
            "\nGive Add scenario ONLY and auto-generate View/Edit/ChangeStatus for the SAME "
            "module/fields too (one run, one page scan, separate testdata sheet per action)? "
            "(y/n, press Enter for n): "
        ).strip().lower()
    if expand_answer in ("y", "yes"):
        if not used_multi_mode and not used_guided_mode and not used_dom_mode and not used_file_mode and not used_screenshot_mode:
            explicit_scenarios: dict[str, str] = {}
            write_own = input(
                "\nType your OWN View/Edit/ChangeStatus scenarios instead of letting AI derive "
                "them from Add? (y/n, press Enter for n = auto-derive all three): "
            ).strip().lower()
            if write_own in ("y", "yes"):
                print("\nFor each action, type your scenario, or just press Enter to let AI derive "
                      "that one from the Add scenario instead (mixing is fine).")
                for act_key, act_label in (("view", "View"), ("edit", "Edit"), ("changestatus", "ChangeStatus")):
                    typed = input(f"{act_label} scenario (Enter to auto-derive): ").strip()
                    if typed:
                        explicit_scenarios[act_key] = typed

        # SCENARIO REVIEW: before any live scan or generation happens,
        # check EVERY action's scenario text for genuine gaps/ambiguity
        # (vague field references, missing assertions, contradictory
        # steps) - not just the base Add scenario. A MULTI-style
        # scenario with several named actions (Add/Search/Edit/Delete/
        # etc, held in explicit_scenarios) needs each one reviewed
        # separately - a gap in the Search or Delete wording is just as
        # real as one in Add, and was previously invisible here since
        # only "scenario" (the Add text) was ever checked. NOT for
        # DOM/FILE/SCREENSHOT modes, where a brief description is the
        # whole point, not a gap. Shows exactly what was found and a
        # suggested corrected version per action, and asks for approval
        # before using it - never silently substitutes an "improved"
        # scenario without the person's explicit yes.
        if not (used_dom_mode or used_file_mode or used_screenshot_mode):
            actions_to_review = []
            if scenario:
                actions_to_review.append(("Add", "scenario", None))
            for action_name, action_text in (explicit_scenarios or {}).items():
                if action_text:
                    actions_to_review.append((action_name, "explicit_scenarios", action_name))

            for display_name, holder, key in actions_to_review:
                text_to_check = scenario if holder == "scenario" else explicit_scenarios[key]
                has_issues, issues_text, suggested_scenario = review_scenario_for_gaps(
                    text_to_check, module)
                if has_issues:
                    print(f"\nThe '{display_name}' scenario as written has a few gaps that could "
                          f"cause generation to guess or miss something:")
                    print(issues_text)
                    print(f"\nSuggested corrected '{display_name}' scenario:")
                    print(f"  {suggested_scenario}")
                    use_suggestion = input(
                        f"\nUse this corrected '{display_name}' scenario instead? "
                        f"(y/n, press Enter for y): "
                    ).strip().lower()
                    if use_suggestion in ("", "y", "yes"):
                        if holder == "scenario":
                            scenario = suggested_scenario
                        else:
                            explicit_scenarios[key] = suggested_scenario
                        print(f"Using the corrected '{display_name}' scenario.")
                    else:
                        print(f"Keeping your original '{display_name}' scenario as written.")

        if used_dom_mode or used_file_mode or used_screenshot_mode:
            inspect_choice = "1"  # unused in these modes (their own exploration path replaces
                                   # it) but kept defined since run_full_module_pipeline expects it
        else:
            inspect_choice = ""
            while inspect_choice not in ("1", "3"):
                inspect_choice = input(
                    "How should real page elements be gathered - 1) Real login (recommended) "
                    "2) Skip, use placeholders (press Enter for 1): "
                ).strip() or "1"
                if inspect_choice not in ("1", "3"):
                    # Accept a plain "2" typed out of habit as "skip" too.
                    inspect_choice = "3" if inspect_choice == "2" else inspect_choice
        ref_dir = ADDON_ROOT / "reference"
        if not ref_dir.exists() or not any(ref_dir.glob("*.py")):
            print(f"ERROR: put your real base_page.py + sample locators/page/test files into {ref_dir} first.")
            sys.exit(1)
        ref_text = load_reference_files(ref_dir)
        bank_notes = load_bank_notes(ref_dir, bank)
        if bank_notes:
            print(f"  (using your saved notes for bank '{bank}' - "
                  f"{ref_dir / 'bank_notes' / (bank.lower() + '.txt')})")
        # Build the actual action list being run, from what was really
        # confirmed - this used to always print the generic "Add + View
        # + Edit + ChangeStatus" regardless of what was actually
        # confirmed (e.g. only View + Edit), which was misleading right
        # before the real (correct) call below that only processes the
        # actions actually given.
        actions_being_run = (["Add"] if scenario else []) + [
            k.capitalize() for k in explicit_scenarios
        ]
        print(f"\nRunning {' + '.join(actions_being_run) if actions_being_run else '(nothing confirmed)'} "
              f"for module '{module}' ({bank})...")
        results = run_full_module_pipeline(
            repo_root, bank, module, portal_type, url, scenario, ref_text,
            expand_actions=True, inspect_choice=inspect_choice,
            explicit_scenarios=explicit_scenarios or None,
            module_url=dom_module_url, menu_name=(menu_name if used_dom_mode else None),
            manual_html_path=manual_html_path,
            screenshot_paths=screenshot_paths or None,
            search_by_fields=search_by_fields,
            pre_scanned_html=dom_pre_scanned_html if used_dom_mode else None,
            field_values=dom_field_values if (used_dom_mode or used_guided_mode) else None,
            field_constraints=dom_field_constraints if (used_dom_mode or used_guided_mode) else None,
            bank_notes=bank_notes or None,
        )
        print(f"\n{'=' * 60}")
        print(f"Multi-action run complete for module '{module}':")
        for action, outcome in results.items():
            if "written" in outcome:
                print(f"  [{action}] OK -> " + ", ".join(f"{k}: {v}" for k, v in outcome["written"].items()))
                # "combined" means one AI call produced add+view+edit+changestatus
                # together - document it under "add" (the scenario actually given).
                readme_action = "add" if action == "combined" else action
                update_module_readme(repo_root, module, bank, readme_action, outcome["scenario"])
            else:
                print(f"  [{action}] FAILED -> {outcome.get('error')}")
        print(f"{'=' * 60}")

        any_written = any("written" in outcome for outcome in results.values())
        if not any_written:
            print(f"Nothing was written - nothing to run.")
            return
        print("\nNEXT, automatically (browser): 1) every locator is checked and healed on the live page  "
              "2) each scenario is executed for real (stops before the final Save / Update click)  3) negative cases are generated.\n"
              "Only AFTER that you are asked whether pytest should run now (the default answer is n).")

        if inspect_choice == "1":
            _merged_written: dict = {}
            for _o in results.values():
                _merged_written.update(_o.get("written", {}))
            _neg_outcomes = {}
            try:
                _neg_outcomes = _verify_and_dry_run(repo_root, bank, portal_type, module, scenario,
                                                    explicit_scenarios, _merged_written, heal=True)
            except Exception as exc:
                _log_exception("interactive verification/dry-run", exc)
            _maybe_generate_negative_suite(repo_root, bank, module, scenario, _merged_written, _neg_outcomes,
                                           explicit_scenarios=explicit_scenarios, portal_type=portal_type, live=True)
        else:
            print("  [SKIPPED] verification + dry-run: you chose placeholders (no real login) above.")
            _merged_written = {}
            for _o in results.values():
                _merged_written.update(_o.get("written", {}))
            _maybe_generate_negative_suite(repo_root, bank, module, scenario, _merged_written, {})

        _maybe_merge_single_file(repo_root, bank, module,
                                 [_o.get("written") for _o in results.values() if _o.get("written") is not None])

        run_now = input(
            "\nRun pytest now and let AI auto-fix failures if any come up? "
            "(y/n, press Enter for n - files stay generated either way): "
        ).strip().lower()
        if run_now not in ("y", "yes"):
            print(f"Nothing was run with pytest. When ready:")
            print(f"  cd {repo_root} && pytest -k {module} -v")
            return

        # Merge every action's "written" dict into one, so run_with_auto_fix
        # (built for a single action's file set) sees everything this
        # combined multi-action run actually produced - locators/page/test
        # are shared across actions anyway, only the testdata_* keys differ.
        all_written: dict = {}
        for outcome in results.values():
            all_written.update(outcome.get("written", {}))

        print(f"\nRunning: pytest -k {module}  (auto-fix enabled)")
        passed, last_output = run_with_auto_fix(
            repo_root, module, all_written, max_attempts=3,
            addon_root=ADDON_ROOT, bank=bank, action="combined",
        )
        if not passed:
            print("\nAutomatic fixing didn't resolve it after 3 attempts. What do you think "
                  "the issue is, or how should it be fixed? (describe it in your own words, "
                  "or press Enter to skip)")
            user_guidance = input("> ").strip()
            if user_guidance:
                print("Applying your guidance and retrying once more...")
                fix_result = attempt_user_guided_fix(repo_root, module, all_written,
                                                      last_output, user_guidance)
                if fix_result:
                    fixed_kind, summary = fix_result
                    print(f"AI updated: {all_written[fixed_kind]} ({summary})")
                    retry_passed, last_output = run_pytest(repo_root, module)
                    print(last_output[-2000:])
                    if retry_passed:
                        print("PASSED after applying your guidance.")
                        visually_verify_latest_screenshot(repo_root, module)
                    else:
                        print("Still failing - review the output above for manual fixing.")
                else:
                    print("AI could not turn your guidance into a concrete fix - review manually.")
        return

    print(f"\nHow should real page elements be gathered?")
    print(f"  1) Real login (recommended) - actually logs in via your framework's real "
          f"{portal_type.capitalize()}LoginPage using real credentials, then scans the real "
          f"post-login page. Most reliable, no manual browser step.")
    print(f"  2) Manual browser - opens a visible browser for you to log in by hand once, saves the session.")
    print(f"  3) Skip - use placeholder selectors, fill in manually later.")
    inspect_choice = input("Choice (1/2/3, press Enter for 1): ").strip() or "1"

    page_html = ""
    phrase_xpaths: dict[str, str] = {}
    if inspect_choice == "1":
        page_html, phrase_xpaths = login_via_real_framework(repo_root, bank, portal_type, scenario)
        print("Real page elements captured." if page_html
              else "Real login inspection didn't return elements - falling back to placeholders.")
    elif inspect_choice == "2" and url:
        storage_state_path = ADDON_ROOT / "login_session.json"
        if not storage_state_path.exists():
            print(f"\nNo saved login session found. If '{url}' requires login, "
                  f"a real browser window will open now so you can log in once.")
            answer = input("Open a browser to log in now? (y/n, press Enter for y): ").strip().lower()
            if answer in ("", "y", "yes"):
                capture_login_session(url, storage_state_path)
            else:
                print("Skipping login capture - inspecting without a session (may only see a login page).")
        else:
            refresh = input(
                f"A saved login session already exists ({storage_state_path}). "
                f"Reuse it, or log out and capture a fresh one? (reuse/refresh, press Enter for reuse): "
            ).strip().lower()
            if refresh in ("refresh", "r", "fresh", "new"):
                print("Logging out of the old session first (server-side session lock fix)...")
                perform_logout(url, storage_state_path)
                storage_state_path.unlink(missing_ok=True)
                print("Old session cleared. Opening a browser to log in fresh...")
                capture_login_session(url, storage_state_path)
            else:
                print(f"Reusing saved login session from {storage_state_path}.")

        print(f"Inspecting {url} for real selectors...")
        page_html = inspect_url(url, storage_state_path)
        print("Live elements found - using real selectors." if page_html
              else "Could not inspect page - falling back to placeholder selectors.")
    else:
        print("Skipping live inspection - placeholder selectors will be used.")

    action = extract_action_from_scenario(scenario)
    existing_locators = find_existing_locators(repo_root, bank, module)
    existing_page_class = find_existing_page_class(repo_root, module, bank)
    existing_test_file = find_existing_test_file(repo_root, module, bank)
    real_login_code = load_real_login_files(repo_root, bank, portal_type)

    # OVERVIEW - summarize everything gathered so far and get one explicit
    # confirmation before spending an AI call and touching the repo.
    print("\n" + "=" * 60)
    print("OVERVIEW - review before generating")
    print("=" * 60)
    print(f"  Repo:              {repo_root}")
    print(f"  Bank:              {bank}")
    print(f"  Module:            {module}")
    print(f"  Action:            {action}  (execute_{action}_{module})")
    print(f"  Portal type:       {portal_type or '(could not determine - will default to bank)'}")
    print(f"  Login URL:         {url or '(none given)'}")
    print(f"  Real login code:   {'found, will be reused exactly' if real_login_code else 'not found - login import may need manual review'}")
    print(f"  Existing locators: {'found for this module, will be reused' if existing_locators else 'none found - will be generated fresh'}")
    print(f"  Existing page:     {'found - will ADD this bank/action, not overwrite' if existing_page_class else 'none found - fresh page class will be created'}")
    print(f"  Existing test:     {'found - will ADD this action, not overwrite' if existing_test_file else 'none found - fresh test file will be created'}")
    print(f"  Live page scan:    {'selectors captured' if page_html else 'not available - placeholders will be used'}")
    print(f"  Scenario:          {scenario}")
    print("=" * 60)
    proceed = input("Proceed with generation? (y/n, press Enter for y): ").strip().lower()
    if proceed not in ("", "y", "yes"):
        print("Stopped - nothing generated.")
        sys.exit(0)

    user_prompt = build_user_prompt(bank, module, scenario, ref_text, page_html, existing_locators,
                                     url, real_login_code, existing_page_class, existing_test_file,
                                     action, phrase_xpaths)

    print("Generating code (calling AI backend)...")
    reply = ask_ai(SYSTEM_PROMPT, user_prompt)
    if not reply:
        print("ERROR: AI call failed. Check AI_BACKEND / API key / network and retry.")
        sys.exit(1)

    preview_answer = input("\nPreview the generated files before writing them into the real repo? "
                            "(y/n, press Enter for y): ").strip().lower()
    if preview_answer in ("", "y", "yes"):
        preview_dir = ADDON_ROOT / "generated_preview" / module
        preview_files = parse_and_write(reply, preview_dir)
        if not preview_files:
            print("WARNING: could not parse any files from the AI reply.")
            (ADDON_ROOT / "last_failed_reply.txt").write_text(reply, encoding="utf-8")
            print(f"Raw reply saved to {ADDON_ROOT / 'last_failed_reply.txt'}")
            sys.exit(1)
        print(f"\n{len(preview_files)} file(s) written for review in {preview_dir}:")
        for f in preview_files:
            print(f"  {f}")
        print("\nOpen and check them now if you'd like.")
        proceed = input("Copy these into the real repo and run pytest? (y/n, press Enter for y): ").strip().lower()
        if proceed not in ("", "y", "yes"):
            print("Stopped - nothing was written into the real repo. "
                  f"The preview files remain at {preview_dir} if you want to look again.")
            sys.exit(0)

    print("Writing files directly into the real repo...")
    written = auto_write_into_repo(reply, repo_root, bank, module, action,
                                    existing_page_class, existing_test_file, real_login_code)

    if not written:
        print("WARNING: could not parse any files from the AI reply.")
        (ADDON_ROOT / "last_failed_reply.txt").write_text(reply, encoding="utf-8")
        print(f"Raw reply saved to {ADDON_ROOT / 'last_failed_reply.txt'}")
        sys.exit(1)

    for kind, path in written.items():
        print(f"  {kind}: {path}")

    missing = {"locators", "page", "test", "testdata"} - written.keys()
    if missing:
        print(f"WARNING: AI did not produce: {', '.join(missing)} - check the files above manually.")

    # Auto-heal (re-verifying every locator against the live page after
    # generation) is ON by default - this is the accuracy-critical step
    # that catches a locator that LOOKED right during generation but
    # doesn't actually resolve to exactly one visible element on the
    # real live page. Set AI_AUTO_HEAL_LOCATORS=0 to skip it (faster,
    # but no post-write verification pass).
    if os.environ.get("AI_AUTO_HEAL_LOCATORS", "1") != "0" and "locators" in written and inspect_choice == "1":
        print(f"\nVerifying every locator against the live page before running pytest...")
        healed, healed_attrs, agentic_healed_attrs = verify_and_heal_locators_file(
            repo_root, bank, portal_type, module, scenario)
        if healed:
            print(f"Healed {healed} locator(s) that didn't resolve - re-verified before writing.")
        else:
            print(f"All locators already resolve correctly on the live page.")

    _single_outcomes = {}
    if inspect_choice == "1":
        try:
            _single_outcomes = _verify_and_dry_run(repo_root, bank, portal_type, module, scenario, None, written, heal=False)
        except Exception as exc:
            _log_exception("interactive dry-run", exc)
    _maybe_generate_negative_suite(repo_root, bank, module, scenario, written, _single_outcomes,
                                   portal_type=portal_type, live=(inspect_choice == "1"))
    _maybe_merge_single_file(repo_root, bank, module, [written])

    # Auto-running pytest after generation is OFF by default now - files
    # are written to the real repo and the job stops there; run pytest
    # yourself whenever you're ready. Set AI_AUTO_RUN_TESTS=1 to turn the
    # automatic run+auto-fix loop back on.
    if os.environ.get("AI_AUTO_RUN_TESTS") != "1":
        print(f"\n{'=' * 60}")
        print(f"Files generated and written to the repo. Nothing was run.")
        print(f"{'=' * 60}")
        for kind, path in written.items():
            print(f"  {kind}: {path}")
        readme_path = update_module_readme(repo_root, module, bank, action, scenario)
        if readme_path:
            print(f"Documentation updated: {readme_path}")
        print(f"\nRun it yourself whenever you're ready:")
        print(f"  cd {repo_root} && pytest -k {module} -v")
        return

    print(f"\nRunning pytest (single attempt - no auto-retry-fix loop)...")
    passed, last_output = run_with_auto_fix(repo_root, module, written, max_attempts=1,
                                             addon_root=ADDON_ROOT, bank=bank, action=action)

    if not passed:
        print("\nAutomatic fixing didn't resolve it. What do you think the issue is, or how "
              "should it be fixed? (describe it in your own words, or press Enter to skip)")
        user_guidance = input("> ").strip()
        if user_guidance:
            print("Applying your guidance and retrying once more...")
            fix_result = attempt_user_guided_fix(repo_root, module, written, last_output, user_guidance)
            if fix_result:
                fixed_kind, summary = fix_result
                print(f"AI updated: {written[fixed_kind]} ({summary})")
                retry_passed, last_output = run_pytest(repo_root, module)
                print(last_output[-2000:])
                if retry_passed:
                    print("PASSED after applying your guidance.")
                    passed = True
                    visually_verify_latest_screenshot(repo_root, module)
                else:
                    print("Still failing after applying your guidance - see output above.")
            else:
                print("Could not apply that guidance to a fix automatically - review the output above and fix manually.")

    if passed:
        print(f"\nDone - scenario ran successfully end-to-end.")
        readme_path = update_module_readme(repo_root, module, bank, action, scenario)
        if readme_path:
            print(f"Documentation updated: {readme_path}")
        updated_test_file = find_existing_test_file(repo_root, module, bank)
        gap = analyze_coverage_gaps(module, updated_test_file)
        if gap:
            print(f"Coverage suggestion: {gap}")
    else:
        print(f"\nCould not get it passing automatically. The generated files at the paths above")
        print(f"are the latest attempt (possibly partially fixed) - open them and finish by hand, then:")
        print(f"  cd {repo_root} && pytest -k {module} -v")


def _run_entries_unattended(repo_root: Path, entries: list[dict], source_label: str) -> dict[str, dict]:
    """Shared core loop for both run_batch_file and run_url_list_file -
    runs Add + auto-derived View/Edit/ChangeStatus for every entry, one
    after another, with NO input() prompts at all - each entry's own
    failure is printed and skipped rather than stopping the whole run.
    source_label is just what gets printed as the run's origin (a batch
    file path or a URL list file path) so the summary output makes
    sense either way.

    Returns {module: {"bank": ..., "written": {...}}} for every entry
    that wrote at least one file - this is what --full-auto's later
    auto-fix stage needs (run_with_auto_fix requires the actual written
    dict to know which files it's allowed to touch for that module)."""
    ref_dir = ADDON_ROOT / "reference"
    if not ref_dir.exists() or not any(ref_dir.glob("*.py")):
        print(f"ERROR: put your real base_page.py + sample locators/page/test files into {ref_dir} first.")
        sys.exit(1)
    ref_text = load_reference_files(ref_dir)

    print(f"{source_label}  ({len(entries)} scenario-set(s) found)")
    summary = []
    written_by_module: dict[str, dict] = {}
    for idx, entry in enumerate(entries, start=1):
        cleanup_stray_files(repo_root)
        print(f"\n{'#' * 60}")
        print(f"# Entry {idx}/{len(entries)}: {entry['bank']} / {entry['module']}")
        print(f"{'#' * 60}")
        try:
            bank_notes = load_bank_notes(ref_dir, entry["bank"])
            if entry.get("menu_name") or entry.get("module_url"):
                print(f"  (DOM mode for this line - deriving everything from a live scan via "
                      f"{'menu path ' + repr(entry['menu_name']) if entry.get('menu_name') else 'URL ' + repr(entry['module_url'])})")
            results = run_full_module_pipeline(
                repo_root, entry["bank"], entry["module"], entry["portal_type"], entry["url"],
                entry["scenario"], ref_text, expand_actions=True, inspect_choice="1",
                bank_notes=bank_notes or None,
                menu_name=entry.get("menu_name"), module_url=entry.get("module_url"),
                explicit_scenarios=entry.get("explicit_scenarios"),
            )
            for action, outcome in results.items():
                if "written" in outcome:
                    readme_action = "add" if action == "combined" else action
                    update_module_readme(repo_root, entry["module"], entry["bank"], readme_action,
                                          outcome["scenario"])
                    written_by_module.setdefault(entry["module"], {"bank": entry["bank"], "written": {}})
                    written_by_module[entry["module"]]["written"].update(outcome["written"])
                summary.append((entry["bank"], entry["module"], action, "written" in outcome))

            # LOCATOR VERIFICATION (default ON for batch/full-auto runs -
            # this is the accuracy-critical unattended path, exactly where
            # a placeholder or non-resolving locator is most likely to go
            # unnoticed until pytest fails much later). Re-opens a real
            # logged-in session, re-navigates to this module's real page,
            # and checks EVERY locator in the just-written locators.py
            # against the LIVE page - not a guess, an actual
            # page.locator(value) resolution check - healing any that
            # don't resolve to exactly one visible element. Set
            # AI_AUTO_HEAL_LOCATORS=0 to skip this (faster, but locators
            # only get the accuracy this run's own live scan already gave
            # them - no post-write verification pass).
            if not (entry["module"] in written_by_module
                    and "locators" in written_by_module[entry["module"]]["written"]):
                print(f"  [SKIPPED] locator verification + dry-run: generation did NOT write a "
                      f"locators file for '{entry['module']}', so there is nothing to verify. "
                      f"Look ABOVE for why generation failed.")
            elif os.environ.get("AI_AUTO_HEAL_LOCATORS", "1") == "0":
                print(f"  [SKIPPED] locator verification + dry-run: AI_AUTO_HEAL_LOCATORS=0 in your env/.env")
            _neg_done_for_entry = False
            if (os.environ.get("AI_AUTO_HEAL_LOCATORS", "1") != "0"
                    and entry["module"] in written_by_module
                    and "locators" in written_by_module[entry["module"]]["written"]):
                print(f"  Verifying every locator against the live page...")
                healed, healed_attrs, agentic_healed_attrs = verify_and_heal_locators_file(
                    repo_root, entry["bank"], entry["portal_type"], entry["module"],
                    entry["scenario"] or "",
                    extra_scenarios=list((entry.get("explicit_scenarios") or {}).items()))
                if healed:
                    print(f"  Healed {healed} locator(s) that didn't resolve on the live page.")
                else:
                    print(f"  All locators already resolve correctly on the live page.")

                # DRY RUN: one step beyond "does the locator resolve?" -
                # does a REAL fill/select/check on it actually work,
                # short of clicking Save/Submit (never creates real
                # data). Default ON alongside auto-heal; same opt-out.
                if os.environ.get("AI_DRY_RUN_INTERACTIONS", "1") != "0":
                    print(f"  Dry-running each field's real interaction (stopping before "
                          f"Save/Submit)...")
                    # Real generated testdata values (not a generic
                    # placeholder) - a format-constrained field (a
                    # numeric-only BIN, say) needs a REAL value that
                    # respects its own constraints, or the dry-run can
                    # silently mangle a placeholder into something that
                    # LOOKS like success but verified nothing meaningful.
                    testdata_path = written_by_module[entry["module"]]["written"].get(
                        "testdata_add") or written_by_module[entry["module"]]["written"].get("testdata")
                    testdata_row = read_first_testdata_row(testdata_path) if testdata_path else {}
                    dry_run_warnings = dry_run_verify_interactions(
                        repo_root, entry["bank"], entry["portal_type"], entry["module"],
                        entry["scenario"] or "", testdata_values=testdata_row) \
                        if os.environ.get("AI_FIELD_DRYRUN", "0") == "1" else []
                    if dry_run_warnings:
                        for w in dry_run_warnings:
                            print(f"    WARNING (dry-run): {w}")
                    else:
                        print(f"  Every field's real fill/select/check interaction succeeded.")

                    # CAPSTONE: combine every signal just gathered above
                    # (clean resolution, ordinary heal, agentic heal,
                    # dry-run outcome) into one scannable per-locator
                    # trust summary, saved alongside the run's other
                    # artifacts.
                    _outcomes = _run_scenario_dry_runs(
                        repo_root, entry["bank"], entry["portal_type"], entry["module"],
                        entry["scenario"] or "", entry.get("explicit_scenarios"),
                        written_by_module[entry["module"]]["written"])
                    confidence_report = generate_locator_confidence_report(
                        repo_root, entry["bank"], entry["module"],
                        healed_attrs, agentic_healed_attrs, dry_run_warnings,
                        scenario_status=_merge_scenario_status(_outcomes),
                        field_dryrun_ran=os.environ.get("AI_FIELD_DRYRUN", "0") == "1")
                    print(f"\n{confidence_report}")
                    report_dir = repo_root / "reports"
                    report_dir.mkdir(exist_ok=True)
                    (report_dir / f"{entry['module']}_locator_confidence.txt").write_text(
                        confidence_report, encoding="utf-8")
                    _maybe_generate_negative_suite(
                        repo_root, entry["bank"], entry["module"], entry["scenario"] or "",
                        written_by_module[entry["module"]]["written"], _outcomes, ask=False,
                        explicit_scenarios=entry.get("explicit_scenarios"), portal_type=entry["portal_type"], live=True)
                    _neg_done_for_entry = True
                else:
                    print(f"  [SKIPPED] dry-run: AI_DRY_RUN_INTERACTIONS=0 in your env/.env")
            if entry["module"] in written_by_module and written_by_module[entry["module"]].get("written"):
                if not _neg_done_for_entry:
                    _maybe_generate_negative_suite(
                        repo_root, entry["bank"], entry["module"], entry["scenario"] or "",
                        written_by_module[entry["module"]]["written"], {}, ask=False)
                _maybe_merge_single_file(repo_root, entry["bank"], entry["module"],
                                         [written_by_module[entry["module"]]["written"]])
        except Exception as exc:  # noqa: BLE001 - one bad entry must not kill the whole run
            _log_exception(f"entry {idx} failed unexpectedly", exc)
            print(f"  ERROR: entry {idx} failed unexpectedly ({exc}) - skipping to next entry.")
            summary.append((entry["bank"], entry["module"], "ALL", False))

    print(f"\n{'=' * 60}")
    print(f"RUN COMPLETE - {len(entries)} scenario-set(s), {len(summary)} action(s) attempted")
    print(f"{'=' * 60}")
    for bank, module, action, ok in summary:
        print(f"  [{'OK' if ok else 'FAILED'}] {bank} / {module} / {action}")

    # FEATURE: plain-English summary written to a file too, not just the
    # terminal - grouped per (bank, module) since "summary" above is
    # per-action; a module counts as OK only if every one of its
    # actions succeeded, and any failed action names are listed as the
    # note so the markdown file is useful on its own without needing
    # the full terminal scrollback.
    per_module: dict[tuple[str, str], list[tuple[str, bool]]] = {}
    for bank, module, action, ok in summary:
        per_module.setdefault((bank, module), []).append((action, ok))
    module_results = []
    for (bank, module), actions in per_module.items():
        all_ok = all(ok for _, ok in actions)
        failed_actions = [a for a, ok in actions if not ok]
        module_results.append((bank, module, all_ok, ", ".join(failed_actions) + " failed" if failed_actions else ""))
    md_summary = generate_regression_summary(module_results)
    reports_dir = repo_root / "reports"
    reports_dir.mkdir(exist_ok=True)
    summary_path = reports_dir / "generation_summary.md"
    summary_path.write_text(md_summary, encoding="utf-8")
    print(f"\nPlain-English summary written to: {summary_path}")

    print(f"\nNothing was run with pytest. When ready:")
    print(f"  cd {repo_root} && pytest -v")

    return written_by_module


def run_batch_file(repo_root: Path, batch_path: Path) -> None:
    """Non-interactive batch mode: reads a scenarios file (one
    bank|module|portal_type|url|scenario per line - see
    generate_scenario.parse_batch_file for the exact format, including
    the "DOM" literal-scenario shortcut) and runs every line
    unattended. This is the 'give many scenarios at once' mode; the
    interactive run_one_scenario() loop above remains for typing
    scenarios in one at a time with full review at each step."""
    entries = parse_batch_file(batch_path)
    if not entries:
        print(f"ERROR: no usable lines found in batch file {batch_path}")
        sys.exit(1)
    _run_entries_unattended(repo_root, entries, f"Batch file: {batch_path}")


def run_url_list_file(repo_root: Path, list_path: Path, bank: str, portal_type: str) -> None:
    """The simplest possible unattended mode: a plain text file of bare
    URLs, one per line - no scenario writing, no per-line bank/module/
    portal columns at all (see generate_scenario.parse_url_list_file).
    bank and portal_type apply to every URL; each URL's module name is
    auto-derived from the URL itself. Every entry runs in full DOM
    mode - log in, navigate straight to that URL, scan the real page,
    and derive the Add flow (plus auto-derived View/Edit/ChangeStatus)
    entirely from what's found there."""
    entries = parse_url_list_file(list_path, bank, portal_type)
    if not entries:
        print(f"ERROR: no usable URLs found in {list_path}")
        sys.exit(1)
    _run_entries_unattended(repo_root, entries, f"URL list: {list_path}")


def run_multibank_flow(repo_root: Path) -> None:
    """Bank(s) -> Portal -> Menu path -> Module, then: for EVERY bank
    given (up to ~7), logs in and scans that bank's own real version of
    the module FIRST, shows a short structured description of what it
    found (actions/search pattern/Add fields), and lets the person
    accept or correct it - only once every bank's structure has been
    reviewed does generation actually start, one bank at a time, each
    using its own confirmed structure alongside a fresh DOM scan. This
    is for exactly the case where the "same" module can look genuinely
    different bank to bank (different actions, different search UI) -
    catching that at the cheap review stage instead of after a full
    generation call already assumed the wrong structure."""
    banks_raw = ""
    while not banks_raw:
        banks_raw = input("Bank names, comma-separated, up to 7 (e.g. wio, alrajhi, oab): ").strip()
    banks = [b.strip().lower() for b in banks_raw.split(",") if b.strip()][:7]
    if not banks:
        print("No valid bank names given.")
        return
    print(f"Banks: {', '.join(banks)}")

    portal_type = ""
    while portal_type not in ("admin", "bank", "merchant", "superadmin"):
        portal_type = input("Portal type (admin/bank/merchant/superadmin): ").strip().lower()
        if portal_type not in ("admin", "bank", "merchant", "superadmin"):
            print("Please type exactly one of: admin, bank, merchant, superadmin")

    menu_name = ""
    while not menu_name:
        menu_name = input("Menu / Submenu path this module sits under "
                          "(e.g. 'Configuration > Brand Type'): ").strip()

    module = ""
    while not module or " " in module:
        module = input("Module name (e.g. brand, merchant - NO spaces): ").strip().lower()
        if " " in module:
            print("Module name cannot contain spaces.")
            module = ""

    ref_dir = ADDON_ROOT / "reference"
    if not ref_dir.exists() or not any(ref_dir.glob("*.py")):
        print(f"ERROR: put your real base_page.py + sample locators/page/test files into {ref_dir} first.")
        return
    ref_text = load_reference_files(ref_dir)

    print(f"\n{'=' * 60}")
    print(f"DISCOVERY - checking each bank's real structure for '{module}' before generating anything")
    print(f"{'=' * 60}")
    confirmed = run_multibank_discovery(repo_root, banks, portal_type, menu_name)

    print(f"\n{'=' * 60}")
    print(f"All {len(banks)} bank(s) confirmed - starting generation")
    print(f"{'=' * 60}")
    all_results = {}
    for i, bank in enumerate(confirmed.keys(), start=1):
        cleanup_stray_files(repo_root)
        print(f"\n{'#' * 60}")
        print(f"# Generating {i}/{len(confirmed)}: {bank}")
        print(f"{'#' * 60}")
        results = run_full_module_pipeline(
            repo_root, bank, module, portal_type, None, None, ref_text,
            expand_actions=True, inspect_choice="1",
            # Reuse the EXACT scan discovery already captured for this
            # bank (pre_scanned_html) instead of menu_name, which would
            # trigger a completely fresh login+navigate+scan here - that
            # was redundant (double login) and could show a confusing
            # "Could not find an Add element" even when discovery already
            # correctly confirmed this bank has no Add at all.
            pre_scanned_html=confirmed[bank]["page_html"] or None,
            menu_name=menu_name if not confirmed[bank]["page_html"] else None,
            confirmed_description=confirmed[bank]["description"],
            field_values=confirmed[bank]["field_values"] or None,
            bank_notes=load_bank_notes(ref_dir, bank) or None,
        )
        for action, outcome in results.items():
            if "written" in outcome:
                for kind, path in outcome["written"].items():
                    print(f"  {kind}: {path}")
                readme_action = "add" if action == "combined" else action
                update_module_readme(repo_root, module, bank, readme_action, outcome.get("scenario", ""))
            else:
                print(f"  FAILED -> {outcome.get('error')}")
        all_results[bank] = results

    print(f"\n{'=' * 60}")
    print(f"MULTI-BANK RUN COMPLETE - {len(confirmed)} bank(s) generated"
          f"{f' ({len(banks) - len(confirmed)} skipped during discovery)' if len(confirmed) < len(banks) else ''}")
    print(f"{'=' * 60}")
    for bank, results in all_results.items():
        ok = any("written" in o for o in results.values())
        print(f"  [{'OK' if ok else 'FAILED'}] {bank}")
    print(f"\nNothing was run with pytest. When ready:")
    print(f"  cd {repo_root} && pytest -k {module} -v")


class _Tee:
    """Mirrors everything printed to the terminal into a log file too."""
    def __init__(self, stream, fh):
        self._stream, self._fh = stream, fh
    def write(self, data):
        try:
            self._stream.write(data)
        except Exception:
            pass
        try:
            self._fh.write(data)
            self._fh.flush()
        except Exception:
            pass
    def flush(self):
        try:
            self._stream.flush()
            self._fh.flush()
        except Exception:
            pass
    def __getattr__(self, name):
        return getattr(self._stream, name)


def _start_run_log() -> Path | None:
    """Everything this run prints (including full tracebacks) is saved to
    debug_logs/last_run.log - just send that ONE file, no copy-paste or
    output redirection needed."""
    try:
        log_dir = Path.cwd() / "debug_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "last_run.log"
        fh = open(log_path, "w", encoding="utf-8", errors="replace")
        sys.stdout = _Tee(sys.stdout, fh)
        sys.stderr = _Tee(sys.stderr, fh)
        return log_path
    except Exception:
        return None


def main():
    _log_path = _start_run_log()
    if _log_path:
        print(f"(this run's full output is being saved to {_log_path})")
    print("=" * 60)
    print("Scenario -> Code -> Auto-write -> Auto-run  (FULL AUTO, BATCH-capable)")
    print("base_page.py is read-only reference - never modified")
    print("=" * 60)

    repo_root_str = None
    batch_file_str = None
    url_list_str = None
    url_list_bank = None
    url_list_portal = None
    discover_menu = False
    discover_out = "discovered_urls.txt"
    staleness_module = None
    audit_module = None
    triage_log_str = None
    deep_triage_str = None
    full_auto = False
    for arg in sys.argv[1:]:
        if arg.startswith("--root="):
            repo_root_str = arg.split("=", 1)[1]
        elif arg.startswith("--batch-file="):
            batch_file_str = arg.split("=", 1)[1]
        elif arg.startswith("--url-list="):
            url_list_str = arg.split("=", 1)[1]
        elif arg.startswith("--bank="):
            url_list_bank = arg.split("=", 1)[1]
        elif arg.startswith("--portal-type="):
            url_list_portal = arg.split("=", 1)[1]
        elif arg == "--discover-menu":
            discover_menu = True
        elif arg.startswith("--out="):
            discover_out = arg.split("=", 1)[1]
        elif arg.startswith("--check-staleness="):
            staleness_module = arg.split("=", 1)[1]
        elif arg.startswith("--audit-dispatch="):
            audit_module = arg.split("=", 1)[1]
        elif arg.startswith("--triage="):
            triage_log_str = arg.split("=", 1)[1]
        elif arg.startswith("--deep-triage="):
            # Format: --deep-triage=<bank>:<module>:<pytest_output_file>
            deep_triage_str = arg.split("=", 1)[1]
        elif arg == "--full-auto":
            full_auto = True
    if not repo_root_str:
        repo_root_str = input(
            "Path to your REAL framework repo "
            "(e.g. D:\\Automation\\iqa_playwright_commonframework): "
        ).strip()
    repo_root = Path(repo_root_str)
    if not (repo_root / "src").exists():
        print(f"ERROR: {repo_root} doesn't look like the framework root (no 'src' folder found).")
        sys.exit(1)

    if full_auto:
        # FEATURE: the capstone command - chains EVERY feature above
        # into one run: discover the whole menu -> generate every
        # module found -> run pytest across the whole batch in one
        # pass -> triage any failures -> everything ends up in
        # reports/. This is "prepare everything, ask as little as
        # possible" - the person only answers bank/portal once, up
        # front, then the rest runs unattended.
        if not url_list_bank:
            url_list_bank = input("Bank name: ").strip()
        if not url_list_portal:
            url_list_portal = ""
            while url_list_portal not in ("admin", "bank", "merchant", "superadmin"):
                url_list_portal = input("Portal type (admin/bank/merchant/superadmin): ").strip().lower()

        print(f"\n{'=' * 60}\nSTAGE 1/5: Discovering the full menu for '{url_list_bank}'\n{'=' * 60}")
        discovered = discover_full_menu_tree(repo_root, url_list_bank, url_list_portal)
        if not discovered:
            print("Nothing discovered - stopping here. Try --discover-menu alone first to debug the crawl.")
            return
        urls_path = repo_root / discover_out
        write_discovered_urls_file(discovered, urls_path)

        print(f"\n{'=' * 60}\nSTAGE 2/5: Generating {len(discovered)} module(s)\n{'=' * 60}")
        entries = parse_url_list_file(urls_path, url_list_bank, url_list_portal)
        written_by_module = _run_entries_unattended(repo_root, entries, f"URL list: {urls_path}")

        print(f"\n{'=' * 60}\nSTAGE 3/5: Running pytest across everything just generated\n{'=' * 60}")
        module_names = [e["module"] for e in entries]
        passed, pytest_output = run_pytest_multi(repo_root, module_names)
        print(pytest_output[-4000:])  # tail - the full log can be huge across many modules
        log_path = repo_root / "reports" / "full_auto_pytest_log.txt"
        log_path.parent.mkdir(exist_ok=True)
        log_path.write_text(pytest_output, encoding="utf-8")
        print(f"\nFull pytest log saved to: {log_path}")

        failed_modules: list[str] = []
        if not passed:
            print(f"\n{'=' * 60}\nSTAGE 4/5: Triaging failures\n{'=' * 60}")
            triage = triage_pytest_failures(pytest_output)
            print(triage)
            triage_path = repo_root / "reports" / "full_auto_triage.md"
            triage_path.write_text(f"# Failure Triage\n\n{triage}\n", encoding="utf-8")
            print(f"\nTriage saved to: {triage_path}")
            failed_modules = extract_failed_modules_from_pytest_output(pytest_output, module_names)
        else:
            print(f"\n{'=' * 60}\nSTAGE 4/5: All tests passed - nothing to triage\n{'=' * 60}")

        # STAGE 5: actually ATTEMPT to fix each failing module (not just
        # report on it) - reuses the same run_with_auto_fix loop a
        # single-module interactive run already offers, applied here to
        # every failed module from this batch in turn. Every module's
        # FINAL result (after any fix attempts) gets recorded into the
        # flaky-test history either way, so this also naturally builds
        # up the history detect_flaky_modules reads.
        final_results: dict[str, bool] = {m: True for m in module_names if m not in failed_modules}
        if failed_modules:
            print(f"\n{'=' * 60}\nSTAGE 5/5: Attempting AI auto-fix for {len(failed_modules)} failing module(s)\n{'=' * 60}")
            for module in failed_modules:
                info = written_by_module.get(module)
                if not info:
                    print(f"  {module}: no written-files record for this module - skipping auto-fix.")
                    final_results[module] = False
                    continue
                print(f"\n  --- Fixing {info['bank']}/{module} ---")
                fixed, _last_output = run_with_auto_fix(repo_root, module, info["written"], bank=info["bank"])
                final_results[module] = fixed
                print(f"  {module}: {'FIXED - now passing' if fixed else 'still failing after auto-fix attempts'}")
        else:
            print(f"\n{'=' * 60}\nSTAGE 5/5: Nothing to fix\n{'=' * 60}")

        # Record every module's FINAL result (post-fix) for flaky
        # detection, and check for flakiness across past runs too.
        for module in module_names:
            bank = next((e["bank"] for e in entries if e["module"] == module), url_list_bank)
            record_test_run_result(repo_root, bank, module, final_results.get(module, False))
        flaky = detect_flaky_modules(repo_root)

        still_failing = [m for m, ok in final_results.items() if not ok]
        print(f"\n{'=' * 60}\nFULL-AUTO RUN COMPLETE\n{'=' * 60}")
        print(f"  Modules discovered & generated: {len(discovered)}")
        print(f"  Passing after auto-fix: {len(module_names) - len(still_failing)}/{len(module_names)}")
        if still_failing:
            print(f"  Still failing (needs manual review): {', '.join(still_failing)}")
        if flaky:
            print(f"\n  FLAKY (inconsistent across recent runs, not necessarily a real bug):")
            for f in flaky:
                print(f"    {f['bank']}/{f['module']}: {f['pass_count']} pass / {f['fail_count']} fail recently")
        print(f"\n  reports/generation_summary.md    - what got written")
        print(f"  reports/full_auto_pytest_log.txt - full test output")
        if not passed:
            print(f"  reports/full_auto_triage.md      - grouped failure analysis")
        print(f"  reports/test_run_history.json    - accumulating flaky-test history")
        return

    if discover_menu:
        # FEATURE: full menu auto-discovery - logs in once, crawls the
        # whole visible nav, writes the results straight into the SAME
        # format --url-list= reads, so the natural next step is running
        # that flag against this file's output.
        if not url_list_bank:
            url_list_bank = input("Bank name to log in as for the crawl: ").strip()
        if not url_list_portal:
            url_list_portal = ""
            while url_list_portal not in ("admin", "bank", "merchant", "superadmin"):
                url_list_portal = input("Portal type (admin/bank/merchant/superadmin): ").strip().lower()
        print(f"\nCrawling the full menu for '{url_list_bank}' ({url_list_portal})...")
        discovered = discover_full_menu_tree(repo_root, url_list_bank, url_list_portal)
        if discovered:
            write_discovered_urls_file(discovered, Path(discover_out))
            print(f"\nReview {discover_out}, then run:\n"
                  f"  python scripts\\run_scenario.py --url-list={discover_out} --bank={url_list_bank} --portal-type={url_list_portal}")
        else:
            print("Nothing was discovered - the crawl may need a different selector for this portal's nav, "
                  "or login itself failed. Falling back to manual --url-list=/batch-file= input.")
        return

    if staleness_module:
        if not url_list_bank:
            url_list_bank = input("Bank name: ").strip()
        menu_name = input("Menu / Submenu path this module sits under: ").strip()
        print(f"\nChecking '{staleness_module}' ({url_list_bank}) for drift against the live page...")
        report = check_module_staleness(repo_root, url_list_bank, staleness_module, menu_name)
        print(f"\n{'=' * 60}\nSTALENESS REPORT: {url_list_bank} / {staleness_module}\n{'=' * 60}")
        print(report)
        return

    if audit_module:
        print(f"\nAuditing dispatch grouping for '{audit_module}'...")
        report = audit_dispatch_grouping(repo_root, audit_module)
        print(f"\n{'=' * 60}\nDISPATCH AUDIT: {audit_module}\n{'=' * 60}")
        print(report)
        return

    if triage_log_str:
        log_path = Path(triage_log_str)
        if not log_path.exists():
            print(f"ERROR: {log_path} not found.")
            sys.exit(1)
        print(f"\nTriaging failures in {log_path}...")
        report = triage_pytest_failures(log_path.read_text(encoding="utf-8", errors="ignore"))
        print(f"\n{'=' * 60}\nFAILURE TRIAGE\n{'=' * 60}")
        print(report)
        return

    if deep_triage_str:
        # FEATURE: deep-dive single-failure triage - combines the real
        # scanned DOM, the real locators.py, and a real failure
        # screenshot (via vision) together with the pytest error, for
        # genuinely root-causing ONE specific failure rather than a
        # quick multi-module grouping. See --triage= above for that.
        try:
            deep_bank, deep_module, deep_log_str = deep_triage_str.split(":", 2)
        except ValueError:
            print("ERROR: --deep-triage= needs the format <bank>:<module>:<pytest_output_file>")
            sys.exit(1)
        deep_log_path = Path(deep_log_str)
        if not deep_log_path.exists():
            print(f"ERROR: {deep_log_path} not found.")
            sys.exit(1)
        print(f"\nDeep-triaging '{deep_module}' ({deep_bank}) using {deep_log_path}...")
        report = deep_triage_single_failure(
            repo_root, deep_bank, deep_module,
            deep_log_path.read_text(encoding="utf-8", errors="ignore"))
        print(f"\n{'=' * 60}\nDEEP TRIAGE\n{'=' * 60}")
        print(report)
        return

    if url_list_str:
        # The simplest possible input: a file of bare URLs, nothing else
        # typed per line - see parse_url_list_file. bank/portal_type
        # apply to every URL and must be given here since a URL alone
        # doesn't say which bank/portal it belongs to.
        if not url_list_bank:
            url_list_bank = input("Bank name (applies to every URL in the list): ").strip()
        if not url_list_portal:
            url_list_portal = ""
            while url_list_portal not in ("admin", "bank", "merchant", "superadmin"):
                url_list_portal = input("Portal type (admin/bank/merchant/superadmin) - "
                                        "applies to every URL in the list: ").strip().lower()
        run_url_list_file(repo_root, Path(url_list_str), url_list_bank, url_list_portal)
        return

    if batch_file_str:
        run_batch_file(repo_root, Path(batch_file_str))
        return

    mode = input(
        "\n1) Single bank (normal flow)\n2) Multi-bank discovery - check each bank's real "
        "structure first, review/correct, then generate for all\nChoice (1/2, press Enter "
        "for 1): "
    ).strip() or "1"
    if mode == "2":
        run_multibank_flow(repo_root)
        return

    scenario_count = 0
    while True:
        scenario_count += 1
        print(f"\n{'#' * 60}")
        print(f"# Scenario {scenario_count}")
        print(f"{'#' * 60}")
        run_one_scenario(repo_root)

        again = input("\nAdd another scenario/module in this same run? "
                      "(y/n, press Enter for n): ").strip().lower()
        if again not in ("y", "yes"):
            break

    print(f"\nBatch complete - {scenario_count} scenario(s) processed this run.")


if __name__ == "__main__":
    main()
