"""probe_dropdowns.py - opens the LIVE Add form and tries EVERY dropdown with the values of the Excel Add row, then tells you for each
dropdown whether it works and WHY it does not (value differs in capitals / no such option / two options match / dropdown disabled /
no options appear / the locators.py option template matches nothing).

    python scripts\\probe_dropdowns.py <module> --nav "<menu> > <submenu> > Add"
    (add --headless to hide the browser; --bank <name> if config.yaml has no bank; --portal admin|bank|merchant|superadmin)

The menu path is exactly what you click to reach the Add form. Nothing is saved: the form is only filled."""
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from scripts.generate_scenario import (  # noqa: E402
    PORTAL_CLASS_MAP, _frames, _norm_tokens, _robust_click, _wait_for_form, navigate_via_scenario_text,
)

_LABEL_JS = """el => { const ff = el.closest('mat-form-field,.mat-mdc-form-field,.form-group,div');
  const l = ff ? ff.querySelector('mat-label,label') : null;
  return ((l ? l.innerText : '') || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').replace(/[*:]/g, ' ').replace(/\\s+/g, ' ').trim(); }"""


def _bank_from_config() -> str | None:
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def _excel_row(xlsx: Path) -> dict:
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    ws = wb["Add"] if "Add" in wb.sheetnames else wb.worksheets[0]
    it = ws.iter_rows(values_only=True)
    header = [str(c).strip() if c is not None else "" for c in next(it, [])]
    row = next(it, [])
    wb.close()
    return {h: ("" if v is None else str(v)) for h, v in zip(header, row) if h}


def _option_template(bank: str, module: str) -> str | None:
    for f in (ROOT / "src" / "banks" / bank / "locators").glob(f"{module}*locators.py"):
        m = re.search(r"^\s+option_by_text\s*=\s*(['\"])(.*)\1\s*$", f.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(2)
    return None


def _best_column(label: str, row: dict) -> str | None:
    lt = _norm_tokens(label)
    best, score = None, 0.0
    for col in row:
        ct = _norm_tokens(col)
        if lt and ct:
            s = len(lt & ct) / len(lt | ct)
            if s > score:
                best, score = col, s
    return best if score >= 0.5 else None


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-") or "--nav" not in argv or argv.index("--nav") + 1 >= len(argv):
        print(__doc__)
        return 0
    module = argv[0].lower()
    nav = argv[argv.index("--nav") + 1]
    bank = argv[argv.index("--bank") + 1] if "--bank" in argv and argv.index("--bank") + 1 < len(argv) else _bank_from_config()
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return 1
    xlsx = ROOT / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    if not xlsx.exists():
        print(f"Workbook not found: {xlsx}")
        return 1
    row = _excel_row(xlsx)
    template = _option_template(bank, module)
    from playwright.sync_api import sync_playwright
    saved_portal = ""
    try:
        import json
        saved_portal = json.loads((ROOT / "reports" / f"{module}_scenarios.json").read_text(encoding="utf-8")).get("portal_type", "")
    except Exception:
        pass
    portal = (argv[argv.index("--portal") + 1] if "--portal" in argv and argv.index("--portal") + 1 < len(argv) else "") or saved_portal or "bank"
    if portal not in PORTAL_CLASS_MAP:
        print(f"Unknown portal '{portal}'. Known: {sorted(PORTAL_CLASS_MAP)}")
        return 1
    module_name, class_name = PORTAL_CLASS_MAP[portal]
    login_module = __import__(f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless="--headless" in argv)
        page = browser.new_page(viewport={"width": 1500, "height": 950})
        print(f"Logging in as {bank} ...")
        getattr(login_module, class_name)(page).login(bank)
        page.wait_for_load_state("networkidle", timeout=15000)
        navigate_via_scenario_text(page, f"Navigate to {nav}")
        _wait_for_form(page, lambda m: None, 12000)
        triggers = []
        for fr in _frames(page):
            sel = fr.locator("mat-select")
            triggers += [sel.nth(k) for k in range(sel.count()) if sel.nth(k).is_visible()]
        print(f"The form shows {len(triggers)} dropdown(s). Template from locators.py: {template or '(none - option_by_text not found)'}\n")
        if not triggers:
            print("No <mat-select> is visible: either the form did not open (check the --nav path) or this portal does not use Angular "
                  "Material dropdowns - right-click a dropdown in the browser > Inspect and send a screenshot of its HTML.")
        for trig in triggers:
            label = trig.evaluate(_LABEL_JS) or "(no label)"
            col = _best_column(label, row)
            value = row.get(col, "") if col else ""
            rec = {"label": label, "column": col, "value": value, "verdict": "", "options": [], "tpl": None}
            results.append(rec)
            if not col or not value:
                rec["verdict"] = "SKIPPED - no Excel column / value for this dropdown (it stays empty)"
                continue
            if "{{" in value:
                rec["verdict"] = "SKIPPED - the Excel value is still a {{token}}"
                continue
            waited = 0
            while trig.get_attribute("aria-disabled") == "true" and waited < 6000:
                page.wait_for_timeout(500)
                waited += 500
            if trig.get_attribute("aria-disabled") == "true":
                rec["verdict"] = "DISABLED - it never became enabled (it depends on an earlier dropdown / field being filled first)"
                continue
            try:
                _robust_click(page, trig)
                page.locator("mat-option").first.wait_for(state="visible", timeout=6000)
            except Exception:
                rec["verdict"] = "NO OPTIONS - the dropdown opened but no option appeared within 6 s (options load from the server, or the click missed)"
                continue
            opts = [re.sub(r"\s+", " ", t).strip() for t in page.locator("mat-option").all_inner_texts()]
            rec["options"] = opts
            exact = [o for o in opts if o == value]
            ci = [o for o in opts if o.lower() == value.lower()]
            part = [o for o in opts if value.lower() in o.lower()]
            if template:
                try:
                    rec["tpl"] = page.locator(template.format(value=value)).count()
                except Exception as exc:
                    rec["tpl"] = f"error: {str(exc)[:40]}"
            if exact:
                rec["verdict"] = "OK - an option equals the Excel value"
            elif ci:
                rec["verdict"] = f"CASE DIFFERS - the portal says '{ci[0]}', the Excel says '{value}' (a case-sensitive XPath never matches)"
            elif len(part) > 1:
                rec["verdict"] = f"AMBIGUOUS - {len(part)} options contain '{value}': {part[:3]}"
            elif part:
                rec["verdict"] = f"PARTIAL - only '{part[0]}' contains the Excel value '{value}'"
            else:
                rec["verdict"] = f"NO MATCH - the portal has no option like '{value}'"
            try:                                         # choose something so the NEXT (dependent) dropdown can enable
                if template and isinstance(rec["tpl"], int) and rec["tpl"] >= 1:
                    page.locator(template.format(value=value)).first.click(timeout=4000)
                else:
                    page.locator("mat-option").first.click(timeout=4000)
                    rec["verdict"] += "  (the FIRST option was picked to continue)"
                page.locator("mat-option").first.wait_for(state="detached", timeout=4000)
            except Exception:
                try:
                    page.keyboard.press("Escape")
                except Exception:
                    pass
        browser.close()
    print(f"{'DROPDOWN':22} {'EXCEL COLUMN = VALUE':38} {'TEMPLATE':9} RESULT")
    for r in results:
        print(f"{r['label'][:21]:22} {(str(r['column']) + ' = ' + r['value'])[:37]:38} {str(r['tpl'] if r['tpl'] is not None else '-'):9} {r['verdict']}")
        if r["options"] and not r["verdict"].startswith("OK"):
            print(f"{'':22} options in the portal: {r['options'][:8]}")
    bad = [r for r in results if not r["verdict"].startswith(("OK", "SKIPPED"))]
    print(f"\n{len(results) - len(bad)} of {len(results)} dropdown(s) are fine." + ("" if not bad else f" {len(bad)} need attention - see RESULT above."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
