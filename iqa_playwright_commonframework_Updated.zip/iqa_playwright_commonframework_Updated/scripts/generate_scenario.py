"""
generate_scenario.py - Feature 2: scenario -> code generator, wired to the
REAL framework conventions (not hard-coded templates).

Usage (run from the framework root, e.g. D:\\Automation\\iqa_playwright_commonframework):

    python scripts/generate_scenario.py ^
        --bank wio ^
        --module brand ^
        --scenario "Navigate to Brand menu, click Add, fill Brand Name field, click Save, assert success message" ^
        --url https://qa-portal.example.com/brand   (optional - live inspection)

Output: writes generated files under generated_preview/<module>/ - it never
writes into src/ directly. You review, then copy the files into the real
locations yourself:
    src/banks/<bank>/locators/<module>_locators.py
    src/common/pages/<module>/<module>_page.py
    src/testcase/<module>/test_<module>.py
    src/banks/<bank>/testdata/<Module>.xlsx   (build from the printed rows)

Company-laptop note: this script only calls out to whichever backend you
set via AI_BACKEND (gemini/anthropic/ollama) in ai_backend.py. No repo
credentials are ever included in the prompt - only the reference *.py
files you point it at with --ref-dir.
"""
from __future__ import annotations

import argparse
import ast
import os
import re
import subprocess
import sys
from pathlib import Path


def _log_exception(context: str, exc: BaseException) -> None:
    """Prints the FULL traceback for a swallowed exception AND appends it
    to debug_logs/errors.log, so the real cause is never hidden behind a
    one-line 'falling back to placeholder selectors' message."""
    import traceback as _tb
    tb_text = "".join(_tb.format_exception(type(exc), exc, exc.__traceback__))
    print(f"\n  !!! {context} -> {type(exc).__name__}: {exc}")
    print(tb_text)
    try:
        log_dir = Path.cwd() / "debug_logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        with open(log_dir / "errors.log", "a", encoding="utf-8") as fh:
            fh.write(f"\n===== {context} =====\n{tb_text}\n")
        print(f"  (full traceback also saved to {log_dir / 'errors.log'})")
    except Exception:
        pass


def _headless() -> bool:
    """Set AI_HEADED=1 in .env/terminal to watch the browser while it
    logs in and navigates - the fastest way to SEE where it gets stuck."""
    return os.environ.get("AI_HEADED", "0").strip().lower() not in ("1", "true", "yes")

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.common.utilities.ai_backend import ask_ai as _ask_ai_raw, ask_ai_vision, BACKEND  # noqa: E402


def _install_tolerant_networkidle() -> None:
    """A portal that polls the server (or keeps a socket open) is NEVER 'network idle': page.wait_for_load_state('networkidle') then raises
    TimeoutError after its 15 s and the whole run stopped right after the login ('Real-login inspection failed -> TimeoutError: Timeout
    15000ms exceeded'). 'Network idle' is only a hint that the page has settled, so in these scripts a timeout of THAT wait is no error: the
    page is waited for until it has loaded and the run goes on. AI_STRICT_NETWORKIDLE=1 brings the old behaviour back."""
    try:
        from playwright.sync_api import Page, TimeoutError as PWTimeout
    except Exception:
        return
    orig = Page.wait_for_load_state
    if getattr(orig, "_tolerant", False):
        return

    def wait_for_load_state(self, state=None, **kwargs):
        try:
            return orig(self, state, **kwargs)
        except PWTimeout:
            if state != "networkidle" or os.environ.get("AI_STRICT_NETWORKIDLE", "0").strip() == "1":
                raise
            try:
                orig(self, "load", timeout=5000)                    # at least the page itself has loaded
            except Exception:
                pass
            return None
    wait_for_load_state._tolerant = True
    wait_for_load_state._original = orig
    Page.wait_for_load_state = wait_for_load_state


_install_tolerant_networkidle()


def ask_ai(*args, **kwargs):
    """The AI call, with a sign of life: a big module takes 2-5 minutes and the terminal showed nothing, so it looked frozen. Every
    AI_PROGRESS_SECONDS (default 20) one line says that the AI is still working and for how long."""
    import threading
    import time as _time
    try:
        every = max(float(os.environ.get("AI_PROGRESS_SECONDS", "20")), 0.2)
    except ValueError:
        every = 20.0
    done = threading.Event()
    t0 = _time.time()

    def beat() -> None:
        while not done.wait(every):
            print(f"  ... the AI is still generating (waiting {int(_time.time() - t0)} s - a big module takes 2-5 minutes; "
                  f"nothing is frozen)", flush=True)
    th = threading.Thread(target=beat, daemon=True)
    th.start()
    try:
        return _ask_ai_raw(*args, **kwargs)
    finally:
        done.set()
        if _time.time() - t0 >= every:
            print(f"  AI answered after {int(_time.time() - t0)} s.", flush=True)

ROOT = Path(__file__).resolve().parents[1]

SYSTEM_PROMPT = """You generate code for an existing Playwright + Python test
automation framework. You MUST match its exact conventions - class names,
method names, docstring style, error handling - shown in the reference
files below. Do not invent a different structure.

FOLLOW THE GIVEN SCENARIO EXACTLY - DO NOT ADD, SKIP, OR REINTERPRET
STEPS (strict, this is the most common way generated code goes wrong):
the scenario text given below is the CONTRACT for what this action does
- every step in it must appear in the generated method, in the SAME
order, and NOTHING beyond it should be invented:
- Do not add an extra field, click, wait, or assertion the scenario
  didn't mention, even if a "typical" flow for this kind of screen
  would usually have one (e.g. don't add a confirmation-dialog click
  the scenario never described, don't assert an extra field the
  scenario didn't ask you to verify).
- Do not skip or silently merge a step the scenario DID mention, even
  if it looks redundant to you (e.g. if it says "verify the listing
  page is displayed" AND separately "click Add", generate BOTH steps,
  don't drop the first as implied).
- Do not rename or re-word what the scenario asked you to enter/select/
  assert - use its exact field names and exact expected message text,
  character-for-character, as the values in the generated code/testdata
  (translate them into the right base_page.py method call, but never
  substitute a different field name, button label, or message than
  what was actually written in the scenario).
- If the scenario is ambiguous or missing a detail you'd normally need
  (e.g. no expected message text given for an assertion it asks for),
  use a clearly-marked placeholder rather than inventing a
  plausible-sounding value - a wrong guess is worse than an honest
  placeholder, since it silently tests the wrong thing.
This applies with equal force whether the scenario came from the person
directly, was derived by you from an Add scenario (MULTI-ACTION MODE),
or was read from a screenshot/DOM capture (zero-scenario modes) - in the
derived/DOM cases you are inferring the steps themselves, but once
you've stated a step, generate exactly that step, nothing more.

NAMING DISCIPLINE (strict - this is enforced by the calling script too,
but get it right to avoid any post-processing surprises):
- The Page class name MUST be exactly <ModuleTitle>Page (module name
  title-cased, e.g. module "brandtype" -> class BrandtypePage).
  Use this EXACT class name everywhere: in the page file's class
  definition, in the test file's import line, and in the test file's
  constructor call. Never use a different or shortened class name in
  one file than another.
- The Locators class name MUST be exactly <ModuleTitle>Locators
  (e.g. BrandtypeLocators). Same rule: identical everywhere it's used.
- Import lines MUST use the exact module name given below - not a
  variation, not a guess, not the scenario's wording:
  from src.common.pages.<module>.<module>_page import <ModuleTitle>Page
  from src.banks.<bank>.locators.<module>_locators import <ModuleTitle>Locators
- Do not paraphrase, pluralize, or reformat <module> or <bank> anywhere
  in generated code. Copy them character-for-character from the "Module
  name" and "Bank" values given below.

LOGIN RULE (strict - this is a common mistake, follow exactly): the Page
class you generate for the module (e.g. BrandtypePage) NEVER has a
login() method and is NEVER used to log in. Login is a completely
separate, already-existing class - BankLoginPage (or AdminLoginPage /
MerchantLoginPage if the scenario clearly says admin/merchant portal) -
shown in the reference files below. Your generated test file MUST log in
like this, exactly matching the reference's real import path AND real
method signatures (including every required argument - a call missing a
required argument is a real TypeError at runtime, not a style issue):
    from src.common.pages.authentication.bank_login_page import BankLoginPage
    ...
    login_page = BankLoginPage(page)
    login_page.login(BANK_NAME)
    login_page.assert_dashboard_visible(BANK_NAME)
If the real login class file given below shows assert_dashboard_visible
(or any other method) taking a required parameter like bank, you MUST
pass it in every call - never call it with zero arguments just because
the login() call above it didn't need one repeated. Check EVERY method
call against that file's actual def line, not just the ones you remember.
Never invent a different import path for login (e.g. never write
"src.common.pages.login.login_page" or similar - that module does not
exist). Never call .login() on the module's own Page object. If the
reference bank_login_page.py is not provided below, do not guess at all -
write the test using only self.page fixture setup and add a clear
'# TODO: verify correct login page/import for this portal' comment
instead of a fabricated import.

ALREADY-LOGGED-IN HANDLING (belongs in the login step, not the module):
some apps show a "User already logged in" message when a previous
session for the same account is still active server-side - this is a
login-time concern, not something the module's own page/test logic
should handle. If the real login_locators.py given below already defines
a locator for this (e.g. something named like already_logged_in,
force_login, or logout_confirm), the login page's real login() method
already handles it - just call login() normally, do not add extra
handling in your generated test. If no such locator exists in the real
file, do NOT invent one or add ad-hoc handling in the test file; instead
add exactly this comment above the login call so it's easy to find and
fix once, in the right place:
    # TODO: if "User already logged in" appears, add a locator for it to
    # this bank's real login_locators.py and handle it inside
    # BankLoginPage.login() - not here in the test.

CRITICAL RULE: base_page.py is provided ONLY as a read-only reference so
you know which methods already exist. NEVER output a file named
base_page.py and NEVER suggest adding/editing anything inside it. Every
generated Page class method you write MUST call INTO base_page.py's
existing methods only (self.click_by_locator, self.fill_by_locator,
self.select_by_locator, self.assert_text, self.navigate, etc.) - do not
invent new base-level methods or bypass them with raw self.page.* calls.

Locators must be selectors you can see in the "Live page interactive
elements" section if one is provided (real, application-based selectors) -
never invent a selector that isn't present there. If no live elements are
provided, use clearly-marked placeholders like '#TODO-verify-add-button'
instead of guessing a real-looking one.

LOCATOR VALUE FORMAT (strict): every locator's value must be a real,
usable XPath selector string, starting with // or (// - use XPath for
EVERY locator in this framework, never CSS syntax, to match this
project's established convention. Never a bare word or phrase copied
from the menu/button's visible text. WRONG: menu_configuration =
"Configuration" (this is plain text, not a selector - clicking it will
fail). WRONG: menu_configuration = "li.menu-item:has-text('Configuration')"
(this is CSS, not XPath). RIGHT: menu_configuration =
"//li[contains(@class,'menu-item') and contains(text(),'Configuration')]"
or, if you see the real element's tag/class/id/attributes in the live
elements section, build the XPath directly from those, e.g.
"//span[@id='addBtn']" or "//input[@name='brandTypeName']". A locator
value must always be something Playwright's page.locator() could
directly use to find exactly one element - never a plain label, never a
vague description, never CSS syntax.

NEVER HEDGE WITH "or" CONDITIONS (strict - this is the SAME hedging
mistake as crammed comma-separated selectors, just written differently):
WRONG: "//span[@id='stUI17_txt' or contains(text(),'Configuration')]" -
combining an id-match and a text-match with "or" inside one XPath is
still picking two guesses and hoping one works, exactly like the
comma-separated CSS hedge this rule already forbids. Pick ONE match
strategy and commit to it: either the id/attribute you actually saw on
the real element, OR a text-based match if that's what you saw - never
both joined by "or". If you are not confident which one is correct,
that is exactly when a clearly-marked placeholder is the honest answer,
not a two-strategy XPath dressed up as a single locator.

The test data Excel file will be named exactly <ModuleTitle>.xlsx (one
file shared across every action for this module - e.g. module "brand" ->
file Brand.xlsx), but the SHEET inside it is named after the CURRENT
ACTION, title-cased (e.g. action "add" -> sheet "Add", action "view" ->
sheet "View"). Your generated test file's method for this action MUST
call ExcelUtil.get_sheet("<ModuleTitle>", "<ActionTitle>") - module title
for the file, action title for the sheet.

CSV COLUMNS (critical - this is what makes the test actually data-driven,
not just validation-only): the FIRST five columns, in this exact order,
are always:
ScenarioID,TestcaseID,Description,ExpectedMessage,Priority
Priority must be exactly one of High/Medium/Low, assigned by YOU based on
real business risk - the positive/happy-path row and any row testing a
required-field validation are usually High (core functionality); a
max-length or format-edge-case row is usually Medium; a cosmetic or
rarely-hit edge case is Low. This lets a sanity run filter to High-only
later. Immediately after those five, add ONE MORE COLUMN PER DISTINCT
INPUT FIELD identified in the scenario, named exactly after that field's
own label (e.g. "Brand Type Name", "Description" if the form itself has
a field literally called Description). If a field's own name would be
identical to one of the fixed column names above (e.g. the form has a
field called "Description"), rename that field's column to
"<FieldName> Value" (e.g. "Description Value") to avoid ambiguity - never
silently drop or merge it with a fixed column. Every row must have a
real, usable value in every field column - the value that row's flow
should actually type into that field (e.g. "TestBrand01" for a positive
row's Brand Type Name column, an empty string "" for the row testing
that field left blank, a 300-character string for the row testing max-
length). Your generated Page class method must read these exact column
names via data["<Field Name>"] - never invent a field value inline in
the Page class code, always pull it from the row's own column, since
that is what makes each test case row actually exercise a different
value.

FIELD-BASED TEST DATA RULE: the scenario you are given will normally
describe ONLY the positive/happy-path flow (fields filled correctly,
successful save). You must still identify every distinct input field
named in that positive scenario (e.g. "Brand Type Name", "Description")
and, entirely on your own, generate the negative/validation rows for
each one - the user will not describe negative cases separately. This
applies REGARDLESS of whether that field's locator ended up as a real
verified selector or a placeholder (#TODO-verify-...) - never skip
generating negative rows for a field just because its locator wasn't
verified against a live page. The locator being a placeholder is a
separate, later concern (fixed once the real selector is confirmed) -
it must never reduce the test DATA coverage. For
EACH field found in the positive scenario, generate:
  - 1 positive/valid row (that field filled correctly, everything else valid)
  - empty/required-field row (that field left blank, others valid)
  - max-length / too-long value row, if the field looks like a text input
  - invalid-format row, if the field name implies a format (email, code,
    number, date, etc.) - skip this for plain free-text fields
Do not invent fields that were never mentioned in the scenario. Do not
generate duplicate rows for the same field+condition. Each row's
Description must name which field and which condition it tests, e.g.
"Brand Type Name left empty", "Description exceeds max length" - so the
CSV is self-explanatory field-by-field, not just one generic positive
and one generic negative row for the whole form. Keep every row in the
exact same CSV column format given above (ScenarioID,TestcaseID,
Description,ExpectedMessage) so it matches the existing testdata file
conventions already used elsewhere in this framework.

REALISTIC EXPECTEDMESSAGE WORDING: ExpectedMessage must read like real
application copy, not a generic placeholder like "Success" or "Error
occurred". If the live page elements given below (or the existing
locators file) show an actual success/error/validation message text
anywhere, use that EXACT wording. Otherwise, write a plausible,
specific message matching how this kind of field/action normally phrases
it in real UIs (e.g. "Brand Type Name is required" not "Field is
required", "Brand Type added successfully" not "Success"). For any field
value referenced inside the Page class method body itself (not the CSV -
this framework's CSV columns are fixed to ScenarioID/TestcaseID/
Description/ExpectedMessage only), use realistic, format-correct sample
values matching the field's apparent type - a real-looking email address
for an email field, a plausible name for a name field, a properly
formatted date for a date field - never a placeholder-looking string
like "test123" or "asdasd".

PAGE CLASS METHOD STRUCTURE (strict): the generated Page class holds
several small, clearly-named methods - one per distinct step of the
scenario (navigate to the module, click Add/Edit/etc., fill the fields,
click Save, assert the result) - matching this framework's real,
existing convention exactly as shown in the MULTI-BANK DISPATCH section
below (see user_role_page.py-style reference there). Do NOT collapse
everything into one giant method - each logical step is its own method,
named for what it does (e.g. navigate_to_<module>, click_add_button,
fill_<module>_form, click_save_button, assert_<module>_message). Login is
a separate concern entirely - done via BankLoginPage/AdminLoginPage/etc.
in the TEST file BEFORE calling any of these page methods, exactly as
described in the LOGIN PAGE section above; it never appears as a method
on this page class. The test file then calls these methods in sequence,
passing bank explicitly to each one (see MULTI-BANK DISPATCH below for
the exact signature shape). Keep base_page.py's own methods
(click_by_locator etc.) as the only lower-level calls used inside each
of your small methods.

MULTIPLE ACTIONS IN ONE MODULE (critical - see the EXISTING PAGE/TEST
FILE sections above for whether you're adding to existing files): a
module like "brandtype" commonly ends up with several actions built over
time - Add today, View/Edit/ChangeStatus later. Each action gets its OWN
set of small methods in the SAME page class file and its OWN test
method(s) in the SAME test file - never a separate module, separate page
file, or separate test file per action. If an existing page/test file is
given below and it already has methods for a DIFFERENT action than the
one you're generating now, add your new action's methods alongside them,
changing nothing about the existing action's methods. If it already has
methods for the SAME action you're generating now (re-running the same
action, e.g. because fields were added to the scenario), replace only
those specific methods, not the whole file, and not other actions'
methods.

MULTI-BANK DISPATCH (the DEFAULT pattern - see below for when a real
reference overrides it, and see the MULTI-BANK PAGE CLASS section above
for whether you're adding to an existing file or creating fresh): unless
overridden (see REAL REFERENCE CONVENTION OVERRIDES THIS DEFAULT, right
after this example), match this framework's real, already-working
instance-dispatch convention EXACTLY - the same pattern admin_login_page.py
and bank_login_page.py use. self._dispatch is an INSTANCE dict built inside
__init__ (NOT a module-level variable, NOT a class attribute), mapping
each bank to a (method, locators) TUPLE. Each bank's locators class is
imported with an ALIAS (every bank's own locators file names its class
the same way, e.g. every bank has its own class called
BrandtypeLocators - the alias is what makes multiple banks importable
into one page file without a name collision):
    from src.common.base.base_page import BasePage
    from src.banks.wio.locators.brandtype_locators import BrandtypeLocators as WioBrandtypeLocators
    from src.banks.alrajhi.locators.brandtype_locators import BrandtypeLocators as AlrajhiBrandtypeLocators

    class BrandtypePage(BasePage):
        def __init__(self, page, module_name="Brandtype"):
            super().__init__(page, module_name=module_name)
            self._dispatch = {
                "wio": (self._add_standard, WioBrandtypeLocators),
                "alrajhi": (self._add_standard, AlrajhiBrandtypeLocators),
            }

        def navigate_to_brandtype(self, bank: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.hover_by_getbytext(loc.menu_configuration, "Configuration menu")
            self.click_by_locator(loc.menu_brandtype, "Brand Type submenu")

        def click_add_button(self, bank: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.add_button, "Add button")

        def fill_brandtype_form(self, bank: str, data: dict) -> None:
            method, loc = self._dispatch[bank.lower()]
            method(loc, data)

        def _add_standard(self, loc, data: dict) -> None:
            self.fill_by_locator(loc.brand_type_name_input, data["Brand Type Name"], "Brand Type Name")
            self.fill_by_locator(loc.description_input, data["Description Value"], "Description")

        def click_save_button(self, bank: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.click_by_locator(loc.save_button, "Save button")

        def assert_brandtype_message(self, bank: str, expected_message: str) -> None:
            _, loc = self._dispatch[bank.lower()]
            self.assert_text(self.locator(loc.message_container), expected_message, "Response Message")

REAL REFERENCE CONVENTION OVERRIDES THIS DEFAULT TOO: exactly like the
testdata-structure override elsewhere in this prompt, the self._dispatch
tuple pattern above is only the DEFAULT for when nothing else is known.
If the REFERENCE FILES given elsewhere in this prompt show the team's
real, established page-class convention is actually DIFFERENT - e.g. a
MODULE-LEVEL "BANK_LOCATORS = {"wio": WioXLocators, ...}" dict (not
built inside __init__), the page class storing self.bank = bank directly
in __init__ instead of a per-method bank parameter, and each method doing
"loc = BANK_LOCATORS[self.bank]" with no handler-function-in-a-tuple at
all (calling its own field-filling logic inline, or delegating to a
plain helper method chosen by an if a bank-specific override is
genuinely needed) - REPLICATE THAT REAL CONVENTION EXACTLY instead of
the self._dispatch-tuple shape shown above. Do not mix the two styles
within one file (e.g. never a module-level BANK_LOCATORS dict THAT ALSO
stores handler tuples - pick whichever one the reference actually shows
and follow it completely, including where self.bank is stored, how each
method receives/looks up its bank, and the exact method-naming pattern
for assertion helpers (e.g. assert_success_message,
assert_validation_error) shown in the reference.

ASSERTION LOCATOR - GROUNDED, NEVER GUESSED: message_container above is a
NAMED locator defined in that bank's own locators file, exactly like
every other locator - it is NEVER a hardcoded, generic xpath written
directly inside the assertion call (e.g. never inline
self.assert_text(self.locator_by_xpath("//div[@class='success']"), ...) -
a guessed class name like that is exactly as unreliable as guessing a
form field's locator, and for the same reason: real pages name their
success/error/toast/alert containers all kinds of different things
(a <div class="alert-success">, a <span role="status">, a Bootstrap
toast, a plain <p> right after the form), and guessing one generic
pattern will silently fail to match the real page. Ground it the same
way every other locator is grounded:
  - If the live DOM scan actually captured a message/alert/toast
    element (e.g. left over from a prior action on the same page, or
    visible in the scanned HTML), use ITS real selector.
  - If the person's own scenario text describes where/how the message
    appears (e.g. "a green banner at the top"), that description is
    real evidence too - build the locator from it.
  - If NEITHER gives real evidence for this specific page, mark it
    exactly like an unconfirmed field locator elsewhere in this
    framework: message_container = "#TODO-not-found-in-scan" - never
    silently substitute a plausible-looking generic guess in its place.
Every bank starts pointing at the SAME shared flow method (e.g.
_add_standard above) unless you have concrete evidence a specific bank
needs a genuinely different flow (an extra MFA step, an extra field only
that bank's form has, different field order, etc.) - in that case, give
that bank its own private method (prefixed with _, like
_login_standard_mfa in the real login pages) and point its dispatch
entry at that instead, exactly like admin_login_page.py routes
"neoleap" to _login_standard_mfa while others use _login_standard.
CONCRETE EXAMPLE - one bank has an extra field: if ecentric's locators
class has a "category_dropdown" that no other bank's locators class
defines, do NOT try to handle that with a getattr guard bolted onto the
shared method - give ecentric its own method instead:
    self._dispatch = {
        "wio": (self._add_standard, WioBrandtypeLocators),
        "ecentric": (self._add_with_category, EcentricBrandtypeLocators),
    }

    def _add_standard(self, loc, data: dict) -> None:
        self.fill_by_locator(loc.brand_type_name_input, data["Brand Type Name"], "Brand Type Name")
        self.fill_by_locator(loc.description_input, data["Description Value"], "Description")

    def _add_with_category(self, loc, data: dict) -> None:
        self.fill_by_locator(loc.brand_type_name_input, data["Brand Type Name"], "Brand Type Name")
        self.fill_by_locator(loc.description_input, data["Description Value"], "Description")
        self.select_by_locator(loc.category_dropdown, data["Category"], "Category")
This is the preferred pattern for ANY bank-specific extra field or step
difference - a dedicated method per distinct flow, dispatched via the
tuple in self._dispatch - not defensive getattr guards scattered through
one shared method trying to cover every bank's variations at once.
Public methods (navigate_to_x, click_add_button, etc.) always unpack
`_, loc = self._dispatch[bank.lower()]` (or `method, loc = ...` when
they need to call the shared/bank-specific flow method); never reference
a specific bank's Locators class directly anywhere else in a method
body. This is the reference shape for EVERY generated page class: one
small, clearly-named method PER STEP of the scenario (navigate, click
each button, fill the fields, assert the
result) - not one giant method. Only include a bank's import/dispatch
entry for banks that actually have this module built (start with just
the current bank on first creation; ADD further banks' entries/imports
when this module is generated for them later, per the MULTI-BANK PAGE
FILE merge rules above). Adjust the method names/count/fields only to
match THIS scenario's actual steps - never invent extra methods the
scenario doesn't need, and never collapse multiple distinct steps into
one method just to shorten the file. The test file then calls these
small methods in sequence, passing bank explicitly to each one, exactly
as the real login pages' test files do.

HOVER VS CLICK - MATCH THE SCENARIO'S OWN VERB, DO NOT COPY THE EXAMPLE
LITERALLY (critical): the example above uses hover for the Configuration
menu and click for Brand Type/Add because THAT scenario said "hover the
Configuration menu... click the Brand Type sub-menu... click Add
button". For the CURRENT scenario you are given, look at the actual verb
used for EACH navigation step:
  - scenario says "hover" for a step -> generate self.hover_by_getbytext(
    loc.xxx, "...") or self.hover_by_role(...) for that step (pick
    whichever real base_page.py hover method's signature fits) - NEVER
    self.click_by_locator for a step the scenario says to hover. There is
    NO self.hover_by_locator method anywhere in base_page.py - do not
    call it under any circumstance, even though the name sounds
    plausible next to click_by_locator/fill_by_locator; if you are not
    sure which real hover_by_* method fits, use hover_by_getbytext.
  - scenario says "click"/"select"/"tap" for a step -> generate
    self.click_by_locator(loc.xxx, "...") for that step.
Every navigation step's method choice must trace back to that specific
step's own verb in the CURRENT scenario - never assume every menu is
hover, never assume every menu is click, and never reuse the example's
hover/click pattern for a scenario that describes something different.

CORE FIELDS VS OPTIONAL FIELDS (critical - do not blanket-wrap
everything in getattr/None-checks, this was a real bug seen in practice
that made generated methods needlessly verbose AND masked real failures
by silently skipping required steps): a field is CORE if it is
explicitly named in the scenario you were given for THIS run - call its
locator DIRECTLY, no getattr, no "if field and value" guard, exactly the
way the existing reference page files do it (self.fill_by_locator(
loc.brand_type_name_input, data["Brand Type Name"], "Brand Type Name") -
nothing more). If loc doesn't actually have that attribute for the
current bank, that IS a real bug that should surface as an
AttributeError and get fixed, not be silently swallowed.
A field is OPTIONAL only when you were EXPLICITLY told it exists for one
bank/action but not another (via the MULTI-BANK PAGE CLASS or existing
locators sections above showing a real difference between banks) - ONLY
those specific fields get the defensive getattr(loc, "field_name", None)
guard shown below. Do not apply this pattern preemptively to fields you
have no actual evidence differ across banks - Save button, the
assertion, and every field named in the current scenario are core and
must be called directly, matching this project's existing page file
style exactly (see the reference sample_page.py given below for the
plain, direct calling convention to match).
    # Only for a field confirmed to be bank/action-specific:
    extra_field = getattr(loc, "category_input", None)
    if extra_field and "Category" in data:
        self.fill_by_locator(extra_field, data["Category"], "Category")

MULTI-BANK MODULES MUST BE SCENARIO-DRIVEN, NOT RE-DERIVED FROM A FRESH
DOM SCAN (critical): when this module ALREADY has an existing page class
for at least one other bank (an EXISTING PAGE CLASS is given below), the
scan you were given for THIS bank exists ONLY to find this bank's own
real locators - it must NEVER be allowed to independently reshape the
module's method names, action set, or structure. A fresh, unguided DOM
scan naturally varies page to page (different field order, an extra
field the last bank didn't have, a slightly different label) - if that
variation is allowed to drive the generated method structure the way it
would for a brand-new module, the SAME logical module ends up with
inconsistent, incompatible method signatures across banks in what should
be one coherent page class. The existing page class's own real method
names, parameters, and dispatch structure are the authority on what this
module's actions and fields actually are - add this bank into that SAME
structure (its own locators class, one more dispatch entry) rather than
generating a parallel, independently-shaped set of methods from what
this bank's scan happened to show. If this bank's real page genuinely
lacks a field every other bank has (or has a genuinely new one), that is
exactly the "field confirmed to be bank/action-specific" case above -
handle it with the getattr guard shown there, not by renaming or
restructuring the shared methods themselves.

TEST-FILE-HELD LOCATOR CONSTANTS FOR GENERIC ASSERTION METHODS: if the
reference shows the test file itself importing the bank's locators class
directly (e.g. "from src.banks.wio.locators.merchant_locators import
MerchantLocators as loc" at the top of test_merchant.py) and then calling
a GENERIC page-class assertion method by passing a specific named
locator constant as an argument (e.g.
merchant_page.assert_validation_error(loc.search_by_error,
data["ExpectedMessage"], "Search By validation error") - one shared
method, many different real locators supplied by the test file per
call), that is the real, established convention to match - not a
dedicated per-field assertion method fully encapsulated inside the page
class. In that case: the page class defines ONE generic method (e.g.
assert_validation_error(self, locator: str, expected_message: str,
description: str) -> None, internally doing
self.assert_text(self.locator(locator), expected_message, description) -
see the reference's own version for the exact real signature), the test
file imports the SAME bank's locators class the page file itself uses,
and each assertion call in the test file passes the specific real
locator constant for what it's checking. This keeps the assertion CALL
itself in the test file (matching what the real reference does) while
the actual assert_text mechanics still live in the page class - do not
move this generic assertion method's real logic into the test file, and
do not invent a separate dedicated method per validation error when the
reference's own convention already shares one generic method this way.

NEVER ADD STEPS NOT IN THE SCENARIO (critical): the generated method must
do EXACTLY what the scenario describes - navigate, fill, save/submit,
assert - and NOTHING else. Never add a logout step, a navigation-away
step, a cleanup step, or any action the scenario didn't mention, even if
it seems like reasonable housekeeping. Logout is handled entirely
separately by this tool's own login-session management - it must NEVER
appear inside a generated execute_<action>_<module>() method.

Output format is STRICT: one or more blocks, each starting with a line
exactly like:
### FILE: <relative/path/from/repo/root.py>
followed by the full file content, then a blank line before the next
block. No prose, no markdown fences, no explanation outside the blocks.
Always include, in this order:
1. The locators file (src/banks/<bank>/locators/<module>_locators.py)
2. The page class file (src/common/pages/<module>/<module>_page.py)
3. The test file (src/testcase/<module>/test_<module>.py)
4. A CSV-formatted block (### FILE: <module>_testdata.csv) with columns
   ScenarioID,TestcaseID,Description,ExpectedMessage - 1 positive case
   and 2-3 negative/boundary cases, ready to paste into Excel.

TESTDATA COLUMNS - ONLY THE REAL FIELDS, NOTHING INVENTED: beyond the
fixed metadata columns (ScenarioID, TestcaseID, Description,
ExpectedMessage), every OTHER column must correspond to a field the
person's scenario text actually named or the real scan actually found
- never add a column for a field neither of those mentioned, even if
it seems like a plausible, commonly-paired field a real form "usually"
has. If the scenario says "fill BIN, fill Reason" - the testdata gets
exactly a BIN column and a Reason column, not also a Currency column or
a Status column the person never asked for. This applies per-action
too: a Search action's testdata only gets columns for what Search
itself actually fills/selects (e.g. just the field being searched by) -
it does NOT inherit every column the Add action's testdata has, unless
Search's own scenario text genuinely fills those same fields too.

EXECUTION ORDER FOR MULTI-ACTION MODULES: when a test class covers
several actions on the SAME record (Add, then View/Edit/Delete that all
reference what Add just created - see the testdata continuity rule
elsewhere in this prompt), the actions MUST run in the real dependency
order, never left to pytest's own default (usually file-definition
order, which happens to often match, but isn't a RELIABLE guarantee
across pytest versions/plugins/collection changes). Mark each test
method explicitly with @pytest.mark.order(N) (the pytest-order plugin,
already a dependency of this framework): Add gets order(1); View and
Edit (which only READ or MODIFY the Add'd record, not each other) both
get order(2); Delete - which must run LAST, after anything else that
needed the record to still exist - gets order(3). Stack this mark
alongside the existing pytest marks (sanity/bank-name/regression etc),
never replacing them. A module with only Add (no linked View/Edit/
Delete) doesn't need this mark at all - it only matters once a LATER
action's testdata genuinely depends on an EARLIER action's record still
existing.

TEST FILE QUALITY BAR: match the polish of the reference test file exactly
- not just its import/parametrize shape. Specifically:
- A module-level docstring: one line naming the module under test.
- The test class docstring states what flow it covers.
- Read BANK_NAME from ConfigManager.get("bank") exactly as the reference
  does - never hardcode the bank name as a string literal in the test.
- Build the parametrize ids the same way the reference does (ScenarioID -
  TestcaseID - Description), so pytest -v output is as readable as the
  reference's.
- Each test method has a one-line docstring describing the scenario in
  plain English, not just repeating the method name.
- Assertions must be specific: assert on the exact expected message/state
  from the data row, never a bare assert True or a vague truthy check.
- No commented-out code, no print-debugging left in, no TODO placeholders
  in the test file itself (placeholders belong only in locators.py where
  a real selector couldn't be determined).
- PYTEST MARKS: if the reference test file stacks multiple @pytest.mark
  decorators on its test class (e.g. @pytest.mark.sanity,
  @pytest.mark.<bankname>, @pytest.mark.regression), apply that SAME set
  on the generated class too - these are real, meaningful test-selection
  tags the team's CI/local runs rely on, not decoration to drop.
- CHAINED, MULTI-STEP TEST METHODS: if the reference shows a single test
  method performing SEVERAL actions and assertions in sequence (e.g. one
  test that edits a record by ID, asserts success, then edits the same
  or another record by name, asserts success again - or one negative
  test that walks through several distinct validation errors one after
  another), that is the real convention to match - do not force everything
  into one-assertion-per-test-method if the reference's own established
  style chains multiple steps/assertions together in a single method.
- NAMED, REUSABLE ASSERTION HELPERS: if the reference's page class defines
  its own small helper methods for common assertions (e.g.
  assert_success_message(expected_message) or assert_validation_error(
  locator, expected_message, description), each internally calling
  self.assert_text(...) once) rather than calling self.assert_text(...)
  directly from the test file every time, define and use those SAME
  named helpers in the generated page class too - test methods then call
  merchant_page.assert_success_message(...) the same clean way the
  reference does, instead of reaching past the page object into raw
  assert_text calls from the test file itself.
- NO if/else BRANCHING INSIDE A TEST METHOD: a test method's body must
  follow ONE single, deterministic path from login to final assertion -
  never an if/else (or ternary used the same way) that decides WHICH
  action to take, WHICH button to click, or WHICH assertion to run based
  on the test data or any other condition. A test with a branch inside
  it is actually testing two different things under one name, which
  hides which path actually ran in the pytest report and makes failures
  ambiguous. When a module offers multiple distinct outcomes for the same
  starting flow - the clearest real example being a form with BOTH a
  Save button and a Cancel button - that is TWO SEPARATE test methods
  (e.g. test_save_brandtype and test_cancel_brandtype), each following
  its own single straight-line path with its own parametrize/testdata
  slice, never one test method that branches on a flag to decide which
  button to press. This applies generally, not just to Save/Cancel -
  any "two ways this flow can end" situation (Confirm vs Reject, Submit
  vs Discard, Approve vs Decline) gets the same treatment: one clean
  method per outcome.
- CONDITIONAL FIELDS (a toggle that reveals extra fields when turned
  on): if the scan includes a "[CONDITIONAL FIELDS - found by toggling
  controls on/off during the scan...]" section, that's REAL evidence -
  not a guess - that turning a specific control on reveals the exact
  extra fields listed there. This is the SAME "two ways this flow can
  end" situation as Save/Cancel above, applied to a toggle instead of
  two buttons: write it as TWO separate test methods, never one method
  that branches on whether the toggle is on. One method exercises the
  ENABLED path (turns the toggle on, fills the base fields PLUS every
  extra field the scan found, saves, asserts success) with its own
  testdata rows; the other exercises the DISABLED path (leaves the
  toggle off, fills only the base fields, saves, asserts success) with
  its own separate testdata rows. The page class gets two corresponding
  methods (e.g. add_x_enabled and add_x_disabled, or whatever naming
  the reference's own convention uses for two related-but-distinct
  flows) rather than one method with an if enabled: ... else: ... split
  inside it - the "no branching" rule above applies inside the page
  class's own methods too, not only inside test methods.
"""

SCENARIO_REVIEW_SYSTEM_PROMPT = """You are reviewing a QA automation scenario BEFORE any code is
generated from it - the goal is to catch gaps, ambiguity, or missing
information NOW, while it's cheap to ask the person a clarifying
question, rather than after a live DOM scan and AI code generation have
already happened based on a flawed scenario.

Look for genuine problems only - things that would make it impossible
or unreliable to generate correct code from this scenario as written:
  - A field, button, or value referenced too vaguely to act on (e.g.
    "fill the fields" with no field names, "select the right option"
    with no indication which one)
  - A step that assumes something not stated (e.g. jumping straight to
    "click Save" with no navigation or field-filling steps at all)
  - An assertion/expected outcome that's missing entirely (no mention
    of what should happen after the action - success message, a
    specific value, a page change)
  - Internally contradictory steps (e.g. describes both "select Yes"
    and "select No" for what sounds like the same single field)
  - A dropdown/radio/checkbox referenced with no real option values
    given at all, where the scenario's own wording suggests the person
    DOES know the real options (e.g. "select the country" - which
    country, from what options?)

Do NOT flag things that are genuinely fine as written:
  - A short, clear scenario that simply doesn't need every field
    spelled out (e.g. "click Add, fill Name and Description, click
    Save, assert success message" is complete and fine even though it
    doesn't list every possible field)
  - "DOM mode" style brevity is not itself a gap - a deliberately
    short scenario that says to derive details from a live scan is
    working as intended, not incomplete
  - Reasonable assumptions a competent test engineer would fill in
    automatically (e.g. "click Login" doesn't need "on the login
    page" spelled out)

Respond in EXACTLY one of these two formats, nothing else:

FORMAT 1 - no real issues found:
NO_ISSUES

FORMAT 2 - genuine issues found:
ISSUES:
- <first specific issue, one line, plain language>
- <second specific issue, if any>
SUGGESTED_SCENARIO:
<a corrected/completed version of the scenario text, fixing exactly the
issues listed above and nothing else - do not rewrite parts that were
already fine, do not add speculative fields/steps the person never
implied, only resolve genuine ambiguity/gaps using the most reasonable
interpretation of what they likely meant>
"""


def review_scenario_for_gaps(scenario_text: str, module: str) -> tuple[bool, str, str]:
    """FEATURE: pre-generation scenario review - catches a vague or
    incomplete scenario BEFORE any live DOM scan or code generation
    happens, while it's still cheap to show the person a specific
    concern and a suggested fix rather than only discovering the
    problem after generation produces something wrong/incomplete from
    an ambiguous description. This is NOT the same thing as DOM
    auto-derivation (a deliberately brief "DOM" scenario is not what
    this flags) - it targets scenarios the person WROTE THEMSELVES that
    have a genuine, specific gap a reviewer would actually notice.

    Returns (has_issues, issues_text, suggested_scenario). If
    has_issues is False, issues_text and suggested_scenario are both
    empty strings and the original scenario should be used unchanged -
    this happens both when the AI found nothing wrong AND when the
    review call itself fails (never blocks generation just because the
    review step had a hiccup)."""
    if not scenario_text or not scenario_text.strip():
        return False, "", ""
    user_prompt = f"Module: {module}\n\nScenario as written:\n{scenario_text}"
    reply = ask_ai(SCENARIO_REVIEW_SYSTEM_PROMPT, user_prompt)
    if not reply or reply.strip().upper().startswith("NO_ISSUES"):
        return False, "", ""
    issues_match = re.search(r"ISSUES:\s*\n(.*?)\nSUGGESTED_SCENARIO:\s*\n(.*)", reply, re.DOTALL)
    if not issues_match:
        return False, "", ""  # reply didn't follow the expected format - don't block generation over it
    issues_text = issues_match.group(1).strip()
    suggested_scenario = issues_match.group(2).strip()
    if not issues_text or not suggested_scenario:
        return False, "", ""
    return True, issues_text, suggested_scenario


def compute_multi_action_list(explicit_scenarios: dict[str, str] | None, include_add: bool) -> list[str]:
    """Returns the exact list of action names (e.g. ["view", "edit"] or
    ["add", "view", "edit", "changestatus"] or ["add", "assignmenu"])
    that a combined multi-action call was told to generate - the SAME
    logic build_multi_action_instructions uses to decide what to
    include, extracted here so run_full_module_pipeline can check the
    AI's reply against what was actually ASKED for (not a hardcoded
    standard-4 assumption, which would wrongly flag a deliberately
    Add-less or ChangeStatus-less module as having "missing" sheets)."""
    explicit_scenarios = explicit_scenarios or {}
    STANDARD = ("view", "edit", "changestatus")
    custom_keys = [k for k in explicit_scenarios if k not in STANDARD]
    derive_missing_standard = not custom_keys and include_add
    included = []
    for action in STANDARD:
        if (action in explicit_scenarios and explicit_scenarios[action].strip()) or derive_missing_standard:
            included.append(action)
    included.extend(custom_keys)
    return (["add"] + included) if include_add else included


def build_multi_action_instructions(explicit_scenarios: dict[str, str] | None = None,
                                     include_add: bool = True,
                                     search_by_fields: list[str] | None = None) -> str:
    """Builds the instruction block that tells the AI to produce Add plus
    every other action for this module in ONE reply. For any action the
    person typed a scenario for themselves (explicit_scenarios), that
    EXACT scenario text is given and the AI is told to follow it as
    written - not to invent its own version.

    include_add: False when the module ALREADY has Add implemented (see
    run_full_module_pipeline's add_already_exists) - the AI is told to
    generate ONLY the action(s) in explicit_scenarios and leave the
    existing execute_add_<module> alone entirely, instead of the normal
    "Add plus N others" contract.

    search_by_fields: when the person has confirmed this module has a
    "Search by" dropdown (search by ID / Name / Email / etc, not just a
    single plain search box), the list of field options given (e.g.
    ["ID", "Name", "Email"]) - this triggers a THIRD layout case in the
    SEARCH-SELECT-ACTION PATTERN below (dropdown + value, distinct from
    both the plain-search-box and no-search-box layouts).

    The standard three (View/Edit/ChangeStatus) get AUTO-DERIVED from the
    Add scenario when left out - BUT ONLY when the person hasn't also
    given some OTHER custom action (e.g. "Assign Menu:", "Approve:") of
    their own. A custom action's presence means the person described
    their own real, complete action set for this module - many modules
    genuinely don't have a Change Status at all (e.g. a User Role screen
    with Add/View/Edit/Assign Menu instead), and force-deriving one
    anyway would invent a flow/button that doesn't exist on the real
    page. Any custom action given is ALWAYS included as-is, verbatim -
    there's no generic template to derive it from if left blank, unlike
    the standard three."""
    explicit_scenarios = explicit_scenarios or {}
    STANDARD = ("view", "edit", "changestatus")
    custom_keys = [k for k in explicit_scenarios if k not in STANDARD]
    # If the person gave even one custom action, treat their set as their
    # own deliberate, complete list - don't also force-invent whichever
    # standard ones they left unmentioned.
    derive_missing_standard = not custom_keys and include_add

    action_lines = []
    included_action_names = []
    for action, label in (("view", "VIEW"), ("edit", "EDIT"), ("changestatus", "CHANGESTATUS")):
        if action in explicit_scenarios and explicit_scenarios[action].strip():
            action_lines.append(
                f"  {label:<13} - use this EXACT scenario as given, do not reword or "
                f"reinterpret it: \"{explicit_scenarios[action].strip()}\""
            )
            included_action_names.append(action)
        elif derive_missing_standard:
            derive_hint = {
                "view": "search for the added record (see SEARCH-SELECT-ACTION PATTERN below), "
                        "select it, click View, assert its fields display correctly (no Save).",
                "edit": "search for the added record, select it, click Edit, change the SAME "
                        "field(s) named in the Add scenario, click Save, assert an "
                        "updated/success message.",
                "changestatus": "search for the added record, select it, click Change Status "
                                 "(or Activate/Deactivate/Enable/Disable - use this module's "
                                 "realistic wording), confirm, assert the status-changed message.",
            }[action]
            action_lines.append(f"  {label:<13} - not given explicitly, DERIVE it yourself: "
                                 f"log in fresh, reuse the same menu navigation and field names "
                                 f"as the Add scenario, then {derive_hint}")
            included_action_names.append(action)
        # else: not given, and either a custom action was given elsewhere
        # or Add already exists (nothing to derive from in this call) -
        # this action isn't being generated this time, skip it entirely.

    for key in custom_keys:
        label = key.upper()
        action_lines.append(
            f"  {label:<13} - use this EXACT scenario as given, do not reword or "
            f"reinterpret it: \"{explicit_scenarios[key].strip()}\""
        )
        included_action_names.append(key)

    base_actions = (["add"] + included_action_names) if include_add else included_action_names
    action_count = len(base_actions)
    method_list = ", ".join(f"execute_{a}_<module>" for a in base_actions)
    test_list = ", ".join(f"test_<module>_{a}" for a in base_actions)
    csv_file_lines = "\n".join(f"### FILE: <module>_testdata_{a}.csv" for a in base_actions)

    add_context_line = (
        "Generate Add plus" if include_add else
        "Add ALREADY EXISTS (do not generate or touch execute_add_<module> - see the existing "
        "page/test file content given below) - generate ONLY"
    )

    return f"""
MULTI-ACTION MODE - IMPORTANT, READ CAREFULLY:
{add_context_line} {len(included_action_names)} other action(s) for this
module in this single reply - {action_count} action(s) total.
{"The Add scenario is given separately below; for the rest:" if include_add else "For each:"}

{chr(10).join(action_lines)}

SEARCH-SELECT-ACTION PATTERN (applies to View/Edit/ChangeStatus and any
similar record-level custom action like Assign Menu, whether derived by
you or given explicitly, unless the given scenario clearly describes
something different): these admin-grid modules require FINDING the
target record before acting on it - the record could be on the first
page or any later page of the list, so a bare "click the row" is WRONG.
Look at the live-scanned page elements given below to decide WHICH of
these {"three" if search_by_fields else "two"} real layouts this module
actually uses - do not assume, check what was actually captured:
{f'''
  A) A "Search by" DROPDOWN + value input exists (CONFIRMED for this
     module - the person told us it has one, with these field options:
     {", ".join(search_by_fields)}): select the dropdown option matching
     the kind of value you're searching by (e.g. select "ID" if
     searching by the record's ID, "Name" if searching by name), THEN
     type the actual value into the adjacent input, THEN click the
     module's Search/Go button. This is DIFFERENT from case B below - a
     plain search box has no dropdown to select first. Use whichever of
     the given options the scenario's identifying value naturally
     matches (an ID looks numeric/coded, a Name is text, etc).
''' if search_by_fields else ""}
  {"B" if search_by_fields else "A"}) A visible plain search/filter input exists (no dropdown) in the
     scanned elements:
     1. Log in fresh (every action's test is independent - never assume
        Add's session/browser state carries over to the other actions).
     2. Navigate to the same menu/submenu as the Add scenario.
     3. Type the record's identifying value (the same Name/Code used in
        Add) into that search/filter field so the grid narrows to that
        one record regardless of which page it was originally on.
     4. Then proceed to row-level action as in ({"C" if search_by_fields else "B"}) step 4 onward.

  {"C" if search_by_fields else "B"}) NO search/filter input exists (common - many of these grids are a
     plain paginated table with Select/View/Edit/Action columns and
     nothing else, e.g. a "Currency" or "Brand Type" listing): there is
     no textbox to type into, so build a DYNAMIC xpath that finds the
     table ROW containing the record's identifying value as visible
     TEXT, e.g. //tr[td[contains(normalize-space(text()),'{{value}}')]] -
     never hardcode one specific row's position or index, since the row
     added just now could land anywhere (older frameworks/pagination may
     even put it on page 1, not necessarily the last page - inspect
     what's realistic for this UI rather than guessing).
     4. Per-record links/buttons (View/Edit/Assign Menu and similar) are
        usually PER-ROW inline inside that matched row (as seen in the
        scanned elements) - click them directly within the matched row's
        own xpath (matched_row + "//a[text()='View']" style), no
        checkbox needed for these.
     5. Change Status is usually ONE global button below/outside the
        table (not per-row) - first tick THAT row's own checkbox
        (matched_row + "//input[@type='checkbox']"), THEN click the
        global Change Status button. Follow the SAME pattern for any
        other custom action whose given scenario describes a checkbox +
        global button instead of a per-row link.
     6. Edit only: update the field(s), click Save. ChangeStatus only:
        confirm on any dialog that appears.

This means the locators file needs a PARAMETRIZED/dynamic row locator
(built as an f-string/format template with the identifying value as a
placeholder, e.g. def row_by_value(value): return f"//tr[td[contains(...,'{{value}}')]]" -
not one fixed static xpath per record) plus separate locators for each
per-record action scoped inside that row, and a global button locator
for whichever action(s) use a checkbox+global-button pattern instead -
and the page class needs a shared helper (e.g. _find_row_<module>(bank,
identifier_value)) that builds/returns that row locator once, so no
action method duplicates the matching logic.

CRITICAL - generate EXACTLY this set of actions, no more, no fewer:
Put these {action_count} action methods in the SAME page class:
  {method_list}
And these {action_count} test methods in the SAME test file:
  {test_list}
Every method still follows the dispatch-per-bank convention above, one
bank's entry only. Do NOT add any action beyond the {action_count}
listed above, even if you think a real module "should" have one (e.g.
do not invent a Delete or Change Status flow that was neither given nor
listed here) - only build what's explicitly asked for in this list.

Output {action_count} separate testdata CSV blocks (not one) - one per
action - using EXACTLY these file names so the calling script can route
each to its own worksheet:
{csv_file_lines}
Each has columns ScenarioID,TestcaseID,Description,ExpectedMessage.

REAL REFERENCE CONVENTION OVERRIDES THIS DEFAULT: the one-CSV-per-action
structure above is only the DEFAULT for when nothing else is known - if
the REFERENCE FILES given elsewhere in this prompt show the team's real,
established Excel/testdata convention is actually DIFFERENT (e.g. a
SINGLE "Configuration" sheet holding every action's rows together,
distinguished by a ScenarioID naming convention like
TS_<Module><Action>_<NNN> and read via a shared filter_rows(scenario_id,
run_config) helper that filters by ScenarioID prefix and a Y/N
run_config flag, rather than one worksheet per action) - REPLICATE THAT
REAL CONVENTION EXACTLY instead of the default described above,
including matching column names, the ScenarioID naming pattern, and the
filter_rows-style helper if the reference shows one. Real, working code
the team already has is always the authoritative style to match, never
this document's own generic default - this same principle already
governs every other part of the generated code (locators, page
structure, method naming), and testdata structure is no exception.

DIRECT SETTINGS FORM MODULES (scan shows "[DIRECT SETTINGS FORM (no
Add/Edit/View flow - the page itself is the form)]" instead of the usual
"[ADD FORM]"/"[EDIT FORM]"): some real modules are a single, persistent
settings/configuration page - loaded already pre-filled with existing
values, no Add button, no list of rows to search/select/edit, just
fields plus one Save/Update button (e.g. "PG information": Gateway/FI
name, country, currency, contact details, all on one page, always the
same single record). Do NOT force this into the standard Add/View/
Edit/ChangeStatus action shape - there is no create flow and no second
record to view/edit/search for. Generate exactly ONE action for a module
scanned this way - name it update_<module> or save_<module> (match
whatever the reference's own naming convention would produce for a
single-record update), whose flow is: fill every real field found in the
scan with the test data provided, click the real Save/Update button,
assert the real success message. If the scan also found conditional
fields (see the CONDITIONAL FIELDS rule elsewhere in this prompt), that
still applies exactly the same way here - two separate test methods (one
per toggle state), never a branch inside one method.

COMPONENT-LIBRARY FORMS (Angular Material, PrimeNG, etc.): the scan HTML
you receive shows each field's small surrounding container (not just the
bare input tag), separated by "---" - this is deliberate, because these
UI libraries commonly render the real label in a CUSTOM element (e.g.
<mat-label>Gateway/FI name</mat-label>) rather than a plain <label>, and
the input itself often carries no name/placeholder at all, only a
meaningless auto-generated id (e.g. "mat-input-47"). Read the field's
REAL name from whatever readable text appears in that container - a
<mat-label>, a preceding <span>, any plain text - rather than from the
input's own id/name when that id is clearly auto-generated (numeric
suffixes, no readable words). Never invent a field name when the
container's text is genuinely just as meaningless as the id - flag that
locator as #TODO-not-found-in-scan the same as any other unconfirmed
field. Multi-select CHIPS (e.g. selected currency chips each with an "x"
to remove) are a real multi-value field, same treatment as a checkbox
group elsewhere in this prompt - not a plain text input.

<mat-select> IS NOT A NATIVE <select> - NEVER GENERATE select_option()
FOR ONE (critical, a real recurring mistake): when the scan shows a
<mat-select> element for a dropdown field (Angular Material's own
dropdown component - NOT a plain HTML <select>), the locator AND the
interaction code must both reflect that it behaves completely
differently from a native <select>:
  - LOCATOR: ground it in the real <mat-select> tag itself, e.g.
    "//mat-select[@formcontrolname='currencyCode']" or
    "//mat-select[@id='mat-select-2']" - never write a locator implying
    it's a plain <select> (e.g. never "//select[@name='currencyCode']"
    for something the scan showed as <mat-select>).
  - INTERACTION: a <mat-select> has NO real <option> children a
    playwright select_option() call could ever work against - it is a
    clickable trigger that, when clicked, opens a floating overlay
    panel containing separate <mat-option> elements elsewhere in the
    DOM (often appended to <body>, not nested inside the mat-select
    itself). The page-class method for this field must therefore be
    TWO real actions, not one select_option() call:
        self.click_by_locator(loc.currency_code_dropdown, "Currency Code dropdown")
        self.click_by_locator(loc.option_by_text.format(value=data["Currency Code"]), "Currency Code option")
    The LOCATORS class (never the page method) holds ONE shared template for every dropdown option:
        option_by_text = "//mat-option[contains(normalize-space(.), '{{value}}')]"
    An Angular Material option keeps its text in a CHILD <span>, so contains(text(), ...) or text()='...' NEVER matches -
    always normalize-space(.) (or "mat-option:has-text('{{value}}')"). If the scan shows a different option pattern for one
    dropdown, put THAT pattern in the locators class as its own template - the key point is CLICK the trigger, then CLICK
    the matching option, never select_option().
  - A generic select_by_locator()-style base_page helper that
    internally calls Playwright's native .select_option() will silently
    fail or do nothing on a <mat-select> (it has no real <select>
    element to select against) - do not call that helper for any field
    the scan showed as <mat-select>, even if the reference's own
    convention normally uses it for plain <select> dropdowns elsewhere.

NO HARDCODING ANYWHERE IN THE PAGE (critical - the generated code is reviewed for this):
  - A page method contains NO selector string at all (no "//...", no "css=", no ":has-text(", no "mat-..." selector). Every
    selector lives in the LOCATORS class. A selector that needs a value is a TEMPLATE there with a {{value}} placeholder and the
    page fills it:  loc.option_by_text.format(value=data["Card Type"]).
  - A choice among several options (radio buttons, checkbox groups, toggles, tabs, chips) is ONE template in the locators class,
    e.g.  radio_by_label = "mat-radio-button:has-text('{{value}}')"  and the page reads the choice from the Excel column:
        self.click_by_locator(loc.radio_by_label.format(value=data["BIN Status"]), "BIN Status radio")
    NEVER one locator per option (no bin_status_active_radio / bin_status_inactive_radio) and NEVER a method that always picks
    "Active" - the Excel row decides.
  - Every value that is typed, selected or asserted comes from data["<Excel header>"] - no literal text, no number, no bank name,
    no module name inside a page method. The key is spelled EXACTLY like the Excel header (same capitals, same spaces) and the
    same spelling is used in every sheet.
  - A message to assert uses a template too:
        error_message_by_text = "//mat-error[contains(normalize-space(.), '{{value}}')]"
        self.assert_visible(loc.error_message_by_text.format(value=data["ExpectedMessage"]), "validation message")

ANGULAR MATERIAL'S label[for] <-> input[id] PAIRING (use this over a raw
auto-generated id when the scan shows it): Angular Material's own real
markup, e.g.
    <label matformfieldfloatinglabel for="mat-input-8">
      <mat-label><span>Risk profile name</span></mat-label>
    </label>
    ... <input id="mat-input-8"> ...
deliberately pairs the label's for="mat-input-8" with that exact
input's id="mat-input-8" - this IS the accessible-name relationship the
framework itself relies on, not a coincidence, and it is exactly what
Playwright's own get_by_label() is built to resolve. When the scan shows
this pairing for a field, PREFER an XPath built on the real label TEXT
rather than the raw numeric id directly - e.g.
    //input[@id=//label[contains(., 'Risk profile name')]/@for]
(read the id off whichever real label text the scan actually shows, per
field) - over hardcoding "//input[@id='mat-input-8']" directly. The
numeric id is real and will work today, but it is Angular Material's own
sequential counter (assigned in component-instantiation order), and a
locator anchored to the STABLE label text survives future re-renders or
minor layout reorders that would silently shift which number a given
field gets, in a way a locator hardcoded to today's specific number
cannot. Apply this whenever the scan shows a real for/id pair with
readable label text - not only for this one field name.

CHECKER / APPROVAL STEP (an action named Approve, Authorise, Reject ...): it is its OWN action - its own data sheet (named after
the action, e.g. 'Approve'), its own page method and its own test (test_<module>_approve). It acts on the SAME record Add created, so
its identifier column continues Add's value exactly like View/Edit/Delete do. It runs right after Add and BEFORE View/Edit/Delete
(the record must be approved first), and its steps are the scenario's steps in order: the menu path of the APPROVAL screen (it differs
from the Add screen), search by the identifier, expand / open the request, click Approve, click Approve again in the confirmation dialog.
Assert the status afterwards only if the scenario says so.

TESTDATA CONTINUITY ACROSS RELATED ACTIONS (Add -> Search/View/Edit/
Delete, when they're meant to test the SAME record): a real end-to-end
flow only makes sense if the record Add creates is the SAME record
View/Edit/Delete/Search then act on - e.g. Add creates BIN "654321",
then Search for that BIN, Edit that BIN, Delete that BIN all need to
reference "654321" too, not each independently invent their own sample
BIN value. When generating testdata rows for multiple actions on the
SAME module in one reply, identify the field that's the record's real
identifying key (whatever a person would actually search/edit/delete
by - a BIN, an IP, a Merchant ID, a Name - usually obvious from the
scan/scenario) and give that field the IDENTICAL value across the Add
row and every other action's "happy path" row that's meant to continue
from it. Rows testing a genuinely different case (a negative/boundary
row, or a row explicitly about a DIFFERENT record) don't need to match -
this only applies to rows meant to chain together as one real flow.
Do NOT let this rule override the test-data uniqueness mechanism the
framework already applies AFTER generation (a run-specific suffix gets
appended automatically to whichever value you give this shared field,
uniformly across every row that shares it) - just make sure the
BASE value you write is identical across the chained rows; the
uniqueness step downstream keeps it identical after its own suffix is
applied too, since it processes the whole testdata file with one shared
run-tag, not independently per row.

FIELD-LEVEL VALIDATION COVERAGE (applies to Add and Edit specifically,
and to ANY module this pattern fits - not tied to one particular
module's fields, generic across all of them): do not just write a
fixed small negative-case count disconnected from the actual fields -
instead, for EVERY field actually present in the scanned form (look at
its real label/placeholder/name and any constraint hint visible right
in that label, e.g. "Idle State Minutes (Minimum 5 & Maximum 15)"
literally states the valid range to violate):
  - ONE positive case using a valid value for that field (respecting
    any stated min/max/format), and
  - EVERY OTHER real, distinct constraint that field states gets its
    OWN SEPARATE negative case, each with its own specific
    ExpectedMessage assertion for THAT exact violation - not one
    generic negative case covering only the first constraint noticed.
    A field stating "Idle State Minutes (Minimum 5 & Maximum 15),
    required" has THREE distinct constraints, so it gets THREE separate
    negative rows (below 5, above 15, left blank), each asserting the
    specific message that violation actually produces - not a single
    row for only one of the three. A dropdown gets a negative row for
    an option outside its real choices if that's checkable.

    SMALL FIXED-OPTION FIELDS (2-5 real choices - a Yes/No dropdown, a
    2-3-way radio group, a short enum select): this is the ONE case
    where "ONE positive case" above is not enough on its own - EVERY
    real option gets its OWN positive row, not just one of them picked
    arbitrarily. A 2-option "Enable (Yes/No)" field genuinely means TWO
    positive scenarios - the record behaves differently depending on
    which was chosen (exactly like the conditional-fields pattern
    elsewhere in this prompt, where Yes may reveal extra fields a
    No-path row never touches) - picking only one and treating the
    other as untested leaves real, reachable behavior completely
    unverified. Each option's row gets its own appropriate
    ExpectedMessage for THAT path, not a shared generic one. This
    doesn't apply to a field with many real options (a 50-country
    dropdown) - there, ONE positive case with a representative valid
    choice is still correct; exhaustively testing every option only
    makes sense once the field's own choice count is genuinely small
    enough that each one plausibly represents a distinct, real scenario
    worth its own row.

    a format-pattern field (an email, a fixed-length code) gets a
    wrong-format row in addition to any min/max/required rows it also
    has. Only truly write ONE negative row for a field if it only
    genuinely has one checkable constraint to begin with - never
    collapse multiple real constraints into a single row to save space.
A field with no discernible constraint (a free-text name field with no
stated rule) still gets a blank/required-style negative case as the
default. This means the total row count scales with how many fields
the form actually has - a 3-field form gets a handful of rows, a
15-field form (like a Password Security-style settings screen with
Min/Max lengths, several Yes/No toggles, and numeric ranges) gets a row
addressing each of its 15 fields' own constraint, not a flat 2-3.
Never copy the exact same rows across two actions' CSVs.

VIEW IS READ-ONLY (applies generically, not one module): a View action
never edits or saves anything - its testdata is just the record(s) to
open (see DROPDOWN COVERAGE below if applicable) plus assertions that
the right field values are displayed, then Back/Close. Do not generate
Save-related rows for View.
{f'''
DROPDOWN COVERAGE (confirmed for this module - it searches via a
dropdown with these exact option values: {", ".join(search_by_fields)}):
for View and Edit specifically (and any other action that also searches
via this same dropdown), the POSITIVE test cases must cover EVERY one
of these {len(search_by_fields)} option value(s) - one positive row per
value, not just one row total for the whole dropdown (e.g. if the
options are PG, INSTITUTION, MERCHANT, TRANPORTAL, that is 4 separate
positive rows for View - one selecting each - not 1). The field-level
negative cases above still apply per option where relevant.
''' if search_by_fields else ""}
Still output the locators file and the page file only ONCE each (they
hold all actions' locators/methods together) - so the full reply for
this mode is: 1 locators file + 1 page file + 1 test file + {action_count}
CSV blocks = {3 + action_count} "### FILE:" blocks total, no more, no fewer.
"""


MULTI_ACTION_INSTRUCTIONS = build_multi_action_instructions()  # the fully-auto-derive version -
                                                                # kept as a module-level constant
                                                                # since it's identical on every
                                                                # call and safe to prompt-cache.


def summarize_python_file(source: str, max_full_file_chars: int = 3000) -> str:
    """For a small file, returns it unchanged. For a large file (like
    base_page.py), automatically extracts just class/method signatures +
    docstrings via the ast module - the AI still learns every method name,
    its parameters, and what it does, but the prompt shrinks by ~90%,
    avoiding slow/timed-out AI calls. The actual file on disk is never
    touched - this only affects what gets sent in the prompt."""
    if len(source) <= max_full_file_chars:
        return source
    try:
        import ast
        tree = ast.parse(source)
    except SyntaxError:
        return source[:max_full_file_chars] + "\n# ...(truncated)..."

    lines = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            lines.append(f"class {node.name}:")
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = [a.arg for a in node.args.args]
            indent = "    " if getattr(node, "col_offset", 0) > 0 else ""
            lines.append(f"{indent}def {node.name}({', '.join(args)}):")
            doc = ast.get_docstring(node)
            if doc:
                first_line = doc.strip().splitlines()[0]
                lines.append(f"{indent}    \"\"\"{first_line}\"\"\"")
    return "\n".join(lines)


def load_reference_files(ref_dir: Path) -> str:
    parts = []
    for f in sorted(ref_dir.glob("*.py")):
        content = f.read_text(encoding="utf-8", errors="ignore")
        summarized = summarize_python_file(content)
        parts.append(f"--- REFERENCE FILE: {f.name} ---\n{summarized}")
    return "\n\n".join(parts)


def load_bank_notes(ref_dir: Path, bank: str) -> str:
    """Reads a PERSISTENT, one-time-written note about a specific bank's
    known architectural quirks - e.g. reference/bank_notes/ecentric.txt
    might say "Has an extra Category dropdown on every Add/Edit form
    that no other bank has. Uses a completely different MFA login flow
    (extra OTP step after password)." - so the person documents a
    bank's real differences ONCE, in one file, instead of having to
    re-type "ecentric has an extra field" into every single scenario/
    GUIDED-mode answer for every module they ever generate for that
    bank. Automatically included (see run_full_module_pipeline) as
    authoritative context on every call for that bank - this is what
    gives the AI the "concrete evidence" the MULTI-BANK DISPATCH
    instructions require before it will give a bank its own dedicated
    method instead of assuming it's identical to every other bank.

    Returns "" (not an error) if no notes file exists for this bank -
    most banks don't need one; only document the ones that actually
    differ."""
    notes_path = ref_dir / "bank_notes" / f"{bank.lower()}.txt"
    if not notes_path.exists():
        return ""
    try:
        return notes_path.read_text(encoding="utf-8", errors="ignore").strip()
    except Exception as exc:
        print(f"  Could not read bank notes at {notes_path}: {exc}")
        return ""


def perform_logout(login_url: str, old_storage_state_path: Path) -> None:
    """Uses the OLD saved session's cookies to visit a guessed logout URL,
    which properly ends that session server-side. This is necessary
    because "User already logged in" errors are usually a SERVER-SIDE
    session lock tied to the username - deleting the local cookie file
    alone does NOT fix it, since the server still thinks that user is
    active until an explicit logout request is made (or the session
    times out on its own, which can take a long time).

    Tries a handful of common logout URL patterns derived from the login
    URL's filename. If LOGOUT_URL env var is set, that exact URL is tried
    first instead of guessing. Failures are silent/best-effort - this is
    a convenience step, not a hard requirement, since we can't know your
    app's exact logout endpoint without you confirming it once."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return
    if not old_storage_state_path.exists():
        return  # nothing to log out of

    import os
    candidates = []
    env_logout = os.environ.get("LOGOUT_URL")
    if env_logout:
        candidates.append(env_logout)
    else:
        base = login_url.rsplit("/", 1)[0]
        for guess in ["logout.htm", "Logout.htm", "adminLogout.htm", "logoff.htm", "signOut.htm"]:
            candidates.append(f"{base}/{guess}")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            context = browser.new_context(storage_state=str(old_storage_state_path))
            page = context.new_page()
            for candidate_url in candidates:
                try:
                    page.goto(candidate_url, timeout=8000)
                    print(f"  Tried logout at {candidate_url}")
                except Exception:
                    continue
            browser.close()
    except Exception as exc:
        print(f"  (Logout attempt failed, continuing anyway: {exc})")


def capture_login_session(url: str, storage_state_path: Path) -> bool:
    """Opens a REAL, visible browser window on the given URL so you can log
    in by hand (type username/password, solve any captcha/2FA, click
    Login). Once you press Enter back in this terminal, the logged-in
    session (cookies, local storage) is saved to storage_state_path. Every
    future run of this tool re-uses that saved session automatically, so
    inspect_url() can reach pages that require login instead of only ever
    seeing the login page itself. Returns True on success."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed - run: pip install playwright --break-system-packages && playwright install chromium")
        return False
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False)  # visible window - you need to see it to log in
            context = browser.new_context()
            page = context.new_page()
            page.goto(url, timeout=30000)
            print("\nA browser window has opened. Log in there manually (username, password, any 2FA).")
            print("If you see 'User already logged in', that's a server-side session lock from a")
            print("previous login - use the Submit button anyway (most apps force-override on submit),")
            print("or check with your team for the correct logout URL and set it via: $env:LOGOUT_URL=\"...\"")
            print("Once you're logged in and can see the real application page, come back here and press Enter.")
            input("Press Enter after you've logged in... ")
            storage_state_path.parent.mkdir(parents=True, exist_ok=True)
            context.storage_state(path=str(storage_state_path))
            browser.close()
            print(f"Login session saved to {storage_state_path}. Future runs will reuse it automatically.")
            return True
    except Exception as exc:
        print(f"Could not capture login session: {exc}")
        return False


def inspect_url(url: str, storage_state_path: Path | None = None) -> str:
    """Optional: launch Playwright, grab interactive elements from the live
    page, so the AI gets real selectors instead of guessing. If a saved
    login session exists at storage_state_path, it's applied so pages that
    require login can be inspected directly (not just the login page)."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed in this environment - skipping live inspection.")
        return ""
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            state = str(storage_state_path) if storage_state_path and storage_state_path.exists() else None
            context = browser.new_context(storage_state=state)
            page = context.new_page()
            page.goto(url, timeout=30000)
            page.wait_for_load_state("networkidle", timeout=10000)
            html = page.eval_on_selector_all(
                "input, button, a, select, textarea, [role='button'], [role='menuitem'], "
                "li, span[onclick], div[onclick], [class*='menu'], [class*='nav'], "
                "[class*='tab'], [id*='menu'], [data-testid]",
                "els => els.slice(0, 300).map(e => e.outerHTML.slice(0, 300)).join('\\n')",
            )
            browser.close()
            return html
    except Exception as exc:
        _log_exception("Live inspection failed", exc)
        print(f"Live inspection failed ({exc}) - continuing with placeholder locators.")
        return ""


PORTAL_CLASS_MAP = {
    "admin": ("admin_login_page", "AdminLoginPage"),
    "bank": ("bank_login_page", "BankLoginPage"),
    "merchant": ("merchant_login_page", "MerchantLoginPage"),
    "superadmin": ("superadmin_login_page", "SuperAdminLoginPage"),  # note: capital A, matches the real class
}


def extract_nav_phrases(scenario: str) -> list[tuple[str, str]]:
    """Pulls likely clickable menu/button phrases out of the scenario text,
    in the order they appear, paired with the ACTION verb that precedes
    each one (hover vs click) - so a menu that only reveals its submenu on
    mouse-hover (a common pattern) gets hovered instead of clicked, which
    would otherwise close the dropdown before the submenu item can be
    found. Falls back to "click" if no clear action verb is found before
    a phrase. Stops collecting once it hits a phrase that signals we've
    reached the target page and further words are field values /
    assertions, not menu items - filling and saving must never happen
    during a pure scan.

    CASE-INSENSITIVE BY DESIGN (a real, serious bug fixed here): an
    earlier version of this function only matched WORDS STARTING WITH A
    CAPITAL LETTER as candidate phrases (assuming a person would type
    menu names capitalized the way they appear on screen, e.g. "hover
    Administration, click Brand Type"). A person who instead writes
    their whole scenario in natural lowercase prose (e.g. "navigate to
    administration menu, click bin management sub-menu, click the add
    button...") hit NOTHING but the one stray capitalized word in the
    entire scenario - every real navigation phrase after it was silently
    never extracted at all, which is exactly what cascades into "Could
    not click through any scenario menu text" and every step after
    navigation never running. This version works purely off the real
    ACTION_WORDS/STOP_WORDS/PREPOSITIONS as boundaries - capitalization
    is irrelevant to whether a phrase gets extracted (downstream matching
    against the real page is already case-insensitive too, via
    get_by_text(..., exact=False))."""
    STOP_WORDS = {"save", "submit", "assert", "verify", "delete", "remove",
                  "enter", "fill", "type", "leave", "generate", "use", "pick",
                  "choose", "input", "provide", "specify",
                  "update", "modify", "change", "amend", "ensure", "confirm", "toggle", "enable",
                  "disable", "uncheck", "check", "validate", "reopen", "reload", "refresh"}
    ACTION_WORDS = {"hover", "click", "navigate", "select", "go", "open",
                    "login", "log"}
    # Words that commonly appear right after an action word but aren't
    # part of the real element's own clickable text - skipped rather
    # than included in the extracted phrase, so "click the bin
    # management sub-menu" yields "bin management", not "the bin
    # management sub menu" (which would fail to match the real element's
    # actual, shorter accessible text).
    LEADING_FILLERS = {"to", "the", "a", "an", "on", "then", "and", "next", "also", "finally", "into"}
    # 'and' / 'then' / 'after' etc. TRAIL a phrase in natural sentences ("Navigate to the
    # Administration menu AND click ...") - without stripping them the phrase became
    # "Administration menu and", which matches nothing on the page, so navigation stopped
    # at the very first phrase and nothing was ever clicked.
    TRAILING_FILLERS = {"menu", "sub-menu", "submenu", "sub", "button", "page", "tab",
                         "link", "icon", "dropdown", "option", "and", "then", "next",
                         "after", "afterwards", "finally", "also", "followed", "by"}
    # A preposition reliably signals "descriptive context about WHERE
    # this element is follows, not more of its own name" - e.g. "click
    # the add button in the bin management listing page" should extract
    # just "add button" (later trimmed to "add" by TRAILING_FILLERS),
    # stopping before "in the bin management listing page" gets pulled
    # in too.
    PREPOSITIONS = {"in", "within", "under", "at", "for", "on", "inside", "from"}

    # '>' '->' arrows etc. separate menu levels in "Administration > Bin Management" - without
    # treating them as boundaries both names merged into ONE phrase that matches nothing.
    tokens = re.findall(r"[A-Za-z][A-Za-z\-']*|->|\u2192|\u203a|[>|;.,]", scenario)
    pairs = []
    current_action = "click"
    current_words: list[str] = []
    skipping_context = False

    def flush():
        words = list(current_words)
        while words and words[0].lower() in LEADING_FILLERS:
            words.pop(0)
        while words and words[-1].lower() in TRAILING_FILLERS:
            words.pop()
        if words and words[0].lower() in PREPOSITIONS:
            return                      # "In PG info section, verify ..." = where the next steps happen, nothing to click
        if words:
            pairs.append((current_action, " ".join(words)))

    for idx_tok, tok in enumerate(tokens):
        tok_lower = tok.lower()
        if tok_lower in ("search", "filter", "find", "locate", "lookup") and idx_tok + 1 < len(tokens) \
                and tokens[idx_tok + 1].lower() in ("for", "by", "using", "with", "the", "a", "an", "that", "this"):
            flush()
            return pairs     # "search for the BIN ..." is a STEP (type the BIN, run the search), not a menu to click
        if tok in (",", ".", ";", ">", "|", "->", "\u2192", "\u203a"):
            flush()
            current_words = []
            skipping_context = False
            continue
        if tok_lower in STOP_WORDS:
            flush()
            return pairs  # reached field-filling/assertion territory - stop for good
        # TYPO TOLERANCE: "navigate" is one of the most commonly
        # mistyped action words in casual scenario writing (e.g.
        # "Navigatie", "navigat") - a prefix check catches these common
        # variants without needing an exhaustive list of every possible
        # misspelling. A single mistyped action word being treated as a
        # literal PHRASE instead (the original bug this guards against)
        # produces a garbage first "phrase" with no real page match,
        # which - combined with navigate_via_scenario_text's own
        # "stop entirely on the first unmatched phrase" behavior -
        # silently prevented EVERY SUBSEQUENT real phrase from ever
        # being attempted at all, not just the mistyped one.
        if tok_lower in ACTION_WORDS or tok_lower.startswith("navigat"):
            flush()  # finish whatever phrase belonged to the PREVIOUS action word, if any
            current_words = []
            skipping_context = False
            current_action = "hover" if tok_lower == "hover" else "click"
            continue
        if tok_lower in PREPOSITIONS and current_words:
            # Only treat this as a phrase-ending preposition once we
            # already have at least one real word collected - a leading
            # "on"/"at" with nothing yet gathered is almost certainly
            # just award-order noise, not a genuine boundary.
            flush()
            current_words = []
            skipping_context = True      # what follows ("the BIN management listing") is WHERE, not a target
            continue
        if skipping_context:
            continue
        current_words.append(tok)
    flush()
    return pairs


AI_SELECTOR_SYSTEM_PROMPT = """You find a working Playwright CSS or XPath
selector for ONE specific element on a real web page, given the page's
current HTML. Reply with ONLY the selector string - no explanation, no
markdown, no quotes around it. If nothing on the page plausibly matches,
reply exactly: NO_MATCH"""


def ai_suggest_selector(page, phrase: str, action: str) -> str | None:
    """AI-based fallback when the fixed strategies (get_by_text, role
    lookups) don't find a match for a phrase. Dumps the current page's
    interactive HTML and asks the AI to find a real selector for it -
    this is what makes navigation self-healing/adaptive instead of
    relying only on a fixed list of hardcoded matching strategies, since
    real apps vary too much (icons instead of text, custom widgets,
    ARIA-only labeling, etc.) for any fixed strategy list to cover
    everything. Returns a selector string, or None if the AI found
    nothing confident or is unavailable."""
    try:
        html_snapshot = page.eval_on_selector_all(
            "input, button, a, select, textarea, [role='button'], [role='menuitem'], "
            "li, span, div[onclick], [class*='menu'], [class*='nav'], [class*='tab'], "
            "[data-testid]",
            "els => els.slice(0, 250).map(e => e.outerHTML.slice(0, 250)).join('\\n')",
        )
    except Exception:
        return None
    if not html_snapshot:
        return None

    user_prompt = (
        f"I need to {action} an element whose visible text/purpose is: \"{phrase}\"\n\n"
        f"Current page's interactive elements:\n{html_snapshot}"
    )
    reply = ask_ai(AI_SELECTOR_SYSTEM_PROMPT, user_prompt)
    if not reply or reply.strip().upper() == "NO_MATCH":
        return None
    return strip_code_fence(reply.strip())


def build_xpath_from_outer_html(outer_html: str, prefer_text: bool = False) -> str | None:
    """Deterministically (no AI, no guessing) builds a single-strategy
    XPath directly from a REAL captured element's outerHTML - this is
    what removes the AI from the loop entirely for navigation locators,
    since a hallucinated/hedged XPath ("id X or text Y") can only happen
    when the AI is left to transcribe the real HTML into a selector
    itself.

    prefer_text=True flips the priority to check visible text FIRST,
    before id/name/class - use this for MENU/NAV elements specifically.
    Real-world experience with this exact class of app showed dynamic,
    auto-generated ids on menu items (e.g. "stUI17_txt") that work when
    captured live but are NOT STABLE across sessions/page loads - the
    same menu re-rendered can get a different generated id, so a locator
    built from that id fails on replay even though the live capture
    itself succeeded. Visible menu text is far more stable across
    sessions for this kind of app. Target-page FORM FIELDS (the actual
    input elements on the landed page, not the menu items used to get
    there) keep the default id-first priority, since form field ids tend
    to be genuinely stable, developer-chosen names.
    Returns None if nothing usable was found."""
    tag_match = re.match(r"<(\w+)", outer_html.strip())
    if not tag_match:
        return None
    tag = tag_match.group(1)

    def _try_text():
        text_match = re.search(r">([^<]{2,60})<", outer_html)
        if text_match and text_match.group(1).strip():
            clean_text = text_match.group(1).strip()
            if tag.startswith("mat-"):        # an Angular Material element keeps its text in a child <span>: text() never matches
                return f"//{tag}[contains(normalize-space(.),'{clean_text}')]"
            return f"//{tag}[contains(text(),'{clean_text}')]"
        return None

    def _try_id():
        id_match = re.search(r'\bid=["\']([^"\']+)["\']', outer_html)
        if id_match and id_match.group(1).strip():
            return f"//{tag}[@id='{id_match.group(1)}']"
        return None

    def _try_name():
        name_match = re.search(r'\bname=["\']([^"\']+)["\']', outer_html)
        if name_match and name_match.group(1).strip():
            return f"//{tag}[@name='{name_match.group(1)}']"
        return None

    def _try_class():
        class_match = re.search(r'\bclass=["\']([^"\']+)["\']', outer_html)
        if class_match:
            GENERIC = {"active", "show", "hide", "hidden", "container", "row", "col",
                       "item", "btn", "link", "text", "wrapper", "flex"}
            candidates = [c for c in class_match.group(1).split() if c.lower() not in GENERIC]
            if candidates:
                return f"//{tag}[contains(@class,'{candidates[0]}')]"
        return None

    order = [_try_text, _try_id, _try_name, _try_class] if prefer_text \
        else [_try_id, _try_name, _try_class, _try_text]
    for strategy in order:
        result = strategy()
        if result:
            return result

    return None


_VISIBLE_TEXTS_JS = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const st = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none'; };
  const seen = new Set(), out = [];
  for (const e of document.querySelectorAll('a,button,[role=menuitem],[role=treeitem],li,mat-list-item,mat-label,.mat-mdc-tab,span')) {
    if (!vis(e) || e.children.length > 2) continue;
    const t = (e.innerText || '').replace(/\s+/g, ' ').trim();
    if (!t || t.length > 40 || seen.has(t.toLowerCase())) continue;
    seen.add(t.toLowerCase()); out.push(t);
    if (out.length >= 70) break;
  }
  return out;
}
"""


def _nav_diagnostics(page, scenario: str, snapshot_path: Path | None = None, log=print) -> None:
    """When navigation clicked nothing: show exactly WHICH phrases were extracted from the
    scenario and WHICH clickable texts actually exist on the page right now, and save a
    screenshot - so a wording/timing/menu-name mismatch is visible instead of guessed."""
    try:
        phrases = [f"{a}: '{p}'" for a, p in extract_nav_phrases(scenario)]
    except Exception:
        phrases = []
    log(f"  Navigation phrases taken from the scenario: "
        f"{phrases or '(NONE - the scenario text produced no menu phrases at all)'}")
    for fr in _frames(page):
        try:
            texts = fr.evaluate(_VISIBLE_TEXTS_JS)
            if texts:
                log(f"  Clickable texts visible on the page right now{_frame_tag(fr, page)}: {texts}")
                break
        except Exception:
            continue
    else:
        log("  No clickable texts are visible on the page at all - it may still be loading, or the login "
            "did not land on the dashboard.")
    log(f"  Current URL: {page.url}")
    if snapshot_path is not None:
        try:
            snapshot_path.parent.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(snapshot_path), full_page=True)
            log(f"  Screenshot of where navigation stopped: {snapshot_path}")
        except Exception:
            pass


def _wait_for_phrase(page, phrase: str, timeout_ms: int) -> bool:
    """Menus on Angular portals render a moment AFTER login. Poll (instead of one 3s try)
    until the phrase exists in some frame as text / button / link / menuitem."""
    import re as _re
    pat = _re.compile(r"[\s\-\u2013\u2014:/_]*".join(_re.escape(w) for w in _re.split(r"[\s\-_]+", phrase.strip()) if w) or _re.escape(phrase), _re.I)
    waited = 0
    while waited <= timeout_ms:
        for fr in _frames(page):
            try:
                if (fr.get_by_text(phrase, exact=False).count() > 0
                        or fr.get_by_text(pat).count() > 0
                        or fr.get_by_role("button", name=pat).count() > 0
                        or fr.get_by_role("link", name=pat).count() > 0
                        or fr.get_by_role("menuitem", name=pat).count() > 0):
                    return True
            except Exception:
                continue
        page.wait_for_timeout(400)
        waited += 400
    return False


def _nav_click(locator) -> None:
    """A tile / card whose TITLE text is not directly clickable (pointer-events: none, an animation layer on top, a plain <span> inside
    a clickable card) made the plain click fail on every strategy and the navigation stopped there. Order: normal click -> click the
    nearest clickable ancestor (link, button, card, tile) from JavaScript (not blocked by an overlay) -> forced click."""
    try:
        locator.click(timeout=5000)
        return
    except Exception as first:
        try:
            locator.evaluate("""el => { const t = el.closest("a, button, [role='button'], [role='link'], [routerlink], [onclick], "
                + "mat-card, [class*='card'], [class*='tile']") || el; t.click(); }""")
            return
        except Exception:
            pass
        try:
            locator.click(timeout=3000, force=True)
            return
        except Exception:
            raise first


def navigate_via_scenario_text(page, scenario: str) -> tuple[list[str], list[str], dict[str, str]]:
    """After a successful login, navigates through the real page using ONLY
    the visible text phrases found in the scenario (Configuration, Brand
    Type, Add, ...) - no locators needed, since Playwright can find
    elements by their visible text directly. Each phrase is HOVERED or
    CLICKED depending on which verb the scenario used for it - hovering a
    parent menu keeps its dropdown open so the next phrase (its submenu
    item) becomes visible and clickable, whereas clicking a hover-only
    menu would immediately close the dropdown again. Tries several
    matching strategies per phrase (plain text, button role, link role,
    menuitem role) since AJAX-rendered or accessibility-named elements
    aren't always found by text matching alone. Stops at the first phrase
    that doesn't match anything after all strategies, on the assumption
    that's either the target page reached or a field name, not a menu
    item.

    CAPTURES the outerHTML of every element it successfully navigates
    through (e.g. the actual Configuration menu, the actual Brand Type
    submenu link) - not just the final landed page. Without this, menu
    items you navigate THROUGH would never appear in the generated
    locators file, since they're on pages you've already left by the time
    the final scan happens - and the module's own navigation code needs
    those exact selectors too, not just the target page's form fields.

    Returns (list of phrases successfully navigated through, list of
    outerHTML snippets for each of those navigated elements, dict mapping
    each phrase to a DETERMINISTICALLY-built XPath from its real captured
    outerHTML - no AI involved in building this specific value, which is
    what prevents the hedged/hallucinated locator problem for navigation
    elements specifically)."""
    clicked = []
    nav_elements_html = []
    phrase_xpaths: dict[str, str] = {}
    try:
        page.wait_for_load_state("networkidle", timeout=10000)
    except Exception:
        pass
    for idx_phrase, (action, phrase) in enumerate(extract_nav_phrases(scenario)):
        # first phrase = top-level menu right after login (renders late) -> wait longer
        _wait_for_phrase(page, phrase, 9000 if idx_phrase == 0 else 2500)
        strategies = [
            lambda p=phrase: page.get_by_role("button", name=p, exact=True).first,
            lambda p=phrase: page.get_by_text(p, exact=True).first,
            lambda p=phrase: page.get_by_text(p, exact=False).first,
            lambda p=phrase: page.get_by_role("button", name=p, exact=False).first,
            lambda p=phrase: page.get_by_role("link", name=p, exact=False).first,
            lambda p=phrase: page.get_by_role("menuitem", name=p, exact=False).first,
            # separators are tolerant: the scenario says "Channel support PG" / "channel support-pg" while the menu
            # shows "Channel support - PG" (the tokenizer drops a lone hyphen), so match the words with any
            # spaces / dashes / colons between them, case-insensitive, whole item only
            lambda p=phrase: page.get_by_text(re.compile(r"^\s*" + r"[\s\-\u2013\u2014:/_]*".join(re.escape(w) for w in re.split(r"[\s\-_]+", p.strip()) if w) + r"\s*$", re.I)).first,
            lambda p=phrase: page.get_by_text(re.compile(r"[\s\-\u2013\u2014:/_]*".join(re.escape(w) for w in re.split(r"[\s\-_]+", p.strip()) if w), re.I)).first,
        ]
        found = False
        last_error = ""
        for get_locator in strategies:
            try:
                locator = get_locator()
                if locator.count() == 0:
                    continue          # nothing matches this strategy - don't burn a 3s timeout on it
                locator.scroll_into_view_if_needed(timeout=3000)
                try:
                    outer_html = locator.evaluate("el => el.outerHTML.slice(0, 300)")
                    nav_elements_html.append(f"<!-- navigated: \"{phrase}\" ({action}) -->\n{outer_html}")
                    suggested = build_xpath_from_outer_html(outer_html, prefer_text=True)
                    if suggested:
                        phrase_xpaths[phrase] = suggested
                except Exception:
                    pass
                if action == "hover":
                    # Count visible interactive elements BEFORE hovering, so
                    # we can confirm the hover actually revealed something
                    # new (a submenu) - not just that .hover() didn't throw.
                    # A hover that silently reveals nothing is the most
                    # common cause of the NEXT phrase (the submenu item)
                    # failing to match anything.
                    before_count = page.locator(
                        "a, button, li, [role='menuitem'], span[onclick]"
                    ).count()
                    locator.hover(timeout=5000)
                    # AJAX-LOADED SUBMENU FIX: a fixed short wait (the
                    # 500ms/800ms below) assumes the submenu appears via
                    # a quick CSS animation - but a real menu can instead
                    # fire an AJAX call to fetch its submenu items, whose
                    # response time is genuinely unpredictable (network
                    # latency, server load) and can easily exceed a fixed
                    # short window. Waiting for networkidle FIRST lets
                    # this settle for however long the real AJAX call
                    # actually takes (up to a generous cap), instead of
                    # deciding "hover revealed nothing" before an
                    # in-flight request has even finished - which is
                    # exactly what cascades into navigation failing
                    # entirely and every step after it (scan, generation,
                    # self-review, locator-heal) never running at all.
                    try:
                        page.wait_for_load_state("networkidle", timeout=8000)
                    except Exception:
                        pass  # no new network activity to wait for (a pure CSS-animated
                              # menu, say) - fall through to the short fixed waits below
                    page.wait_for_timeout(500)
                    after_count = page.locator(
                        "a, button, li, [role='menuitem'], span[onclick]"
                    ).count()
                    if after_count <= before_count:
                        # Hover technically succeeded but revealed nothing -
                        # try again with a longer settle time once before
                        # giving up on this strategy (some menus animate in
                        # slowly, or need the mouse to stay in place longer).
                        page.wait_for_timeout(800)
                        after_count = page.locator(
                            "a, button, li, [role='menuitem'], span[onclick]"
                        ).count()
                    if after_count <= before_count:
                        # CLICK-BASED SIDEBAR FALLBACK: some real portals'
                        # sidebars are click-to-expand, not hover-to-reveal
                        # (e.g. a permanent left sidebar where every parent
                        # item is a plain clickable link, not a CSS :hover
                        # dropdown - see bank_notes for known examples of
                        # this). A hover that reveals nothing is exactly
                        # what that looks like from here, so before giving
                        # up on this element entirely, try CLICKING it
                        # instead - if that reveals new elements, treat it
                        # the same as a successful hover (this phrase was a
                        # parent to expand, not a final destination) and
                        # carry on to the next phrase. This makes menu
                        # navigation work on both hover-based AND
                        # click-based sidebars without needing to know
                        # which one a given bank uses in advance.
                        try:
                            locator.click(timeout=3000)
                            page.wait_for_timeout(600)
                            after_click_count = page.locator(
                                "a, button, li, [role='menuitem'], span[onclick]"
                            ).count()
                        except Exception:
                            after_click_count = after_count
                        if after_click_count <= before_count:
                            # Still nothing revealed either way - this
                            # strategy's element wasn't the real target.
                            # Try the next matching strategy instead of
                            # accepting a no-op hover/click.
                            continue
                        else:
                            print(f"    (hover on '{phrase}' revealed nothing - clicking it "
                                  f"instead worked, this sidebar looks click-based)")
                else:
                    _nav_click(locator)
                    # networkidle catches AJAX-rendered content (e.g. an Add
                    # button/form that only appears after a background call) -
                    # domcontentloaded alone can fire before that finishes.
                    page.wait_for_load_state("networkidle", timeout=10000)
                    # SPA/Angular-style hash-routing (e.g. "#/dashboard/...")
                    # often changes route with NO new network request at all,
                    # so networkidle above can resolve almost instantly while
                    # the framework's own change-detection/render cycle is
                    # still catching up - a short settle-wait here (same
                    # reasoning as _scan_listing_and_add_form's own settle
                    # wait) avoids landing on a still-stale DOM for whatever
                    # comes next (the next nav phrase, or the final scan).
                    page.wait_for_timeout(800)
                clicked.append(phrase)
                found = True
                break
            except Exception as _exc:
                last_error = str(_exc).strip().splitlines()[0][:150] if str(_exc).strip() else type(_exc).__name__
                continue

        if not found:
            print(f"    could not click '{phrase}'" + (f" - last error: {last_error}" if last_error else
                  " - no element with that text was found on the page (the AI is asked next)"))
            # Fixed strategies all missed - ask the AI to find a selector by
            # actually reading the current page's real HTML, instead of
            # giving up. This is what makes navigation adaptive rather than
            # limited to a fixed list of hardcoded matching strategies.
            ai_selector = ai_suggest_selector(page, phrase, action)
            if ai_selector:
                try:
                    locator = page.locator(ai_selector).first
                    locator.scroll_into_view_if_needed(timeout=3000)
                    try:
                        outer_html = locator.evaluate("el => el.outerHTML.slice(0, 300)")
                        nav_elements_html.append(
                            f"<!-- navigated: \"{phrase}\" ({action}, AI-found selector) -->\n{outer_html}")
                        suggested = build_xpath_from_outer_html(outer_html, prefer_text=True)
                        if suggested:
                            phrase_xpaths[phrase] = suggested
                    except Exception:
                        pass
                    if action == "hover":
                        before_count = page.locator(
                            "a, button, li, [role='menuitem'], span[onclick]"
                        ).count()
                        locator.hover(timeout=5000)
                        page.wait_for_timeout(800)
                        after_count = page.locator(
                            "a, button, li, [role='menuitem'], span[onclick]"
                        ).count()
                        if after_count <= before_count:
                            raise RuntimeError("AI-suggested hover target revealed nothing")
                    else:
                        locator.click(timeout=5000)
                        page.wait_for_load_state("networkidle", timeout=10000)
                    clicked.append(phrase)
                    found = True
                except Exception:
                    pass

        if not found and os.environ.get("AI_AGENTIC_LOCATORS", "0") == "1":
            # LAST-RESORT FALLBACK (opt-in, default OFF - the Claude
            # API round-trip in agentic_resolve_locator has not been
            # verified end-to-end in development, unlike every other
            # fallback above): the fixed strategies AND the one-shot AI
            # suggestion both missed - give Claude the check_selector
            # tool and let it iteratively TEST candidate selectors
            # against this exact live page until one genuinely resolves,
            # rather than a single guess from a static HTML snippet.
            agentic_selector = agentic_resolve_locator(
                page, f"the element to {action} for the navigation step described as '{phrase}'")
            if agentic_selector:
                try:
                    locator = page.locator(agentic_selector).first
                    if action == "hover":
                        before_count = page.locator(
                            "a, button, li, [role='menuitem'], span[onclick]"
                        ).count()
                        locator.hover(timeout=5000)
                        page.wait_for_timeout(800)
                        after_count = page.locator(
                            "a, button, li, [role='menuitem'], span[onclick]"
                        ).count()
                        if after_count <= before_count:
                            raise RuntimeError("agentic-suggested hover target revealed nothing")
                    else:
                        locator.click(timeout=5000)
                        page.wait_for_load_state("networkidle", timeout=10000)
                    clicked.append(phrase)
                    phrase_xpaths[phrase] = agentic_selector
                    found = True
                except Exception:
                    pass

        if not found:
            break  # nothing matched this phrase even with AI help - assume target page reached
    try:
        _click_section_hints(page, scenario, clicked, nav_elements_html)
    except Exception as _exc:
        print(f"    (section/tile fallback skipped: {str(_exc).splitlines()[0][:100] if str(_exc) else type(_exc).__name__})")
    return clicked, nav_elements_html, phrase_xpaths


_SECTION_HINT_RE = re.compile(
    r"\b(?:in|under|within|inside|on|at|open|click|select)\s+(?:the\s+)?([A-Za-z][A-Za-z0-9\- ]{1,40}?)\s+"
    r"(?:section|tile|card|tab|page|screen|panel|option|menu)\b", re.I)


def _form_controls_visible(page) -> int:
    total = 0
    for fr in _frames(page):
        try:
            total += fr.evaluate(_CTL_COUNT_JS)
        except Exception:
            pass
    return total


def _click_section_hints(page, scenario: str, clicked: list, nav_elements_html: list) -> None:
    """Fallback for a landing page made of TILES / sections (e.g. Administration > PG configuration shows 'PG information',
    'Service integration' ... tiles): the scenario says 'In PG info section, update ...', which is not a click phrase, so
    navigation stopped on the tile page and no form field was ever visible. When NO field is visible after the normal
    navigation, every 'in <X> section / tile / tab' mention is tried as a click target, with each word matched as a
    PREFIX ('info' matches 'information') and any separator."""
    if _form_controls_visible(page) > 0:
        return
    done = {c.lower() for c in clicked}
    for m in _SECTION_HINT_RE.finditer(scenario or ""):
        words = [w for w in re.split(r"[\s\-]+", m.group(1).strip()) if w and w.lower() not in ("the", "a", "an")]
        if not words or " ".join(words).lower() in done:
            continue
        pat = re.compile(r"[\s\-\u2013\u2014:/_]*".join(re.escape(w) + (r"\w*" if len(w) >= 3 else "") for w in words), re.I)
        for get in (lambda: page.get_by_text(pat).first, lambda: page.get_by_role("link", name=pat).first,
                    lambda: page.get_by_role("button", name=pat).first):
            try:
                loc = get()
                if loc.count() == 0:
                    continue
                loc.scroll_into_view_if_needed(timeout=3000)
                try:
                    nav_elements_html.append(f"<!-- navigated: \"{' '.join(words)}\" (click, section hint) -->\n"
                                             + loc.evaluate("el => el.outerHTML.slice(0, 300)"))
                except Exception:
                    pass
                _nav_click(loc)
                try:
                    page.wait_for_load_state("networkidle", timeout=10000)
                except Exception:
                    pass
                page.wait_for_timeout(800)
                clicked.append(" ".join(words))
                print(f"    (no form field visible after navigation - clicked the '{' '.join(words)}' section/tile named in the scenario)")
                break
            except Exception:
                continue
        if _form_controls_visible(page) > 0:
            return


def attempt_logout(page) -> bool:
    """Best-effort logout using only visible text, tried at the end of a
    scan so the account isn't left in a logged-in state (which is the
    root cause of "User already logged in" blocking the NEXT run). Tries
    common logout label variants; failures are silent since this is a
    convenience cleanup step, not a hard requirement.

    PROFILE-MENU FALLBACK: on a real admin portal, "Logout" is very
    commonly NOT a direct visible link at all - it's tucked inside a
    profile/avatar dropdown in the top corner (e.g. clicking a
    "Fssadminuser / FSS Super Admin" element reveals a small menu that
    THEN contains "Logout") - a direct text search for "Logout" finds
    nothing because it genuinely isn't on the page until that menu is
    opened first. If the direct search below finds nothing, this tries
    clicking a handful of common profile-menu trigger patterns (a
    role='button' near account-looking text, a generic avatar/user-icon
    class) to reveal a hidden menu, then retries the same logout-label
    search once against whatever that revealed."""
    for label in ["Logout", "Log Out", "Log out", "Sign Out", "Sign out"]:
        try:
            page.get_by_text(label, exact=False).first.click(timeout=3000)
            return True
        except Exception:
            continue

    # Direct search failed - try opening a profile/avatar menu first,
    # since that's the most common reason "Logout" isn't directly visible.
    PROFILE_TRIGGER_SELECTORS = [
        "[class*='avatar']", "[class*='profile']", "[class*='user-menu']",
        "[class*='account']", "img[alt*='user' i]", "img[alt*='avatar' i]",
        "[role='button'][aria-haspopup='true']",
    ]
    for selector in PROFILE_TRIGGER_SELECTORS:
        try:
            trigger = page.locator(selector).first
            if trigger.count() == 0:
                continue
            trigger.click(timeout=2000)
            page.wait_for_timeout(500)  # let the dropdown menu render
            for label in ["Logout", "Log Out", "Log out", "Sign Out", "Sign out"]:
                try:
                    page.get_by_text(label, exact=False).first.click(timeout=2000)
                    return True
                except Exception:
                    continue
        except Exception:
            continue
    return False


LOCATOR_LINE_RE = re.compile(r'^(\s*)(\w+)\s*=\s*"([^"]*)"\s*$', re.MULTILINE)


def find_hedged_locators(content: str) -> list[str]:
    """Deterministically catches the 'or'-combined hedge pattern (e.g.
    "//span[@id='x' or contains(text(),'y')]") that keeps slipping past
    the AI despite the system prompt forbidding it - two match strategies
    joined by 'or' inside one XPath is the same hedging mistake as a
    comma-separated CSS list, just written differently. Checked
    deterministically (no AI call) so a repeat of this mistake gets
    caught for free instead of burning another AI fix attempt on it."""
    hedged = []
    for match in LOCATOR_LINE_RE.finditer(content):
        attr_name, value = match.group(2), match.group(3)
        if re.search(r"\bor\b", value) and ("@id=" in value or "@name=" in value
                                             or "@class=" in value) and "contains(text()" in value:
            hedged.append(attr_name)
    return hedged


def _check_selector_against_live_page(page, selector: str) -> str:
    """The real execution behind the check_selector tool below - the
    ONE piece of this feature that's actually been verified end-to-end
    with a real Playwright page in this session. Returns a short,
    model-readable status string Claude uses to decide whether to keep
    this selector or try a different one."""
    try:
        loc = page.locator(selector)
        count = loc.count()
        if count == 0:
            return "count=0 (no matching element found)"
        visible = loc.first.is_visible()
        tag = loc.first.evaluate("el => el.tagName.toLowerCase()")
        return f"count={count}, visible={visible}, tag={tag}" + (
            " - WARNING: matches more than one element, narrow it" if count > 1 else "")
    except Exception as exc:
        return f"error: {exc}"


def agentic_resolve_locator(page, field_description: str, max_attempts: int = 4) -> str | None:
    """AGENTIC TOOL-USE LOCATOR RESOLUTION (an architectural alternative
    to the rest of this file's "generate once from a static HTML dump,
    verify afterward" approach): gives Claude a check_selector tool
    backed by the REAL live page, open in the SAME browser session the
    scan already has running, so Claude can propose a candidate
    selector, immediately see whether it genuinely resolves to exactly
    one visible element, and refine its guess based on real feedback -
    iteratively, before ever committing to a final answer - rather than
    guessing once from a static snapshot and only finding out it was
    wrong during a later heal/dry-run pass.

    IMPORTANT, HONEST CAVEAT: the check_selector EXECUTION side (the
    Playwright calls inside _check_selector_against_live_page) has been
    tested for real in this session. The actual Claude API round-trip
    in the loop below has NOT - this sandbox has no outbound
    ANTHROPIC_API_KEY to call the real API with, so the tool-use
    conversation loop itself is implemented carefully but UNVERIFIED
    end-to-end. Test this specifically before relying on it.

    Returns the first selector Claude proposes that the real page
    confirms resolves to exactly one visible element, or None if no
    working selector is found within max_attempts or the API call
    itself fails."""
    try:
        import anthropic
    except ImportError:
        print("  (agentic locator resolution skipped - anthropic package not installed)")
        return None
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    client = anthropic.Anthropic(api_key=api_key)
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5")

    tools = [{
        "name": "check_selector",
        "description": ("Test whether a CSS selector or an XPath expression resolves to "
                         "exactly one visible element on the REAL live page right now. "
                         "Returns the match count, whether it's visible, and its tag name."),
        "input_schema": {
            "type": "object",
            "properties": {
                "selector": {"type": "string",
                             "description": "A CSS selector, or an XPath expression starting with // or (//"}
            },
            "required": ["selector"],
        },
    }]
    messages = [{
        "role": "user",
        "content": (
            f"Find a real, working locator for this field on the current live page: "
            f"{field_description}\n\nUse the check_selector tool to test candidate selectors "
            f"against the REAL page until you find one that resolves to exactly one visible "
            f"element. Try a few different candidates if your first guess doesn't resolve "
            f"uniquely. Once you find one that genuinely works, respond with ONLY that "
            f"selector string and nothing else - no explanation, no markdown."
        ),
    }]

    for _ in range(max_attempts):
        try:
            response = client.messages.create(
                model=model, max_tokens=500, tools=tools, messages=messages)
        except Exception as exc:
            print(f"  (agentic locator resolution call failed: {exc})")
            return None

        messages.append({"role": "assistant", "content": response.content})
        tool_use_blocks = [b for b in response.content if b.type == "tool_use"]
        if not tool_use_blocks:
            text = "".join(b.text for b in response.content if b.type == "text").strip()
            return text or None

        tool_results = []
        for block in tool_use_blocks:
            selector = block.input.get("selector", "")
            result_text = _check_selector_against_live_page(page, selector)
            tool_results.append({"type": "tool_result", "tool_use_id": block.id,
                                  "content": result_text})
        messages.append({"role": "user", "content": tool_results})

    return None


def verify_and_heal_locators_file(repo_root: Path, bank: str, portal_type: str,
                                   module: str, scenario: str,
                                   extra_scenarios: list[str] | None = None
                                   ) -> tuple[int, set[str], set[str]]:
    """THE core anti-locator-failure step: re-opens a real logged-in
    session, navigates to the same target page the scenario describes,
    and checks EVERY locator value just written to this module's real
    locators.py file against the LIVE page - not by re-running pytest,
    but directly: does page.locator(value) resolve to exactly one real,
    usable element right now? Any locator that does NOT (0 matches, or
    ambiguous multiple matches) is immediately healed by asking the AI
    for a replacement, given the current live page's HTML and the
    attribute's own name as the intent hint (e.g. "add_button" -> "Add
    button") - then the replacement is verified the SAME way before being
    accepted, so a bad AI guess never silently replaces one bad selector
    with another.

    MULTI-ACTION COVERAGE: a locator used only by View/Edit/ChangeStatus/
    Delete (e.g. a row's "Edit" link, or a toggle that only exists once
    you're actually inside an edit form) will never resolve while
    sitting on the page the Add scenario's own navigation reaches - a
    single verification pass anchored to just the Add flow silently
    leaves those un-checked, not because they're wrong, but because
    they were never really looked at. extra_scenarios (each action's own
    scenario text, e.g. the View/Edit/ChangeStatus/Delete strings from
    explicit_scenarios) lets this run ONE ADDITIONAL fresh login+navigate
    pass per action, each one checking whatever locators are STILL
    unresolved after the passes before it against THAT action's own real
    page - so a locator only gets flagged as genuinely broken once it's
    failed to resolve on every page it could plausibly belong to, not
    just the first one checked.

    This runs BEFORE pytest ever executes, so a broken locator is caught
    and fixed here - not discovered later as a test failure. Returns the
    number of locators that were healed (0 means everything already
    resolved correctly)."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("  (skipping locator verification - playwright not available)")
        return 0

    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not locators_path.exists():
        return 0

    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]

    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n:
            config_path.write_text(new_text, encoding="utf-8")

    total_healed = 0
    still_broken: set[str] = set()  # attr names still unresolved after the most recent pass
    healed_attrs: set[str] = set()  # attr names healed via EITHER ordinary or agentic resolution
    agentic_healed_attrs: set[str] = set()  # the subset that specifically needed the agentic fallback
    try:
        import sys as _sys
        repo_str = str(repo_root)
        if repo_str not in _sys.path:
            _sys.path.insert(0, repo_str)
        try:
            from src.common.utilities.config_loader import ConfigManager
            ConfigManager._cached = None
        except Exception:
            pass

        login_module = __import__(
            f"src.common.pages.authentication.{module_name}", fromlist=[class_name]
        )
        LoginPageClass = getattr(login_module, class_name)

        def _run_one_pass(page, nav_scenario_text: str, only_attrs: set[str] | None) -> int:
            """One navigate+heal pass on an ALREADY-LOGGED-IN page (login
            happens ONCE, outside this function - see below). only_attrs,
            if given, restricts healing attempts to just those attribute
            names (used for the extra_scenarios passes, so a locator that
            ALREADY resolved on an earlier pass never gets needlessly
            re-checked or - worse - "healed" into a DIFFERENT locator
            that happens to also work on this later page but breaks the
            first one)."""
            nonlocal still_broken
            pass_healed = 0
            if nav_scenario_text:
                navigate_via_scenario_text(page, nav_scenario_text)

            def resolves_uniquely(selector: str) -> bool:
                """A locator only counts as "working" if it matches EXACTLY
                one element AND that element is actually visible - a
                selector that technically resolves to 1 element but a
                hidden one (e.g. a duplicate mobile-menu clone, or a
                collapsed/display:none variant) would still fail at click
                time, so visibility is checked here too, not left to be
                discovered later as a pytest failure."""
                try:
                    loc = page.locator(selector)
                    return loc.count() == 1 and loc.first.is_visible()
                except Exception:
                    return False

            # ASSERTION/RESULT LOCATORS: a locator like "success_message"
            # or "search_by_error" typically only appears AFTER
            # performing the real action (clicking Save, submitting an
            # invalid search) - it's correctly absent from the page
            # BEFORE that happens, which is the only state this
            # verification pass ever puts the page into (it navigates
            # and checks, it doesn't fill forms and submit them). Trying
            # to "resolve" or "heal" this kind of locator here would
            # either wrongly flag a perfectly correct locator as broken,
            # or worse - replace it with something that happens to match
            # SOMETHING on the static pre-action page, silently
            # corrupting a locator that was actually fine. These are
            # left untouched here; pytest (which actually performs the
            # action first) is the only place that can genuinely verify
            # a result/message locator.
            RESULT_LOCATOR_HINTS = ("message", "error", "success", "toast", "alert",
                                     "notification", "validation", "warning", "banner")

            def heal_one(match):
                nonlocal pass_healed, healed_attrs, agentic_healed_attrs
                indent, attr_name, value = match.group(1), match.group(2), match.group(3)
                if only_attrs is not None and attr_name not in only_attrs:
                    return match.group(0)  # not this pass's concern - leave untouched
                if value.startswith("#TODO-verify"):
                    return match.group(0)  # already a known placeholder, leave for manual review
                if any(hint in attr_name.lower() for hint in RESULT_LOCATOR_HINTS):
                    still_broken.discard(attr_name)  # not "broken" - just out of scope for this check
                    return match.group(0)  # leave untouched - see RESULT_LOCATOR_HINTS note above
                if resolves_uniquely(value):
                    still_broken.discard(attr_name)
                    return match.group(0)  # already correct, leave untouched

                human_hint = attr_name.replace("_", " ")
                ai_value = ai_suggest_selector(page, human_hint, "interact with")
                if ai_value and resolves_uniquely(ai_value):
                    pass_healed += 1
                    healed_attrs.add(attr_name)
                    still_broken.discard(attr_name)
                    print(f"  Healed locator '{attr_name}': did not resolve -> now resolves to 1 element.")
                    return f'{indent}{attr_name} = "{safe_locator_value(ai_value)}"'

                if os.environ.get("AI_AGENTIC_LOCATORS", "0") == "1":
                    # LAST-RESORT FALLBACK for a FIELD locator (opt-in,
                    # same unverified-end-to-end caveat as the
                    # navigation use of this function): the one-shot AI
                    # suggestion above also failed to resolve - give
                    # Claude the check_selector tool and let it
                    # iteratively test candidates against this exact
                    # live page until one genuinely resolves to exactly
                    # one visible element, rather than a single guess.
                    agentic_value = agentic_resolve_locator(
                        page, f"the form field or element for '{human_hint}'")
                    if agentic_value and resolves_uniquely(agentic_value):
                        pass_healed += 1
                        healed_attrs.add(attr_name)
                        agentic_healed_attrs.add(attr_name)
                        still_broken.discard(attr_name)
                        print(f"  Healed locator '{attr_name}' via agentic resolution: "
                              f"did not resolve -> now resolves to 1 element.")
                        return f'{indent}{attr_name} = "{safe_locator_value(agentic_value)}"'

                still_broken.add(attr_name)
                return match.group(0)

            current_content = locators_path.read_text(encoding="utf-8")
            new_content = LOCATOR_LINE_RE.sub(heal_one, current_content)
            if pass_healed:
                locators_path.write_text(new_content, encoding="utf-8")
                repair_python_string_lines(locators_path)          # belt and braces: never leave it unparsable
            return pass_healed

        # SINGLE SESSION FOR EVERY PASS: login ONCE here, then reuse the
        # SAME browser/page for the primary scenario AND every extra
        # scenario - just re-navigating between them - instead of a
        # fresh sync_playwright()+browser.launch()+login() per pass.
        # Real logins can be slow and occasionally flaky in their own
        # right (captcha, an Angular form that stays disabled briefly
        # after filling, network hiccups) - every additional login is
        # one more independent chance for the WHOLE verification pass
        # to fail for a reason that has nothing to do with locators at
        # all. One login for the whole multi-pass run cuts that risk
        # down to a single point instead of multiplying it by (1 +
        # number of extra_scenarios).
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)

            # Normalise extras: accept (key, text) tuples as well as plain strings.
            _extras = []
            for _e in (extra_scenarios or []):
                _t = _e[1] if isinstance(_e, (tuple, list)) else _e
                if isinstance(_t, str) and _t.strip():
                    _extras.append(_t)
            _primary = scenario if (isinstance(scenario, str) and scenario.strip()) else ""
            if not _primary and _extras:               # update-only module: the Update/edit scenario IS the primary page
                _primary = _extras.pop(0)
            extra_scenarios = _extras
            # Pass 1: the primary (Add, or the only) scenario - checks every locator.
            total_healed += _run_one_pass(page, _primary, only_attrs=None)

            # Passes 2+: one per extra action scenario (View/Edit/
            # ChangeStatus/Delete/etc.) - each pass ONLY re-attempts
            # whatever is still unresolved after the pass(es) before it,
            # checked against that action's own real page - same
            # already-logged-in session throughout.
            for extra_scenario in (extra_scenarios or []):
                if not still_broken or not extra_scenario:
                    break
                total_healed += _run_one_pass(page, extra_scenario, only_attrs=set(still_broken))

            attempt_logout(page)
            browser.close()

        if still_broken:
            print(f"  {len(still_broken)} locator(s) still don't resolve on any page checked "
                  f"({', '.join(sorted(still_broken))}) - left as-is for manual review.")
    except Exception as exc:
        print(f"  (Locator verification pass failed: {exc} - continuing without it)")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    return total_healed, healed_attrs, agentic_healed_attrs


def read_first_testdata_row(xlsx_path: Path, sheet_name: str = "Add") -> dict[str, str]:
    """Reads back the FIRST data row (column name -> value) of a real
    generated testdata sheet - used to hand dry_run_verify_interactions
    REAL, format-appropriate values instead of a generic placeholder.
    Tries the given sheet name first (defaults to "Add", the usual
    happy-path scenario), falls back to whichever sheet the workbook
    actually has if that exact name isn't present. Returns {} on any
    failure (missing file, empty sheet) - dry-run's own generic
    placeholder fallback covers that case, this is a pure enhancement,
    never a hard requirement."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
        sheet = wb[sheet_name] if sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
        rows = sheet.iter_rows(values_only=True)
        header = next(rows, None)
        first_data_row = next(rows, None)
        wb.close()
        if not header or not first_data_row:
            return {}
        return {str(h): ("" if v is None else str(v))
                for h, v in zip(header, first_data_row) if h}
    except Exception:
        return {}


def generate_locator_confidence_report(repo_root: Path, bank: str, module: str,
                                        healed_attrs: set[str], agentic_healed_attrs: set[str],
                                        dry_run_warnings: list[str],
                                        scenario_status: dict[str, str] | None = None,
                                        field_dryrun_ran: bool = True) -> str:
    """FEATURE: locator confidence report - a capstone that combines
    EVERY independent verification signal this file already gathers
    (which this session built up one at a time: resolve-check healing,
    agentic resolution as a harder-won last resort, and real dry-run
    interaction) into ONE scannable per-locator summary, rather than
    leaving the person to mentally piece together several scattered
    terminal sections to judge how trustworthy each locator really is.

    Confidence levels, highest to lowest:
      HIGH   - resolved immediately, no healing needed at all, AND its
               real interaction (fill/select/check) succeeded in dry-run.
      MEDIUM - needed healing (an ordinary AI fix) but resolved after,
               AND its dry-run interaction succeeded.
      LOW    - needed the AGENTIC last-resort fallback to resolve at all
               (the harder case - every more direct strategy missed),
               even if it did eventually succeed.
      UNVERIFIED - a dry-run warning was raised for it, or it's a
               result/assertion locator (success_message etc) that
               never gets checked by either heal or dry-run at all
               (see RESULT_LOCATOR_HINTS elsewhere in this file) -
               genuinely unknown until pytest actually runs.

    healed_attrs: attribute names that needed ANY healing (ordinary or
    agentic) to resolve - from verify_and_heal_locators_file's own
    pass_healed tracking. agentic_healed_attrs: the subset of those that
    specifically needed the agentic fallback - a strict subset of
    healed_attrs. dry_run_warnings: the warning strings
    dry_run_verify_interactions returned (attribute names are extracted
    from them by the same quoted-name pattern that function's own
    warnings use, 'ATTR_NAME' resolved but...).

    Returns a plain-text report, meant to be printed to the terminal and/
    or saved alongside the run's other artifacts - not parsed further."""
    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not locators_path.exists():
        return "(no locators file found - nothing to report on)"
    content = locators_path.read_text(encoding="utf-8")
    entries = LOCATOR_LINE_RE.findall(content)

    RESULT_LOCATOR_HINTS = ("message", "error", "success", "toast", "alert",
                             "notification", "validation", "warning", "banner")
    warned_attrs = set()
    for w in dry_run_warnings:
        m = re.search(r"'([a-zA-Z_][a-zA-Z0-9_]*)'", w)
        if m:
            warned_attrs.add(m.group(1))

    lines = [f"LOCATOR CONFIDENCE REPORT - {bank}/{module}", "=" * 60]
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNVERIFIED": 0}
    for _, attr_name, value in entries:
        sc = (scenario_status or {}).get(attr_name)
        if value.startswith("#TODO"):
            level = "UNVERIFIED"
            reason = "never resolved during scan/generation at all (#TODO placeholder)"
        elif sc == "HEALED_attr":
            level = "MEDIUM"
            reason = "generated selector was wrong - scenario dry run found the real element and REWROTE it (stable attribute)"
        elif sc == "HEALED_path":
            level = "LOW"
            reason = "generated selector was wrong - rewritten as a positional path (fragile, review it)"
        elif sc == "OK":
            level = "HIGH"
            reason = "verified by the scenario dry run: real fill/select/click worked through this locator"
        elif sc == "FINAL_FOUND":
            level = "MEDIUM"
            reason = "final button resolves to 1 element (click deliberately not performed in dry run)"
        elif sc == "FAILED":
            level = "UNVERIFIED"
            reason = "scenario dry run could not use this field at all"
        elif any(h in attr_name.lower() for h in RESULT_LOCATOR_HINTS):
            level = "UNVERIFIED"
            reason = "result/assertion locator - only checkable by pytest's real submit"
        elif attr_name in warned_attrs:
            level = "UNVERIFIED"
            reason = "dry-run reported a real interaction failure"
        elif attr_name in agentic_healed_attrs:
            level = "LOW"
            reason = "needed the agentic last-resort fallback to resolve"
        elif attr_name in healed_attrs:
            level = "MEDIUM"
            reason = "needed ordinary AI healing to resolve"
        elif any(h in attr_name.lower() for h in _FINALIZING_ATTR_HINTS):
            level = "UNVERIFIED"
            reason = "finalizing/destructive control - deliberately never clicked by the dry run"
        elif not _is_form_field_attr(attr_name):
            level = "UNVERIFIED"
            reason = "page-state locator (menu/button/listing/display) - not on the form the dry run exercised"
        elif not field_dryrun_ran and scenario_status is not None:
            level = "UNVERIFIED"
            reason = "not exercised - this field is not mentioned in the scenario steps"
        else:
            level = "HIGH"
            reason = "resolved immediately, dry-run interaction succeeded"
        counts[level] += 1
        lines.append(f"  [{level:10s}] {attr_name:35s} - {reason}")

    lines.append("=" * 60)
    lines.append(f"Summary: {counts['HIGH']} HIGH, {counts['MEDIUM']} MEDIUM, "
                  f"{counts['LOW']} LOW, {counts['UNVERIFIED']} UNVERIFIED "
                  f"(of {sum(counts.values())} total locators)")
    return "\n".join(lines)


def dry_run_verify_interactions(repo_root: Path, bank: str, portal_type: str,
                                 module: str, scenario: str,
                                 testdata_values: dict[str, str] | None = None) -> list[str]:
    """FEATURE: dry-run interaction verification - a step beyond
    verify_and_heal_locators_file's own check (does a locator resolve to
    one visible element?) that goes further: does the field ACTUALLY
    accept a real fill/select/check interaction without throwing? A
    locator can resolve to exactly one visible element and STILL fail
    when actually interacted with (e.g. a disabled input that resolves
    fine but throws on .fill(), a mat-select whose overlay panel doesn't
    open the way expected, a checkbox that's covered by another element
    intercepting the click). This is the gap between "the element
    exists" and "the generated interaction actually works."

    Deliberately STOPS SHORT of the real submission: any locator whose
    attribute name suggests it finalizes the action (save, submit,
    confirm, delete, remove) is SKIPPED, never clicked - the whole point
    is validating the fill-in sequence without ever actually creating,
    modifying, or deleting real data. This is NOT a full "run the
    generated test" - it's real interaction attempts on real elements,
    short of the one step that would have side effects, giving much
    higher confidence than a static locator-resolution check alone
    without touching production data.

    REALISTIC VALUES, NOT A GENERIC PLACEHOLDER (matters for accuracy):
    testdata_values, when given (the Add row's real generated column
    values, keyed by column name), is fuzzy-matched against each
    locator's attribute name and used to fill that field with a value
    the AI already generated to respect ITS OWN real constraints (a
    6-digit-only BIN, a fixed-format code) - a generic placeholder like
    "DryRunTest123" would fail a real numeric-only field's OWN format
    validation, producing a FALSE "this field is broken" warning that
    has nothing to do with the locator or interaction actually being
    wrong. Falls back to the generic placeholder only for a field with
    no reasonably-matching testdata column.

    Handles the common field shapes directly: a plain <input>/<textarea>
    gets a real .fill() with a safe dummy value; a native <select> gets
    a real .select_option() against whichever real option text is
    available; a checkbox gets a real .check(); a <mat-select> gets a
    real click to open its panel, then a real click on whichever real
    <mat-option> appears (reverted by picking the option that was
    already selected before, where detectable, so state isn't left
    changed). Anything else (a locator resolving to an element type this
    doesn't recognize, or one that still doesn't resolve at all) is
    reported as a warning rather than guessed at - this stays a genuine
    check, not another chance to invent behavior.

    Returns a list of warning strings describing every interaction that
    failed or was skipped as unrecognized - empty list means every
    plain-interactable field for this module handled a real fill/select/
    check without error."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return ["(skipped dry-run - playwright not available)"]

    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not locators_path.exists():
        return []

    FINALIZING_HINTS = ("save", "submit", "confirm", "delete", "remove", "cancel")
    content = locators_path.read_text(encoding="utf-8")
    entries = LOCATOR_LINE_RE.findall(content)  # [(indent, attr_name, value), ...]
    to_check = [(attr, val) for _, attr, val in entries
                if not any(h in attr.lower() for h in FINALIZING_HINTS)
                and _is_form_field_attr(attr)
                and not val.startswith("#TODO")]
    if not to_check:
        return []

    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]

    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n:
            config_path.write_text(new_text, encoding="utf-8")

    warnings: list[str] = []
    try:
        import sys as _sys
        repo_str = str(repo_root)
        if repo_str not in _sys.path:
            _sys.path.insert(0, repo_str)
        login_module = __import__(
            f"src.common.pages.authentication.{module_name}", fromlist=[class_name]
        )
        LoginPageClass = getattr(login_module, class_name)

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            print(f"  [dry-run] logging in as {bank} ...")
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"  [dry-run] logged in OK")
            if scenario:
                _clicked, _n_html, _n_xp = navigate_via_scenario_text(page, scenario)
                print(f"  [dry-run] navigated through: {' -> '.join(_clicked) if _clicked else '(nothing clicked - scanning landing page)'}")
            print(f"  [dry-run] checking {len(to_check)} field locator(s), will STOP before Save/Submit/Delete")

            for attr_name, value in to_check:
                _warn_count_before = len(warnings)
                try:
                    loc = _locate_in_frames(page, value)
                    if loc.count() != 1:
                        warnings.append(f"'{attr_name}' does not resolve to exactly one element - "
                                         f"skipped (this should already be flagged by locator "
                                         f"verification separately).")
                        continue
                    tag = loc.evaluate("el => el.tagName.toLowerCase()")
                    input_type = (loc.get_attribute("type") or "").lower() if tag == "input" else ""
                    if tag == "input" and input_type in ("checkbox", "radio"):
                        was_checked = loc.is_checked()
                        loc.check(timeout=3000)
                        if not was_checked:
                            loc.uncheck(timeout=2000)  # revert - dry run shouldn't leave state changed
                    elif tag in ("input", "textarea"):
                        fill_value = "DryRunTest123"  # generic fallback
                        if testdata_values:
                            norm_attr = re.sub(r"[_\s]", "", attr_name.lower())
                            for col, val in testdata_values.items():
                                if not val or not val.strip():
                                    continue
                                norm_col = re.sub(r"[_\s]", "", col.lower())
                                if norm_col in norm_attr or norm_attr in norm_col:
                                    fill_value = val
                                    break
                        loc.fill(fill_value, timeout=3000)
                    elif tag == "select":
                        options = loc.locator("option").all_text_contents()
                        real_option = next((o for o in options if o.strip()), None)
                        if real_option:
                            loc.select_option(label=real_option, timeout=3000)
                        else:
                            warnings.append(f"'{attr_name}' is a <select> with no real options "
                                             f"found - could not dry-run it.")
                    elif tag == "mat-select":
                        was_selected_text = loc.inner_text().strip()
                        loc.click(timeout=3000)
                        page.wait_for_timeout(400)
                        option = page.locator("mat-option").first
                        if option.count() > 0:
                            option.click(timeout=3000)
                        else:
                            warnings.append(f"'{attr_name}' is a <mat-select> but clicking it "
                                             f"revealed no <mat-option> elements - could not "
                                             f"dry-run it.")
                    else:
                        warnings.append(f"'{attr_name}' resolves to a <{tag}> element - dry-run "
                                         f"doesn't have a recognized interaction pattern for this "
                                         f"tag, skipped (not necessarily wrong, just unverified).")
                except Exception as exc:
                    warnings.append(f"'{attr_name}' resolved to an element but the real "
                                     f"fill/select/check interaction itself failed: {exc}")
                finally:
                    print(f"    [dry-run] {attr_name}: "
                          f"{'OK' if len(warnings) == _warn_count_before else 'WARNING'}")

            attempt_logout(page)
            browser.close()
    except Exception as exc:
        _log_exception("dry-run pass failed to run at all", exc)
        warnings.append(f"(dry-run pass failed to run at all: {exc})")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    return warnings


# ======================================================================
# SCENARIO-BASED DRY RUN (executes the scenario's own steps in order)
# ======================================================================
_GENERIC_VALUE_RE = re.compile(
    r"\b(generated|generate|generates|valid|random|randomly|unique|dynamic|dynamically|auto|any|some|"
    r"sample|appropriate|correct|same|it|new|number|value|digit|digits)\b", re.I)
_RANDOM_HINT_RE = re.compile(r"random|generat|unique|dynamic", re.I)
_NUMERIC_WORDS = {"bin", "number", "no", "num", "amount", "count", "range", "limit", "digit", "digits",
                  "mobile", "phone", "pin", "otp", "minutes", "days", "percentage", "percent", "fee",
                  "rate", "id", "length", "min", "max", "low", "high"}
_FINALIZE_CLICK_RE = re.compile(
    r"\b(save|submit|send|approve|reject|confirm|delete|remove|create|update|apply|proceed|"
    r"finish|activate|deactivate|enable|disable|block|unblock|suspend|terminate|ok|yes|"
    r"publish|post|register)\b", re.IGNORECASE)
_STEP_LEAD = r"^(?:then\s+|and\s+then\s+|and\s+|finally\s+)?"
_STEP_VERBS = (r"fill|enter|type|input|provide|specify|set|select|choose|pick|click|press|tap|tick|check|"
               r"uncheck|untick|leave|assert|verify|generate")
_ASSERT_RE = re.compile(_STEP_LEAD + r"(?:assert|verify|ensure|validate|expect|confirm that|check that)\b", re.I)
_FILL_RE = re.compile(_STEP_LEAD + r"(?:fill|enter|type|input|provide|specify|set)\s+(?:in\s+)?(?:the\s+)?"
                      r"(?P<field>.+?)\s+(?:with|as|to|=|:)\s*(?:the\s+)?(?:value\s+)?(?P<val>.+?)\s*$", re.I)
# "enter a random 6 digit number in BIN field" / "enter 453634 in the BIN field"
_FILL_IN_RE = re.compile(_STEP_LEAD + r"(?:fill|enter|type|input|provide|specify|set|generate)\s+"
                         r"(?P<val>.+?)\s+(?:in|into|on|for)\s+(?:the\s+)?"
                         r"(?P<field>.+?)(?:\s+(?:field|textbox|text\s*box|input|box))?\s*$", re.I)
_SELECT_RE = re.compile(_STEP_LEAD + r"(?:select|choose|pick)\s+(?:the\s+)?"
                        r"(?P<field>.+?)\s+(?:as|to|=|:|with|value)\s*(?:the\s+)?(?:value\s+)?(?P<val>.+?)\s*$", re.I)
_CHECK_RE = re.compile(_STEP_LEAD + r"(?P<verb>check|tick|uncheck|untick)\s+(?:the\s+)?"
                       r"(?P<field>.+?)(?:\s+(?:checkbox|toggle|switch|radio))?\s*$", re.I)
_LEAVE_RE = re.compile(_STEP_LEAD + r"leave\s+(?:the\s+)?(?P<field>.+?)\s+(?:empty|blank)\s*$", re.I)
_CLICK_RE = re.compile(_STEP_LEAD + r"(?:click|press|tap|hit)\s+(?:on\s+)?(?:the\s+)?(?P<target>.+?)\s*$", re.I)
_GEN_ONLY_RE = re.compile(_STEP_LEAD + r"generate\s+(?:a\s+|an\s+|the\s+)?(?P<spec>.+?)\s*$", re.I)
_INTENT_ALWAYS_RE = re.compile(_STEP_LEAD + r"(?:fill|enter|type|input|provide|specify|generate)\b", re.I)
_INTENT_AFTER_START_RE = re.compile(_STEP_LEAD + r"(?:select|choose|pick|tick|untick|uncheck|check|leave|set)\b", re.I)
_FIELD_NOISE = {"the", "field", "input", "textbox", "text", "box", "button", "btn", "dropdown",
                "drop", "down", "checkbox", "radio", "link", "icon", "menu", "select", "a", "an", "of", "for"}


def _split_scenario_clauses(scenario: str) -> list[str]:
    """Splits scenario text into step clauses: commas, semicolons, new lines, sentence-ending
    periods, ' then ', and ' and ' when it is followed by another step verb - but never
    inside double quotes (a quoted value may itself contain a comma or a period)."""
    text = (scenario or "").replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = re.sub(r"(?m)^\s*(?:step\s*)?\d+\s*[.):-]\s+", "", text, flags=re.I)   # "1. " / "Step 2:"
    and_re = re.compile(rf"\s+and\s+(?:then\s+)?(?=(?:{_STEP_VERBS})\b)", re.I)
    clauses, buf, in_q = [], [], False
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == '"':
            in_q = not in_q
            buf.append(ch)
        elif not in_q and ch in ",;\n":
            clauses.append("".join(buf)); buf = []
        elif not in_q and ch == "." and (i + 1 >= n or text[i + 1] in " \n\t"):
            clauses.append("".join(buf)); buf = []
        elif not in_q and text[i:i + 6].lower() == " then ":
            clauses.append("".join(buf)); buf = []
            i += 5
        elif not in_q and ch == " " and and_re.match(text, i):
            clauses.append("".join(buf)); buf = []
            i = and_re.match(text, i).end() - 1
        else:
            buf.append(ch)
        i += 1
    clauses.append("".join(buf))
    return [c.strip().strip(".").strip() for c in clauses if c.strip().strip(".").strip()]


def _clean_value(raw: str) -> tuple[str, bool]:
    """Returns (value, is_explicit). A quoted value is explicit unless it is only a generic
    word like "random"; an unquoted value is explicit only if it looks like a real literal,
    not a phrase such as 'a random 6 digit number' or 'it'."""
    raw = raw.strip()
    m = re.match(r'^(["\'])(.*)\1(?:\s*\(.*\))?$', raw)
    if m:
        inner = m.group(2)
        generic_only = re.fullmatch(r"\s*(random|generated|unique|dynamic|auto|any)\s*", inner, re.I)
        return inner, not generic_only
    if re.match(r"^[\w.@\-/+ ]{1,60}$", raw) and not _GENERIC_VALUE_RE.search(raw) \
            and not re.search(r"\d+\s*-?\s*digit", raw, re.I):
        return raw, True
    return "", False


# ======================================================================
# LUHN: the 6-digit BIN is generated so that the whole 6-digit number passes the Luhn check (5 random digits + the check
# digit); BIN ranges are 19 digits (BIN + zeros / BIN + nines), so the BIN is always INSIDE [low, high].
# ======================================================================
def luhn_check_digit(payload: str) -> int:
    total = 0
    for i, ch in enumerate(reversed(payload)):
        d = int(ch)
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10


def luhn_valid(number: str) -> bool:
    return number.isdigit() and len(number) > 1 and luhn_check_digit(number[:-1]) == int(number[-1])


def luhn_number(length: int = 6) -> str:
    """A random `length`-digit number (first digit 1-9) whose LAST digit is the Luhn check digit of the others."""
    import random
    import string
    length = max(int(length), 2)
    body = random.choice("123456789") + "".join(random.choices(string.digits, k=length - 2))
    return body + str(luhn_check_digit(body))


def luhn_bad_number(length: int = 6) -> str:
    good = luhn_number(length)
    return good[:-1] + str((int(good[-1]) + 1) % 10)       # changing the check digit always breaks the Luhn check


def is_luhn_column(col: str) -> bool:
    hints = [h.strip().lower() for h in os.environ.get("AI_LUHN_COLUMNS", "bin").split(",") if h.strip()]
    low = re.sub(r"[^a-z0-9 ]", " ", (col or "").lower())
    words = set(low.split())
    return bool(hints) and any(h in words for h in hints) and not range_kind(col, None) and "range" not in low


def _generate_value(loc, field: str, clause: str) -> tuple[str, str]:
    """Builds a realistic random value for a field whose scenario step asked for a random /
    generated / unique value (or gave none). Respects the real input's maxlength/minlength/
    type/pattern, and an 'N digit' hint in the step text; numeric for BIN/number/amount-like
    fields, otherwise a short alphanumeric string."""
    import random
    import string
    toks = _norm_tokens(field)
    m = re.search(r"(\d+)\s*-?\s*digit", clause, re.I)
    try:
        maxlen = loc.get_attribute("maxlength")
        minlen = loc.get_attribute("minlength")
        itype = (loc.get_attribute("type") or "").lower()
        pattern = loc.get_attribute("pattern") or ""
    except Exception:
        maxlen = minlen = None
        itype, pattern = "", ""
    numeric = bool(m) or itype in ("number", "tel") or bool(toks & _NUMERIC_WORDS) \
        or "\\d" in pattern or "[0-9]" in pattern
    if m:
        n = int(m.group(1)); why = f"{n}-digit from the step text"
    elif maxlen and maxlen.isdigit() and 0 < int(maxlen) <= 12:
        n = int(maxlen); why = f"length {n} from the field's maxlength"
    else:
        n = 6 if "bin" in toks else 8; why = f"default length {n}"
    if minlen and minlen.isdigit():
        n = max(n, int(minlen))
    if maxlen and maxlen.isdigit() and int(maxlen) > 0:
        n = min(n, int(maxlen))
    if numeric and n >= 2 and is_luhn_column(field) and os.environ.get("AI_LUHN_BIN", "1").strip() != "0":
        return luhn_number(n), f"random {n}-digit number that PASSES the Luhn check, {why}"
    if numeric:
        return random.choice("123456789") + "".join(random.choices(string.digits, k=n - 1)), f"random numeric, {why}"
    body = "".join(random.choices(string.ascii_letters + string.digits, k=max(n - 3, 1)))
    return ("Dry" + body)[:max(n, 1)], f"random text, {why}"


_STABLE_SELECTOR_JS = r"""
el => {
  const q = v => String(v).replace(/'/g, "\\'");
  const tag = el.tagName.toLowerCase();
  const type = (el.getAttribute('type') || '').toLowerCase();
  const dyn = v => /\d{3,}|[0-9a-f]{8,}|^(mat|cdk|ng|ui|react|ember)-?/i.test(v) || /-\d+$/.test(v);
  const bad = t => /["\\]/.test(t);
  const uniq = sel => { try { return document.querySelectorAll(sel).length === 1; } catch (e) { return false; } };
  const xcount = xp => { try { return document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength; } catch (e) { return 0; } };
  const tries = [];
  if (el.id && !dyn(el.id) && !/[^\w-]/.test(el.id)) tries.push('#' + el.id);
  for (const a of ['data-testid','data-test','data-cy','data-qa','formcontrolname','name','aria-label',
                   'placeholder','ng-reflect-name','ng-reflect-form-control-name']) {
    const v = el.getAttribute(a);
    if (v && !dyn(v) && v.length < 60) { tries.push(tag + "[" + a + "='" + q(v) + "']"); tries.push("[" + a + "='" + q(v) + "']"); }
  }
  for (const t of tries) { if (!bad(t) && uniq(t)) return [t, 'attr']; }
  if (tag === 'button' || tag === 'a' || el.getAttribute('role') === 'button') {
    const txt = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (txt && txt.length < 60 && !/['"\\]/.test(txt)) {
      const xp = '//' + tag + "[normalize-space()='" + txt + "']";
      if (xcount(xp) === 1) return [xp, 'attr'];
    }
  }
  const anc = []; let a = el.parentElement; let depth = 0;
  while (a && a !== document.body && depth < 8) {
    if (a.id && !dyn(a.id) && !/[^\w-]/.test(a.id)) anc.push(a);
    a = a.parentElement; depth++;
  }
  if (type === 'radio' || type === 'checkbox') {
    const lab = el.closest('label,mat-radio-button,mat-checkbox');
    const txt = lab ? (lab.textContent || '').replace(/\s+/g, ' ').trim() : '';
    if (txt && txt.length < 60 && !/['"\\]/.test(txt)) {
      const wrap = lab.tagName.toLowerCase();
      for (const an of anc) {
        const xp = "//*[@id='" + an.id + "']//" + wrap + "[normalize-space()='" + txt + "']//input[@type='" + type + "']";
        if (xcount(xp) === 1) return [xp, 'attr'];
      }
      const xp2 = '//' + wrap + "[normalize-space()='" + txt + "']//input[@type='" + type + "']";
      if (xcount(xp2) === 1) return [xp2, 'attr'];
    }
  }
  for (const an of anc) {
    const c1 = '#' + an.id + ' ' + tag + (type ? "[type='" + type + "']" : '');
    const c2 = '#' + an.id + ' ' + tag;
    for (const c of [c1, c2]) { if (!bad(c) && uniq(c)) return [c, 'attr']; }
  }
  const parts = []; let cur = el;
  while (cur && cur.nodeType === 1 && cur !== document.body && parts.length < 8) {
    let part = cur.tagName.toLowerCase();
    if (cur.id && !dyn(cur.id) && !/[^\w-]/.test(cur.id)) { parts.unshift('#' + cur.id); break; }
    const sib = cur.parentElement ? [...cur.parentElement.children].filter(c => c.tagName === cur.tagName) : [];
    if (sib.length > 1) part += ':nth-of-type(' + (sib.indexOf(cur) + 1) + ')';
    parts.unshift(part); cur = cur.parentElement;
  }
  const path = parts.join(' > ');
  return uniq(path) ? [path, 'path'] : ['', ''];
}
"""


def _stable_selector(loc) -> tuple[str, str]:
    """A selector for the element `loc` points at that is unique on the live page, preferring
    stable attributes (id, formcontrolname, name, data-testid, aria-label, placeholder) over
    positional paths. Returns (selector, 'attr'|'path') or ('', '')."""
    try:
        sel, kind = loc.first.evaluate(_STABLE_SELECTOR_JS)
        if sel and '"' not in sel and "\\" not in sel:
            return sel, kind
    except Exception:
        pass
    return "", ""



_DYNAMIC_ID_RE = re.compile(r"(?:mat|cdk|ng|ui)-[a-z-]*?-?\d+\b|mat-mdc-[\w-]*\d+|id\s*=\s*'[^']*\d{3,}[^']*'", re.I)


def _is_fragile_selector(value: str) -> bool:
    """A locator that will break between runs: Angular auto-generated ids (mat-input-5), long
    positional nth-of-type chains, or a leftover '#TODO' placeholder."""
    return bool(_DYNAMIC_ID_RE.search(value)) or value.count(":nth-of-type") >= 2 \
        or value.count(":nth-child") >= 2 or "#TODO" in value


def _looks_like_placeholder(v: str) -> bool:
    return bool(re.search(r"[<>{}$%\[\]]|random|dynamic|generate|auto|placeholder|todo", v or "", re.I))


_CONTROL_WORDS = {"dropdown", "drop-down", "drop", "down", "select", "selector", "combobox", "combo", "list", "listbox",
                  "picker", "radio", "checkbox", "toggle", "switch", "field", "textbox", "text", "input", "box", "menu"}


def _clean_field_name(name: str) -> str:
    """'Card type dropdown' / 'Country drop down' / 'BIN status radio' / 'Name input field' -> the LABEL on the page
    ('Card type', 'Country', 'BIN status', 'Name'). Trailing control-type words are the scenario writer's description of
    the widget, never part of the label, so they are removed (always keeping at least one word)."""
    words = name.strip().strip("\"'").split()
    while len(words) > 1 and words[-1].lower().strip("-:") in _CONTROL_WORDS:
        words.pop()
    return " ".join(words).strip()


def _control_kind(loc) -> tuple[str, str]:
    try:
        tag = loc.first.evaluate("el => el.tagName.toLowerCase()")
        typ = (loc.first.get_attribute("type") or "").lower() if tag == "input" else ""
        return tag, typ
    except Exception:
        return "", ""


_PICK_RADIO_JS = r"""
(el, want) => {
  const norm = s => (s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const w = norm(want);
  document.querySelectorAll('[data-dryrun-radio]').forEach(e => e.removeAttribute('data-dryrun-radio'));
  const root = el.closest('mat-radio-group,[role=radiogroup],fieldset') || el.form || document;
  let radios = [...root.querySelectorAll('input[type=radio]')];
  if (el.name) { const same = radios.filter(r => r.name === el.name); if (same.length) radios = same; }
  const labelOf = r => norm(((r.closest('label,mat-radio-button')) || {}).textContent || r.value);
  const pick = radios.find(r => labelOf(r) === w) || radios.find(r => labelOf(r).includes(w))
            || radios.find(r => norm(r.value) === w);
  if (!pick) return radios.map(labelOf);
  pick.setAttribute('data-dryrun-radio', '1');
  return true;
}
"""

_FIELD_TOKENS = {"input", "field", "dropdown", "select", "checkbox", "radio", "textarea", "toggle",
                 "picker", "switch", "textbox", "date"}
_NOT_FIELD_TOKENS = {"search", "display", "listing", "menu", "filter", "view", "label", "header",
                     "title", "row", "table", "column", "tab", "message", "dialog", "container"}
_FINALIZING_ATTR_HINTS = ("save", "submit", "confirm", "delete", "remove", "cancel", "send", "approve")


def _is_form_field_attr(attr: str) -> bool:
    toks = {t for t in attr.lower().split("_") if t}
    return bool(toks & _FIELD_TOKENS) and not (toks & _NOT_FIELD_TOKENS)


def _apply_locator_heals(repo_root: Path, bank: str, module: str,
                         heals: dict[str, tuple[str, str, str]], log=print) -> int:
    """Rewrites locators in <module>_locators.py whose generated selector did NOT work on the
    live page but whose real element the scenario run found (via its label) and gave a unique
    selector for. A backup is saved to debug_logs/backups first. Returns how many were fixed."""
    if not heals:
        return 0
    path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not path.exists():
        return 0
    text = path.read_text(encoding="utf-8")
    new_text, fixed = text, []
    for attr, (old, new, kind) in heals.items():
        if not new or new == old:
            continue
        pat = re.compile(rf'^(\s*{re.escape(attr)}\s*=\s*)"{re.escape(old)}"(\s*)$', re.M)
        new_text, n = pat.subn(lambda m: f'{m.group(1)}"{new}"{m.group(2)}', new_text)
        if n:
            fixed.append((attr, old, new, kind))
    if not fixed:
        return 0
    try:
        import time as _t
        bdir = repo_root / "debug_logs" / "backups"
        bdir.mkdir(parents=True, exist_ok=True)
        (bdir / f"{module}_locators_{_t.strftime('%Y%m%d_%H%M%S')}.py").write_text(text, encoding="utf-8")
    except Exception:
        pass
    path.write_text(new_text, encoding="utf-8")
    repair_python_string_lines(path)
    log(f"  [scenario-run] AUTO-HEALED {len(fixed)} locator(s) in {path} (backup in debug_logs\\backups):")
    for attr, old, new, kind in fixed:
        log(f"       {attr}: {old}  ->  {new}   [{'stable attribute' if kind == 'attr' else ('row template ({value} = the record)' if kind == 'template' else 'positional path - fragile, review')}]")
    return len(fixed)


def _norm_tokens(text: str) -> set[str]:
    words = re.sub(r"[^a-z0-9]+", " ", re.sub(r"([a-z])([A-Z])", r"\1 \2", text).lower()).split()
    return {w for w in words if w not in _FIELD_NOISE}


_FIELD_ATTR_WORDS = {"input", "field", "dropdown", "select", "checkbox", "radio", "textarea", "textbox", "combobox"}
_BUTTON_ATTR_WORDS = {"button", "btn", "link", "icon", "tab", "menu"}


def _match_locator_entry(name: str, entries: list[tuple[str, str]], kind: str | None = None) -> tuple[str, str] | None:
    """Finds the locators.py attribute that best corresponds to a field/button name from
    the scenario. Deliberately strict (token-set equality or strong overlap) so 'bin'
    never silently matches 'bin_low_range'. kind='button' ignores attributes that are INPUT FIELDS (so the step
    'click Search' can never pick search_input) and kind='field' ignores buttons / links / icons."""
    want = _norm_tokens(name)
    if not want:
        return None
    best, best_score = None, 0.0
    for attr, val in entries:
        words = set(attr.lower().split("_"))
        if kind == "button" and (words & _FIELD_ATTR_WORDS) and not (words & _BUTTON_ATTR_WORDS):
            continue
        if kind == "field" and (words & _BUTTON_ATTR_WORDS) and not (words & _FIELD_ATTR_WORDS):
            continue
        have = _norm_tokens(attr)
        if not have:
            continue
        inter = len(want & have)
        if not inter:
            continue
        score = inter / len(want | have)
        if want == have:
            score = 1.0
        if score > best_score:
            best, best_score = (attr, val), score
    return best if best and best_score >= 0.6 else None


_MARK_ATTR = "data-dryrun-target"
_FIND_BY_LABEL_JS = """
(name) => {
  const norm = s => (s || '').toLowerCase().replace(/[*:\\u00a0]/g, ' ').replace(/\\s+/g, ' ').trim();
  const want = norm(name);
  document.querySelectorAll('[data-dryrun-target]').forEach(e => e.removeAttribute('data-dryrun-target'));
  const isCtl = e => /^(input|select|textarea)$/i.test(e.tagName) || /^mat-select$/i.test(e.tagName)
                     || e.getAttribute('role') === 'combobox';
  const visible = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                         return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const cands = [...document.querySelectorAll('label, td, th, span, div, p, b, strong, legend, mat-label')]
    .filter(e => visible(e) && (e.tagName === 'LABEL' || e.children.length === 0 ||
                                [...e.children].every(c => !isCtl(c) && !c.querySelector('input,select,textarea'))));
  const scored = [];
  for (const e of cands) {
    const t = norm(e.innerText || e.textContent);
    if (!t || t.length > 80) continue;
    let rank = -1;
    if (t === want) rank = 0; else if (t.startsWith(want + ' ') || t.startsWith(want + '(')) rank = 1;
    else if (t.includes(want)) rank = 2;
    if (rank >= 0) scored.push([rank, t.length, e]);
  }
  scored.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  if (!scored.length) return 0;
  const bestRank = scored[0][0];
  const top = scored.filter(s => s[0] === bestRank && s[1] === scored[0][1]);
  if (top.length > 1 && bestRank > 0) return -top.length;   // ambiguous
  const lab = top[0][2];
  let ctl = null;
  if (lab.tagName === 'LABEL' && lab.control) ctl = lab.control;
  if (!ctl && lab.getAttribute && lab.getAttribute('for')) ctl = document.getElementById(lab.getAttribute('for'));
  const CTL_SEL = 'input,select,textarea,mat-select,[role=combobox]';
  if (!ctl) ctl = lab.querySelector(CTL_SEL);
  if (!ctl) {
    const all = [...document.querySelectorAll(CTL_SEL)].filter(c => visible(c) && c.type !== 'hidden');
    ctl = all.find(c => (lab.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING));
    // Safety: the control must live in the same row/group as its label - otherwise this
    // would silently grab the NEXT field's control (and fill the wrong field).
    const box = lab.closest('tr, .form-group, mat-form-field, .mat-form-field, fieldset, li');
    if (ctl && box && !box.contains(ctl)) ctl = null;
  }
  if (!ctl) return 0;
  ctl.setAttribute('data-dryrun-target', '1');
  return 1;
}
"""


_CTL_COUNT_JS = """
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  return [...document.querySelectorAll('input,select,textarea,mat-select,[role=combobox]')]
          .filter(e => e.type !== 'hidden' && vis(e)).length;
}
"""
_LIST_CONTROLS_JS = """
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const norm = s => (s || '').replace(/\\s+/g, ' ').trim().slice(0, 50);
  return [...document.querySelectorAll('input,select,textarea,mat-select,[role=combobox]')]
    .filter(e => e.type !== 'hidden').slice(0, 60).map(e => {
      let label = '';
      if (e.id) { const l = document.querySelector('label[for="' + e.id + '"]'); if (l) label = norm(l.innerText); }
      if (!label) { const l = e.closest('label'); if (l) label = norm(l.innerText); }
      if (!label) { const ff = e.closest('mat-form-field,.mat-mdc-form-field'); const ml = ff && ff.querySelector('mat-label,label');
                    if (ml) label = norm(ml.innerText); }
      if (!label) { const cell = e.closest('td,th,div'); const prev = cell && cell.previousElementSibling;
                    if (prev) label = norm(prev.innerText); }
      if (!label) { let n = e.parentElement; for (let i = 0; i < 4 && n && !label; i++, n = n.parentElement) {
                      const lab = n.querySelector(':scope > label, :scope > mat-label'); if (lab) label = norm(lab.innerText); } }
      return {tag: e.tagName.toLowerCase(), type: e.type || '', id: e.id || '', name: e.getAttribute('name') || '',
              placeholder: e.getAttribute('placeholder') || '', label: label, visible: vis(e)};
    });
}
"""


def _frames(page):
    """Main document first, then every iframe - legacy portals commonly render the real form
    inside an iframe while the top document is only a menu shell with MANY links, which is
    why 'pick the main page if it has >=5 elements' wrongly ignored the form."""
    out = [page.main_frame] if hasattr(page, "main_frame") else [page]
    for fr in getattr(page, "frames", []):
        if fr not in out:
            out.append(fr)
    return out


def _frame_tag(fr, page) -> str:
    try:
        return "" if fr == page.main_frame else f" [iframe {fr.url.rsplit('/', 1)[-1][:40]}]"
    except Exception:
        return ""


def _wait_for_form(page, log=print, timeout_ms: int = 12000) -> int:
    """After clicking Add the form often arrives via AJAX a moment later. Wait (up to
    timeout_ms) until any frame shows a visible input/select/textarea, then let it settle."""
    waited, total = 0, 0
    while waited <= timeout_ms:
        total = 0
        for fr in _frames(page):
            try:
                total += fr.evaluate(_CTL_COUNT_JS)
            except Exception:
                pass
        if total > 0:
            page.wait_for_timeout(600)
            log(f"    [scenario-run] form ready: {total} visible field control(s) across "
                f"{len(_frames(page))} frame(s) after ~{waited / 1000:.1f}s")
            return total
        page.wait_for_timeout(400)
        waited += 400
    log(f"    [scenario-run] WARNING: no visible input/select/textarea appeared within {timeout_ms // 1000}s "
        f"- the Add form may not have opened (wrong click?) or is a widget this tool can't see")
    return 0


def _dump_visible_fields(page, wanted: str, snapshot_stem: Path | None, log=print) -> None:
    """Called when a field can't be found: prints every control the tool CAN see (with its
    label/id/name), suggests the closest label, and saves each frame's HTML - so the real
    reason is visible instead of guessed."""
    want = _norm_tokens(wanted)
    seen = []
    for fr in _frames(page):
        try:
            for c in fr.evaluate(_LIST_CONTROLS_JS):
                c["frame"] = _frame_tag(fr, page).strip()
                seen.append(c)
        except Exception:
            continue
    log(f"    [scenario-run] --- what the tool can see on the page right now ({len(seen)} control(s)) ---")
    for c in seen[:25]:
        log(f"       {c['frame'] or '[main]'} <{c['tag']}{(' type=' + c['type']) if c['type'] else ''}> "
            f"label='{c['label']}' id='{c['id']}' name='{c['name']}' placeholder='{c['placeholder']}'"
            f"{'' if c['visible'] else '  (HIDDEN)'}")
    if not seen:
        log("       (no input/select/textarea in ANY frame - the form isn't on the page yet, "
            "or it's drawn by a canvas/shadow-DOM widget)")
    scored = []
    for c in seen:
        have = _norm_tokens(" ".join([c["label"], c["id"], c["name"], c["placeholder"]]))
        if want & have and len(want & have) / len(want) > 0.5:
            scored.append((len(want & have) / len(want | have), c))
    for _, c in sorted(scored, key=lambda t: -t[0])[:3]:
        log(f"    [scenario-run] did you mean: label='{c['label']}' id='{c['id']}' name='{c['name']}' ?")
    if snapshot_stem is not None:
        try:
            snapshot_stem.parent.mkdir(parents=True, exist_ok=True)
            for i, fr in enumerate(_frames(page)):
                path = snapshot_stem.with_name(f"{snapshot_stem.name}_frame{i}.html")
                path.write_text(fr.content(), encoding="utf-8")
            log(f"    [scenario-run] saved the page HTML (every frame) as {snapshot_stem}_frame*.html")
        except Exception as exc:
            log(f"    [scenario-run] (could not save page HTML: {exc})")


def _resolve_field(page, name: str, entries: list[tuple[str, str]], skip_entries: bool = False):
    """Returns (locator, how) or (None, reason). Looks in EVERY frame. Tries locators.py
    first (so this verifies the generated locator), then the live page's own label text.
    skip_entries=True goes straight to the live page (used when the generated locator
    resolved but could not actually be used)."""
    matched = _match_locator_entry(name, entries, "field")
    reasons = []
    variants: list[str] = []                       # the scenario's wording, then the bare label ("Card type dropdown" -> "Card type")
    for v in (name, _clean_field_name(name),
              " ".join(w for w in name.split() if w.lower().strip("-:") not in _CONTROL_WORDS)):
        v = v.strip()
        if v and v not in variants:
            variants.append(v)
    for target in _frames(page):
        tag = _frame_tag(target, page)
        if matched and not skip_entries and not matched[1].startswith("#TODO"):
            attr, val = matched
            try:
                loc = target.locator(val)
                if loc.count() == 1:
                    return loc, f"locators.py:{attr}{tag}"
            except Exception:
                pass
        for variant in variants:
            try:
                res = target.evaluate(_FIND_BY_LABEL_JS, variant)
                if res == 1:
                    return target.locator(f"[{_MARK_ATTR}='1']"), (
                        "live page label" + tag + (f" '{variant}'" if variant != name else "") + " (generated locator " +
                        (f"'{matched[0]}' did NOT work)" if matched else "not found in locators.py)"))
                if isinstance(res, int) and res < 0:
                    reasons.append(f"label '{variant}' is ambiguous{tag} ({-res} equally-good matches)")
            except Exception as exc:
                reasons.append(f"live label search errored{tag}: {str(exc).splitlines()[0][:80]}")
            for getter in (lambda v=variant: target.get_by_label(v, exact=True),
                           lambda v=variant: target.get_by_placeholder(v, exact=False)):
                try:
                    loc = getter()
                    if loc.count() == 1:
                        return loc, f"live page accessible label/placeholder{tag}"
                except Exception:
                    continue
    return None, (reasons[0] if reasons else
                  f"no input/select/checkbox found for field '{name}' in any frame (label text tried: {variants}; "
                  f"{'locators.py entry ' + repr(matched[0]) + ' is a #TODO placeholder or did not resolve' if matched else 'no matching locators.py entry'}; "
                  f"no standard control sits next to a label with that text - it may be a custom widget)")


def _resolve_button(page, name: str, entries: list[tuple[str, str]]):
    """Returns (locator, how, count). Searches every frame."""
    matched = _match_locator_entry(name, entries, "button")
    pat = re.compile(re.escape(name.strip()), re.I)
    for target in _frames(page):
        tag = _frame_tag(target, page)
        if matched and not matched[1].startswith("#TODO"):
            try:
                loc = target.locator(matched[1])
                if loc.count() == 1:
                    return loc, f"locators.py:{matched[0]}{tag}", 1
            except Exception:
                pass
        for how, getter in (
            ("button by name", lambda: target.get_by_role("button", name=pat)),
            ("link by name", lambda: target.get_by_role("link", name=pat)),
            ("submit/button input by value", lambda: target.locator(
                f"input[type=submit][value*='{name.strip()}' i], input[type=button][value*='{name.strip()}' i]")),
            ("text", lambda: target.get_by_text(pat)),
        ):
            try:
                loc = getter()
                n = loc.count()
                if n >= 1:
                    return (loc.first if n > 1 else loc), how + tag, n
            except Exception:
                continue
    return None, "not found", 0


def _locate_in_frames(page, selector: str):
    """For the older field-level dry run: the first frame where `selector` matches exactly
    one element, else the main page's locator (so existing warning text is unchanged)."""
    for target in _frames(page):
        try:
            loc = target.locator(selector)
            if loc.count() == 1:
                return loc
        except Exception:
            continue
    return page.locator(selector)


_DROPDOWN_STATE_JS = r"""
el => {
  const r = el.getBoundingClientRect();
  const disabled = el.getAttribute('aria-disabled') === 'true' || el.hasAttribute('disabled')
                   || /disabled/.test(el.className || '');
  let covered = '';
  if (r.width > 0 && r.height > 0) {
    const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (top && !(el.contains(top) || top.contains(el))) covered = top.tagName.toLowerCase() + '.' + String(top.className || '').slice(0, 50);
  }
  return {disabled: disabled, visible: r.width > 0 && r.height > 0, covered: covered};
}
"""


def _panel_open(page) -> bool:
    """A mat-select / combobox panel is open when its option elements exist in the overlay."""
    for fr in _frames(page):
        try:
            if fr.locator("mat-option, [role=option], .select2-results__option").count() > 0:
                return True
        except Exception:
            continue
    return False


def _dismiss_overlays(page) -> None:
    """Closes any leftover cdk-overlay-backdrop / open panel (e.g. a multi-select that stays open) so the next
    field is clickable: Escape first, then click the backdrop if it is still there."""
    for _ in range(3):
        try:
            bd = page.locator(".cdk-overlay-backdrop.cdk-overlay-backdrop-showing, .cdk-overlay-backdrop-showing")
            if bd.count() == 0 and not _panel_open(page):
                return
            page.keyboard.press("Escape")
            page.wait_for_timeout(250)
            if bd.count() > 0:
                try:
                    bd.last.click(timeout=1000, force=True, position={"x": 2, "y": 2})
                except Exception:
                    pass
                page.wait_for_timeout(250)
        except Exception:
            return


def _open_custom_dropdown(page, loc, log=print) -> str:
    """Opens a custom (mat-select style) dropdown WITHOUT trusting one plain click: closes any panel left open, waits
    while it is disabled (dependent dropdowns enable only after an earlier selection / data load), then tries a normal click,
    scroll-to-centre + click (sticky footers cover fields), force click, keyboard Enter and a JS click. Returns the
    strategy that worked; raises with the REAL reason (disabled / covered by <x> / not visible) when none works."""
    _dismiss_overlays(page)
    state = {}
    for _ in range(24):                                   # up to ~9s while a dependent dropdown is still disabled
        try:
            state = loc.first.evaluate(_DROPDOWN_STATE_JS)
        except Exception:
            state = {}
        if not state.get("disabled"):
            break
        page.wait_for_timeout(400)
    if state.get("disabled"):                              # still disabled after ~9s: clicking would only burn time
        raise RuntimeError("could not open the dropdown: the dropdown is DISABLED even after waiting ~9s (it probably "
                           "depends on an earlier selection - fill/select that first)")
    attempts = [
        ("click", lambda: (loc.scroll_into_view_if_needed(timeout=2500), loc.click(timeout=3500))),
        ("scroll-to-centre + click", lambda: (loc.evaluate("el => el.scrollIntoView({block: 'center'})"),
                                              page.wait_for_timeout(300), loc.click(timeout=3500))),
        ("force click", lambda: loc.click(force=True, timeout=3000)),
        ("keyboard Enter", lambda: (loc.focus(), page.keyboard.press("Enter"))),
        ("JS click", lambda: loc.evaluate("el => el.click()")),
    ]
    last = ""
    for name, fn in attempts:
        try:
            fn()
        except Exception as exc:
            last = str(exc).strip().splitlines()[0][:160]
            continue
        page.wait_for_timeout(450)
        if _panel_open(page):
            return name
        _dismiss_overlays(page)                           # clicked but nothing opened - reset and try the next way
    try:
        state = loc.first.evaluate(_DROPDOWN_STATE_JS)
    except Exception:
        pass
    why = []
    if state.get("disabled"):
        why.append("the dropdown is DISABLED (it probably depends on an earlier selection - fill/select that first)")
    if state.get("covered"):
        why.append(f"it is covered by <{state['covered']}>")
    if state and not state.get("visible"):
        why.append("it is not visible on the page")
    raise RuntimeError("could not open the dropdown: " + ("; ".join(why) or "no reason found") +
                       (f". Last Playwright error: {last}" if last else ""))


def _apply_value(page, loc, value: str, out: dict | None = None) -> str:
    """Performs the real interaction on a resolved field. Returns a short detail string,
    raises on failure. For a radio group, picks the option whose LABEL matches `value` (not
    just the first radio) and returns the picked radio's locator in out['loc']."""
    tag = loc.evaluate("el => el.tagName.toLowerCase()")
    itype = (loc.get_attribute("type") or "").lower() if tag == "input" else ""
    if tag == "input" and itype == "radio":
        res = loc.first.evaluate(_PICK_RADIO_JS, value)
        if res is not True:
            raise RuntimeError(f"no radio option '{value}' in this group; options are: {res}")
        for fr in _frames(page):
            cand = fr.locator("[data-dryrun-radio='1']")
            if cand.count() == 1:
                cand.check(timeout=3000)
                if out is not None:
                    out["loc"] = cand
                return f"selected radio '{value}'"
        raise RuntimeError(f"radio option '{value}' found in the DOM but could not be located to click")
    if tag == "input" and itype == "checkbox":
        loc.check(timeout=3000)
        return "checked"
    if tag in ("input", "textarea"):
        loc.fill(value, timeout=3000)
        actual = loc.input_value()
        if actual != value:
            return f"WARN page changed the value: typed '{value}' but field now holds '{actual}'"
        return f"filled '{value}'"
    if tag == "select":
        options = [o.strip() for o in loc.locator("option").all_text_contents()]
        pick = next((o for o in options if o.lower() == value.lower()), None) or \
               next((o for o in options if value.lower() in o.lower()), None)
        if pick is None:
            raise RuntimeError(f"option '{value}' not in dropdown; real options are: {options[:12]}")
        try:
            loc.select_option(label=pick, timeout=3000)
            return f"selected '{pick}'"
        except Exception:
            # Hidden <select> behind a custom widget (select2/chosen/bootstrap-select style).
            loc.select_option(label=pick, force=True, timeout=3000)
            return (f"WARN selected '{pick}' programmatically - the <select> is hidden behind a custom "
                    f"widget, so a real click on that widget was NOT verified")
    opened_via = _open_custom_dropdown(page, loc)
    for pattern in (re.compile(rf"^\s*{re.escape(value)}\s*$", re.I), re.compile(re.escape(value), re.I)):
        for target in _frames(page):
            opt = target.locator("mat-option, [role=option], li, option").filter(has_text=pattern)
            try:
                if opt.count() > 0:
                    opt.first.click(timeout=3000)
                    try:                                       # dependent dropdowns load their data after a selection
                        page.wait_for_load_state("networkidle", timeout=2500)
                    except Exception:
                        pass
                    return f"picked '{value}' from custom dropdown" + \
                        ("" if opened_via == "click" else f" (opened via {opened_via})")
            except Exception:
                continue
    options = []
    for target in _frames(page):
        try:
            options += [t.strip() for t in target.locator("mat-option, [role=option]").all_text_contents()][:15]
        except Exception:
            pass
    raise RuntimeError(f"custom dropdown opened but no option '{value}' appeared; the real options are: {options}")


# ======================================================================
# SEARCH + ROW-ACTION steps (View / Edit / Delete / ChangeStatus scenarios) and the identifier handed over by Add
#   * the Add dry run really SAVES the record (AI_DRYRUN_COMMIT_ADD, only when View/Edit/Delete scenarios follow) so those
#     scenarios have a real BIN to search for;
#   * "search for the BIN created in Add" types THAT BIN into the listing's search box, clicks Search, waits for its row;
#   * "click the delete icon (trash can) at the end of the row for that BIN" finds that row and the icon inside it;
#     opening a delete/edit/view icon is NOT destructive - only the confirmation (Yes / Send for approval) is final.
# ======================================================================
_CTX_WORDS = r"(?:page|dialog|popup|pop-up|modal|screen|form|window|section|tab|listing|summary|details|confirmation)"
_CTX_ONLY_RE = re.compile(rf"^(?:then\s+)?(?:on|in|at|inside|within)\s+the\s+[\w\s-]{{1,40}}?\b{_CTX_WORDS}\b\s*$", re.I)
_CTX_PREFIX_RE = re.compile(rf"^(?:then\s+)?(?:on|in|at|inside|within)\s+the\s+[\w\s-]{{1,40}}?\b{_CTX_WORDS}\b\s*[,:]?\s*"
                            rf"(?=(?:click|press|tap|select|choose|enter|fill|type|search|verify|assert|check|confirm)\b)", re.I)
_SEARCH_RE = re.compile(_STEP_LEAD + r"(?:search|filter|find|look\s*up|locate)\b(?P<rest>.*)$", re.I)
_ROW_ACTION_WORDS = {"expand": ("expand", "open_in_full", "fullscreen", "zoom_out_map", "launch", "open_in_new", "north_east",
                                "call_made", "chevron", "arrow", "keyboard_arrow", "expand_more"),
                     "view": ("view", "eye", "visibility", "detail", "details"),
                     "edit": ("edit", "pencil", "modify"),
                     "delete": ("delete", "trash", "remove"),
                     "status": ("status", "activate", "deactivate", "toggle")}
_ROW_CONTEXT_RE = re.compile(r"\b(icon|row|record|listing|table|end of|against|for that|for the|of that|of the)\b", re.I)
_CONFIRM_RE = re.compile(r"\b(yes|confirm|ok|proceed|send for approval|submit|save|approve)\b", re.I)
_ROW_SEL = "tr, mat-row, [role=row], .mat-mdc-row, .mdc-data-table__row"
_SNACK_SEL = "mat-snack-bar-container, .mat-mdc-snack-bar-container, .snackbar, [class*='toast' i], [role=alert]"


def _row_action_of(target: str, clause: str) -> str | None:
    """'delete icon (trash can) at the end of the row for that BIN' -> 'delete'. A confirmation click is never a row action."""
    if _CONFIRM_RE.search(target) or not _ROW_CONTEXT_RE.search(clause):
        return None
    low = target.lower()
    for act, words in _ROW_ACTION_WORDS.items():
        if any(re.search(rf"\b{w}\b", low) for w in words):
            return act
    return None


def _robust_click(page, el, timeout: int = 3500) -> str:
    last = ""
    for name, fn in (("click", lambda: (el.scroll_into_view_if_needed(timeout=2500), el.click(timeout=timeout))),
                     ("force click", lambda: el.click(force=True, timeout=3000)),
                     ("JS click", lambda: el.evaluate("e => e.click()"))):
        try:
            fn()
            return name
        except Exception as exc:
            last = str(exc).strip().splitlines()[0][:160]
    raise RuntimeError(f"could not click the element ({last})")


def _find_row(page, value: str, timeout_ms: int = 9000):
    """The table row that shows `value` (waits - listings load after Search). -> (rows locator, count) or (None, 0)."""
    waited = 0
    while waited <= timeout_ms:
        for fr in _frames(page):
            try:
                rows = fr.locator(_ROW_SEL).filter(has_text=value)
                visible = [rows.nth(k) for k in range(min(rows.count(), 40)) if rows.nth(k).is_visible()]
                if visible:                     # a HIDDEN row (the listing behind an opened details page) is not "the row"
                    return visible[0], len(visible)
            except Exception:
                continue
        page.wait_for_timeout(500)
        waited += 500
    return None, 0


_NAV_ANCESTOR_JS = "e => !e.closest('nav,header,mat-sidenav,mat-toolbar,[class*=navigation],[class*=sidebar]')"


_ICON_SEL = "button, a, mat-icon, cl-icon, svg, i, img, [role=button]"
_ICON_DESC_JS = """el => { const t = el.tagName.toLowerCase(); const g = a => (el.getAttribute(a) || '').trim();
  const cls = [...el.classList].filter(c => !/^(ng-|cdk-|mat-mdc-|mdc-|mat-ripple|ripple)/.test(c) && !/\\d/.test(c)
                                           && !['notranslate', 'material-icons', 'mat-icon', 'material-icons-outlined'].includes(c));
  const inner = el.querySelector('mat-icon,cl-icon,svg,i,img');
  const txt = (el.innerText || el.textContent || '').trim();
  const cell = el.closest('td,mat-cell,[role=cell]');
  const idx = cell && cell.parentElement ? [...cell.parentElement.children].indexOf(cell) + 1 : 0;
  return {tag: t, aria: g('aria-label'), title: g('title'), text: txt.length <= 30 ? txt : '', cls: cls.slice(0, 2), idx,
          inner: inner ? {tag: inner.tagName.toLowerCase(), text: (inner.textContent || '').trim().slice(0, 30), aria: (inner.getAttribute('aria-label') || '')} : null}; }"""


def _visible_icons(scope) -> list:
    """Visible icon-like elements of `scope`; an icon inside a button counts once (the button)."""
    out = []
    try:
        icons = scope.locator(_ICON_SEL)
        for k in range(min(icons.count(), 40)):
            e = icons.nth(k)
            if e.is_visible() and not e.evaluate("e => !!(e.parentElement && e.parentElement.closest('button, a, [role=button]'))"):
                out.append(e)
    except Exception:
        pass
    return out


def _icon_in_request_cell(row) -> list:
    """The row has an expand icon that carries no name at all (an <svg>, an <img>): it sits in the 'Request ID' cell. Found by the
    column of that header; with no such header, the row's only icon."""
    try:
        idx = row.evaluate("""row => { const t = row.closest('table,mat-table,[role=table],[role=grid]');
            const heads = t ? [...t.querySelectorAll('th, mat-header-cell, [role=columnheader]')] : [];
            return heads.findIndex(h => /request\\s*id/i.test(h.innerText || '')); }""")
        cells = row.locator("td, mat-cell, [role=cell]")
        if isinstance(idx, int) and idx >= 0 and cells.count() > idx:
            vis = _visible_icons(cells.nth(idx))
            if vis:
                return vis[:1]
        vis = _visible_icons(row)
        return vis if len(vis) == 1 else []
    except Exception:
        return []


def _row_icon_template(el) -> str | None:
    """A ROW-SCOPED XPath TEMPLATE for the icon `el`:  //tr[contains(normalize-space(.),'{value}')]//mat-icon[normalize-space()='open_in_full']
    - the identifier of the record is the {value}, so the SAME icon is found in the row of whatever record is searched."""
    try:
        d = el.evaluate(_ICON_DESC_JS)
    except Exception:
        return None
    q = lambda t: "'" + str(t).replace("'", "") + "'"               # noqa: E731  (XPath 1.0 has no quote escaping)
    # an <svg> is in the SVG namespace: //svg never matches it in an HTML page - local-name() does
    nm = lambda t: f"*[local-name()='{t}']" if t in ("svg", "path", "use", "g", "circle", "rect") else t     # noqa: E731
    tag = nm(d["tag"])
    inner = dict(d.get("inner") or {})
    if inner:
        inner["tag"] = nm(inner["tag"])
    if d["aria"]:
        pred = f"[@aria-label={q(d['aria'])}]"
    elif d["title"]:
        pred = f"[@title={q(d['title'])}]"
    elif d["text"]:
        pred = f"[normalize-space()={q(d['text'])}]"
    elif inner.get("text"):
        pred = f"[.//{inner['tag']}[normalize-space()={q(inner['text'])}]]"
    elif inner.get("aria"):
        pred = f"[.//{inner['tag']}[@aria-label={q(inner['aria'])}]]"
    elif d["cls"]:
        pred = f"[contains(@class,{q(d['cls'][0])})]"
    else:
        pred = ""
    row = "//*[self::tr or self::mat-row or @role='row'][contains(normalize-space(.),'{value}')]"
    if not pred and d.get("idx"):
        return f"{row}/*[{d['idx']}]//{tag}"                          # no name at all: the icon of that CELL of the row
    return f"{row}//{tag}{pred}"


def _template_resolves(page, template: str, value: str) -> bool:
    try:
        loc = page.locator(template.format(value=value))
        return loc.count() == 1 and loc.first.is_visible()
    except Exception:
        return False


def _action_candidates(scope, action: str) -> list:
    """Visible controls inside `scope` (a row locator or a frame) whose id / class / title / aria-label / text names the action."""
    for w in _ROW_ACTION_WORDS.get(action, (action,)):
        found = []
        for sel in (f"[id*='{w}' i]", f"[class*='{w}' i]", f"[title*='{w}' i]", f"[aria-label*='{w}' i]",
                    f"[data-testid*='{w}' i]", f"mat-icon:text-is('{w}')", f"button:has-text('{w}')", f"a:has-text('{w}')"):
            try:
                loc = scope.locator(sel)
                for k in range(min(loc.count(), 30)):
                    el = loc.nth(k)
                    if el.is_visible() and el.evaluate(_NAV_ANCESTOR_JS):
                        found.append(el)
            except Exception:
                continue
            if found:
                break
        if found:
            return found
    return []


_APPROVE_ACTION_RE = re.compile(r"approv|authori[sz]|checker|reject", re.I)


def is_commit_action(action: str) -> bool:
    """Actions whose final click is REALLY performed in the dry run (when records must exist for what follows): Add, and the checker
    step after it (approve / authorise / reject ...)."""
    return action == "add" or bool(_APPROVE_ACTION_RE.search(action or ""))


def _resolve_button_in_dialog(page, name: str):
    """The button called `name` INSIDE an open confirmation dialog / popup (the page behind it has a button with the same name)."""
    words = [w for w in re.split(r"\W+", name) if w and w.lower() not in ("button", "btn", "the", "a", "on", "in", "dialog", "popup",
                                                                         "modal", "confirmation", "confirm")]
    pattern = re.compile(r".*".join(re.escape(w) for w in words), re.I) if words else None
    for fr in _frames(page):
        try:
            dlg = fr.locator("mat-dialog-container, [role=dialog], [role=alertdialog], .swal2-popup, .modal.show")
            if dlg.count() and dlg.first.is_visible():
                b = dlg.first.get_by_role("button", name=pattern) if pattern else dlg.first.get_by_role("button")
                if b.count() and b.first.is_visible():
                    return b.first
        except Exception:
            continue
    return None


def _click_row_action(page, action: str, value: str, prefer_last: bool = False):
    """Clicks the view / edit / delete / status control of the record `value`:
       1) the icon INSIDE the row that shows the value;
       2) for 'view' (or when the row has no such icon): the record itself - its link / cell showing the value;
       3) no table row at all: the record's own DETAILS page is open, so the control sits on the page itself."""
    rows, n = _find_row(page, value)
    picked = None
    if n:
        row = rows
        found = _action_candidates(row, action)
        if not found and action == "expand":
            found = _icon_in_request_cell(row)                        # an icon without any name: the one beside the Request ID
        if found:
            picked = found[-1] if prefer_last else found[0]
        elif action == "view":
            for sel in ("a", "button", "td", "mat-cell", "span", "div"):
                try:
                    loc = row.locator(sel).filter(has_text=value)
                    if loc.count() and loc.first.is_visible():
                        picked = loc.first
                        break
                except Exception:
                    continue
            picked = picked or row
        else:
            try:
                inv = row.evaluate("""row => [...row.querySelectorAll('a,button,mat-icon,cl-icon,svg,i,[role=button]')].slice(0, 12)
                    .map(e => (e.tagName.toLowerCase() + '#' + (e.id || '') + '.' + String(e.className || '').slice(0, 30) +
                               ' title=' + (e.getAttribute('title') || '') + ' text=' + (e.textContent || '').trim().slice(0, 15)))""")
            except Exception:
                inv = []
            raise RuntimeError(f"no '{action}' control inside the row for '{value}'; the row holds: {inv}")
    else:
        shows_value = False
        for fr in _frames(page):
            try:
                if fr.get_by_text(value, exact=False).count() > 0:
                    shows_value = True
                    found = _action_candidates(fr, action)
                    if found:
                        picked = found[-1] if prefer_last else found[0]
                        break
            except Exception:
                continue
        if picked is None:
            raise RuntimeError(f"no table row shows '{value}' and no '{action}' control was found on the page"
                               f"{' (the page does show the value)' if shows_value else ''} - the search did not return the "
                               f"record (was it really created by Add?)")
    how = _robust_click(page, picked)
    try:
        page.wait_for_load_state("networkidle", timeout=6000)
    except Exception:
        pass
    return picked, how


def _find_search_input(page):
    """The listing's search box: type=search / placeholder|aria-label|name|id|formcontrolname containing 'search'."""
    for fr in _frames(page):
        for sel in ("input[type=search]", "input[placeholder*='search' i]", "input[aria-label*='search' i]",
                    "input[name*='search' i]", "input[id*='search' i]", "input[formcontrolname*='search' i]"):
            try:
                loc = fr.locator(sel)
                if loc.count() >= 1 and loc.first.is_visible():
                    return loc.first, f"search box ({sel})"
            except Exception:
                continue
    return None, ""


def _is_editable_input(loc) -> bool:
    try:
        return bool(loc.first.evaluate("""e => (/^(input|textarea)$/i.test(e.tagName) &&
            !['radio','checkbox','button','submit','hidden','file'].includes((e.type || '').toLowerCase())) || e.isContentEditable"""))
    except Exception:
        return False


def _pick_editable(loc):
    """`loc` itself when it is a text input, else the text input INSIDE it (a mat-form-field / wrapper), else None."""
    if _is_editable_input(loc):
        return loc
    try:
        inner = loc.first.locator("input:not([type=radio]):not([type=checkbox]):not([type=hidden]):not([type=button]):"
                                  "not([type=submit]), textarea")
        if inner.count() >= 1 and _is_editable_input(inner.first):
            return inner.first
    except Exception:
        pass
    return None


def _do_search(page, rest: str, identifier: dict | None, entries: list[tuple[str, str]]) -> dict:
    """Types the value into the search field and runs the search; the value is a quoted literal in the step, otherwise the
    identifier (BIN) the Add dry run created. The search field must be a REAL text input (a locator that points at a
    wrapper / dropdown is looked inside, or skipped). Returns {value, input_loc, input_how, input_match, button_loc, ...}."""
    quoted = re.search(r'"([^"]+)"', rest or "")
    value = quoted.group(1) if quoted else (identifier or {}).get("value")
    if not value:
        raise RuntimeError("nothing to search for: the step gives no value and Add did not hand over an identifier "
                           "(Add must run first and be saved - AI_DRYRUN_COMMIT_ADD=1)")
    label = (identifier or {}).get("label") or ""          # the identifier's own name (BIN, Merchant ID, Name ...) - no default
    loc, how, match = None, "", None
    cands = [(a, v) for a, v in entries if "search" in a.lower().split("_") and not v.startswith("#TODO")
             and not ({"button", "btn", "link", "icon"} & set(a.lower().split("_")))]
    pref = _match_locator_entry(f"search {label}", entries, "field") if label else None
    if pref and pref in cands:
        cands.remove(pref)
        cands.insert(0, pref)
    for cand in cands:
        for fr in _frames(page):
            try:
                l = fr.locator(cand[1])
                if l.count() == 1:
                    ed = _pick_editable(l)
                    if ed is not None:
                        loc, how, match = ed, f"locators.py:{cand[0]}", cand
                        break
            except Exception:
                continue
        if loc is not None:
            break
    if loc is None:
        for variant in ([f"Search {label}", label] if label else []) + ["Search"]:
            l, h = _resolve_field(page, variant, [])
            if l is not None:
                ed = _pick_editable(l)
                if ed is not None:
                    loc, how, match = ed, h, (cands[0] if cands else _match_locator_entry(f"search {label}", entries, "field"))
                    break
    if loc is None:
        l, h = _find_search_input(page)
        if l is not None and _pick_editable(l) is not None:
            loc, how, match = _pick_editable(l), h, (cands[0] if cands else None)
    if loc is None:                                          # the only visible text input on a listing is its search box
        only = []
        for fr in _frames(page):
            try:
                inp = fr.locator("input:not([type=radio]):not([type=checkbox]):not([type=hidden]):not([type=button]):"
                                 "not([type=submit]):not([type=file])")
                only += [inp.nth(k) for k in range(min(inp.count(), 8)) if inp.nth(k).is_visible()]
            except Exception:
                continue
        if len(only) == 1:
            loc, how, match = only[0], "the only visible text input on the page", (cands[0] if cands else None)
    if loc is None:
        inv = []
        for fr in _frames(page):
            try:
                inv += [f"<{c['tag']}> id='{c['id']}' label='{c['label']}' placeholder='{c['placeholder']}'"
                        for c in fr.evaluate(_LIST_CONTROLS_JS)][:10]
            except Exception:
                continue
        raise RuntimeError(f"could not find an editable search box on this page (looked for a text input labelled 'Search "
                           f"{label}' / '{label}' / 'Search'); the page has: {inv}".replace("'Search ' / '' / ", ""))
    loc.fill(value, timeout=4000)
    btn, bhow, _n_btn = _resolve_button(page, "Search", entries)
    bmatch = _match_locator_entry("search button", entries, "button") or next(
        ((a, v) for a, v in entries if a.lower().startswith("search") and any(h in a.lower() for h in ("button", "btn"))), None)
    if btn is not None:
        _robust_click(page, btn)
    else:
        loc.press("Enter")
        bhow = "pressed Enter (no Search button found)"
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    rows, n = _find_row(page, value)
    if not n:
        raise RuntimeError(f"searched for '{value}' but no row shows it - the record does not exist on this listing "
                           f"(was Add really saved? is it filtered by status?)")
    return {"value": value, "input_loc": loc, "input_how": how, "input_match": match, "button_loc": btn,
            "button_how": bhow, "button_match": bmatch, "notes": f"{n} row(s) show it"}


def _snackbar_text(page) -> str:
    for fr in _frames(page):
        try:
            t = fr.locator(_SNACK_SEL)
            if t.count() and t.first.is_visible():
                return re.sub(r"\s+", " ", t.first.inner_text()).strip()[:160]
        except Exception:
            continue
    return ""


_SAVE_ERR_RE = re.compile(r"already|exist|overlap|duplicate|invalid|error|fail|cannot|can not|not allowed|conflict|mandatory|"
                          r"required|must|unable|not valid|out of range|within", re.I)


def _save_outcome(page) -> tuple[str, str]:
    """After the final click of Add: ('saved' | 'error' | 'unknown', the message the portal showed)."""
    errs: list[str] = []
    for fr in _frames(page):
        try:
            errs += [e.strip() for e in fr.locator("mat-error").all_text_contents() if e.strip()][:5]
        except Exception:
            pass
    msg = _snackbar_text(page)
    if errs:
        return "error", "; ".join(dict.fromkeys(errs))[:200]
    if msg:
        if _SAVE_ERR_RE.search(msg) and not re.search(r"success|saved|created|sent for approval|approval", msg, re.I):
            return "error", msg
        if _SAVE_ERR_RE.search(msg) and re.search(r"already|overlap|duplicate|invalid|fail|cannot", msg, re.I):
            return "error", msg
        return "saved", msg
    return "unknown", ""


def _regenerate_identifier_and_ranges(page, typed: dict, entries: list[tuple[str, str]], log=print) -> dict:
    """The portal rejected the record (BIN already exists / range overlaps ...): put a DIFFERENT Luhn-valid BIN into the BIN
    field and rebuild the low / high range from it (same lengths as before), so the BIN stays inside [low, high]."""
    id_col = detect_identifier_column(list(typed))
    if not id_col:
        raise RuntimeError("no identifying field was typed, so there is nothing to regenerate")
    old_len = len(str(typed[id_col]))
    new_id = luhn_number(old_len) if is_luhn_column(id_col) and os.environ.get("AI_LUHN_BIN", "1").strip() != "0" \
        else (__import__("random").choice("123456789") + "".join(__import__("random").choices("0123456789", k=old_len - 1)))
    new_vals = {id_col: new_id}
    for col, old in list(typed.items()):
        kind = range_kind(col, id_col)
        if kind:
            total = max(len(str(old)), len(new_id))
            new_vals[col] = new_id + ("0" if kind == "low" else "9") * (total - len(new_id))
    for col, value in new_vals.items():
        loc, how = _resolve_field(page, col, entries)
        if loc is None:
            raise RuntimeError(f"could not find the '{col}' field again to type the new value ({how})")
        _apply_value(page, loc, value)
        typed[col] = value
    return new_vals


def _execute_scenario_steps(page, scenario: str, entries: list[tuple[str, str]],
                            testdata_values: dict[str, str] | None, log=print,
                            screenshot_path: Path | None = None, action: str = "add",
                            identifier: dict | None = None, commit_final: bool = False) -> dict:
    """Core executor (login/navigation are done by the caller). Walks the scenario's own
    clauses in order from the first fill/select/check step; resolves every field against
    locators.py (falling back to the live page's labels); performs the real interaction
    with the value written in the scenario (or a generated random one when the step asks for
    it); self-heals generated locators that did not work; and STOPS at the first finalizing
    click (Save/Submit/Send/Delete/...) after confirming that button resolves - never clicking it."""
    testdata_values = testdata_values or {}
    results: list[dict] = []
    stopped_at = None
    status_map: dict[str, str] = {}
    heals: dict[str, tuple[str, str, str]] = {}
    typed: dict[str, str] = {}              # what the Add dry run typed per field (the identifier is picked from it)
    committed = False
    messages: list[str] = []

    def td_lookup(field: str) -> str | None:
        want = _norm_tokens(field)
        for col, v in testdata_values.items():
            if v and v.strip() and _norm_tokens(col) == want:
                return v
        return None

    def record(i, text, status, detail):
        results.append({"n": i, "step": text, "status": status, "detail": detail})
        log(f"    [scenario-run] step {i}: {text}  ->  {status}" + (f"  ({detail})" if detail else ""))

    def note_locator(matched, loc, how, final=False):
        """Bookkeeping for the confidence report + auto-heal. A locator that works but is
        FRAGILE (Angular auto id like mat-input-5, positional nth-of-type chain, #TODO
        placeholder) is also replaced when a strictly better stable selector exists."""
        if not matched or "[iframe" in how:
            return          # generated page code uses page.locator() - a selector valid only inside an iframe must not be written back
        attr, old = matched
        if how.startswith("locators.py"):
            if _is_fragile_selector(old):
                sel, kind = _stable_selector(loc)
                if sel and kind == "attr" and sel != old and not _is_fragile_selector(sel):
                    heals[attr] = (old, sel, kind)
                    status_map[attr] = "HEALED_attr"
                    return
            status_map[attr] = "FINAL_FOUND" if final else "OK"
            return
        sel, kind = _stable_selector(loc)
        if sel:
            heals[attr] = (old, sel, kind)
            status_map[attr] = "HEALED_attr" if kind == "attr" else "HEALED_path"
        else:
            status_map[attr] = "FAILED"

    clauses = _split_scenario_clauses(scenario)
    # Several finalizing clicks ("click approve" on the details page, then "click approve in the confirmation dialog"): when the LAST
    # one is in a dialog / popup, the earlier ones only OPEN that dialog - they are executed; only the dialog's button is final.
    _fin_idx = []
    for _k, _c in enumerate(clauses, 1):
        _c2 = _CTX_PREFIX_RE.sub("", _c).strip() or _c
        _m = _CLICK_RE.match(_c2)
        if _m:
            _t = re.split(r"\s+(?:in|under|inside)\s+the\s+", _m.group("target"))[0].strip().strip("\"'")
            if _FINALIZE_CLICK_RE.search(_t) and not _row_action_of(_t, _c2):
                _fin_idx.append(_k)
    intermediate_finals: set[int] = set()
    if len(_fin_idx) > 1 and re.search(r"dialog|popup|pop-up|modal|confirmation", clauses[_fin_idx[-1] - 1], re.I):
        intermediate_finals = set(_fin_idx[:-1])
    started = False
    dumped = False
    pending_spec = None          # text of a preceding "generate a random 6 digit number" step
    for i, clause in enumerate(clauses, 1):
        if _CTX_ONLY_RE.match(clause):
            continue                                  # "On the details page" - where we are, not something to do
        clause = _CTX_PREFIX_RE.sub("", clause).strip() or clause      # "in the confirmation dialog click X" -> "click X"
        if _ASSERT_RE.match(clause):
            if started:
                record(i, clause[:70], "NOT RUN", "assertion - only verified by a real submit")
            continue
        m_leave, m_fill, m_fillin, m_sel, m_chk, m_click, m_gen = (r.match(clause) for r in
            (_LEAVE_RE, _FILL_RE, _FILL_IN_RE, _SELECT_RE, _CHECK_RE, _CLICK_RE, _GEN_ONLY_RE))
        m_fill = m_fill or m_fillin
        if m_gen and (m_fill or m_sel or m_chk or m_click or m_leave):
            m_gen = None
        m_search = _SEARCH_RE.match(clause) if not (m_fill or m_sel or m_chk or m_click or m_leave or m_gen) else None
        row_action = None
        if m_click:
            _tn = re.split(r"\s+(?:in|under|inside)\s+the\s+", m_click.group("target"))[0].strip().strip("\"'")
            row_action = _row_action_of(_tn, clause)
        is_field_step = bool(m_leave or m_fill or m_sel or m_chk or m_search or row_action)
        looks_like_field_intent = bool(_INTENT_ALWAYS_RE.match(clause) or
                                       (started and _INTENT_AFTER_START_RE.match(clause)))
        if not started:
            if not is_field_step and not looks_like_field_intent and \
                    not (m_click and _FINALIZE_CLICK_RE.search(m_click.group("target"))):
                continue                      # navigation clause - handled by the caller already
            started = True
            _wait_for_form(page, log)
        try:
            if m_gen:
                pending_spec = m_gen.group("spec")
                record(i, clause[:70], "OK", "will generate the value when the next field is filled with 'it'")
            elif m_search:
                res = _do_search(page, m_search.group("rest"), identifier, entries)
                note_locator(res["input_match"], res["input_loc"], res["input_how"])
                note_locator(res["button_match"], res["button_loc"], res["button_how"]) if res["button_loc"] is not None else None
                record(i, f"search for '{res['value']}'", "OK",
                       f"typed via {res['input_how']}; searched via {res['button_how']}; {res['notes']}")
            elif m_leave:
                loc, how = _resolve_field(page, m_leave.group("field"), entries)
                record(i, f"leave '{m_leave.group('field')}' blank",
                       "OK" if loc is not None else "FAILED", how)
            elif m_fill or m_sel:
                m = m_fill or m_sel
                verb = "fill" if m_fill else "select"
                field = _clean_field_name(m.group("field"))
                val, explicit = _clean_value(m.group("val"))
                loc, how = _resolve_field(page, field, entries)
                if loc is None:
                    matched = _match_locator_entry(field, entries, "field")
                    record(i, f"{verb} '{field}'", "FAILED", how)
                    if matched:
                        status_map[matched[0]] = "FAILED"
                    if not dumped:
                        dumped = True
                        _dump_visible_fields(page, field, (screenshot_path.with_suffix("") if screenshot_path else None), log)
                    continue
                tag_, type_ = _control_kind(loc)
                is_choice = (tag_ == "input" and type_ in ("radio", "checkbox"))
                matched = _match_locator_entry(f"{field} {val}", entries) if (is_choice and val) \
                    else (None if is_choice else _match_locator_entry(field, entries, "field"))
                gen_note = ""
                if not explicit and identifier and action != "add" and \
                        (_norm_tokens(field) & _norm_tokens(identifier.get("label", ""))):
                    val, explicit = identifier["value"], True                  # "that BIN" = the one Add created
                    gen_note = f"the {identifier['label']} created by Add"
                # ---- BIN ranges are GENERATED FROM the BIN: low = BIN + zeros, high = BIN + nines ----
                if os.environ.get("AI_AUTO_RANGES", "1").strip() != "0":
                    id_ctx = identifier if (identifier and action != "add") else None
                    if action == "add" and typed:
                        _c = detect_identifier_column(list(typed))
                        id_ctx = {"label": _c, "value": typed[_c]} if _c else None
                    rk = range_kind(field, id_ctx["label"]) if id_ctx else None
                    if rk and (not explicit or re.fullmatch(r"\d+", val or "")):
                        _ml = loc.first.get_attribute("maxlength") or ""
                        n_len = min(int(_ml), range_length()) if _ml.isdigit() and int(_ml) > 0 else range_length()
                        n_len = max(n_len, len(id_ctx["value"]))
                        val = id_ctx["value"] + ("0" if rk == "low" else "9") * (n_len - len(id_ctx["value"]))
                        explicit = True
                        gen_note = f"{rk} range built from the {id_ctx['label']} {id_ctx['value']}"
                if not explicit:
                    wants_random = bool(_RANDOM_HINT_RE.search(clause)) or pending_spec is not None
                    val = None if wants_random else td_lookup(field)
                    if val and _looks_like_placeholder(val):
                        val = None
                    if not val:
                        val, gen_note = _generate_value(loc, field, f"{pending_spec or ''} {clause}")
                    pending_spec = None
                if tag_ == "input" and type_ in ("number", "tel") and not re.fullmatch(r"-?\d+([.,]\d+)?", val or ""):
                    bad_val = val
                    val, gen_note = _generate_value(loc, field, clause)
                    gen_note = f"'{bad_val}' is not numeric but the field is type={type_} -> {gen_note}"
                picked: dict = {}

                def heal_even_though_failed(m_attr, m_loc, m_how):
                    """The element WAS found (by its label), only the interaction failed (state/timing): still fix the
                    generated locator, and never report this field as 'not mentioned in the scenario'."""
                    if not m_attr:
                        return
                    note_locator(m_attr, m_loc, m_how)
                    if status_map.get(m_attr[0]) in ("OK", "FINAL_FOUND"):
                        status_map[m_attr[0]] = "FAILED"

                try:
                    detail = _apply_value(page, loc, val, picked)
                except Exception as first_exc:
                    if not how.startswith("locators.py"):
                        heal_even_though_failed(matched, loc, how)
                        raise
                    loc2, how2 = _resolve_field(page, field, entries, skip_entries=True)
                    if loc2 is None:
                        heal_even_though_failed(matched, loc, how)
                        raise
                    try:
                        detail = _apply_value(page, loc2, val, picked)
                    except Exception:
                        heal_even_though_failed(matched, loc2, how2)
                        raise
                    loc = loc2
                    how = how2 + (f" [generated locator '{matched[0]}' resolved but could not be used: "
                                  f"{str(first_exc).splitlines()[0][:90]}]" if matched else "")
                note_locator(matched, picked.get("loc", loc), how)
                if action == "add":
                    typed[field] = val
                status = "WARNING" if detail.startswith("WARN") else "OK"
                record(i, f"{verb} '{field}' = '{val}'", status,
                       f"{detail}{'; ' + gen_note if gen_note else ''}; via {how}")
            elif m_chk:
                field = m_chk.group("field").strip().strip("\"'")
                matched = _match_locator_entry(field, entries)
                loc, how = _resolve_field(page, field, entries)
                if loc is None:
                    record(i, f"{m_chk.group('verb')} '{field}'", "FAILED", how)
                    if matched:
                        status_map[matched[0]] = "FAILED"
                    continue
                if m_chk.group("verb").lower().startswith(("un",)):
                    loc.uncheck(timeout=3000)
                else:
                    loc.check(timeout=3000)
                note_locator(matched, loc, how)
                record(i, f"{m_chk.group('verb')} '{field}'", "OK", f"via {how}")
            elif m_click:
                target_name = re.split(r"\s+(?:in|under|inside)\s+the\s+", m_click.group("target"))[0]
                target_name = target_name.strip().strip("\"'").strip()
                m_cut = re.match(r"^(.*?\b(?:button|btn|link|icon|tab))\b\s+(?!\()\S.*$", target_name, re.I)
                if m_cut and not row_action:                     # "approve button request details page" = the Approve button (on that page)
                    target_name = m_cut.group(1).strip().strip("\"'").strip()
                target_name = re.sub(r"\s+(?:button|link|icon|tab|sub-?menu|menu)$", "", target_name, flags=re.I)
                if row_action:
                    ident_value = (re.search(r'"([^"]+)"', clause) or [None, (identifier or {}).get("value")])[1]
                    if not ident_value:
                        raise RuntimeError("no record to act on: Add did not hand over an identifier (Add must run first "
                                           "and be saved - AI_DRYRUN_COMMIT_ADD=1)")
                    el, how_row = _click_row_action(page, row_action, ident_value,
                                                    prefer_last=bool(re.search(r"end of|last", clause, re.I)))
                    m_act = _match_locator_entry(f"{row_action} button", entries, "button") or _match_locator_entry(row_action, entries, "button")
                    if m_act:
                        if "{value}" in m_act[1] or row_action == "expand":      # a row-scoped locator: a TEMPLATE with the record's {value}
                            tmpl = _row_icon_template(el)
                            cur = m_act[1]
                            if tmpl and (cur.startswith("#TODO") or "{value}" not in cur or not _template_resolves(page, cur, ident_value)):
                                heals[m_act[0]] = (cur, tmpl, "template")
                                status_map[m_act[0]] = "HEALED_attr"
                            elif tmpl:
                                status_map.setdefault(m_act[0], "OK")
                        else:
                            sel_, kind_ = _stable_selector(el)
                            if sel_ and kind_ == "attr":
                                if m_act[1].startswith("#TODO") or _is_fragile_selector(m_act[1]):
                                    heals[m_act[0]] = (m_act[1], sel_, kind_)
                                    status_map[m_act[0]] = "HEALED_attr"
                                else:
                                    status_map.setdefault(m_act[0], "OK")
                    record(i, f"click the {row_action} icon in the row of '{ident_value}'", "OK", f"via {how_row}")
                    continue
                matched = _match_locator_entry(target_name, entries, "button")
                loc, how, n = None, "", 0
                if re.search(r"dialog|popup|pop-up|modal|confirmation", clause, re.I):
                    loc = _resolve_button_in_dialog(page, target_name)          # not the same-named button of the page behind it
                    how, n = ("inside the dialog", 1) if loc is not None else ("", 0)
                if loc is None:
                    loc, how, n = _resolve_button(page, target_name, entries)
                if _FINALIZE_CLICK_RE.search(target_name) and i not in intermediate_finals:
                    stopped_at = target_name
                    if loc is None:
                        record(i, f"final click '{target_name}'", "FAILED", "final button NOT found on the page")
                        if matched:
                            status_map[matched[0]] = "FAILED"
                    elif commit_final and is_commit_action(action):
                        note_locator(matched, loc, how, final=True)
                        max_tries = max(int(os.environ.get("AI_ADD_RETRIES", "5") or 5), 1) if action == "add" else 1
                        attempt = 1
                        btn_loc = loc
                        while True:
                            how_click = _robust_click(page, btn_loc, timeout=5000)
                            try:
                                page.wait_for_load_state("networkidle", timeout=10000)
                            except Exception:
                                pass
                            page.wait_for_timeout(700)
                            state, msg = _save_outcome(page)
                            if msg:
                                messages.append(msg)
                            if state != "error":
                                committed = True
                                record(i, f"final click '{target_name}'" + (f" (attempt {attempt})" if attempt > 1 else ""), "OK",
                                       f"{'SAVED the record' if action == 'add' else 'DONE for real'} ({how_click}); "
                                       f"the page says: {msg or '(no message shown)'}")
                                break
                            if attempt >= max_tries:
                                record(i, f"final click '{target_name}' (attempt {attempt})", "FAILED",
                                       f"still rejected after {attempt} different BIN / range combinations - last message: {msg}")
                                break
                            try:
                                before = {k: typed[k] for k in typed}
                                new_vals = _regenerate_identifier_and_ranges(page, typed, entries)
                            except Exception as exc:
                                record(i, f"final click '{target_name}' (attempt {attempt})", "FAILED",
                                       f"rejected ('{msg}') and a new BIN / range could not be entered: {str(exc)[:150]}")
                                break
                            record(i, f"final click '{target_name}' (attempt {attempt})", "WARNING",
                                   f"REJECTED: '{msg}' -> trying again with a different "
                                   + ", ".join(f"{k}={v}" for k, v in new_vals.items()))
                            attempt += 1
                            nb, nh, _nn = _resolve_button(page, target_name, entries)
                            if nb is None:
                                record(i, f"final click '{target_name}'", "FAILED", "the final button disappeared after the error")
                                break
                            btn_loc = nb
                    else:
                        note_locator(matched, loc, how, final=True)
                        extra = "" if matched else (
                            "; NOTE: locators.py has no locator for this button" +
                            (f" - suggested: \"{_stable_selector(loc)[0]}\"" if _stable_selector(loc)[0] else ""))
                        record(i, f"final click '{target_name}'", "STOPPED",
                               f"button found via {how}" + (f", {n} matches" if n > 1 else "") +
                               " - deliberately NOT clicked (dry run)" + extra)
                    break
                if loc is None:
                    record(i, f"click '{target_name}'", "FAILED", "element not found")
                    continue
                loc.click(timeout=5000)
                try:
                    page.wait_for_load_state("networkidle", timeout=8000)
                except Exception:
                    pass
                note_locator(matched, loc, how)
                record(i, f"click '{target_name}'", "OK", f"via {how}")
            else:
                record(i, clause[:70], "SKIPPED",
                       "wording not understood - write it as: fill <field> with \"<value>\"  /  "
                       "select <field> as \"<value>\"  /  enter a random 6 digit number in <field> field")
        except Exception as exc:
            record(i, clause[:70], "FAILED", " ".join(str(exc).strip().splitlines()[:2])[:330])

    if started:
        # Heal leftover '#TODO' placeholders of ordinary form fields (not radios/buttons) whose
        # label can be found on this form by name, e.g. card_product_dropdown -> label 'Card product'.
        swept = 0
        for attr, old_val in entries:
            _first = attr.lower().split("_")[0]
            _other_action = _first in ("view", "edit", "delete", "status", "search", "changestatus") and _first != action.lower()
            if action == "add":
                _in_scope = _is_form_field_attr(attr) and not _other_action          # edit_country_dropdown is NOT the Add form's
            else:
                _in_scope = _first == action.lower() and bool(
                    {"field", "input", "dropdown", "select", "radio", "checkbox", "date"} & set(attr.lower().split("_")))
            if attr in status_map or not old_val.startswith("#TODO") or not _in_scope:
                continue
            toks = [t for t in attr.lower().split("_") if t and t not in _FIELD_TOKENS and t != action.lower()]
            if not toks or "checkbox" in attr.lower():
                continue
            try:
                if "radio" in attr.lower():
                    # e.g. bin_status_inactive_radio -> group label 'bin status', option 'inactive'
                    if len(toks) < 2:
                        continue
                    grp, _k = _resolve_field(page, " ".join(toks[:-1]), [])
                    if grp is None or _control_kind(grp) != ("input", "radio"):
                        continue
                    if grp.first.evaluate(_PICK_RADIO_JS, toks[-1]) is not True:
                        continue
                    loc = None
                    for fr in _frames(page):
                        cand = fr.locator("[data-dryrun-radio='1']")
                        if cand.count() == 1:
                            loc = cand
                            break
                    if loc is None:
                        continue
                    toks = toks[:-1] + [toks[-1]]
                else:
                    loc, how = _resolve_field(page, " ".join(toks), [])
                if loc is None:
                    continue
                sel, kind = _stable_selector(loc)
                if sel:
                    heals[attr] = (old_val, sel, kind)
                    status_map[attr] = "HEALED_attr" if kind == "attr" else "HEALED_path"
                    swept += 1
                    log(f"    [scenario-run] placeholder '{attr}' not used by the scenario but its label "
                        f"'{' '.join(toks)}' is on the form -> found {sel}")
            except Exception:
                continue
        if swept:
            log(f"    [scenario-run] healed {swept} extra placeholder locator(s) by label")

    facts = _collect_field_facts(page) if started else []
    if screenshot_path is not None:
        try:
            screenshot_path.parent.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(screenshot_path), full_page=True)
            log(f"    [scenario-run] screenshot of the form as filled: {screenshot_path}")
        except Exception:
            pass
    if action == "add" and typed:
        _id_c = detect_identifier_column(list(typed))
        if _id_c:
            for _rc, _rv in typed.items():
                _k = range_kind(_rc, _id_c)
                if _k:
                    ok_ = str(_rv).startswith(str(typed[_id_c]))
                    record(len(clauses) + 1, f"range check: '{_rc}' ({_rv}) must START WITH the {_id_c} ({typed[_id_c]})",
                           "OK" if ok_ else "WARNING",
                           f"the {_id_c} is inside the {_k} range" if ok_ else
                           f"this {_k} range does NOT contain the {_id_c} - the portal may reject it")
    ident_out = None
    if typed:
        col_ = detect_identifier_column(list(typed))
        if col_:
            ident_out = {"label": col_, "value": typed[col_]}
    return {"steps": results, "field_facts": facts, "identifier": ident_out, "committed": committed,
            "messages": messages, "stopped_at": stopped_at, "locator_status": status_map, "heals": heals,
            "failed": sum(1 for r in results if r["status"] == "FAILED"),
            "warned": sum(1 for r in results if r["status"] == "WARNING"),
            "skipped": sum(1 for r in results if r["status"] == "SKIPPED"),
            "ok": sum(1 for r in results if r["status"] == "OK")}


def dry_run_scenario_execution(repo_root: Path, bank: str, portal_type: str, module: str,
                               action: str, scenario: str,
                               testdata_values: dict[str, str] | None = None,
                               identifier: dict | None = None, commit_final: bool = False) -> dict:
    """FEATURE: scenario-driven dry run. Logs in with the real framework login, navigates
    exactly like the scenario says, then performs the scenario's own steps in order with
    the scenario's own values, and stops BEFORE the finalizing click. Result is printed
    step by step and saved to reports/<module>_<action>_dryrun.txt."""
    summary = {"steps": [], "stopped_at": None, "failed": 0, "warned": 0, "ok": 0, "skipped": 0,
               "error": None, "locator_status": {}, "heals": {}}
    if not (scenario or "").strip():
        print(f"  [scenario-run] '{action}': no scenario text (DOM/FILE/SCREENSHOT mode) - nothing to execute.")
        return summary
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        summary["error"] = "playwright not installed"
        return summary
    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]

    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    entries: list[tuple[str, str]] = []
    if locators_path.exists():
        # '#TODO' placeholders are KEPT: they are precisely the locators that need healing, and
        # without them in this list a step like "select Card type" has no locators.py attribute
        # to attach the healed selector to.
        entries = [(a, v) for _, a, v in LOCATOR_LINE_RE.findall(locators_path.read_text(encoding="utf-8"))]

    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text, count=1, flags=re.MULTILINE)
        if n:
            config_path.write_text(new_text, encoding="utf-8")
    print(f"\n  [scenario-run] === {bank}/{module}/{action}: executing the scenario for real (stops before Save/Submit) ===")
    try:
        import sys as _sys
        if str(repo_root) not in _sys.path:
            _sys.path.insert(0, str(repo_root))
        login_module = __import__(f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
        LoginPageClass = getattr(login_module, class_name)
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            page.on("dialog", lambda d: (print(f"    [scenario-run] browser dialog dismissed: {d.message[:100]}"), d.dismiss()))
            print(f"  [scenario-run] logging in as {bank} ...")
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"  [scenario-run] logged in")
            clicked, _h, _x = navigate_via_scenario_text(page, scenario)
            print(f"  [scenario-run] navigated through: {' -> '.join(clicked) if clicked else '(nothing clicked)'}")
            if not clicked:
                _nav_diagnostics(page, scenario, repo_root / "ai_debug_dom" / f"{bank}_{module}_{action}_nav_stopped.png")
            if len(page.context.pages) > 1:
                page = page.context.pages[-1]
                print(f"  [scenario-run] a new tab/window opened - continuing in it ({page.url[-60:]})")
            shot = repo_root / "ai_debug_dom" / f"{bank}_{module}_{action}_before_submit.png"
            summary.update(_execute_scenario_steps(page, scenario, entries, testdata_values, screenshot_path=shot,
                                                   action=action, identifier=identifier, commit_final=commit_final))
            try:
                attempt_logout(page)
            except Exception:
                pass
            browser.close()
    except Exception as exc:
        _log_exception(f"scenario dry-run {bank}/{module}/{action}", exc)
        summary["error"] = str(exc)
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    if summary.get("heals") and os.environ.get("AI_DRYRUN_AUTOHEAL", "1") != "0":
        try:
            summary["healed_count"] = _apply_locator_heals(repo_root, bank, module, summary["heals"])
        except Exception as exc:
            _log_exception("applying locator heals", exc)
    print(f"  [scenario-run] '{action}' finished: {summary['ok']} OK, {summary['warned']} warning(s), "
          f"{summary.get('skipped', 0)} skipped, {summary['failed']} FAILED" + (f", stopped before '{summary['stopped_at']}'" if summary["stopped_at"] else
          " (no finalizing click found in scenario)"))
    try:
        rep = repo_root / "reports"
        rep.mkdir(exist_ok=True)
        lines = [f"Scenario dry run - {bank}/{module}/{action}", f"Scenario: {scenario}", ""]
        lines += [f"step {r['n']}: {r['step']} -> {r['status']} {r['detail']}" for r in summary["steps"]]
        if summary["error"]:
            lines.append(f"\nRUN ERROR: {summary['error']}")
        (rep / f"{module}_{action}_dryrun.txt").write_text("\n".join(lines), encoding="utf-8")
    except Exception:
        pass
    return summary


# ======================================================================
# NEGATIVE-CASE SUITE (separate class files: negative locators + page + test + sheet)
# ======================================================================
NEGATIVE_STYLE_NOTES = """\
HOUSE STYLE for negative cases in this framework (taken from the team's own hand-written files):
LOCATORS
- Label-anchored Playwright selectors, never auto-generated ids (mat-input-5, mat-select-7, cdk-*):
    field input    -> ".mat-mdc-form-field:has-text('<Label>') input"
    field dropdown -> ".mat-mdc-form-field:has-text('<Label>') mat-select"
    dropdown option-> "//mat-option[contains(normalize-space(.), '{value}')]"   (ONE shared template: option_by_text, used with
                       .format(value=data["<Column>"]) - never an XPath written inside the page method)
    radio          -> "mat-radio-button:has-text('<Option>')"
    button         -> "button:has-text('<Text>')"
- Error / message locators used by negatives:
    field-level error   -> ".mat-mdc-form-field:has-text('<Label>') mat-error"
    any validation error-> "//mat-error"
    toast / snackbar    -> "//div[contains(@class,'snackbar')]//mat-label"
    the expected text itself comes from the testdata column: the LOCATORS class holds the template
      error_message_by_text = "//mat-error[contains(normalize-space(.), '{value}')]"
    and the PAGE uses  loc.error_message_by_text.format(value=data["ExpectedMessage"])  - no selector string inside a page method.
PAGE
- Negative flows are separate methods (<action>_negative), data-driven: fill every field with the valid
  baseline value EXCEPT the one under test, apply the bad value from the row, click the final button,
  assert the message with the SAME assert helper the positive page already uses.
- Call only helper methods that really exist (listed below). Never invent one.
TESTDATA
- The FIRST FIVE columns are always, in this order: ScenarioID,TestcaseID,Description,ExpectedMessage,Priority
  (the framework builds pytest ids from ScenarioID - TestcaseID - Description and checks id uniqueness), then one
  column per form field (same names as the positive sheet), then NegativeType (and ExpectedMessage1 only when a
  second message is checked). ScenarioID and TestcaseID are never empty and never repeated.
- A row changes exactly ONE thing away from the valid baseline.
RUN-TIME TOKENS (never write a literal identifying number): a negative row that needs a value of a given length writes
  {{FRESH:<n>}} (n random digits) or {{FRESH:<n>:alpha}} (n random letters); a duplicate-record row writes {{FROM_ADD}}
  (the value the Add test generated). Every test calls RuntimeData.resolve(...) first - the framework adds that line.
COVERAGE: EVERY field of the form gets its own negative rows (blank / not selected, too long, too short, letters in a
  numeric field, special characters, only spaces, duplicate identifier, low > high for range pairs) - keep all the
  MANDATORY rows you are given and add business-rule rows on top of them.
TEST METHODS (one straight chain, exactly like the positive tests / reference sample_test.py)
    @pytest.mark.regression
    @pytest.mark.parametrize("data", _rows_Negative,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows_Negative])
    def test_<module>_negative(self, page, data):
        login_page = BankLoginPage(page)
        login_page.login(BANK_NAME)
        negative_page = <PageClass>Negative(page)
        negative_page.navigate_to_<module>(BANK_NAME)      # the SAME navigation call the positive test uses
        negative_page.<action>_negative(BANK_NAME, data)   # fills, clicks, asserts ExpectedMessage inside
  Use the module-level _rows_Negative (loaded once at the top of the file), never load the sheet inside the method.
- ExpectedMessage: write the real text ONLY if it was observed/given. Otherwise write exactly
  TBD-verify-message - never invent message wording.
"""

NEGATIVE_SYSTEM_PROMPT = """You generate the NEGATIVE-CASE layer for ONE module of an existing
Playwright + Python framework, as SEPARATE class files that extend the already-working positive ones.
Reply with exactly four blocks and nothing else, each starting with a line '### FILE: <path>':
  1. src/banks/<bank>/locators/<module>_negative_locators.py
       class <ParentLocatorsClass>Negative(<ParentLocatorsClass>)  - imports and INHERITS the existing
       locators class (so every form field/button locator is reused, never duplicated) and adds ONLY the
       extra locators negatives need (error/validation/message locators, per-field error locators).
  2. src/common/pages/<module>/<module>_negative_page.py
       class <ParentPageClass>Negative(<ParentPageClass>)  - imports and INHERITS the existing page class;
       adds ONLY negative methods, written in the same style/helpers as the parent's positive methods.
  3. src/testcase/<module>/test_<module>_negative.py
       mirrors the existing positive test file EXACTLY (imports, BANK_NAME = ConfigManager.get("bank"), the login call,
       ONE test class named Test<ModuleTitle>NegativeModule, each test one straight chain login -> page -> navigate ->
       action, @pytest.mark.parametrize("data", _rows_Negative, ids=[ScenarioID - TestcaseID - Description ...])), loading
       the sheet ONCE at module level: _rows_Negative = ExcelUtil.get_sheet("<ModuleTitle>", "Negative"); it calls the
       negative page methods.
  4. <module>_testdata_negative.csv   (the 'Negative' sheet; its FIRST FIVE columns are
       ScenarioID,TestcaseID,Description,ExpectedMessage,Priority, then the field columns, then NegativeType)
  5. ONLY when the prompt asks for Edit negatives: <module>_testdata_negativeedit.csv (the 'NegativeEdit' sheet, same columns)
Hard rules: valid Python; only src.* imports that exist; use only page helper methods that really exist;
derive negative cases ONLY from the facts given (field required/maxlength/type, scenario text, baseline row);
do not invent features the form does not have. Follow the HOUSE STYLE notes you are given."""


def _read_text(p) -> str:
    try:
        return Path(p).read_text(encoding="utf-8", errors="ignore") if p else ""
    except Exception:
        return ""


def _clip(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[:limit] + "\n# ... (truncated for length) ..."


_FIELD_FACTS_JS = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const norm = s => (s || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  return [...document.querySelectorAll('input,select,textarea,mat-select,[role=combobox]')]
    .filter(e => e.type !== 'hidden' && vis(e)).slice(0, 80).map(e => {
      let label = '';
      const ff = e.closest('mat-form-field,.mat-mdc-form-field');
      if (ff) { const ml = ff.querySelector('mat-label,label'); if (ml) label = norm(ml.innerText); }
      if (!label && e.id) { const l = document.querySelector('label[for="' + e.id + '"]'); if (l) label = norm(l.innerText); }
      if (!label) { const l = e.closest('label'); if (l) label = norm(l.innerText); }
      if (!label) { const cell = e.closest('td,th,div'); const prev = cell && cell.previousElementSibling; if (prev) label = norm(prev.innerText); }
      const tag = e.tagName.toLowerCase();
      const o = {label: label, tag: tag, type: (e.getAttribute('type') || '').toLowerCase(),
                 required: !!(e.required || e.getAttribute('aria-required') === 'true' || /\*\s*$/.test(label)),
                 maxlength: e.getAttribute('maxlength') || '', minlength: e.getAttribute('minlength') || '',
                 pattern: e.getAttribute('pattern') || '', min: e.getAttribute('min') || '', max: e.getAttribute('max') || ''};
      if (tag === 'select') o.options = [...e.options].map(x => norm(x.text)).slice(0, 15);
      return o;
    });
}
"""


def _collect_field_facts(page) -> list[dict]:
    """Real constraints of every visible control on the form being exercised (label, type,
    required, maxlength...). Feeds the negative-suite generator so boundary cases use the
    page's ACTUAL limits instead of guesses."""
    facts: list[dict] = []
    for fr in _frames(page):
        try:
            facts.extend(fr.evaluate(_FIELD_FACTS_JS))
        except Exception:
            continue
    return [f for f in facts if f.get("label")]


def _format_field_facts(facts: list[dict]) -> str:
    if not facts:
        return "(no live field facts were captured - derive only from the scenario text and baseline row)"
    lines = []
    for f in facts:
        bits = [f"type={f['type'] or f['tag']}", "REQUIRED" if f.get("required") else "optional"]
        for k in ("maxlength", "minlength", "min", "max", "pattern"):
            if f.get(k):
                bits.append(f"{k}={f[k]}")
        if f.get("options"):
            bits.append(f"options={f['options']}")
        lines.append(f"- {f['label']}: " + ", ".join(bits))
    return "\n".join(lines)


def generate_negative_suite_separate(repo_root: Path, bank: str, module: str, scenario: str,
                            written: dict, field_facts: list[dict] | None = None, log=print) -> dict:
    """SECOND AI PASS (opt-in): writes the module's NEGATIVE cases as separate class files that
    inherit the positive ones - negative locators, negative page, negative test, and a
    'Negative' sheet in the module's workbook. Never touches the positive files."""
    out: dict = {}
    loc_path, page_path, test_path = written.get("locators"), written.get("page"), written.get("test")
    if not (loc_path and page_path and test_path):
        _missing = [k for k, v in (("locators", loc_path), ("page", page_path), ("test", test_path)) if not v]
        log(f"  [negative] skipped: the positive {', '.join(_missing)} file(s) were not written "
            f"(see the rejection message above) - fix that first, the negative suite extends them.")
        return out
    loc_src, page_src, test_src = _read_text(loc_path), _read_text(page_path), _read_text(test_path)
    loc_cls, page_cls = extract_class_name(loc_src), extract_class_name(page_src)
    if not (loc_cls and page_cls):
        log("  [negative] skipped: could not find the positive locators/page class names.")
        return out
    module_title = module[:1].upper() + module[1:]
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module_title}.xlsx"
    baseline = {}
    try:
        baseline = read_first_testdata_row(xlsx, sheet_name="Add") if xlsx.exists() else {}
    except Exception:
        baseline = {}
    base_methods = sorted(load_base_page_methods(repo_root))
    synth = _prepare_synth(repo_root, bank, module, baseline, field_facts, log)
    refs = ""
    for rp in [x.strip() for x in os.environ.get("AI_NEGATIVE_REFERENCE", "").split(",") if x.strip()]:
        txt = _read_text(rp)
        if txt:
            refs += f"\n--- team's own hand-written reference: {rp} ---\n{_clip(txt, 12000)}\n"

    loc_mod = f"src.banks.{bank}.locators.{module}_locators"
    page_mod = f"src.common.pages.{module}.{module}_page"
    user_prompt = (
        f"BANK: {bank}\nMODULE: {module}\n\nSCENARIO (positive flow already implemented):\n{scenario}\n\n"
        f"EXISTING POSITIVE LOCATORS - import with: from {loc_mod} import {loc_cls}\n"
        f"{_clip(loc_src, 12000)}\n\n"
        f"EXISTING POSITIVE PAGE - import with: from {page_mod} import {page_cls}\n"
        f"{_clip(page_src, 18000)}\n\n"
        f"EXISTING POSITIVE TEST (mirror its structure exactly):\n{_clip(test_src, 12000)}\n\n"
        f"REAL base page helper methods you may call: {base_methods}\n\n"
        f"VALID BASELINE ROW (first row of the Add sheet): {baseline}\n\n"
        f"LIVE FORM FACTS (real constraints captured from the page):\n{_format_field_facts(_split_facts(field_facts)[0])}\n\n"
        f"MANDATORY NEGATIVE ROWS (derived per field from the real form constraints and from the positive sheets) - keep EVERY one of them in the Negative sheet with the SAME Description, values and tokens, then ADD more rows for business rules and cross-field rules:\n{_seed_text(module)}\n\n"
        f"{NEGATIVE_STYLE_NOTES}\n{refs}\n"
        f"{_edit_negative_prompt(module, module_title)}"
        f"Names to use: locators class {loc_cls}Negative in src/banks/{bank}/locators/{module}_negative_locators.py; "
        f"page class {page_cls}Negative in src/common/pages/{module}/{module}_negative_page.py; "
        f"test file src/testcase/{module}/test_{module}_negative.py; CSV file {module}_testdata_negative.csv."
    )
    dest_map = {
        "locators": repo_root / "src" / "banks" / bank / "locators" / f"{module}_negative_locators.py",
        "page": repo_root / "src" / "common" / "pages" / module / f"{module}_negative_page.py",
        "test": repo_root / "src" / "testcase" / module / f"test_{module}_negative.py",
    }
    parent_of = {"locators": loc_cls, "page": page_cls}
    parent_loc_names = set(re.findall(r"^\s+(\w+)\s*=", loc_src, re.M)) | set(re.findall(r"def (\w+)\(", loc_src))
    parent_page_methods = set(re.findall(r"def (\w+)\(", page_src))

    extra_csvs: dict[str, str] = {}               # 'NegativeEdit' -> csv text (Edit negatives), filled by _evaluate

    def _evaluate(reply_text: str):
        """Parses one AI reply and runs every DETERMINISTIC check. Returns
        (chosen {kind: code}, csv_text, problems [str])."""
        chosen: dict[str, str] = {}
        csv_text = None
        problems: list[str] = []
        extra_csvs.clear()
        for name, content in parse_blocks(reply_text):
            lower = name.lower()
            if lower.endswith(".csv"):
                m_sh = re.search(r"_testdata_negative([a-z0-9]*)\.csv$", lower)
                if m_sh and m_sh.group(1):
                    extra_csvs["Negative" + m_sh.group(1).capitalize()] = content
                else:
                    csv_text = content
                continue
            if not lower.endswith(".py"):
                continue
            if "negative" not in lower:
                log(f"  [negative] ignored '{name}': not a negative file (never overwrites the positive ones).")
                continue
            kind = "locators" if "locator" in lower else "page" if "page" in lower else "test" if "test" in lower else None
            if kind is None:
                continue
            try:
                ast.parse(content)
            except SyntaxError as exc:
                problems.append(f"'{name}' is not valid Python ({exc}). If the reply was cut off, raise ANTHROPIC_MAX_TOKENS.")
                continue
            content, _imp_notes = repair_nonexistent_imports(content, repo_root)
            for _n in _imp_notes:
                log(f"  [negative] repaired a fabricated import in {name}: {_n}")
            if kind in parent_of and not re.search(rf"^class\s+\w+\(\s*{parent_of[kind]}\s*\)", content, re.M):
                problems.append(f"'{name}': its class must inherit the existing {parent_of[kind]} "
                                f"(that is the whole point of a separate negative class).")
                continue
            bad = find_nonexistent_src_import(content, repo_root)
            if bad and not bad.endswith("_negative_locators") and not bad.endswith("_negative_page"):
                problems.append(f"'{name}' imports '{bad}' which does not exist in the repo.")
                continue
            chosen[kind] = content

        # ---- cross-file consistency: page <-> locators <-> testdata columns ----
        header: list[str] = []
        if csv_text:
            import csv as _csv
            import io as _io
            header = next(_csv.reader(_io.StringIO(csv_text)), [])
        else:
            problems.append("no ### FILE: <module>_testdata_negative.csv block - the Negative sheet is missing.")
        CANON = ["ScenarioID", "TestcaseID", "Description", "ExpectedMessage", "Priority"]
        if header and [h.strip() for h in header[:5]] != CANON:
            problems.append(f"the Negative sheet must START with the columns {CANON} (the pytest ids are built from "
                            f"ScenarioID - TestcaseID - Description); it starts with {header[:5]}.")
        import csv as _csv2
        import io as _io2
        for sh_nm, sh_csv in extra_csvs.items():
            h2 = next(_csv2.reader(_io2.StringIO(sh_csv)), [])
            if [x.strip() for x in h2[:5]] != CANON:
                problems.append(f"the {sh_nm} sheet must START with the columns {CANON}; it starts with {h2[:5]}.")
            header = list(header) + [c for c in h2 if c not in header]
        neg_loc_names = set(re.findall(r"^\s+(\w+)\s*=", chosen.get("locators", ""), re.M)) \
            | set(re.findall(r"def (\w+)\(", chosen.get("locators", "")))
        known_loc = parent_loc_names | neg_loc_names
        base_methods_set = set(base_methods)
        for kind in ("page", "test"):
            code = chosen.get(kind)
            if not code:
                continue
            fname = dest_map[kind].name
            if kind == "page" and base_methods_set:
                for m in find_invented_method_calls(code, base_methods_set | parent_page_methods):
                    problems.append(f"{fname}: calls self.{m}(...) which exists neither in base_page.py nor in the "
                                    f"parent page class - an invented helper.")
            if kind == "page" and known_loc:
                for attr in sorted(set(re.findall(r"\bloc\.(\w+)", code)) - known_loc):
                    problems.append(f"{fname}: uses loc.{attr} but neither the positive nor the negative locators "
                                    f"class defines '{attr}'.")
            if kind == "test":
                fixed_t, _n, sheet_problems = fix_sheet_names_in_test(code, module_title, ["Negative"] + list(extra_csvs))
                chosen[kind] = code = fixed_t
                for sh_nm in extra_csvs:
                    if not re.search(rf"""["']{sh_nm}["']""", code):
                        problems.append(f"{fname}: the test never references the '{sh_nm}' data sheet - add a test that loads "
                                        f"_rows_{sh_nm} = ExcelUtil.get_sheet(\"{module_title}\", \"{sh_nm}\").")
                if not re.search(r"""["']Negative["']""", code):
                    problems.append(f"{fname}: the negative test never references the 'Negative' data sheet - it must "
                                    f"load it, e.g. ExcelUtil.get_sheet(\"{module_title}\", \"Negative\").")
                for sp in sheet_problems:
                    if "never calls get_sheet" not in sp and "no test reads it" not in sp:
                        problems.append(f"{fname}: {sp}")
            if header:
                for key in sorted(set(re.findall(r"data\[\s*[\"']([^\"']+)[\"']\s*\]", code)) - set(header)):
                    problems.append(f"{fname}: reads data['{key}'] but the Negative sheet has no '{key}' column "
                                    f"(columns: {header}).")
        return chosen, csv_text, problems

    retries = max(int(os.environ.get("AI_NEGATIVE_RETRIES", "1") or 0), 0)
    attempt_prompt = user_prompt
    chosen, csv_text, problems = {}, None, []
    for attempt in range(retries + 1):
        log(f"  [negative] asking the AI for the negative files (locators + page + test, prompt {len(attempt_prompt):,} chars)..."
            if attempt == 0 else "  [negative] asking again...")
        reply = _negative_ai_reply(NEGATIVE_SYSTEM_PROMPT, attempt_prompt, module, log)
        if not reply or "### FILE:" not in reply:
            problems = ["no usable reply"]
            if attempt < retries:
                continue
            log("  [negative] nothing written.")
            return out
        chosen, csv_text, problems = _evaluate(reply)
        missing_now = [k for k in ("locators", "page", "test") if k not in chosen]
        if not problems and not missing_now:
            break
        for pr in problems:
            log(f"  [negative] PROBLEM: {pr}")
        if attempt < retries:
            attempt_prompt = (user_prompt + "\n\nYOUR PREVIOUS REPLY WAS REJECTED by deterministic checks. Fix exactly "
                              "these and resend ALL FOUR blocks:\n- " + "\n- ".join(problems or
                              [f"missing/invalid file(s): {missing_now}"]))
    if problems:
        chosen = {}          # any remaining problem => write nothing (all-or-nothing, below)

    missing = [k for k in ("locators", "page", "test") if k not in chosen]
    if missing:
        # All-or-nothing: the test imports the negative page, the page imports the negative
        # locators - a partial set would leave broken imports in the repo.
        log(f"  [negative] NOTHING written: {missing} failed validation (reasons above). "
            f"Re-run the negative step; the positive files are untouched.")
        return out
    if runtime_data_enabled() and ensure_runtime_data_util(repo_root) and "test" in chosen:
        chosen["test"] = inject_runtime_resolution(chosen["test"], module, bank)
    if "test" in chosen:
        chosen["test"], _sn = normalize_test_self_usage(chosen["test"], module, bank)
        for _n in _sn:
            log(f"  [negative] test file: {_n}")
    for kind in ("locators", "page", "test"):            # locators first: the page imports them
        if kind not in chosen:
            continue
        dest = dest_map[kind]
        dest.parent.mkdir(parents=True, exist_ok=True)
        (dest.parent / "__init__.py").touch(exist_ok=True)
        if dest.exists():
            try:
                import time as _t
                bdir = repo_root / "debug_logs" / "backups"
                bdir.mkdir(parents=True, exist_ok=True)
                (bdir / f"{dest.stem}_{_t.strftime('%Y%m%d_%H%M%S')}.py").write_text(
                    dest.read_text(encoding="utf-8"), encoding="utf-8")
            except Exception:
                pass
        dest.write_text(chosen[kind] + "\n", encoding="utf-8")
        out[f"negative_{kind}"] = dest
        log(f"  [negative] wrote {dest}")
    edit_synth = _SYNTH_EDIT_ROWS.get(module, [])
    if edit_synth:                                  # Edit negatives: the AI's sheet + every derived row, or the derived rows alone
        try:
            if "NegativeEdit" in extra_csvs:
                edit_csv, _ae = ensure_synth_rows_present(extra_csvs["NegativeEdit"], edit_synth)
            else:
                import csv as _csv3
                import io as _io3
                hdr_e = list(edit_synth[0].keys())
                buf_e = _io3.StringIO()
                w_e = _csv3.DictWriter(buf_e, fieldnames=hdr_e, lineterminator="\n")
                w_e.writeheader()
                w_e.writerows(edit_synth)
                edit_csv, _ae = buf_e.getvalue().rstrip("\n"), len(edit_synth)
                log("  [negative] the AI returned no 'NegativeEdit' sheet - the derived Edit negatives were written "
                    "directly (the negative page/test still need an Edit negative method: re-run to get it).")
            csv_text_to_xlsx(edit_csv, xlsx, sheet_name="NegativeEdit")
            out["negative_edit_testdata"] = xlsx
            log(f"  [negative] wrote sheet 'NegativeEdit' ({max(len([r for r in edit_csv.splitlines() if r.strip()]) - 1, 0)} case(s))")
        except Exception as exc:
            _log_exception("writing the NegativeEdit sheet", exc)
    if csv_text:
        try:
            csv_text, _added = ensure_synth_rows_present(csv_text, synth)
            if _added:
                log(f"  [negative] added {_added} per-field row(s) the AI had left out.")
            csv_text_to_xlsx(csv_text, xlsx, sheet_name="Negative")
            out["negative_testdata"] = xlsx
            tbd = csv_text.count("TBD-verify-message")
            n_rows = max(len([r for r in csv_text.splitlines() if r.strip()]) - 1, 0)
            log(f"  [negative] wrote sheet 'Negative' ({n_rows} case(s)) in {xlsx}")
            if tbd:
                log(f"  [negative] {tbd} row(s) have ExpectedMessage = TBD-verify-message: the real message "
                    f"text was not known - run that case once, copy the message shown, paste it in the sheet.")
        except Exception as exc:
            _log_exception("writing the Negative sheet", exc)
    return out


def _classify_negative_failure(block: str) -> str:
    """Turns one pytest failure block into a plain-English cause + what to do."""
    m = re.search(r"KeyError:\s*([^\n]+)", block)
    if m:
        return f"SHEET COLUMN MISSING {m.group(1).strip()} - the page reads a column the Negative sheet doesn't have"
    m = re.search(r"AttributeError:\s*([^\n]+)", block)
    if m:
        return f"ATTRIBUTE MISSING - {m.group(1).strip()[:110]} (a locator or helper name that doesn't exist)"
    if "TBD-verify-message" in block:
        return "MESSAGE UNKNOWN - ExpectedMessage is still TBD-verify-message: copy the real message shown by the app into the sheet"
    m = re.search(r"waiting for (?:locator|selector)\(?[\"']?([^\n]{0,90})", block)
    if m or "TimeoutError" in block:
        return f"ELEMENT NOT FOUND / TIMEOUT - {(m.group(1) if m else '').strip()[:90]} (wrong locator, or the page never showed it)"
    if "AssertionError" in block:
        m2 = re.search(r"AssertionError:\s*([^\n]{0,140})", block)
        return ("ASSERTION FAILED - the message/state shown by the app differs from ExpectedMessage"
                + (f": {m2.group(1).strip()}" if m2 else ""))
    return "OTHER - see the failure text in the report"


def _parse_pytest_output(output: str) -> tuple[dict[str, str], dict[str, str]]:
    """(per-test status, per-test failure text) from `pytest -v --tb=short` output."""
    results: dict[str, str] = {}
    for m in re.finditer(r"^(\S+?\.py)::(\S+)\s+(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS)\b", output, re.M):
        results[m.group(2)] = m.group(3)
    blocks: dict[str, str] = {}
    parts = re.split(r"^_{3,}\s+(.+?)\s+_{3,}$", output, flags=re.M)
    for i in range(1, len(parts) - 1, 2):
        blocks[parts[i].strip()] = parts[i + 1]
    return results, blocks


def validate_negative_suite(repo_root: Path, module: str, log=print) -> dict:
    """Runs ONLY the generated negative test file and classifies every row: PASSED (the app
    showed the expected message) or the exact kind of failure. Report: reports/<module>_negative_validation.txt"""
    test_path = repo_root / "src" / "testcase" / module / f"test_{module}_negative.py"
    only_negative_k = None
    if not test_path.exists():
        cands = sorted((repo_root / "src" / "testcase" / module).glob(f"test_{module}_*.py")) \
            if (repo_root / "src" / "testcase" / module).exists() else []
        cands = [c for c in cands if "Negative" in c.read_text(encoding="utf-8", errors="ignore")]
        if cands:                                   # one-file mode: negatives live inside the merged file
            test_path, only_negative_k = cands[0], "Negative or negative"
        else:
            log(f"  [negative-validate] {test_path} does not exist - generate the negative suite first.")
            return {}
    timeout = int(os.environ.get("AI_NEGATIVE_TIMEOUT", "900") or 900)
    log(f"  [negative-validate] running {test_path.name} (up to {timeout}s)...")
    try:
        proc = subprocess.run([sys.executable, "-m", "pytest", str(test_path), "-v", "--tb=short",
                               "-p", "no:cacheprovider"] + (["-k", only_negative_k] if only_negative_k else []),
                              cwd=str(repo_root),
                              capture_output=True, text=True, timeout=timeout)
        output = (proc.stdout or "") + "\n" + (proc.stderr or "")
    except subprocess.TimeoutExpired as exc:
        output = ((exc.stdout or b"").decode("utf-8", "ignore") if isinstance(exc.stdout, bytes) else (exc.stdout or "")) \
            + f"\n(pytest timed out after {timeout}s)"
    results, blocks = _parse_pytest_output(output)
    lines, passed, failed = [], 0, 0
    for tid, status in results.items():
        if status == "PASSED":
            passed += 1
            lines.append(f"  [PASS ] {tid}")
            continue
        failed += 1
        cause = _classify_negative_failure(blocks.get(tid, ""))
        if cause.startswith("OTHER"):
            for key, blk in blocks.items():
                if tid in key or key in tid:
                    cause = _classify_negative_failure(blk)
                    break
        lines.append(f"  [{status[:5]:5}] {tid}\n          -> {cause}")
    if not results:
        lines.append("  (pytest produced no test results - see the output below)")
        lines.append(output[-1500:])
    summary = f"Negative validation - {module}: {passed} passed, {failed} need attention, {len(results)} total"
    report = summary + "\n" + "=" * len(summary) + "\n" + "\n".join(lines) + "\n"
    try:
        rd = repo_root / "reports"
        rd.mkdir(exist_ok=True)
        (rd / f"{module}_negative_validation.txt").write_text(report + "\n--- raw pytest output ---\n" + output, encoding="utf-8")
    except Exception:
        pass
    log("\n" + report)
    log(f"  [negative-validate] full report: {repo_root / 'reports' / (module + '_negative_validation.txt')}")
    return {"passed": passed, "failed": failed, "total": len(results), "report": report}


# ======================================================================
# DATA-SHEET NAME consistency: test file  <->  the sheets actually written to <Module>.xlsx
# (the sheet names are written as Add / View / Edit / Changestatus / Negative ... by csv_text_to_xlsx;
#  a test that asks for "ChangeStatus", "add", a wrong file title, or no sheet at all can never load its data)
# ======================================================================
_GET_SHEET_RE = re.compile(r"(\bget_sheet\(\s*)([^,()]+?)(\s*,\s*)([^,()]+?)(\s*[,)])")


def sheets_from_blocks(blocks: list[tuple[str, str]], default_sheet: str) -> list[str]:
    """Sheet names the CSV blocks of an AI reply will become (same rule as auto_write_into_repo)."""
    sheets = []
    for name, _ in blocks:
        m = re.search(r"_testdata_([a-z0-9]+)\.csv$", name.lower())
        if m:
            sheets.append(m.group(1).capitalize())
        elif name.lower().endswith(".csv"):
            sheets.append(default_sheet)
    return list(dict.fromkeys(sheets))


def fix_sheet_names_in_test(content: str, module_title: str, sheets: list[str]) -> tuple[str, list[str], list[str]]:
    """Deterministically corrects ExcelUtil.get_sheet("<File>", "<Sheet>") calls so they match the
    workbook that is really written. Returns (content, notes of what was corrected, problems left)."""
    notes: list[str] = []
    problems: list[str] = []
    if not sheets:
        return content, notes, problems
    ci = {s.lower(): s for s in sheets}
    consts = {m.group(1): m.group(2) for m in re.finditer(r'^([A-Za-z_]\w*)\s*=\s*["\']([^"\']*)["\']\s*$', content, re.M)}
    calls = list(_GET_SHEET_RE.finditer(content))
    if not calls:
        if "ExcelUtil" in content or "read_all_testdata_rows" in content:
            return content, notes, problems         # data is loaded through another API - can't judge sheet names
        problems.append(f"the test never calls get_sheet(\"{module_title}\", \"<sheet>\") - it loads no data sheet "
                        f"(sheets in {module_title}.xlsx: {sheets})")
        return content, notes, problems

    def lit(arg: str):
        m = re.fullmatch(r"""\s*(["'])(.*?)\1\s*""", arg)
        return m.group(2) if m else None

    edits: list[tuple[int, int, str]] = []        # (start, end, replacement) over the call text
    const_fixes: dict[str, str] = {}
    for m in calls:
        pre, a1, mid, a2, post = m.groups()
        start_a1, start_a2 = m.start(2), m.start(4)
        # ---- file title ----
        v1 = lit(a1)
        if v1 is not None and v1 != module_title:
            edits.append((m.start(2), m.end(2), f'"{module_title}"'))
            notes.append(f"file title \"{v1}\" -> \"{module_title}\" (the workbook is {module_title}.xlsx)")
        # ---- sheet ----
        v2 = lit(a2)
        const_name = None
        if v2 is None and a2.strip() in consts:
            const_name, v2 = a2.strip(), consts[a2.strip()]
        if v2 is None:
            continue                                   # dynamic (f-string / parametrized) - leave alone
        if v2 in sheets:
            continue
        target = ci.get(v2.lower())
        if target is None:
            fn = None
            for fm in re.finditer(r"^\s*def\s+(\w+)", content[:m.start()], re.M):
                fn = fm.group(1).lower()
            cands = [s for s in sheets if fn and s.lower() in fn]
            target = cands[0] if len(cands) == 1 else (sheets[0] if len(sheets) == 1 else None)
        if target is None:
            problems.append(f"get_sheet(..., \"{v2}\") asks for a sheet that does not exist - real sheets: {sheets}")
            continue
        if const_name:
            const_fixes[const_name] = target
        else:
            edits.append((m.start(4), m.end(4), f'"{target}"'))
        notes.append(f"sheet \"{v2}\" -> \"{target}\" (real sheets: {sheets})")
    for start, end, rep in sorted(edits, reverse=True):
        content = content[:start] + rep + content[end:]
    for cname, target in const_fixes.items():
        content = re.sub(rf'^({re.escape(cname)}\s*=\s*)["\'][^"\']*["\']', lambda mm: f'{mm.group(1)}"{target}"',
                         content, count=1, flags=re.M)
    used = set(re.findall(r"""["']([^"']+)["']""", " ".join(m.group(0) for m in _GET_SHEET_RE.finditer(content)))) | \
        {consts.get(a.strip(), "") for m in _GET_SHEET_RE.finditer(content) for a in (m.group(4),)}
    for s in sheets:
        if s not in used and s not in content:
            problems.append(f"sheet '{s}' is written to {module_title}.xlsx but no test reads it")
    return content, notes, problems


SHEET_REPAIR_SYSTEM_PROMPT = """You fix ONE pytest test file so it loads its test data from the right Excel sheet.
The framework reads data with ExcelUtil.get_sheet("<File title>", "<Sheet name>"). You are given the file, the
exact File title and the exact sheet names (copy them character-for-character, same capitalisation).
Every test (or parametrize) for an action must load THAT action's sheet. Keep every existing class, method,
import, mark and assertion unchanged. Reply with ONLY the complete corrected file, no markdown fences."""


def ensure_test_loads_sheets(name: str, content: str, module_title: str, sheets: list[str], log=print) -> str:
    """Deterministic fix first; if the test loads no sheet at all, one targeted AI repair; a FIXME banner
    (never silence) if it is still wrong."""
    fixed, notes, problems = fix_sheet_names_in_test(content, module_title, sheets)
    for n in notes:
        log(f"  Corrected the data-sheet reference in '{name}': {n}")
    if problems and any("never calls get_sheet" in p for p in problems):
        prompt = (f"FILE {name}:\n{fixed}\n\nFile title: {module_title}\nSheets (exact): {sheets}\n"
                  f"Required: ExcelUtil.get_sheet(\"{module_title}\", \"<one of the sheets>\") for each action.")
        try:
            reply = ask_ai(SHEET_REPAIR_SYSTEM_PROMPT, prompt)
        except Exception:
            reply = ""
        cand = strip_code_fence((reply or "").strip())
        try:
            ast.parse(cand)
            lost = (set(re.findall(r"^\s*(?:def|class)\s+(\w+)", fixed, re.M))
                    - set(re.findall(r"^\s*(?:def|class)\s+(\w+)", cand, re.M)))
            if not lost:
                cand2, n2, p2 = fix_sheet_names_in_test(cand, module_title, sheets)
                if not any("never calls get_sheet" in p for p in p2):
                    fixed, problems = cand2, p2
                    log(f"  Added the missing data-sheet loading to '{name}' with a targeted repair.")
        except SyntaxError:
            pass
    for p in problems:
        log(f"  WARNING (data sheet) in '{name}': {p}")
    blocking = [p for p in problems if "never calls get_sheet" in p or "does not exist" in p]
    if blocking:
        banner = ("# FIXME (data sheet): " + "; ".join(blocking) + ". Fix the ExcelUtil.get_sheet(...) "
                  f"call(s) - file title \"{module_title}\", sheet names {sheets}.\n")
        fixed = banner + fixed
    return fixed


# ======================================================================
# SINGLE-FILE NEGATIVE LAYOUT
#   ONE file  src/testcase/<module>/test_<module>_negative.py  holds the negative locators class, the
#   negative page class and the negative test class, plus ONE 'Negative' sheet. The positive locators /
#   page / test / sheets carry NO negative cases (they are moved out into the negative file).
# ======================================================================
NEGATIVE_SEPARATE_ONLY_NOTE = """
NEGATIVE CASES ARE OUT OF SCOPE FOR THIS GENERATION (overrides every earlier instruction about negative /
boundary / validation rows): generate ONLY positive behaviour. In the testdata CSV(s) write only the valid
happy-path row (plus one positive row per option of a Yes/No/radio/dropdown choice that changes the flow).
Do NOT write blank / required-field / max-length / wrong-format / duplicate / invalid rows, and do NOT add
error-message / validation-error locators (no *_error, *_required_error, validation_* locators). Negative
cases are generated separately into ONE dedicated negative file afterwards."""


def negative_generation_enabled() -> bool:
    """Negative cases are generated BY DEFAULT (separate single negative file). AI_GENERATE_NEGATIVE=0 turns it off."""
    return os.environ.get("AI_GENERATE_NEGATIVE", "1").strip().lower() not in ("0", "false", "no")


def _separate_negatives() -> bool:
    """Negatives are moved OUT of the positive files only when they WILL be generated into the negative file -
    otherwise they must stay where they are, never silently disappear."""
    return negative_generation_enabled() and os.environ.get("AI_NEGATIVE_SEPARATE_ONLY", "1").strip() != "0"


RUNTIME_DATA_NOTE = """
RUN-TIME DATA (testdata holds NO literal identifying numbers): the record's identifying field (the value a person searches /
edits / deletes the record BY - a BIN, Merchant ID, Name ...) is generated by the Add test at run time and reused by every
other action. Write it in the CSVs as a TOKEN, never as a number:
  Add sheet  -> {{RANDOM:<digits>}}  (only a BIN-like column - see AI_LUHN_COLUMNS - is a 6-digit number that must PASS the Luhn
                check and is written {{LUHN:6}}; every other identifier (Merchant ID, Name ...) is {{RANDOM:<digits>}} / {{RANDOM:<n>:alpha}})
  View / Edit / Delete / ChangeStatus sheets, positive rows -> {{FROM_ADD}}
  a "record does not exist" row -> {{FRESH:<digits>}}
  ONLY when the sheet really has range columns whose name carries the identifier's name (e.g. "BIN low range" / "BIN high range";
  never an unrelated range such as an amount or a date) -> {{LOW:BIN:19}} / {{HIGH:BIN:19}}
  (the BIN padded with zeros / nines to 19 digits: BIN 453634 -> 4536340000000000000 .. 4536349999999999999). They are generated
  from the SAME row's BIN, so they are never typed as numbers either.
Every test calls RuntimeData.resolve(data, "<module>", BANK_NAME) first (the framework adds that line), so the page code must
use data["<column>"] EXACTLY as given: it must never generate its own random value and never hard-code a number.
"""


def _runtime_data_note() -> str:
    return RUNTIME_DATA_NOTE if runtime_data_enabled() else ""


def _negative_scope_note() -> str:
    return NEGATIVE_SEPARATE_ONLY_NOTE if _separate_negatives() else ""


def restore_negative_seed_sheets(repo_root: Path, bank: str, module: str, log=print) -> list[str]:
    """SAFETY NET: if the negative file could not be generated (skipped / validation failed), the negative rows that
    were taken out of the positive sheets are written back as 'Negative' sheet(s) so they are never lost."""
    seeds = _NEGATIVE_SEED_ROWS.get(module, [])
    if not seeds:
        return []
    import csv as _csv
    import io as _io
    by_sheet: dict[str, tuple[list[str], list[list[str]]]] = {}
    for sheet, header, row in seeds:                       # union of the columns (synthesized rows have NegativeType too)
        union, rows_ = by_sheet.setdefault(sheet, (list(header), []))
        for c in header:
            if c not in union:
                union.append(c)
        rows_.append(dict(zip(header, row)))
    by_sheet = {sh: (u, [[r.get(c, "") for c in u] for r in rs]) for sh, (u, rs) in by_sheet.items()}
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    written = []
    for sheet, (header, rows) in by_sheet.items():
        name = "Negative" if sheet == "Add" else f"Negative{sheet}"
        buf = _io.StringIO()
        _csv.writer(buf, lineterminator="\n").writerows([header] + rows)
        try:
            csv_text_to_xlsx(buf.getvalue().rstrip("\n"), xlsx, sheet_name=name)
            written.append(f"{name} ({len(rows)} row(s))")
        except Exception as exc:
            _log_exception("restoring negative rows", exc)
    if written:
        log(f"  [negative] the negative rows were NOT lost: written back to {xlsx} as sheet(s) {written}. "
            f"Only the negative page/test code is missing - re-run the negative step to get it.")
    return written


# rows moved out of the positive sheets, keyed by (module): [(sheet, header, row), ...]
_NEGATIVE_SEED_ROWS: dict[str, list[tuple[str, list[str], list[str]]]] = {}

_NEG_DESC_RE = re.compile(
    r"\b(blank|empty|invalid|negative|boundary|past (?:the|its)|exceed\w*|below|above|missing|wrong|incorrect|"
    r"not allowed|duplicate|already exists|too long|too short|special char\w*|less than|more than|"
    r"mandatory|without)\b", re.I)
_NEG_MSG_RE = re.compile(r"\b(required|invalid|cannot|can not|must|exceed\w*|already exists|not allowed|"
                         r"should not|not valid|only (?:digits|numbers|alphabets)|error)\b", re.I)
_POS_MSG_RE = re.compile(r"\b(success\w*|created|saved|submitted|approval|updated|deleted|activated|"
                         r"deactivated|configured|added)\b", re.I)


def split_out_negative_rows(csv_text: str, sheet: str, module: str) -> tuple[str, int]:
    """Removes negative / boundary / validation rows from a POSITIVE testdata CSV (they belong to the single
    negative file) and remembers them as seeds for it. The first row is always kept. Returns (csv, n_moved)."""
    import csv as _csv
    import io as _io
    rows = list(_csv.reader(_io.StringIO(csv_text)))
    if len(rows) < 3:
        return csv_text, 0
    header = rows[0]
    low = [h.strip().lower() for h in header]
    di = low.index("description") if "description" in low else None
    mi = low.index("expectedmessage") if "expectedmessage" in low else None
    keep, moved = [rows[0], rows[1]], []
    for row in rows[2:]:
        desc = row[di] if di is not None and di < len(row) else ""
        msg = row[mi] if mi is not None and mi < len(row) else ""
        is_neg = (bool(_NEG_DESC_RE.search(desc)) or bool(_NEG_MSG_RE.search(msg))) and not _POS_MSG_RE.search(msg)
        (moved if is_neg else keep).append(row)
    if not moved:
        return csv_text, 0
    _NEGATIVE_SEED_ROWS.setdefault(module, []).extend((sheet, header, r) for r in moved)
    buf = _io.StringIO()
    _csv.writer(buf, lineterminator="\n").writerows(keep)
    return buf.getvalue().rstrip("\n"), len(moved)


_ERROR_LOCATOR_RE = re.compile(r"(^|_)(error|errors|validation|required_error|format_error)(_|$)", re.I)


def strip_unused_error_locators(locators_path: Path, page_path: Path | None, test_path: Path | None,
                                log=print) -> list[str]:
    """Drops error/validation locators from the POSITIVE locators file when nothing in the positive page or
    test uses them (they move to the single negative file). Anything still referenced is kept."""
    try:
        src = locators_path.read_text(encoding="utf-8")
    except Exception:
        return []
    used_text = "".join(_read_text(p) for p in (page_path, test_path) if p)
    dropped = []
    lines = src.split("\n")
    out = []
    for line in lines:
        m = re.match(r"^\s+(\w+)\s*=\s*[\"'].*$", line)
        if m and _ERROR_LOCATOR_RE.search(m.group(1)) and not re.search(rf"\b{re.escape(m.group(1))}\b", used_text):
            dropped.append(m.group(1))
            continue
        out.append(line)
    if dropped:
        locators_path.write_text("\n".join(out), encoding="utf-8")
        log(f"  Removed {len(dropped)} error/validation locator(s) from the positive locators file "
            f"(they belong to the single negative file): {dropped}")
    return dropped


NEGATIVE_SINGLE_SYSTEM_PROMPT = """You generate ALL negative cases of ONE module in ONE Python file for an existing
Playwright + Python framework, extending the already-working positive classes. Reply with exactly two blocks:
  1. ### FILE: src/testcase/<module>/test_<module>_negative.py   - ONE file containing, in this order:
       a) imports of the existing positive locators class and positive page class (+ pytest, ExcelUtil, login class
          exactly as the existing positive test imports them),
       b) class <ParentLocatorsClass>Negative(<ParentLocatorsClass>): ONLY the extra locators negatives need
          (error / validation / message locators, per-field error locators) - never repeat the parent's,
       c) class <ParentPageClass>Negative(<ParentPageClass>): negative flow methods (<action>_negative(self, bank, data)),
          data-driven, obtaining its locators the same way the parent page does but from the Negative locators class,
       d) ONE pytest test class (name it Test<ModuleTitle>Module) that mirrors the existing positive test's fixtures,
          login call and chain EXACTLY (login -> page object -> navigate -> negative action), loading the 'Negative'
          sheet ONCE at module level as _rows_Negative = ExcelUtil.get_sheet("<ModuleTitle>", "Negative") and using it
          in @pytest.mark.parametrize("data", _rows_Negative, ids=[...ScenarioID - TestcaseID - Description...]).
  2. ### FILE: <module>_testdata_negative.csv  - the 'Negative' sheet: ALL negative cases of the module.
Hard rules: valid Python; only src.* imports that exist; only page helper methods that really exist; derive cases
ONLY from the facts given (field required/maxlength/type, scenario, baseline row, seed rows); merge duplicates of the
seed rows instead of repeating them; do not invent features. Follow the HOUSE STYLE notes."""


def generate_negative_suite_single(repo_root: Path, bank: str, module: str, scenario: str,
                                   written: dict, field_facts: list[dict] | None = None, log=print) -> dict:
    out: dict = {}
    loc_path, page_path, test_path = written.get("locators"), written.get("page"), written.get("test")
    if not (loc_path and page_path and test_path):
        _missing = [k for k, v in (("locators", loc_path), ("page", page_path), ("test", test_path)) if not v]
        log(f"  [negative] skipped: the positive {', '.join(_missing)} file(s) were not written "
            f"(see the rejection message above) - fix that first, the negative file extends them.")
        return out
    repair_python_string_lines(Path(loc_path))
    loc_src, page_src, test_src = _read_text(loc_path), _read_text(page_path), _read_text(test_path)
    loc_cls, page_cls = extract_class_name(loc_src), extract_class_name(page_src)
    if not (loc_cls and page_cls):
        log("  [negative] skipped: could not find the positive locators/page class names.")
        return out
    module_title = module[:1].upper() + module[1:]
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module_title}.xlsx"
    try:
        baseline = read_first_testdata_row(xlsx, sheet_name="Add") if xlsx.exists() else {}
    except Exception:
        baseline = {}
    base_methods = sorted(load_base_page_methods(repo_root))
    refs = ""
    for rp in [x.strip() for x in os.environ.get("AI_NEGATIVE_REFERENCE", "").split(",") if x.strip()]:
        txt = _read_text(rp)
        if txt:
            refs += f"\n--- team's own hand-written reference: {rp} ---\n{_clip(txt, 12000)}\n"
    synth = _prepare_synth(repo_root, bank, module, baseline, field_facts, log)
    seed_txt = _seed_text(module)
    loc_mod = f"src.banks.{bank}.locators.{module}_locators"
    page_mod = f"src.common.pages.{module}.{module}_page"
    neg_rel = f"src/testcase/{module}/test_{module}_negative.py"
    user_prompt = (
        f"BANK: {bank}\nMODULE: {module}\n\nSCENARIO (positive flow already implemented):\n{scenario}\n\n"
        f"EXISTING POSITIVE LOCATORS - import with: from {loc_mod} import {loc_cls}\n{_clip(loc_src, 12000)}\n\n"
        f"EXISTING POSITIVE PAGE - import with: from {page_mod} import {page_cls}\n{_clip(page_src, 18000)}\n\n"
        f"EXISTING POSITIVE TEST (mirror its structure exactly):\n{_clip(test_src, 12000)}\n\n"
        f"REAL base page helper methods you may call: {base_methods}\n\n"
        f"VALID BASELINE ROW (first row of the Add sheet): {baseline}\n\n"
        f"LIVE FORM FACTS (real constraints captured from the page):\n{_format_field_facts(_split_facts(field_facts)[0])}\n\n"
        f"MANDATORY NEGATIVE ROWS (derived per field from the real form constraints and from the positive sheets) - keep EVERY one of them in the Negative sheet with the SAME Description, values and tokens, then ADD more rows for business rules and cross-field rules:\n{seed_txt}\n\n"
        f"{NEGATIVE_STYLE_NOTES}\n{refs}\n"
        f"Names: file {neg_rel}; locators class {loc_cls}Negative; page class {page_cls}Negative; "
        f"CSV file {module}_testdata_negative.csv; sheet 'Negative' in {module_title}.xlsx."
    )
    dest = repo_root / "src" / "testcase" / module / f"test_{module}_negative.py"
    parent_loc_names = set(re.findall(r"^\s+(\w+)\s*=", loc_src, re.M)) | set(re.findall(r"def (\w+)\(", loc_src))
    parent_page_methods = set(re.findall(r"def (\w+)\(", page_src))

    def _evaluate(reply_text: str):
        problems: list[str] = []
        code, csv_text = None, None
        for name, content in parse_blocks(reply_text):
            lower = name.lower()
            if lower.endswith(".csv"):
                csv_text = content
            elif lower.endswith(".py") and "negative" in lower and "test" in lower:
                code = content
            elif lower.endswith(".py"):
                log(f"  [negative] ignored '{name}': the negative cases go into ONE file ({neg_rel}) only.")
        if code is None:
            return None, csv_text, [f"no '### FILE: {neg_rel}' block"]
        if csv_text is None:
            problems.append(f"no ### FILE: {module}_testdata_negative.csv block")
        try:
            ast.parse(code)
        except SyntaxError as exc:
            return None, csv_text, [f"{dest.name} is not valid Python ({exc}). If the reply was cut off, raise ANTHROPIC_MAX_TOKENS."]
        code, notes = repair_nonexistent_imports(code, repo_root)
        for n in notes:
            log(f"  [negative] repaired a fabricated import: {n}")
        if not re.search(rf"^class\s+\w+\(\s*{loc_cls}\s*\)", code, re.M):
            problems.append(f"the file must define a locators class inheriting {loc_cls}.")
        if not re.search(rf"^class\s+\w+\(\s*{page_cls}\s*\)", code, re.M):
            problems.append(f"the file must define a page class inheriting {page_cls}.")
        if not re.search(r"^\s*(?:async\s+)?def\s+test_\w+", code, re.M):
            problems.append("the file has no test function (def test_...).")
        bad = find_nonexistent_src_import(code, repo_root)
        if bad:
            problems.append(f"imports '{bad}' which does not exist in the repo.")
        header: list[str] = []
        if csv_text:
            import csv as _csv
            import io as _io
            header = next(_csv.reader(_io.StringIO(csv_text)), [])
        defined_here = set(re.findall(r"^\s+(\w+)\s*=", code, re.M)) | set(re.findall(r"def (\w+)\(", code))
        if base_methods:
            for m in find_invented_method_calls(code, set(base_methods) | parent_page_methods | defined_here):
                problems.append(f"calls self.{m}(...) which exists neither in base_page.py, the parent page nor this file.")
        for attr in sorted(set(re.findall(r"\bloc\.(\w+)", code)) - (parent_loc_names | defined_here)):
            problems.append(f"uses loc.{attr} but neither the positive locators nor the negative locators class defines '{attr}'.")
        CANON = ["ScenarioID", "TestcaseID", "Description", "ExpectedMessage", "Priority"]
        if header and [h.strip() for h in header[:5]] != CANON:
            problems.append(f"the Negative sheet must START with the columns {CANON} (the pytest ids are built from "
                            f"ScenarioID - TestcaseID - Description); it starts with {header[:5]}.")
        if header:
            for key in sorted(set(re.findall(r"data\[\s*[\"']([^\"']+)[\"']\s*\]", code)) - set(header)):
                problems.append(f"reads data['{key}'] but the Negative sheet has no '{key}' column (columns: {header}).")
        code, _n, sheet_problems = fix_sheet_names_in_test(code, module_title, ["Negative"])
        if not re.search(r"""["']Negative["']""", code):
            problems.append(f"the test never references the 'Negative' data sheet - load it with "
                            f"ExcelUtil.get_sheet(\"{module_title}\", \"Negative\").")
        for sp in sheet_problems:
            if "never calls get_sheet" not in sp and "no test reads it" not in sp:
                problems.append(sp)
        return code, csv_text, problems

    retries = max(int(os.environ.get("AI_NEGATIVE_RETRIES", "1") or 0), 0)
    attempt_prompt = user_prompt
    code, csv_text, problems = None, None, []
    for attempt in range(retries + 1):
        log(f"  [negative] asking the AI for the single negative file (prompt {len(attempt_prompt):,} chars)..." if attempt == 0
            else "  [negative] asking again...")
        try:
            reply = ask_ai(NEGATIVE_SINGLE_SYSTEM_PROMPT, attempt_prompt)
        except Exception as exc:
            reply = ""
            log(f"  [negative] the AI call RAISED {type(exc).__name__}: {str(exc)[:300]}")
        if reply and "### FILE:" not in reply:
            fixed_reply = _lenient_blocks(reply).replace("__module__", module)
            if "### FILE:" in fixed_reply:
                log("  [negative] the AI forgot the '### FILE:' markers - recovered the code/CSV blocks anyway.")
                reply = fixed_reply
        if not reply or "### FILE:" not in reply:
            if not reply:
                log("  [negative] the AI call returned an EMPTY reply (API error / timeout / rate limit - look for an "
                    "error line just above; try AI_TIMEOUT_SECONDS=600 in .env).")
            else:
                log(f"  [negative] the AI replied but not in the expected format. Start of its reply: "
                    f"{reply[:400]!r}")
            problems = ["no usable reply"]
            code, csv_text = None, None
            if attempt < retries:
                continue
            log("  [negative] nothing written.")
            return out
        code, csv_text, problems = _evaluate(reply)
        if code is not None and not problems:
            break
        for pr in problems:
            log(f"  [negative] PROBLEM: {pr}")
        if attempt < retries:
            attempt_prompt = (user_prompt + "\n\nYOUR PREVIOUS REPLY WAS REJECTED by deterministic checks. Fix exactly "
                              "these and resend BOTH blocks:\n- " + "\n- ".join(problems))
    if code is None or problems:
        log("  [negative] NOTHING written: validation failed (reasons above). The positive files are untouched.")
        return out

    dest.parent.mkdir(parents=True, exist_ok=True)
    (dest.parent / "__init__.py").touch(exist_ok=True)
    bdir = repo_root / "debug_logs" / "backups"
    import shutil
    import time as _t
    stamp = _t.strftime("%Y%m%d_%H%M%S")
    for old in (dest,
                repo_root / "src" / "banks" / bank / "locators" / f"{module}_negative_locators.py",
                repo_root / "src" / "common" / "pages" / module / f"{module}_negative_page.py"):
        if old.exists():
            try:
                bdir.mkdir(parents=True, exist_ok=True)
                shutil.move(str(old), str(bdir / f"{old.stem}_{stamp}.py")) if old != dest else \
                    (bdir / f"{old.stem}_{stamp}.py").write_text(old.read_text(encoding="utf-8"), encoding="utf-8")
                if old != dest:
                    log(f"  [negative] the old separate file {old.name} was merged into the single file "
                        f"(a copy is in debug_logs\\backups).")
            except Exception:
                pass
    if runtime_data_enabled() and ensure_runtime_data_util(repo_root):
        code = inject_runtime_resolution(code, module, bank)
    code, _sn = normalize_test_self_usage(code, module, bank)
    for _n in _sn:
        log(f"  [negative] test file: {_n}")
    dest.write_text(code + "\n", encoding="utf-8")
    out["negative_test"] = dest
    log(f"  [negative] wrote the single negative file: {dest}")
    if csv_text:
        try:
            csv_text, _added = ensure_synth_rows_present(csv_text, synth)
            if _added:
                log(f"  [negative] added {_added} per-field row(s) the AI had left out.")
            csv_text_to_xlsx(csv_text, xlsx, sheet_name="Negative")
            out["negative_testdata"] = xlsx
            tbd = csv_text.count("TBD-verify-message")
            n_rows = max(len([r for r in csv_text.splitlines() if r.strip()]) - 1, 0)
            log(f"  [negative] wrote sheet 'Negative' ({n_rows} case(s)) in {xlsx}")
            if tbd:
                log(f"  [negative] {tbd} row(s) have ExpectedMessage = TBD-verify-message: run that case once, "
                    f"copy the real message into the sheet.")
        except Exception as exc:
            _log_exception("writing the Negative sheet", exc)
    return out


def _seed_text(module: str) -> str:
    seeds = _NEGATIVE_SEED_ROWS.get(module, [])
    if not seeds:
        return "(none)"
    lines, last_hdr = [], None
    for sheet, header, row in seeds[:160]:
        if header != last_hdr:
            lines.append(f"[{sheet}] columns: " + ",".join(header))
            last_hdr = header
        lines.append("  " + ",".join(row))
    return "\n".join(lines)


def negative_layout() -> str:
    """'inline' (DEFAULT): positive + negative in the SAME locators / page / test file (and the same Excel workbook).
    'separate': negative locators + page + test stay as THREE separate files.   'single': every negative class in one file."""
    v = os.environ.get("AI_NEGATIVE_LAYOUT", "inline").strip().lower()
    return v if v in ("separate", "single") else "inline"


def generate_negative_suite(repo_root: Path, bank: str, module: str, scenario: str,
                            written: dict, field_facts: list[dict] | None = None, log=print) -> dict:
    """Negative cases. DEFAULT = THREE separate files (negative locators, negative page, negative test) + one 'Negative'
    sheet. AI_NEGATIVE_LAYOUT=single puts all negative classes in one file instead."""
    if negative_layout() == "single":
        return generate_negative_suite_single(repo_root, bank, module, scenario, written, field_facts, log)
    return generate_negative_suite_separate(repo_root, bank, module, scenario, written, field_facts, log)   # inline + separate


# ======================================================================
# INLINE NEGATIVE LAYOUT (DEFAULT): positive + negative live in the SAME file, per kind
#     locators file : positive locators class + negative locators class
#     page file     : positive page class     + negative page class
#     test file     : ONE test class (reference layout) with a NEGATIVE section, _rows_Negative at the top
#     Excel         : the same <Module>.xlsx (Add / Edit / ... + Negative sheets)
# The negative code is generated as three working files first (so it can be validated and run), then folded into the
# positive files as the LAST step. All-or-nothing: on any doubt the three negative files simply stay separate.
# ======================================================================
def _rewrite_module_imports(src: str, mapping: dict[str, str]) -> str:
    def repl(m):
        new = mapping.get(m.group(2))
        return f"{m.group(1)}from {new} import {m.group(3)}" if new else m.group(0)
    return re.sub(r"^([ \t]*)from (src\.[\w.]+) import ([^()\n#]+?)[ \t]*$", repl, src, flags=re.M)


def _combine_from_imports(hoisted: dict) -> dict:
    """from m import A  +  from m import B  ->  from m import A, B  (other import lines are kept as they are)."""
    order: list = []
    by_mod: dict[str, list[str]] = {}
    for key, text in hoisted.items():
        try:
            node = ast.parse(text).body[0]
        except Exception:
            node = None
        if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            if node.module not in by_mod:
                by_mod[node.module] = []
                order.append(("from", node.module))
            for a in node.names:
                item = a.name + (f" as {a.asname}" if a.asname else "")
                if item not in by_mod[node.module]:
                    by_mod[node.module].append(item)
        else:
            order.append(("raw", key, text))
    out = {}
    for entry in order:
        if entry[0] == "from":
            out[f"from:{entry[1]}"] = f"from {entry[1]} import {', '.join(by_mod[entry[1]])}"
        else:
            out[entry[1]] = entry[2]
    return out


def _merge_pair(kind: str, pos_path: Path, neg_path: Path, bank: str, module: str, repo_root: Path,
                drop_modules: set[str], rewrites: dict[str, str], log=print) -> str | None:
    """Folds the negative file of one kind INTO the positive file of the same kind; returns the merged source or None."""
    pos_src = pos_path.read_text(encoding="utf-8")
    neg_src = _rewrite_module_imports(neg_path.read_text(encoding="utf-8"), rewrites)
    analysed = []
    for label, src in (("pos", pos_src), ("neg", neg_src)):
        tree, lines, imps, others = _split_py(src)
        analysed.append((label, tree, lines, imps, others))
    # ---- collisions (an identical constant defined twice, e.g. BANK_NAME, is fine) ----
    all_defined: dict[str, str] = {}
    sigs: dict[str, str] = {}
    for label, _t, _l, _i, others in analysed:
        for node_o in others:
            for n in _defined_names([node_o]):
                sig = ast.dump(node_o[0]) if isinstance(node_o[0], (ast.Assign, ast.AnnAssign)) else None
                if n in all_defined and all_defined[n] != label:
                    if sig is not None and sigs.get(n) == sig:
                        continue
                    if kind == "test" and isinstance(node_o[0], ast.ClassDef) and n.startswith("Test"):
                        continue                      # test classes are folded into ONE class by the layout step
                    log(f"  [inline] {kind}: '{n}' is defined in both the positive and the negative file with DIFFERENT code.")
                    return None
                all_defined[n] = label
                if sig is not None:
                    sigs[n] = sig
    if kind == "test":
        names_pos = re.findall(r"^\s*(?:async\s+)?def\s+(test_\w+)", pos_src, re.M)
        dup = set(names_pos) & set(re.findall(r"^\s*(?:async\s+)?def\s+(test_\w+)", neg_src, re.M))
        if dup:
            log(f"  [inline] test: both files define {sorted(dup)} - merging would drop one.")
            return None
    hoisted: dict[str, str] = {}
    future: dict[str, str] = {}
    for label, _t, lines, imps, _o in analysed:
        for node, s, e in imps:
            modname = (node.module or "") if isinstance(node, ast.ImportFrom) else ""
            if isinstance(node, ast.ImportFrom) and node.level == 0 and modname in drop_modules:
                missing = [a.name for a in node.names if a.name != "*" and a.name not in all_defined]
                if missing:
                    log(f"  [inline] {kind}: imports {missing} from '{modname}' but nothing in the merged file defines them.")
                    return None
                continue
            (future if modname == "__future__" else hoisted).setdefault(ast.dump(node), "\n".join(lines[s:e + 1]))
    hoisted = _combine_from_imports(hoisted)
    module_title = module[:1].upper() + module[1:]
    if kind == "test":
        anal = [("test", pos_path, a[1], a[2], a[3], a[4]) for a in analysed[:1]] + \
               [("negative", neg_path, a[1], a[2], a[3], a[4]) for a in analysed[1:]]
        doc = (f'"""{module}: positive and negative tests in ONE test class.\n\n'
               f'Test data lives in src/banks/{bank}/testdata/{module_title}.xlsx\n"""\n')
        laid = _assemble_reference_layout(repo_root, bank, module, anal, dict(hoisted), dict(future), docstring=doc)
        return normalize_test_self_usage(laid, module, bank)[0]
    chunks = []
    for label, tree, lines, imps, others in analysed:
        if not others:
            chunks.append("")
            continue
        skip = set()
        for _n, s, e in imps:
            skip.update(range(s, e + 1))
        first, last = others[0][1], others[-1][2]
        chunks.append("\n".join(ln for idx, ln in enumerate(lines[first:last + 1], start=first) if idx not in skip).strip("\n"))
    first_node = ast.parse(pos_src).body[0] if pos_src.strip() else None
    doc = ""
    if first_node is not None and isinstance(first_node, ast.Expr) and isinstance(getattr(first_node, "value", None), ast.Constant) \
            and isinstance(first_node.value.value, str):
        doc = "\n".join(pos_src.split("\n")[first_node.lineno - 1:first_node.end_lineno]) + "\n"
    title = "NEGATIVE LOCATORS" if kind == "locators" else "NEGATIVE PAGE"
    banner = f"# {'=' * 66}\n# {title}\n# {'=' * 66}\n"
    return (doc + "\n".join(future.values()) + ("\n" if future else "") + "\n".join(hoisted.values())
            + "\n\n\n" + chunks[0] + "\n\n\n" + banner + chunks[1] + "\n").lstrip("\n")


def merge_negative_into_positive_files(repo_root: Path, bank: str, module: str, written: dict, log=print) -> bool:
    """INLINE layout: fold negative locators / page / test into the positive locators / page / test files (same file per
    kind). All three or none."""
    pos = {k: Path(written[k]) for k in ("locators", "page", "test") if written.get(k)}
    neg = {"locators": repo_root / "src" / "banks" / bank / "locators" / f"{module}_negative_locators.py",
           "page": repo_root / "src" / "common" / "pages" / module / f"{module}_negative_page.py",
           "test": repo_root / "src" / "testcase" / module / f"test_{module}_negative.py"}
    if len(pos) < 3 or not all(p.exists() for p in neg.values()) or not all(p.exists() for p in pos.values()):
        log("  [inline] skipped: the positive and negative files are not all present.")
        return False
    loc_pos, loc_neg = f"src.banks.{bank}.locators.{module}_locators", f"src.banks.{bank}.locators.{module}_negative_locators"
    page_pos, page_neg = f"src.common.pages.{module}.{module}_page", f"src.common.pages.{module}.{module}_negative_page"
    plan = {"locators": (set([loc_pos]), {}),
            "page": (set([page_pos]), {loc_neg: loc_pos}),
            "test": (set(), {page_neg: page_pos, loc_neg: loc_pos})}
    merged: dict[str, str] = {}
    try:
        for kind, (drop, rewrites) in plan.items():
            text = _merge_pair(kind, pos[kind], neg[kind], bank, module, repo_root, drop, rewrites, log)
            if text is None:
                log(f"  [inline] NOT merged ({kind}) - the three negative files stay separate; nothing was changed.")
                return False
            ast.parse(text)
            bad = find_nonexistent_src_import(text, repo_root)
            if bad:
                log(f"  [inline] NOT merged: the merged {kind} file would import '{bad}', which does not exist.")
                return False
            merged[kind] = text
        # every name imported from a positive module must exist in that module's MERGED text
        defined = {loc_pos: {n for node in ast.parse(merged["locators"]).body for n in
                             ([node.name] if isinstance(node, (ast.ClassDef, ast.FunctionDef)) else
                              [t.id for t in getattr(node, "targets", []) if isinstance(t, ast.Name)])},
                   page_pos: {n for node in ast.parse(merged["page"]).body for n in
                              ([node.name] if isinstance(node, (ast.ClassDef, ast.FunctionDef)) else
                               [t.id for t in getattr(node, "targets", []) if isinstance(t, ast.Name)])}}
        for kind, text in merged.items():
            for node in ast.parse(text).body:
                if isinstance(node, ast.ImportFrom) and node.module in defined:
                    missing = [a.name for a in node.names if a.name != "*" and a.name not in defined[node.module]]
                    if missing:
                        log(f"  [inline] NOT merged: the {kind} file imports {missing} from {node.module}, which will not define them.")
                        return False
        n_before = sum(len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", p.read_text(encoding="utf-8"), re.M))
                       for p in (pos["test"], neg["test"]))
        if n_before != len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", merged["test"], re.M)):
            log("  [inline] NOT merged: the test count changed while folding the negative tests in.")
            return False
    except Exception as exc:
        _log_exception("inline negative merge", exc)
        log("  [inline] NOT merged (see the error above) - the three negative files stay separate.")
        return False
    import shutil
    import time as _t
    bdir = repo_root / "debug_logs" / "backups" / f"{module}_negative_merge_{_t.strftime('%Y%m%d_%H%M%S')}"
    bdir.mkdir(parents=True, exist_ok=True)
    for kind in ("locators", "page", "test"):
        shutil.copy2(pos[kind], bdir / f"{pos[kind].name}.positive_only")
        pos[kind].write_text(merged[kind], encoding="utf-8")
        shutil.move(str(neg[kind]), str(bdir / neg[kind].name))
        log(f"  [inline] {kind}: positive + negative are now in {pos[kind]}")
    log(f"  [inline] the separate negative files were moved to {bdir} (nothing was deleted).")
    return True


# ======================================================================
# PER-FIELD NEGATIVE CASES (deterministic, so EVERY field gets its cases - not only what the AI happens to think of)
# ======================================================================
def _fact_for_column(col: str, facts: list[dict]) -> dict | None:
    want = _norm_tokens(col)
    best, best_score = None, 0.0
    for f in facts or []:
        have = _norm_tokens(re.sub(r"[*:]", " ", f.get("label", "")))
        if not want or not have:
            continue
        inter = len(want & have)
        score = 1.0 if want == have else (inter / len(want | have) if inter else 0.0)
        if score > best_score:
            best, best_score = f, score
    return best if best_score >= 0.6 else None


def synthesize_negative_rows(baseline: dict, facts: list[dict] | None, id_col: str | None = None,
                             mode: str = "add") -> list[dict]:
    """One block of negative rows PER FIELD of the form, derived from the live field facts (required / maxlength / type /
    options) and the valid baseline row: blank, too long, too short, letters / decimals / negative numbers in a numeric
    field, special characters, SQL / script injection text, spaces only, duplicate identifier, and the BIN-range rules
    (does not start with the BIN, low > high, length mismatch). mode='edit': the identifier selects the record to edit, so
    it is not a field under test. Identifying values use run-time tokens, never numbers."""
    facts = facts or []
    header = list(baseline.keys())
    id_col = id_col or detect_identifier_column(header)
    edit = mode == "edit"
    fields = [c for c in header if c.strip().lower().replace(" ", "") not in _STD_COLS and not (edit and c == id_col)]
    base = dict(baseline)
    for c, v in list(base.items()):                           # a negative row must never overwrite the remembered Add value
        if isinstance(v, str) and re.match(r"^\{\{\s*RANDOM", v.strip(), re.I):
            base[c] = re.sub(r"RANDOM", "FRESH", v.strip(), flags=re.I)
        elif isinstance(v, str) and re.match(r"^\{\{\s*LUHN\s*:", v.strip(), re.I):
            base[c] = re.sub(r"LUHN", "LUHN_FRESH", v.strip(), count=1, flags=re.I)
    if edit and id_col and _MODULE_HAS_ADD_SHEET:
        base[id_col] = "{{FROM_ADD}}"                         # the record Add created is the one being edited
    rows: list[dict] = []
    counter = {"n": 0}
    ranges = {c: range_kind(c, id_col) for c in header}
    sid_prefix = "NEGE" if edit else "NEG"
    d_prefix = "Edit - " if edit else ""
    N = range_length()

    def add(col: str, ntype: str, what: str, value: str, desc: str | None = None, extra: dict | None = None):
        counter["n"] += 1
        row = {c: "" for c in header}
        row.update(base)
        row[col] = value
        if extra:
            row.update(extra)
        if id_col and col == id_col and ntype != "Duplicate":          # ranges built FROM a blank / invalid BIN cannot resolve
            for rc, rk_ in ranges.items():
                if rk_ and str(row.get(rc, "")).startswith(("{{LOW", "{{HIGH")):
                    row[rc] = f"{{{{FRESH:{N}}}}}"
        row.update({"ScenarioID": f"{sid_prefix}-{counter['n']:03d}", "TestcaseID": f"{sid_prefix}-TC-{counter['n']:03d}",
                    "Description": desc or f"{d_prefix}{col} - {what}", "ExpectedMessage": "TBD-verify-message",
                    "Priority": "Medium", "NegativeType": ntype})
        rows.append(row)

    def numeric_len(v: str, default: int = 6) -> int:
        m = re.match(r"^\{\{\s*\w+\s*:\s*(\d+)", v or "")
        if m:
            return int(m.group(1))
        return len(v) if (v or "").isdigit() else default

    ranges = {c: range_kind(c, id_col) for c in fields}
    for col in fields:
        fact = _fact_for_column(col, facts)
        bval = str(base.get(col, "") or "")
        tag = (fact or {}).get("tag", "")
        ftype = (fact or {}).get("type", "")
        options = (fact or {}).get("options")
        is_choice = tag in ("select", "mat-select") or bool(options) or ftype in ("radio", "checkbox") or "role" in tag
        if ftype in ("radio", "checkbox"):
            continue
        is_range = bool(ranges.get(col))
        is_numeric = ftype in ("number", "tel") or bool(re.match(r"^\d+$", bval)) or bool(re.match(r"^\{\{\s*\w+\s*:[^}]*\}\}$", bval)) \
            or col == id_col or is_range
        maxlen = int((fact or {}).get("maxlength") or 0) if str((fact or {}).get("maxlength") or "").isdigit() else 0
        minlen = int((fact or {}).get("minlength") or 0) if str((fact or {}).get("minlength") or "").isdigit() else 0
        required = True if fact is None else bool(fact.get("required"))
        if required:                                           # an OPTIONAL select left empty is valid, so no negative row
            add(col, "Required", "left blank" if not is_choice else "nothing selected", "")
        if is_choice:
            continue
        n = maxlen or (numeric_len(bval) if col == id_col else (N if is_range else 0))
        if n:
            add(col, "MaxLength", f"longer than the maximum ({n + 1} characters)",
                f"{{{{FRESH:{n + 1}}}}}" if is_numeric else f"{{{{FRESH:{n + 1}:alpha}}}}")
        if minlen > 1:
            add(col, "MinLength", f"shorter than the minimum ({minlen - 1} characters)",
                f"{{{{FRESH:{minlen - 1}}}}}" if is_numeric else f"{{{{FRESH:{minlen - 1}:alpha}}}}")
        elif col == id_col and numeric_len(bval) > 1:
            add(col, "MinLength", f"shorter than the usual length ({numeric_len(bval) - 1} characters)",
                f"{{{{FRESH:{numeric_len(bval) - 1}}}}}")
        if is_numeric:
            add(col, "InvalidFormat", "letters in a numeric field", f"{{{{FRESH:{max(numeric_len(bval), 3)}:alpha}}}}")
            add(col, "InvalidFormat", "decimal number", "12.5")
            add(col, "InvalidFormat", "negative number", "-123")
        add(col, "SpecialCharacters", "special characters", "@#$%^&*")
        add(col, "Injection", "SQL injection text", "' OR '1'='1")
        add(col, "Injection", "script tag (XSS) text", "<script>alert(1)</script>")
        if not is_numeric:
            add(col, "OnlySpaces", "only spaces", "   ")
        if col == id_col and is_luhn_column(col) and os.environ.get("AI_LUHN_BIN", "1").strip() != "0":
            add(col, "InvalidFormat", "fails the Luhn check", f"{{{{LUHN_BAD:{max(numeric_len(bval), 6)}}}}}")
        if col == id_col and not edit:
            add(col, "Duplicate", "same value as an existing record (already exists)", "{{FROM_ADD}}")
    # ---- BIN range rules (the ranges are built from the BIN of the SAME row) ----
    low_cols = [c for c, k in ranges.items() if k == "low"]
    high_cols = [c for c, k in ranges.items() if k == "high"]
    if id_col and low_cols and high_cols:
        lo, hi = low_cols[0], high_cols[0]
        add(lo, "CrossField", "", f"{{{{HIGH:{id_col}:{N}}}}}", extra={hi: f"{{{{LOW:{id_col}:{N}}}}}"},
            desc=f"{d_prefix}{lo} / {hi} - low value greater than high value")
        add(lo, "RangeRule", f"does not start with the {id_col}", f"{{{{FRESH:{N}}}}}",
            desc=f"{d_prefix}{lo} - range does not start with the {id_col}")
        add(hi, "RangeRule", f"does not start with the {id_col}", f"{{{{FRESH:{N}}}}}",
            desc=f"{d_prefix}{hi} - range does not start with the {id_col}")
        add(lo, "RangeRule", "length differs from the high range", f"{{{{LOW:{id_col}:{max(N - 3, 8)}}}}}",
            desc=f"{d_prefix}{lo} / {hi} - low and high range lengths differ")
    elif low_cols or high_cols:
        pass
    else:                                                       # generic low > high on plain numeric pairs
        lows = [c for c in fields if re.search(r"\b(low|from|min|start)\b", c, re.I)]
        for lo_ in lows:
            stem = re.sub(r"\b(low|from|min|start)\b", "", lo_, flags=re.I).strip().lower()
            hi_ = next((c for c in fields if c != lo_ and re.search(r"\b(high|to|max|end)\b", c, re.I)
                        and re.sub(r"\b(high|to|max|end)\b", "", c, flags=re.I).strip().lower() == stem), None)
            lv, hv = str(base.get(lo_, "") or ""), str(base.get(hi_, "") or "") if hi_ else ""
            if hi_ and lv.isdigit() and hv.isdigit() and int(lv) != int(hv):
                add(lo_, "CrossField", "", hv, extra={hi_: lv}, desc=f"{d_prefix}{lo_} / {hi_} - low value greater than high value")
    return rows


def ensure_synth_rows_present(csv_text: str, synth_rows: list[dict]) -> tuple[str, int]:
    """After the AI wrote the Negative sheet: every synthesized per-field row must be in it. Missing ones (by Description)
    are appended, aligned to the AI's columns; IDs are kept unique. Returns (csv, rows added)."""
    import csv as _csv
    import io as _io
    reader = _csv.DictReader(_io.StringIO(csv_text))
    header = list(reader.fieldnames or [])
    rows = list(reader)
    if not header:
        return csv_text, 0
    if "NegativeType" not in header:
        header.append("NegativeType")
    have_desc = {(r.get("Description") or "").strip().lower() for r in rows}
    used_ids = {(r.get("ScenarioID") or "", r.get("TestcaseID") or "") for r in rows}
    added = 0
    for sr in synth_rows:
        if sr["Description"].strip().lower() in have_desc:
            continue
        new = {c: sr.get(c, "") for c in header}
        sid, tid = new.get("ScenarioID", ""), new.get("TestcaseID", "")
        while (sid, tid) in used_ids:
            tid += "-S"
        new["TestcaseID"] = tid
        used_ids.add((sid, tid))
        rows.append(new)
        have_desc.add(sr["Description"].strip().lower())
        added += 1
    out = _io.StringIO()
    w = _csv.DictWriter(out, fieldnames=header, lineterminator="\n", extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    return out.getvalue().rstrip("\n"), added


def _edit_negative_prompt(module: str, module_title: str) -> str:
    if not _SYNTH_EDIT_ROWS.get(module):
        return ""
    return (f"EDIT NEGATIVES are required too (the MANDATORY rows above marked [Edit]): also produce "
            f"'### FILE: {module}_testdata_negativeedit.csv' (the 'NegativeEdit' sheet, same 5 first columns), a negative page "
            f"method edit_{module}_negative(self, bank, data) (search the record by its identifier, click the edit icon, put the "
            f"bad value in the field under test, click the final button, assert ExpectedMessage) and a test "
            f"test_edit_{module}_negative that loads _rows_NegativeEdit = ExcelUtil.get_sheet(\"{module_title}\", \"NegativeEdit\"). "
            f"The Add negatives stay in the 'Negative' sheet / test_add_{module}_negative.\n")


def _split_facts(field_facts) -> tuple[list[dict], list[dict]]:
    if isinstance(field_facts, dict):
        return list(field_facts.get("add") or []), list(field_facts.get("edit") or [])
    return list(field_facts or []), []


_SYNTH_EDIT_ROWS: dict[str, list[dict]] = {}


def _prepare_synth(repo_root: Path, bank: str, module: str, baseline: dict, facts, log=print) -> list[dict]:
    """Builds the per-field rows (Add negatives; Edit negatives are kept in _SYNTH_EDIT_ROWS) and registers them as seeds, so
    even a failed AI call still leaves them in the workbook."""
    add_facts, edit_facts = _split_facts(facts)
    _SYNTH_EDIT_ROWS.pop(module, None)
    synth: list[dict] = []
    seeds = _NEGATIVE_SEED_ROWS.setdefault(module, [])
    seeds[:] = [x for x in seeds if not str(x[2][0] if x[2] else "").startswith(("NEG-", "NEGE-"))]    # no duplicates on re-run
    if baseline:
        try:
            synth = synthesize_negative_rows(baseline, add_facts)
        except Exception as exc:
            _log_exception("synthesizing per-field negative rows", exc)
        if synth:
            hdr = list(baseline.keys()) + (["NegativeType"] if "NegativeType" not in baseline else [])
            seeds.extend(("Add", hdr, [r.get(c, "") for c in hdr]) for r in synth)
            log(f"  [negative] derived {len(synth)} Add negative case(s) from the form's real constraints "
                f"({len({r['Description'].split(' - ')[0] for r in synth})} field(s)).")
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    try:
        edit_base = read_first_testdata_row(xlsx, sheet_name="Edit") if xlsx.exists() else {}
    except Exception:
        edit_base = {}
    if edit_base:
        try:
            erows = synthesize_negative_rows(edit_base, edit_facts or add_facts, mode="edit")
        except Exception as exc:
            _log_exception("synthesizing Edit negative rows", exc)
            erows = []
        if erows:
            _SYNTH_EDIT_ROWS[module] = erows
            hdr = list(edit_base.keys()) + (["NegativeType"] if "NegativeType" not in edit_base else [])
            seeds.extend(("Edit", hdr, [r.get(c, "") for c in hdr]) for r in erows)
            log(f"  [negative] derived {len(erows)} Edit negative case(s).")
    return synth


def _lenient_blocks_separate(reply: str, module: str) -> str:
    """AI forgot the '### FILE:' markers: classify the fenced python blocks by the class they define."""
    fences = re.findall(r"```([A-Za-z]*)\n(.*?)```", reply or "", re.S)
    out = []
    for lang, body in fences:
        if lang.lower() == "csv" or body.lstrip().startswith("ScenarioID"):
            out.append(f"### FILE: {module}_testdata_negative.csv\n{body}")
        elif re.search(r"^class\s+Test\w*", body, re.M):
            out.append(f"### FILE: src/testcase/{module}/test_{module}_negative.py\n{body}")
        elif re.search(r"^class\s+\w*Page\w*\(", body, re.M):
            out.append(f"### FILE: src/common/pages/{module}/{module}_negative_page.py\n{body}")
        elif re.search(r"^class\s+\w*Locators\w*\(", body, re.M):
            out.append(f"### FILE: src/banks/x/locators/{module}_negative_locators.py\n{body}")
    return "\n".join(out) if out else reply


def _negative_ai_reply(system_prompt: str, prompt: str, module: str, log=print) -> str:
    """One AI call for the negative step WITH real diagnostics: an exception, an empty reply and a wrong-format reply are
    each reported as such (never the vague 'returned nothing usable'); markers are recovered when merely forgotten."""
    try:
        reply = ask_ai(system_prompt, prompt)
    except Exception as exc:
        reply = ""
        log(f"  [negative] the AI call RAISED {type(exc).__name__}: {str(exc)[:300]}")
    if reply and "### FILE:" not in reply:
        fixed = _lenient_blocks_separate(reply, module)
        if "### FILE:" in fixed:
            log("  [negative] the AI forgot the '### FILE:' markers - recovered the code/CSV blocks anyway.")
            return fixed
        log(f"  [negative] the AI replied but not in the expected format. Start of its reply: {reply[:400]!r}")
        return ""
    if not reply:
        log("  [negative] the AI call returned an EMPTY reply (API error / timeout / rate limit - look for an error line "
            "just above; try AI_TIMEOUT_SECONDS=600 in .env).")
    return reply


def rewrite_negative_imports(repo_root: Path, bank: str, module: str, merged_dest: Path, log=print) -> int:
    """After the POSITIVE locators/page/test were merged into ONE file, the three separate negative files must import the
    positive classes from that merged module instead of the (now moved) separate positive modules."""
    merged_mod = f"src.testcase.{module}.{merged_dest.stem}"
    old_mods = {f"src.banks.{bank}.locators.{module}_locators", f"src.common.pages.{module}.{module}_page",
                f"src.testcase.{module}.test_{module}"}
    try:
        merged_names = {n for node in ast.parse(merged_dest.read_text(encoding="utf-8")).body
                        for n in ([node.name] if isinstance(node, (ast.ClassDef, ast.FunctionDef)) else
                                  [t.id for t in getattr(node, "targets", []) if isinstance(t, ast.Name)])}
    except Exception:
        merged_names = set()
    files = [repo_root / "src" / "banks" / bank / "locators" / f"{module}_negative_locators.py",
             repo_root / "src" / "common" / "pages" / module / f"{module}_negative_page.py",
             repo_root / "src" / "testcase" / module / f"test_{module}_negative.py"]
    changed_files = 0
    for f in files:
        if not f.exists():
            continue
        src = f.read_text(encoding="utf-8")
        did = {"n": 0}

        def repl(m):
            if m.group(2) in old_mods:
                did["n"] += 1
                names = [n.split(" as ")[0].strip() for n in m.group(3).split(",")]
                missing = [n for n in names if merged_names and n not in merged_names]
                if missing:
                    log(f"  [negative-imports] WARNING: {f.name} imports {missing} which the merged file does not define.")
                return f"{m.group(1)}from {merged_mod} import {m.group(3).strip()}"
            return m.group(0)
        new = re.sub(r"^([ \t]*)from (src\.[\w.]+) import ([^()\n#]+?)[ \t]*$", repl, src, flags=re.M)
        if did["n"]:
            ast.parse(new)
            f.write_text(new, encoding="utf-8")
            changed_files += 1
            log(f"  [negative-imports] {f.name}: now imports the positive classes from {merged_mod}")
    return changed_files


# ======================================================================
# LOCATOR QUOTING SAFETY  (real bug: the locator auto-heal wrote  menu_x = "span:has-text("BIN management")"
# - double quotes inside a double-quoted string = SyntaxError, which broke the whole module, the one-file merge and
# everything that reads locators.py)
# ======================================================================
def safe_locator_value(value: str) -> str:
    """A selector text that can sit inside  attr = "<here>"  without breaking Python: inner double quotes become single
    quotes (Playwright/XPath treat them the same); only if the selector already holds BOTH kinds are they escaped."""
    v = (value or "").strip()
    if '"' not in v and "\\" not in v:
        return v
    if "\\" not in v and "'" not in v:
        return v.replace('"', "'")
    return v.replace("\\", "\\\\").replace('"', '\\"')


def repair_python_string_lines(path: Path, log=print) -> int:
    """If a generated .py file does not parse because a  name = "...."  line has unescaped inner double quotes, fix just
    those lines. Returns how many lines were fixed (0 = nothing wrong / not fixable)."""
    try:
        src = path.read_text(encoding="utf-8")
        ast.parse(src)
        return 0
    except SyntaxError:
        pass
    except Exception:
        return 0
    fixed, out = 0, []
    for line in src.split("\n"):
        m = re.match(r'^(\s*\w+\s*=\s*)"(.*)"(\s*(?:#.*)?)$', line)
        if m and '"' in m.group(2):
            line = f'{m.group(1)}"{safe_locator_value(m.group(2))}"{m.group(3)}'
            fixed += 1
        out.append(line)
    new = "\n".join(out)
    try:
        ast.parse(new)
    except SyntaxError as exc:
        log(f"  [repair] {path.name} still has a syntax error after quote repair (line {exc.lineno}: "
            f"{(exc.text or '').strip()[:100]}) - fix that line by hand.")
        return 0
    path.write_text(new, encoding="utf-8")
    log(f"  [repair] fixed {fixed} line(s) with unescaped quotes in {path.name} (it did not parse before).")
    return fixed


def _lenient_blocks(reply: str) -> str:
    """When the AI forgot the '### FILE:' markers but did return a python code block and a CSV block, add the markers."""
    fences = re.findall(r"```([A-Za-z]*)\n(.*?)```", reply or "", re.S)
    code = next((b for lang, b in fences if lang.lower() in ("python", "py") or re.search(r"^class\s+\w+", b, re.M)), None)
    csv_b = next((b for lang, b in fences if lang.lower() == "csv" or b.lstrip().startswith("ScenarioID")), None)
    if not code:
        return reply
    return f"### FILE: __module___negative_test.py\n{code}\n" + (f"### FILE: __module___testdata_negative.csv\n{csv_b}\n" if csv_b else "")


# ======================================================================
# RUNTIME DATA  -  the identifying value (BIN ...) is generated by the ADD test at run time and reused by View / Edit /
# Delete / ChangeStatus; the Excel sheets hold TOKENS, never a literal number:
#     Add sheet           BIN = {{RANDOM:6}}      (6 random digits, remembered as the latest BIN)
#     View/Edit/Delete    BIN = {{FROM_ADD}}      (the BIN the Add test generated)
#     negative rows       BIN = {{FRESH:7}}       (random digits that are NOT remembered, e.g. "exceeds max length")
# Every test calls RuntimeData.resolve(data, module, bank) first, so page code only ever sees real values.
# ======================================================================
RUNTIME_DATA_MARKER = "# runtime_data v3 (generated by the test generator)"
RUNTIME_DATA_SOURCE = '''# runtime_data v3 (generated by the test generator)
"""Run-time test data shared between tests.

Test-data sheets hold NO literal identifying numbers. A cell may hold a TOKEN instead:
    {{RANDOM:6}}        generate 6 random digits NOW and REMEMBER them as the latest value of this column
    {{RANDOM:8:alnum}}  same with letters+digits (charsets: digits (default), alpha, alnum)
    {{LUHN:6}}          a random 6-digit number that PASSES the Luhn check; REMEMBERED as the latest value (the BIN of Add)
    {{LUHN_FRESH:6}}    same, but NOT remembered
    {{LUHN_BAD:6}}      a 6-digit number that FAILS the Luhn check (negative case)
    {{FRESH:7}}         generate 7 random digits but do NOT remember them (negative / not-found cases)
    {{FROM_ADD}}        use the value the Add test generated for this column
    {{LOW:BIN:19}}      the BIN of this row padded with zeros to 19 digits   (e.g. BIN 453634 -> 4536340000000000000)
    {{HIGH:BIN:19}}     the BIN of this row padded with nines to 19 digits   (e.g. BIN 453634 -> 4536349999999999999)
                        so the BIN is always INSIDE the range [low, high]
Every test calls RuntimeData.resolve(data, module, bank) first, so the page code only ever sees real values.
The remembered values live in runtime_data.json at the repo root (add it to .gitignore).
"""
import json
import random
import re
import string
import threading
from pathlib import Path

_FILE = Path(__file__).resolve().parents[3] / "runtime_data.json"
_LOCK = threading.Lock()
_TOKEN = re.compile(r"^\\{\\{\\s*([A-Za-z_]+)\\s*(?::\\s*(\\d+))?\\s*(?::\\s*([A-Za-z]+))?\\s*\\}\\}$")
_DERIVED = re.compile(r"^\\{\\{\\s*(LOW|HIGH)\\s*:\\s*([^:}]+?)\\s*(?::\\s*(\\d+))?\\s*\\}\\}$", re.I)


class RuntimeData:
    @staticmethod
    def _load() -> dict:
        try:
            return json.loads(_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}

    @classmethod
    def set(cls, bank: str, module: str, column: str, value: str) -> None:
        with _LOCK:
            data = cls._load()
            data[f"{bank}.{module}.{column}"] = value
            _FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

    @classmethod
    def get(cls, bank: str, module: str, column: str, default=None):
        return cls._load().get(f"{bank}.{module}.{column}", default)

    @classmethod
    def reset(cls) -> None:
        with _LOCK:
            if _FILE.exists():
                _FILE.unlink()

    @staticmethod
    def _luhn_digit(payload: str) -> int:
        total = 0
        for i, ch in enumerate(reversed(payload)):
            d = int(ch)
            if i % 2 == 0:
                d *= 2
                if d > 9:
                    d -= 9
            total += d
        return (10 - total % 10) % 10

    @classmethod
    def _luhn(cls, length: int, valid: bool = True) -> str:
        length = max(int(length or 6), 2)
        body = random.choice("123456789") + "".join(random.choices(string.digits, k=length - 2))
        check = cls._luhn_digit(body)
        return body + str(check if valid else (check + 1) % 10)

    @staticmethod
    def _generate(length: int, charset: str) -> str:
        length = max(int(length or 6), 1)
        charset = (charset or "digits").lower()
        if charset == "alpha":
            return "".join(random.choices(string.ascii_uppercase, k=length))
        if charset == "alnum":
            return "".join(random.choices(string.ascii_uppercase + string.digits, k=length))
        return random.choice("123456789") + "".join(random.choices(string.digits, k=length - 1))

    @classmethod
    def resolve(cls, data: dict, module: str, bank: str) -> dict:
        """Returns a COPY of the row with every {{TOKEN}} cell replaced by its real value."""
        out = dict(data)
        for column, cell in data.items():
            if not isinstance(cell, str):
                continue
            m = _TOKEN.match(cell.strip())
            if not m:
                continue
            kind, length, charset = m.group(1).upper(), m.group(2), m.group(3)
            if kind == "RANDOM":
                out[column] = cls._generate(length, charset)
                cls.set(bank, module, column, out[column])
            elif kind == "LUHN":
                out[column] = cls._luhn(length)
                cls.set(bank, module, column, out[column])
            elif kind == "LUHN_FRESH":
                out[column] = cls._luhn(length)
            elif kind == "LUHN_BAD":
                out[column] = cls._luhn(length, valid=False)
            elif kind == "FRESH":
                out[column] = cls._generate(length, charset)
            elif kind in ("FROM_ADD", "ADD", "SAVED"):
                value = cls.get(bank, module, column)
                if value is None:
                    raise RuntimeError(
                        f"No '{column}' has been generated yet for {module}/{bank}: the Add test must run first "
                        f"(it creates the {column} that View/Edit/Delete then search for).")
                out[column] = value
        # derived values (a BIN range is built FROM the BIN of the same row, so they are resolved last)
        for column, cell in data.items():
            if not isinstance(cell, str):
                continue
            m = _DERIVED.match(cell.strip())
            if not m:
                continue
            kind, source, length = m.group(1).upper(), m.group(2).strip(), m.group(3)
            key = next((k for k in out if str(k).strip().lower() == source.lower()), None)
            if key is None or not str(out[key]).strip():
                raise RuntimeError(f"{{{{{kind}:{source}}}}} in column '{column}' needs a value in column '{source}' of the same row.")
            base = str(out[key]).strip()
            total = max(int(length or 19), len(base))
            out[column] = base + ("0" if kind == "LOW" else "9") * (total - len(base))
        return out
'''


def runtime_data_enabled() -> bool:
    return os.environ.get("AI_RUNTIME_DATA", "1").strip().lower() not in ("0", "false", "no")


def ensure_runtime_data_util(repo_root: Path, log=print) -> Path | None:
    """Creates src/common/utilities/runtime_data.py once (never overwrites a file that is not ours)."""
    p = repo_root / "src" / "common" / "utilities" / "runtime_data.py"
    try:
        if p.exists():
            head = p.read_text(encoding="utf-8", errors="ignore")[:200]
            if "# runtime_data v" in head and RUNTIME_DATA_MARKER not in head:          # ours, but an older version
                bak = repo_root / "debug_logs" / "backups"
                bak.mkdir(parents=True, exist_ok=True)
                (bak / "runtime_data.py.v1").write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
                p.write_text(RUNTIME_DATA_SOURCE, encoding="utf-8")
                log(f"  Upgraded {p} to the new version (adds the BIN-range tokens).")
            return p
        p.parent.mkdir(parents=True, exist_ok=True)
        (p.parent / "__init__.py").touch(exist_ok=True)
        p.write_text(RUNTIME_DATA_SOURCE, encoding="utf-8")
        log(f"  Created the run-time data helper {p} (the BIN generated by Add is shared with View/Edit/Delete).")
        return p
    except Exception as exc:
        _log_exception("creating runtime_data.py", exc)
        return None


def fix_runtime_resolve_calls(src: str, module: str, bank: str) -> str:
    """The AI sometimes writes  RuntimeData.resolve(data, "Binmanagement", self.bank_name)  as a bare statement. resolve() returns
    a COPY, so the tokens ({{LUHN:6}}, {{FROM_ADD}} ...) would never be replaced - and the module key must be the SAME lower-case
    name in every test, otherwise View/Edit/Delete cannot find the BIN that Add stored. Rewrites every such call to
        data = RuntimeData.resolve(data, "<module>", BANK_NAME)"""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src
    lines = src.split("\n")
    bank_ref = "BANK_NAME" if re.search(r"^BANK_NAME\s*=", src, re.M) else repr(bank)

    def is_resolve(n) -> bool:
        return isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "resolve" \
            and isinstance(n.func.value, ast.Name) and n.func.value.id == "RuntimeData" and len(n.args) >= 1

    edits: list[tuple[int, int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr) and is_resolve(node.value):
            first = ast.get_source_segment(src, node.value.args[0]) or "data"
            target = first if re.fullmatch(r"[A-Za-z_]\w*", first) else "data"
            indent = " " * node.col_offset
            edits.append((node.lineno - 1, node.end_lineno - 1, f'{indent}{target} = RuntimeData.resolve({first}, "{module}", {bank_ref})'))
        elif isinstance(node, ast.Assign) and is_resolve(node.value) and node.lineno == node.end_lineno:
            first = ast.get_source_segment(src, node.value.args[0]) or "data"
            call = ast.get_source_segment(src, node.value)
            new_call = f'RuntimeData.resolve({first}, "{module}", {bank_ref})'
            if call and call != new_call and call in lines[node.lineno - 1]:
                edits.append((node.lineno - 1, node.lineno - 1, lines[node.lineno - 1].replace(call, new_call, 1)))
    if not edits:
        return src
    for a, b, rep in sorted(edits, reverse=True):
        lines[a:b + 1] = [rep]
    out = "\n".join(lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return src
    return out


def inject_runtime_resolution(src: str, module: str, bank: str) -> str:
    """Adds  data = RuntimeData.resolve(data, "<module>", BANK_NAME)  as the FIRST statement of every test that takes a
    `data` row (and the import), so {{RANDOM}} / {{FROM_ADD}} tokens are replaced at run time. Idempotent."""
    if not runtime_data_enabled():
        return src
    src = fix_runtime_resolve_calls(src, module, bank)
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src
    lines = src.split("\n")
    bank_ref = "BANK_NAME" if re.search(r"^BANK_NAME\s*=", src, re.M) else repr(bank)
    inserts: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_") \
                and any(a.arg == "data" for a in node.args.args):
            if "RuntimeData.resolve" in "\n".join(lines[node.lineno - 1:node.end_lineno]):
                continue
            idx = 0
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(getattr(first, "value", None), ast.Constant) \
                    and isinstance(first.value.value, str) and len(node.body) > 1:
                idx = 1
            target = node.body[idx]
            inserts.append((target.lineno - 1, " " * target.col_offset +
                            f'data = RuntimeData.resolve(data, "{module}", {bank_ref})'))
    if not inserts:
        return src
    for at, text in sorted(inserts, reverse=True):
        lines.insert(at, text)
    out = "\n".join(lines)
    if "import RuntimeData" not in out:
        imp = "from src.common.utilities.runtime_data import RuntimeData"
        last_imp = [n for n in ast.parse(out).body if isinstance(n, (ast.Import, ast.ImportFrom))]
        out_lines = out.split("\n")
        out_lines.insert(last_imp[-1].end_lineno if last_imp else 0, imp)
        out = "\n".join(out_lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return src
    return out


_ID_HINTS = ["bin", "merchantid", "merchant id", "ip", "code", "id", "number", "account", "mobile", "phone",
             "username", "email", "name"]
_STD_COLS = {"scenarioid", "testcaseid", "description", "expectedmessage", "expectedmessage1", "priority",
             "negativetype"}


def detect_identifier_column(header: list[str]) -> str | None:
    """The column a person searches/edits/deletes the record BY (BIN, Merchant ID, Name ...). AI_IDENTIFIER_COLUMN
    forces it; otherwise the best hint match, preferring the SHORTEST name (BIN over 'BIN low range')."""
    forced = os.environ.get("AI_IDENTIFIER_COLUMN", "").strip().lower()
    if forced:
        for col in header:
            if col.strip().lower() == forced:
                return col
    best = None
    for col in header:
        low = col.strip().lower()
        if low.replace(" ", "") in _STD_COLS:
            continue
        for rank, hint in enumerate(_ID_HINTS):
            if re.search(rf"\b{re.escape(hint)}\b", low):
                cand = (rank, len(low), col)
                best = cand if best is None or cand < best else best
                break
    return best[2] if best else None


def range_length() -> int:
    """BIN range values are 19 digits (a card number is up to 19 digits): BIN + zeros .. BIN + nines."""
    try:
        return max(int(os.environ.get("AI_RANGE_LENGTH", "19")), 1)
    except ValueError:
        return 19


def ranges_follow_identifier(id_label: str | None) -> bool:
    """Low / high range columns are BUILT FROM the identifier only for card-prefix identifiers (a BIN: low = BIN + zeros, high =
    BIN + nines). Any other module keeps the range values as they are, unless you name its identifier in AI_RANGE_IDENTIFIERS
    (e.g. AI_RANGE_IDENTIFIERS=bin,merchant). Default = AI_LUHN_COLUMNS (bin)."""
    hints = os.environ.get("AI_RANGE_IDENTIFIERS", "").strip() or os.environ.get("AI_LUHN_COLUMNS", "bin")
    wanted = {h.strip().lower() for h in hints.split(",") if h.strip()}
    return bool(id_label) and bool(wanted & _norm_tokens(id_label))


def range_kind(col: str, id_label: str | None = None) -> str | None:
    """'BIN low range' -> 'low', 'BIN high range' -> 'high' (a range column built from the identifier), else None."""
    low = col.strip().lower()
    if id_label:     # only a range that carries the identifier's name ('BIN low range' for 'BIN'); 'Amount low range' is unrelated
        if not ranges_follow_identifier(id_label):
            return None
        if not (_norm_tokens(id_label) <= _norm_tokens(col)) or _norm_tokens(col) == _norm_tokens(id_label):
            return None
    elif "range" not in low:
        return None
    if re.search(r"\b(low|from|min|start)\b", low):
        return "low"
    if re.search(r"\b(high|to|max|end)\b", low):
        return "high"
    return None


_MODULE_HAS_ADD_SHEET = True


def apply_identifier_placeholders(csv_text: str, sheet: str, module: str) -> tuple[str, int]:
    """Replaces the LITERAL identifying numbers in one testdata CSV by run-time tokens (see the block comment above).
    Add: positive rows -> {{RANDOM:n}}.  Other sheets: positive rows -> {{FROM_ADD}}.  Negative rows keep their intent:
    duplicates -> {{FROM_ADD}}, numeric / not-found values -> {{FRESH:n}}. Returns (csv, cells replaced)."""
    if not runtime_data_enabled():
        return csv_text, 0
    if not _MODULE_HAS_ADD_SHEET:             # update-only module: no Add creates a record, so nothing to remember / FROM_ADD
        return csv_text, 0
    import csv as _csv
    import io as _io
    reader = _csv.DictReader(_io.StringIO(csv_text))
    header = reader.fieldnames or []
    col = detect_identifier_column(list(header))
    if not col:
        return csv_text, 0
    rows = list(reader)
    is_add = sheet.strip().lower() == "add"
    changed = 0
    for row in rows:
        val = (row.get(col) or "").strip()
        if not val or val.startswith("{{"):
            continue
        desc, msg = row.get("Description") or "", row.get("ExpectedMessage") or ""
        both = f"{desc} {msg}"
        is_neg = (bool(_NEG_DESC_RE.search(desc)) or bool(_NEG_MSG_RE.search(msg))) and not _POS_MSG_RE.search(msg)
        # the generated value has the SHAPE of the literal: digits -> digits, letters (a name, spaces allowed) -> letters,
        # letters + digits -> letters + digits. A name is never turned into a number.
        compact = re.sub(r"[\s\-_.]+", "", val)
        if compact.isdigit():
            n, charset = len(val), ""
        elif compact.isalpha():
            n, charset = min(max(len(compact), 8), 20), ":alpha"          # 8+ letters: random names must not collide
        elif compact.isalnum():
            n, charset = min(max(len(compact), 8), 20), ":alnum"
        else:
            n, charset = 8, ":alnum"
        if re.search(r"duplicate|already exists", both, re.I):
            row[col] = "{{FROM_ADD}}"                           # "the record that Add created, again"
        elif re.search(r"not\s*found|non-?existent|does not exist|doesn.?t exist|unknown|no record|no data", both, re.I):
            row[col] = f"{{{{FRESH:{n}}}}}"                     # "a record that does not exist"
        elif not is_neg:
            if is_add and val.isdigit() and n == 6 and is_luhn_column(col) and os.environ.get("AI_LUHN_BIN", "1").strip() != "0":
                row[col] = "{{LUHN:6}}"                          # the BIN of Add: random AND Luhn-valid
            else:
                row[col] = f"{{{{RANDOM:{n}{charset}}}}}" if is_add else "{{FROM_ADD}}"
        elif val.isdigit():
            row[col] = f"{{{{FRESH:{n}}}}}"                     # numeric boundary value: same LENGTH, random digits
        else:
            continue                                            # a non-numeric literal (letters, spaces) is not an identifying number
        changed += 1
    # ---- ranges are GENERATED FROM the identifier of the same row: low = BIN + zeros, high = BIN + nines ----
    n_rng = range_length()
    for row in rows:
        desc = f"{row.get('Description') or ''} {row.get('ExpectedMessage') or ''}"
        for rc in header:
            kind = range_kind(rc, col)
            val = (row.get(rc) or "").strip()
            if not kind or not val or val.startswith("{{") or not val.isdigit():
                continue
            if re.search(r"greater|higher|swap|revers|less than|smaller", desc, re.I):
                kind = "high" if kind == "low" else "low"          # "low greater than high": the two are swapped
            row[rc] = f"{{{{{kind.upper()}:{col}:{n_rng}}}}}"
            changed += 1
    out = _io.StringIO()
    w = _csv.DictWriter(out, fieldnames=header, lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return out.getvalue().rstrip("\n"), changed


_ROW_XPATH = "//*[self::tr or self::mat-row or @role='row'][.//*[normalize-space()='{ph}']]"
_LOWER = "translate({x},'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')"
_MISSING_ROW_RE = re.compile(r"^(row_by_\w+|\w+_(?:for|in)_row|row_\w+)$")


def synthesize_missing_row_locators(locators_path: Path, page_path: Path | None, test_path: Path | None, log=print) -> list[str]:
    """The generated page / test sometimes call parametrised ROW locators (loc.row_by_bin, loc.edit_button_for_row ...) that
    the locators class never defines -> AttributeError at run time. Defines them (a template / method that matches how the
    code CALLS it) so nothing crashes; the dry run then verifies the real icons. Returns the names that were added."""
    try:
        loc_src = locators_path.read_text(encoding="utf-8")
        tree = ast.parse(loc_src)
    except Exception:
        return []
    used_src = "".join(_read_text(p) for p in (page_path, test_path) if p)
    defined = set(re.findall(r"^\s{4,}(\w+)\s*=", loc_src, re.M)) | set(re.findall(r"^\s{4,}(?:async\s+)?def\s+(\w+)\s*\(", loc_src, re.M))
    referenced = set(re.findall(r"(?:\bloc\.|BANK_LOCATORS\[[^\]]+\]\.)(\w+)", used_src))
    missing = sorted(n for n in referenced - defined if _MISSING_ROW_RE.match(n))
    cls = next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name.endswith("Locators")), None) or \
        next((n for n in tree.body if isinstance(n, ast.ClassDef)), None)
    if not missing or cls is None:
        return []
    lines = loc_src.split("\n")
    add_lines: list[str] = []
    for name in missing:
        action = next((a for a, words in _ROW_ACTION_WORDS.items() if any(w in name.lower() for w in words)), None)
        if action and not name.lower().startswith("row_by"):
            _attrs = "concat(@id,' ',@title,' ',@aria-label,' ',@class)"
            conds = " or ".join(f"contains({_LOWER.format(x=_attrs)},'{w}')" for w in _ROW_ACTION_WORDS[action])
            body = _ROW_XPATH + "//*[" + conds + "]"
        else:
            body = _ROW_XPATH
        m_call = re.search(rf"\bloc\.{name}\s*\(([^)]*)\)", used_src)
        m_fmt = re.search(rf"\bloc\.{name}\s*\.format\(([^)]*)\)", used_src)
        if m_call:
            n_args = max(len([a for a in m_call.group(1).split(",") if a.strip()]), 1)
            params = ", ".join(["value"] + [f"extra{k}" for k in range(1, n_args)])
            add_lines += ["", "    @staticmethod", f"    def {name}({params}):",
                          f"        return f\"{body.replace('{ph}', '{value}')}\""]
        else:
            kw = re.findall(r"(\w+)\s*=", m_fmt.group(1)) if m_fmt else []
            ph = kw[0] if kw else "0"
            add_lines += ["", f"    # template: use {name}.format(<row value>)  (added because the generated code calls it)",
                          f"    {name} = \"{body.replace('{ph}', '{' + ph + '}')}\""]
    at = cls.end_lineno
    new_src = "\n".join(lines[:at] + add_lines + lines[at:])
    try:
        ast.parse(new_src)
    except SyntaxError:
        return []
    locators_path.write_text(new_src, encoding="utf-8")
    log(f"  Added {len(missing)} missing row locator(s) the page/test call but the locators class never defined: {missing}")
    return missing


# ======================================================================
# NEGATIVE DRY RUN: the negative rows are exercised against the LIVE portal like Add / View / Edit / Delete are.
# For every row (Add negatives -> 'Negative' sheet, Edit negatives -> 'NegativeEdit' sheet): open the form, put the bad
# value into the field under test (all other fields valid), blur the fields, and read the REAL validation message the portal
# shows. Messages replace 'TBD-verify-message' in the workbook; rows where the portal shows nothing are flagged.
# Nothing is submitted, except 'Duplicate' rows (they must fail) - AI_NEGATIVE_DRYRUN_SUBMIT=all also submits the others.
# ======================================================================
_ERRORS_JS = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const out = [];
  for (const err of document.querySelectorAll('mat-error, .mat-mdc-form-field-error, .error-message, .invalid-feedback')) {
    if (!vis(err)) continue;
    const ff = err.closest('mat-form-field,.mat-mdc-form-field,.form-group,div');
    const lab = ff ? ff.querySelector('mat-label,label') : null;
    out.push({label: lab ? (lab.innerText || '').replace(/[*:]/g, ' ').replace(/\s+/g, ' ').trim() : '',
              text: (err.innerText || '').replace(/\s+/g, ' ').trim()});
  }
  const btn = [...document.querySelectorAll('button')].filter(b => vis(b) && /send|submit|save|approval/i.test(b.innerText || ''));
  return {errors: out.filter(e => e.text), submit_disabled: btn.length ? btn.every(b => b.disabled || b.getAttribute('aria-disabled') === 'true') : null};
}
"""


def _read_sheet_rows(xlsx: Path, sheet: str) -> tuple[list[str], list[dict]]:
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    if sheet not in wb.sheetnames:
        wb.close()
        return [], []
    ws = wb[sheet]
    it = ws.iter_rows(values_only=True)
    header = [str(c).strip() if c is not None else "" for c in next(it, [])]
    rows = [{h: ("" if v is None else str(v)) for h, v in zip(header, r)} for r in it if any(v not in (None, "") for v in r)]
    wb.close()
    return header, rows


def _update_expected_messages(xlsx: Path, sheet: str, found: dict[str, str], overwrite: bool = False) -> int:
    """Writes the captured messages into ExpectedMessage (only where it is still TBD-verify-message; overwrite=True replaces any)."""
    import openpyxl
    wb = openpyxl.load_workbook(xlsx)
    ws = wb[sheet]
    hdr = {str(c.value).strip(): i for i, c in enumerate(ws[1], start=1) if c.value is not None}
    ci_id, ci_msg = hdr.get("TestcaseID"), hdr.get("ExpectedMessage")
    n = 0
    if ci_id and ci_msg:
        for r in range(2, ws.max_row + 1):
            tid = str(ws.cell(r, ci_id).value or "")
            if tid in found and (overwrite or "TBD-verify-message" in str(ws.cell(r, ci_msg).value or "")):
                ws.cell(r, ci_msg).value = found[tid]
                n += 1
    if n:
        wb.save(xlsx)
    wb.close()
    return n


def _scenario_prefix(scenario: str) -> str:
    """The Edit scenario up to (not including) its first field step - i.e. nav + search + 'click the edit icon'."""
    keep = []
    for clause in _split_scenario_clauses(scenario):
        if _FILL_RE.match(clause) or _FILL_IN_RE.match(clause) or _SELECT_RE.match(clause) or _CHECK_RE.match(clause) \
                or _LEAVE_RE.match(clause) or _ASSERT_RE.match(clause):
            break
        m = _CLICK_RE.match(clause)
        if m and _FINALIZE_CLICK_RE.search(m.group("target")) and not _row_action_of(m.group("target"), clause):
            break
        keep.append(clause)
    return ". ".join(keep)


_LOGIN_MESSAGE_RE = re.compile(r"\b(username|user name|password|captcha|otp)\b", re.I)


def _on_login_page(page) -> bool:
    """True when a visible password input is on the page (the SPA fell back to the login screen)."""
    for fr in _frames(page):
        try:
            pw = fr.locator("input[type=password]")
            if pw.count() and pw.first.is_visible():
                return True
        except Exception:
            continue
    return False


def _field_error_text(loc) -> str:
    """The validation message that belongs to THIS field (its own mat-form-field), never a message from elsewhere on the page."""
    try:
        return loc.first.evaluate("""el => { const ff = el.closest('mat-form-field,.mat-mdc-form-field,.form-group');
            const e = ff && ff.querySelector('mat-error, .mat-mdc-form-field-error, .invalid-feedback, .error-message');
            return e ? (e.innerText || '').replace(/\\s+/g, ' ').trim() : ''; }""") or ""
    except Exception:
        return ""


def _reset_suspicious_messages(xlsx: Path, sheet: str, header: list[str], log=print) -> int:
    """A previous (buggy) dry run wrote LOGIN-page messages ('Username is mandatory') into ExpectedMessage. Put every message
    that cannot belong to this form back to TBD-verify-message: login words with no such column, or one identical message
    on most rows."""
    import openpyxl
    from collections import Counter
    wb = openpyxl.load_workbook(xlsx)
    if sheet not in wb.sheetnames:
        wb.close()
        return 0
    ws = wb[sheet]
    hdr = {str(c.value).strip(): i for i, c in enumerate(ws[1], start=1) if c.value is not None}
    ci = hdr.get("ExpectedMessage")
    if not ci:
        wb.close()
        return 0
    has_login_col = any(_LOGIN_MESSAGE_RE.search(h or "") for h in header)
    msgs = {r: str(ws.cell(r, ci).value or "") for r in range(2, ws.max_row + 1)}
    common = Counter(m for m in msgs.values() if m and "TBD-verify-message" not in m)
    n = 0
    for r, m in msgs.items():
        if not m or "TBD-verify-message" in m:
            continue
        crowded = len(msgs) >= 5 and common[m] / len(msgs) > 0.6
        if (_LOGIN_MESSAGE_RE.search(m) and not has_login_col) or crowded:
            ws.cell(r, ci).value = "TBD-verify-message"
            n += 1
    if n:
        wb.save(xlsx)
        log(f"  [negative-dryrun] {sheet}: reset {n} message(s) that cannot belong to this form (login-page text / one "
            f"message on most rows) back to TBD-verify-message.")
    wb.close()
    return n


# ======================================================================
# NEGATIVE CASES RUN FOR REAL (not a dry run). For every negative row: open the form like the real test does, fill EVERY field (dropdowns
# and radios included), click the final button (Send for approval ...), answer a confirmation popup, then read what the portal shows - a
# field error, a popup / dialog, a toast, a snackbar, an alert - and write that REAL message into ExpectedMessage (workbook AND template).
# A row the portal ACCEPTS (success message / the form closes) is reported: the record was really created.
# ======================================================================
_MSGS_JS = r"""
() => {
  const vis = e => { const r = e.getBoundingClientRect(); const s = getComputedStyle(e);
                     return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
  const txt = e => (e.innerText || '').replace(/\s+/g, ' ').trim();
  const out = [];
  const label = e => { const ff = e.closest('mat-form-field,.mat-mdc-form-field,.form-group,div');
                       const l = ff ? ff.querySelector('mat-label,label') : null;
                       return l ? (l.innerText || '').replace(/[*:]/g, ' ').replace(/\s+/g, ' ').trim() : ''; };
  for (const e of document.querySelectorAll('mat-error, .mat-mdc-form-field-error, .invalid-feedback, .error-message, .field-error'))
    if (vis(e) && txt(e)) out.push({kind: 'field', label: label(e), text: txt(e)});
  for (const e of document.querySelectorAll('mat-snack-bar-container, .mat-mdc-snack-bar-container, simple-snack-bar, .snackbar'))
    if (vis(e) && txt(e)) out.push({kind: 'snackbar', label: '', text: txt(e)});
  for (const e of document.querySelectorAll('[class*="toast" i], .toast-message, ngx-toastr, [id*="toast" i]'))
    if (vis(e) && txt(e) && !e.querySelector('[class*="toast" i]')) out.push({kind: 'toast', label: '', text: txt(e)});
  for (const e of document.querySelectorAll('mat-dialog-container, [role=dialog], [role=alertdialog], .modal.show, .swal2-popup'))
    if (vis(e) && txt(e)) out.push({kind: 'dialog', label: '', text: txt(e)});
  for (const e of document.querySelectorAll('[role=alert], .alert, .alert-danger, .error-banner, .message-box'))
    if (vis(e) && txt(e) && !e.closest('mat-error,mat-snack-bar-container,.mat-mdc-snack-bar-container')) out.push({kind: 'alert', label: '', text: txt(e)});
  const btn = [...document.querySelectorAll('button')].filter(b => vis(b) && /send|submit|save|approval|create|add/i.test(b.innerText || ''));
  return {messages: out, submit_disabled: btn.length ? btn.every(b => b.disabled || b.getAttribute('aria-disabled') === 'true') : null};
}
"""
_CONFIRM_TEXT_RE = re.compile(r"are you sure|do you want|confirm|proceed|continue|want to (submit|send|save|add|create)|please verify", re.I)
_AFFIRM_BUTTONS = ("Yes", "Confirm", "OK", "Ok", "Proceed", "Continue", "Submit", "Send for approval", "Send", "Save")
_DISMISS_BUTTONS = ("OK", "Ok", "Close", "Cancel", "Got it", "Dismiss")
_MAX_MSG = 220


def _collect_messages(page) -> dict:
    merged = {"messages": [], "submit_disabled": None}
    for fr in _frames(page):
        try:
            info = fr.evaluate(_MSGS_JS)
        except Exception:
            continue
        merged["messages"] += info.get("messages", [])
        if info.get("submit_disabled") is not None:
            merged["submit_disabled"] = info["submit_disabled"]
    seen, uniq = set(), []
    for m in merged["messages"]:
        key = (m["kind"], m["text"])
        if key not in seen:
            seen.add(key)
            uniq.append({**m, "text": m["text"][:_MAX_MSG]})
    merged["messages"] = uniq
    return merged


def _click_dialog_button(page, names) -> str | None:
    for fr in _frames(page):
        try:
            dlg = fr.locator("mat-dialog-container, [role=dialog], [role=alertdialog], .swal2-popup, .modal.show")
            if not dlg.count() or not dlg.first.is_visible():
                continue
            for nm in names:
                b = dlg.first.get_by_role("button", name=re.compile(rf"^\s*{re.escape(nm)}\s*$", re.I))
                if b.count() and b.first.is_visible():
                    _robust_click(page, b.first, timeout=3000)
                    return nm
        except Exception:
            continue
    return None


def _final_button_names(scenario: str) -> list[str]:
    """The button that ends the scenario ('Send for approval'), last one first, then the usual suspects."""
    found: list[str] = []
    for clause in _split_scenario_clauses(scenario or ""):
        m = _CLICK_RE.match(clause)
        if m:
            tgt = re.split(r"\s+(?:in|under|inside)\s+the\s+", m.group("target"))[0].strip().strip("\"'")
            if _FINALIZE_CLICK_RE.search(tgt) and not _row_action_of(tgt, clause) and tgt not in found:
                found.append(tgt)
    custom = [x.strip() for x in os.environ.get("AI_FINAL_BUTTONS", "").split(",") if x.strip()]
    fallbacks = custom or ["Submit", "Save", "Send for approval", "Add", "Create", "Confirm"]
    return list(reversed(found)) + [n for n in fallbacks if n not in found]


def submit_and_capture(page, final_names: list[str], entries, wait_ms: int = 7000) -> dict:
    """Clicks the final button, answers a confirmation popup, waits for what the portal answers and returns
    {state: 'rejected'|'accepted'|'blocked'|'no_button'|'none', messages: [{kind,label,text}], clicked: name}.
    'blocked' = the button is disabled (client validation): the field errors are the messages."""
    btn, name = None, ""
    for nm in final_names:
        b, _how, _n = _resolve_button(page, nm, entries)
        if b is not None:
            btn, name = b, nm
            break
    before = _collect_messages(page)
    if btn is None:
        return {"state": "no_button", "messages": before["messages"], "clicked": ""}
    try:
        disabled = btn.is_disabled()
    except Exception:
        disabled = False
    if disabled:
        return {"state": "blocked", "messages": before["messages"], "clicked": name}
    _robust_click(page, btn, timeout=5000)
    old = {(m["kind"], m["text"]) for m in before["messages"]}
    answered = False
    waited, got = 0, []
    while waited < wait_ms:
        page.wait_for_timeout(350)
        waited += 350
        cur = _collect_messages(page)["messages"]
        dialogs = [m for m in cur if m["kind"] == "dialog"]
        if dialogs and not answered and _CONFIRM_TEXT_RE.search(dialogs[0]["text"]) \
                and not re.search(r"error|invalid|already|failed|cannot|not allowed|exist", dialogs[0]["text"], re.I):
            if _click_dialog_button(page, _AFFIRM_BUTTONS):                 # "Are you sure?" -> Yes: the FULL scenario
                answered = True
                waited = max(waited - 1500, 0)
                continue
        new = [m for m in cur if (m["kind"], m["text"]) not in old]
        if new:
            got = cur
            page.wait_for_timeout(400)                                      # let a second message (toast + field error) show up
            got = _collect_messages(page)["messages"]
            break
    if not got:
        got = _collect_messages(page)["messages"]
    texts = " ".join(m["text"] for m in got)
    ok_like = bool(_POS_MSG_RE.search(texts)) and not _NEG_MSG_RE.search(texts) and not _SAVE_ERR_RE.search(texts)
    for m in got:
        if m["kind"] == "dialog" and not _CONFIRM_TEXT_RE.search(m["text"]):
            _click_dialog_button(page, _DISMISS_BUTTONS)                    # an error popup: read it, then close it
            break
    state = "accepted" if ok_like else ("rejected" if [m for m in got if (m["kind"], m["text"]) not in old or m["kind"] == "field"] else "none")
    return {"state": state, "messages": got, "clicked": name}


def _pick_message(messages: list[dict], under: str | None) -> str:
    """ExpectedMessage: the error of the field under test, else any field error, else a popup / toast / snackbar / alert."""
    field = [m for m in messages if m["kind"] == "field"]
    mine = [m for m in field if under and (_norm_tokens(m["label"]) & _norm_tokens(under))]
    other = [m for m in messages if m["kind"] in ("alert", "toast", "snackbar", "dialog") and not _CONFIRM_TEXT_RE.search(m["text"])]
    for group in (mine, field, other):
        if group:
            return group[0]["text"]
    return ""


def _scenarios_path(repo_root: Path, module: str) -> Path:
    return repo_root / "reports" / f"{module}_scenarios.json"


def save_module_scenarios(repo_root: Path, module: str, scenario: str, explicit_scenarios: dict | None,
                          portal_type: str | None = None) -> None:
    """Keeps the scenario texts of the last generation, so negative cases can be run again later (capture_negative.py)."""
    try:
        import json
        (repo_root / "reports").mkdir(exist_ok=True)
        _scenarios_path(repo_root, module).write_text(
            json.dumps({"add": scenario or "", "explicit": explicit_scenarios or {}, "portal_type": portal_type or ""}, indent=2),
            encoding="utf-8")
    except Exception as exc:
        _log_exception("saving the scenario texts", exc)


def load_module_scenarios(repo_root: Path, module: str) -> dict:
    try:
        import json
        return json.loads(_scenarios_path(repo_root, module).read_text(encoding="utf-8"))
    except Exception:
        return {}


def run_negative_cases(repo_root: Path, bank: str, portal_type: str, module: str, add_scenario: str,
                       edit_scenario: str | None, identifier: dict | None, log=print, only: str | None = None) -> dict:
    """See the block comment above. Returns {'rows','captured','no_message','accepted','filled': {sheet: n}, 'error'}."""
    import importlib.util
    summary = {"rows": 0, "captured": 0, "no_message": 0, "accepted": 0, "filled": {}, "error": None}
    module_title = module[:1].upper() + module[1:]
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module_title}.xlsx"
    rd_path = repo_root / "src" / "common" / "utilities" / "runtime_data.py"
    if not xlsx.exists() or not rd_path.exists():
        log("  [negative-run] skipped: the workbook or runtime_data.py is missing.")
        return summary
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        summary["error"] = "playwright not installed"
        return summary
    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]
    spec = importlib.util.spec_from_file_location("runtime_data_negrun", rd_path)
    rd = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rd)
    RD = rd.RuntimeData
    id_col = (identifier or {}).get("label")
    if identifier:
        RD.set(bank, module, id_col, identifier["value"])           # {{FROM_ADD}} = the record Add created
    max_rows = max(int(os.environ.get("AI_NEGATIVE_RUN_MAX") or os.environ.get("AI_NEGATIVE_DRYRUN_MAX") or "60"), 1)
    submit_mode = (os.environ.get("AI_NEGATIVE_DRYRUN_SUBMIT") or "all").strip().lower()      # all (default) | duplicate | none
    refresh = os.environ.get("AI_NEGATIVE_REFRESH", "0").strip().lower() in ("1", "true", "yes")
    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    entries = [(a, v) for _, a, v in LOCATOR_LINE_RE.findall(locators_path.read_text(encoding="utf-8"))] \
        if locators_path.exists() else []
    jobs = []
    update_only = not (add_scenario or "").strip() and bool((edit_scenario or "").strip())
    if update_only:
        log("  [negative-run] update-only module (no Add scenario): the Update scenario's page is the form - no saved record needed.")
    for sheet, scen, kind in (("Negative", add_scenario, "add"), ("NegativeEdit", edit_scenario, "edit")):
        if only and only != kind and not update_only:
            continue
        header, rows = _read_sheet_rows(xlsx, sheet)
        if not rows:
            continue
        if update_only:
            scen, kind = edit_scenario, "edit"
        if not (scen or "").strip():
            log(f"  [negative-run] '{sheet}': no {kind} scenario text - cannot open the form, skipped.")
            continue
        if kind == "edit" and not identifier and not update_only:
            log(f"  [negative-run] '{sheet}': there is no saved record to edit (run the Add test / dry run first) - skipped.")
            continue
        try:
            if _reset_suspicious_messages(xlsx, sheet, header, log):
                header, rows = _read_sheet_rows(xlsx, sheet)
        except Exception as exc:
            _log_exception("resetting suspicious messages", exc)
        jobs.append((sheet, scen, kind, header, rows[:max_rows], len(rows)))
    if not jobs:
        log("  [negative-run] nothing to run.")
        return summary
    config_path = repo_root / "src" / "config.yaml"
    original_config = config_path.read_text(encoding="utf-8") if config_path.exists() else None
    if original_config is not None:
        new_text, n_sub = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config, count=1, flags=re.MULTILINE)
        if n_sub:
            config_path.write_text(new_text, encoding="utf-8")
    report: list[str] = []
    try:
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))
        login_module = __import__(f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
        LoginPageClass = getattr(login_module, class_name)
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            page.on("dialog", lambda d: d.dismiss())
            log(f"\n  [negative-run] logging in as {bank} ...")
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            for sheet, scen, kind, header, rows, total in jobs:
                finals = _final_button_names(scen)
                log(f"  [negative-run] === {sheet}: running {len(rows)} of {total} negative row(s) FOR REAL on the {kind.upper()} form "
                    f"(fill everything, click the final button [{' / '.join(finals[:3])}], capture the portal's message) ===")
                prefix = _scenario_prefix(scen) if kind == "edit" else ""
                form_cols = [c for c in header if c and c.strip().lower().replace(" ", "") not in _STD_COLS
                             and not (kind == "edit" and c == id_col)]
                found: dict[str, str] = {}
                for idx, row in enumerate(rows, 1):
                    tid, desc = row.get("TestcaseID", f"row{idx}"), row.get("Description", "")
                    summary["rows"] += 1
                    tag = f"[{sheet} {idx}/{len(rows)}] {tid}"
                    try:
                        resolved = RD.resolve({k: v for k, v in row.items()}, module, bank)
                    except Exception as exc:
                        report.append(f"[{sheet}] {tid} {desc}: SKIPPED ({str(exc)[:100]})")
                        log(f"    {tag}: skipped ({str(exc)[:60]})")
                        continue
                    try:
                        form_open = False
                        for _attempt in (1, 2):
                            if _on_login_page(page):
                                log("    [negative-run] the portal is on the LOGIN page - signing in again")
                                LoginPageClass(page).login(bank)
                                page.wait_for_load_state("networkidle", timeout=15000)
                            navigate_via_scenario_text(page, scen)
                            if kind == "edit" and prefix and identifier:
                                _execute_scenario_steps(page, prefix, entries, {}, log=lambda m: None, action="edit", identifier=identifier)
                            _wait_for_form(page, lambda m: None, 9000)
                            probe = form_cols[0] if form_cols else None
                            if not _on_login_page(page) and (probe is None or _resolve_field(page, probe, entries)[0] is not None):
                                form_open = True
                                break
                        if not form_open:
                            raise RuntimeError(f"the {kind.upper()} form could not be opened (login page, or its fields are not on the page)")
                        d_clean = desc.replace("Edit - ", "", 1)
                        under = next((c for c in header if c and (d_clean.startswith(c + " - ") or d_clean.startswith(c + " / ")
                                                                    or f" - {c} - " in f" - {d_clean} - ")), None)
                        blocked, loc_under, fill_problems = "", None, []

                        def fill_all(cols):
                            nonlocal blocked, loc_under
                            failed = []
                            for col in cols:
                                value = resolved.get(col, "")
                                loc, _how = _resolve_field(page, col, entries)
                                if loc is None:
                                    continue
                                tag_, type_ = _control_kind(loc)
                                if col == under:
                                    loc_under = loc
                                if value == "":
                                    if tag_ in ("input", "textarea") and type_ not in ("radio", "checkbox"):
                                        try:
                                            loc.fill("", timeout=3000)
                                        except Exception:
                                            pass
                                    continue
                                try:
                                    _apply_value(page, loc, value)
                                    if col == under and tag_ in ("input", "textarea"):
                                        actual = loc.input_value()
                                        if len(actual) < len(value):
                                            blocked = f"the input TRUNCATES at {len(actual)} characters (maxlength) - the longer value cannot be entered"
                                except Exception as exc:
                                    reason = str(exc).strip().splitlines()[0][:120]
                                    if col == under and re.search(r"Cannot type text into input\[type=", reason):
                                        blocked = f"the input refuses this value ({reason})"
                                    else:
                                        failed.append((col, reason))
                            return failed
                        failed = fill_all(form_cols)
                        if failed:                                   # a dropdown that was still disabled: its parent is filled now - once more
                            page.wait_for_timeout(800)
                            failed = fill_all([c for c, _r in failed])
                        fill_problems = [f"{c}: {r}" for c, r in failed]
                        try:
                            page.keyboard.press("Tab")
                            page.locator("body").click(position={"x": 2, "y": 2}, timeout=1500)
                        except Exception:
                            pass
                        if blocked:
                            summary["no_message"] += 1
                            report.append(f"[{sheet}] {tid} {desc}: UI BLOCKS THE VALUE - {blocked} (not submitted)")
                            log(f"    {tag}: UI blocks the value (not submitted)")
                            continue
                        do_submit = submit_mode == "all" or (submit_mode == "duplicate" and row.get("NegativeType", "") == "Duplicate")
                        if do_submit:
                            res = submit_and_capture(page, finals, entries)
                        else:
                            res = {"state": "not_submitted", "messages": _collect_messages(page)["messages"], "clicked": ""}
                        msgs = res["messages"]
                        msg = _pick_message(msgs, under)
                        has_login_col = any(_LOGIN_MESSAGE_RE.search(c) for c in form_cols)
                        if msg and _LOGIN_MESSAGE_RE.search(msg) and not has_login_col:
                            report.append(f"[{sheet}] {tid} {desc}: IGNORED '{msg}' - a login-page message")
                            msg = ""
                        all_txt = " || ".join(f"{m['kind']}: {m['text']}" for m in msgs) or "(nothing shown)"
                        extra = (f"  [could not fill: {'; '.join(fill_problems)}]" if fill_problems else "")
                        if res["state"] == "accepted":
                            summary["accepted"] += 1
                            summary["no_message"] += 1
                            what = "a record was created" if kind == "add" else "the record was changed"
                            report.append(f"[{sheet}] {tid} {desc}: ACCEPTED - the portal said '{msgs[0]['text'] if msgs else ''}' i.e. it ALLOWED this "
                                          f"value and {what} (a defect, or the case is not negative){extra}")
                            log(f"    {tag}: ACCEPTED by the portal ({what})")
                            continue
                        if msg:
                            found[tid] = msg
                            summary["captured"] += 1
                            report.append(f"[{sheet}] {tid} {desc}: MESSAGE '{msg}'  <- {res['state']}; everything shown: {all_txt}{extra}")
                            log(f"    {tag}: MESSAGE {msg!r}")
                        else:
                            summary["no_message"] += 1
                            why = {"no_button": f"no '{finals[0]}' button was found on the form",
                                   "blocked": "the button is DISABLED and no error text is shown",
                                   "none": "nothing appeared within 7 s after the click",
                                   "not_submitted": "not submitted (AI_NEGATIVE_DRYRUN_SUBMIT is not 'all')"}.get(res["state"], res["state"])
                            report.append(f"[{sheet}] {tid} {desc}: NO MESSAGE - {why}{extra}")
                            log(f"    {tag}: no message ({why})")
                    except Exception as exc:
                        report.append(f"[{sheet}] {tid} {desc}: ERROR {str(exc).strip().splitlines()[0][:140]}")
                        log(f"    {tag}: ERROR {str(exc).strip().splitlines()[0][:100]}")
                if found:
                    n_done, written_to = 0, []
                    for f in (xlsx, xlsx.with_name(xlsx.stem + ".template.xlsx")):      # the TEMPLATE too: every run is built from it
                        if f.exists():
                            try:
                                n_done = max(n_done, _update_expected_messages(f, sheet, found, overwrite=refresh))
                                written_to.append(f.name)
                            except PermissionError:
                                log(f"  [negative-run] {f.name} is OPEN in Excel - the messages could NOT be written there. Close it and run again.")
                    summary["filled"][sheet] = n_done
                    log(f"  [negative-run] {sheet}: wrote {n_done} REAL message(s) into ExpectedMessage of {' and '.join(written_to) or 'no file'}.")
            try:
                browser.close()
            except Exception:
                pass
    except Exception as exc:
        _log_exception("negative run", exc)
        summary["error"] = str(exc)
    finally:
        if original_config is not None:
            config_path.write_text(original_config, encoding="utf-8")
    try:
        rep = repo_root / "reports"
        rep.mkdir(exist_ok=True)
        (rep / f"{module}_negative_capture.txt").write_text("\n".join(report), encoding="utf-8")
        log(f"  [negative-run] done: {summary['captured']} message(s) captured, {summary['accepted']} accepted by the portal, "
            f"{summary['no_message'] - summary['accepted']} without a message. Details: {rep / (module + '_negative_capture.txt')}")
    except Exception:
        pass
    return summary


def dry_run_negative_cases(repo_root: Path, bank: str, portal_type: str, module: str, add_scenario: str,
                           edit_scenario: str | None, identifier: dict | None, log=print) -> dict:
    """Kept under the old name: the negative rows are now run FOR REAL (see run_negative_cases)."""
    return run_negative_cases(repo_root, bank, portal_type, module, add_scenario, edit_scenario, identifier, log=log)




# ======================================================================
# TEST FILE: no hidden state. The reference style (reference/sample_test.py) is one straight chain INSIDE each test:
#       login_page = BankLoginPage(page); login_page.login(BANK_NAME); bin_page = BinmanagementPage(page); ...
# A generated test that instead reads  self.binmanagement_page / self.bank_name  from an autouse fixture can fail at run
# time with  AttributeError: 'TestX' object has no attribute 'binmanagement_page'  (the fixture is missing / not applied /
# names a different attribute). normalize_test_self_usage() converts every such self.<attr> into a LOCAL variable created
# at the top of the test (from the fixture's own assignment, or inferred from the page class), so nothing can be missing.
# ======================================================================
def _tokens_of_name(name: str) -> set[str]:
    return {t for t in re.sub(r"([a-z])([A-Z])", r"\1 \2", name).replace("_", " ").lower().split() if t not in ("page", "obj", "object", "po")}


# ======================================================================
# MARKERS the repo's ROOT conftest needs to KEEP a test. Its pytest_collection_modifyitems drops (silently, no "N deselected")
#   * a test that carries a bank marker but not the configured bank        -> bank_mismatch
#   * every test without the marker named by `test_type` in src/config.yaml -> type_mismatch   (unless test_type is "all")
# A generated test without @pytest.mark.<bank> / @pytest.mark.<test_type> therefore "collects" and never runs.
# ======================================================================
def required_test_markers(bank: str) -> list[str]:
    """The markers EVERY test needs: test_type from src/config.yaml (unless 'all'). The BANK marker is not unconditional any more: a test
    without any bank marker runs for every bank, so adding one would lock a shared test to ONE bank (see ensure_test_markers)."""
    marks: list[str] = []
    cfg = Path(__file__).resolve().parents[1] / "src" / "config.yaml"
    try:
        m = re.search(r"^test_type:\s*['\"]?([A-Za-z0-9_\-]+)", cfg.read_text(encoding="utf-8", errors="ignore"), re.M)
        if m and m.group(1).lower() != "all" and m.group(1) not in marks:
            marks.append(m.group(1))
    except OSError:
        pass
    return marks


def _mark_names(decorators) -> set[str]:
    names: set[str] = set()
    for d in decorators:
        node = d.func if isinstance(d, ast.Call) else d
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Attribute) and node.value.attr == "mark":
            names.add(node.attr)
    return names


def ensure_test_markers(src: str, markers: list[str], bank: str | None = None) -> tuple[str, list[str]]:
    """Adds  @pytest.mark.<m>  to every Test class that does not already give ALL its tests that marker (class level, so the
    negative tests merged into the class are covered too). `bank` is added ONLY to a class whose tests already carry another bank's
    marker (a shared test that must also run for this bank); a class with no bank marker runs for every bank and stays as it is."""
    notes: list[str] = []
    if not markers and not bank:
        return src, notes
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src, notes
    lines = src.split("\n")
    inserts: list[tuple[int, str]] = []
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name.startswith("Test")]:
        cls_marks = _mark_names(cls.decorator_list)
        tests = [f for f in cls.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)) and f.name.startswith("test_")]
        missing = [m for m in markers if m not in cls_marks and not (tests and all(m in _mark_names(t.decorator_list) for t in tests))]
        if bank:
            seen = set(cls_marks)
            for t in tests:
                seen |= _mark_names(t.decorator_list)
            others = (seen & _known_banks()) - {bank}
            if others and bank not in seen:
                missing.append(bank)                  # e.g. a test marked only @pytest.mark.wio must also run for this bank
        if not missing:
            continue
        first = min([d.lineno for d in cls.decorator_list] + [cls.lineno]) - 1
        for m in reversed(missing):
            inserts.append((first, f"@pytest.mark.{m}"))
        notes.append(f"class {cls.name}: added @pytest.mark.{' / @pytest.mark.'.join(missing)} (the root conftest silently drops "
                     f"tests without the bank / test_type marker)")
    if not inserts:
        return src, notes
    for at, text in sorted(inserts, key=lambda x: -x[0]):
        lines.insert(at, text)
    out = "\n".join(lines)
    if not re.search(r"^import pytest\b|^from pytest import", out, re.M):
        ls = out.split("\n")
        ls.insert(0, "import pytest")
        out = "\n".join(ls)
    try:
        ast.parse(out)
    except SyntaxError:
        return src, []
    return out, notes


# ======================================================================
# mat-option XPaths. Angular Material puts an option's text in a CHILD <span>, so  //mat-option[contains(text(),'Visa')]  never matches:
# the dropdown opens, the option click times out, nothing is selected and the test never gets further. The XPath must look at the
# whole element text:  //mat-option[contains(normalize-space(.),'Visa')].
# ======================================================================
_OPTION_XPATH_FIXES = [
    (re.compile(r"mat-option\[\s*contains\(\s*text\(\)\s*,"), "mat-option[contains(normalize-space(.),"),
    (re.compile(r"mat-option\[\s*contains\(\s*normalize-space\(\s*text\(\)\s*\)\s*,"), "mat-option[contains(normalize-space(.),"),
    (re.compile(r"mat-option\[\s*normalize-space\(\s*text\(\)\s*\)\s*="), "mat-option[normalize-space(.)="),
    (re.compile(r"mat-option\[\s*text\(\)\s*="), "mat-option[normalize-space(.)="),
]


def repair_option_xpaths(src: str) -> tuple[str, int]:
    n = 0
    for rx, rep in _OPTION_XPATH_FIXES:
        src, k = rx.subn(rep, src)
        n += k
    return src, n


def _all_bank_locator_files(repo_root: Path, module: str, pattern: str | None = None) -> list[Path]:
    """The module's locators file of EVERY bank (src/banks/<bank>/locators/<module>*): the page / test files are shared by all banks, so a
    change in the page code needs its counterpart in each bank's locators class."""
    return sorted((repo_root / "src" / "banks").glob(f"*/locators/{pattern or module + '*'}.py"))


def _known_banks(repo_root: Path | None = None) -> set[str]:
    root = repo_root or Path(__file__).resolve().parents[1]
    d = root / "src" / "banks"
    return {p.name for p in d.iterdir() if p.is_dir() and not p.name.startswith(("_", "."))} if d.exists() else set()


def _insert_attrs_into_locators(loc_src: str, attrs: dict[str, str]) -> tuple[str, int]:
    """Adds  name = 'value'  to every *Locators class that does not define that name yet."""
    try:
        tree = ast.parse(loc_src)
    except SyntaxError:
        return loc_src, 0
    lines = loc_src.split("\n")
    inserts: list[tuple[int, list[str]]] = []
    n = 0
    for cls in [c for c in tree.body if isinstance(c, ast.ClassDef) and c.name.endswith("Locators")]:
        have = {st.targets[0].id for st in cls.body if isinstance(st, ast.Assign) and isinstance(st.targets[0], ast.Name)}
        add = [f"    {k} = {v!r}" for k, v in attrs.items() if k not in have]
        if add:
            inserts.append((cls.end_lineno, ["", "    # selectors that were written inline in the shared page code (templates use .format(value=...))"] + add))
            n += len(add)
    for at, block in sorted(inserts, key=lambda x: -x[0]):
        lines[at:at] = block
    out = "\n".join(lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return loc_src, 0
    return out, n


def repair_option_xpaths_in_module(repo_root: Path, bank: str, module: str, log=print) -> int:
    """Fixes the mat-option XPaths in the module's locators, page and test files (a .bak copy goes to debug_logs/backups)."""
    files = _all_bank_locator_files(repo_root, module) \
        + sorted((repo_root / "src" / "common" / "pages" / module).glob("*.py")) \
        + sorted((repo_root / "src" / "testcase" / module).glob("test_*.py"))
    total = 0
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
            new, n = repair_option_xpaths(text)
            if n:
                bak = repo_root / "debug_logs" / "backups"
                bak.mkdir(parents=True, exist_ok=True)
                (bak / (f.name + ".before_option_fix")).write_text(text, encoding="utf-8")
                f.write_text(new, encoding="utf-8")
                total += n
                log(f"  {f.name}: {n} dropdown-option XPath(s) fixed (contains(text(),..) never matches an Angular Material option "
                    f"-> contains(normalize-space(.),..))")
        except Exception as exc:
            _log_exception("repairing mat-option XPaths", exc)
    return total


# ======================================================================
# NO SELECTOR (and no chosen option) INSIDE A PAGE METHOD. Selectors live in the locators class; a dropdown option / a message is a
# TEMPLATE there ("//mat-option[contains(normalize-space(.), '{value}')]") used as  loc.option_by_text.format(value=data["Card Type"]).
# The AI still writes  self.click_by_locator(f"//mat-option[contains(text(),'{data['Card Type']}')]", ...)  inside the page now and then,
# so this hoists every inline selector out of the page code into the locators class (and fixes the text() form on the way).
# ======================================================================
_CLICKABLE_NAME_RE = re.compile(r"locator", re.I)
_LOCS_NAMES = ("loc", "locators", "locs")


_U_CASE, _L_CASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"


def _lc(expr: str) -> str:
    return f"translate({expr},'{_U_CASE}','{_L_CASE}')"


# ONE option template for every dropdown: the option whose whole text EQUALS the value (any capitals) wins; only when no option equals
# it, the first option that CONTAINS it. A plain contains() matched 'Visa Classic' AND 'Visa Classic Plus' (two elements = Playwright
# "strict mode violation") and never matched 'mastercard' for 'MasterCard'.
OPTION_TEMPLATE = ("xpath=(//mat-option[" + _lc("normalize-space(.)") + "=" + _lc("'{value}'") + " or (contains(" + _lc("normalize-space(.)")
                   + "," + _lc("'{value}'") + ") and not(../mat-option[" + _lc("normalize-space(.)") + "=" + _lc("'{value}'") + "]))])[1]")


def upgrade_option_templates(repo_root: Path, bank: str, module: str, log=print) -> int:
    """Puts OPTION_TEMPLATE into the locators class attribute  option_by_text  (the shared dropdown-option template)."""
    n = 0
    pat = re.compile(r"^(\s+)option_by_text\s*=\s*(['\"]).*\2\s*$", re.M)
    for f in _all_bank_locator_files(repo_root, module, f"{module}*locators"):
        try:
            text = f.read_text(encoding="utf-8")
            changed = 0

            def repl(m):
                nonlocal changed
                line = f"{m.group(1)}option_by_text = {OPTION_TEMPLATE!r}"
                if m.group(0).strip() == line.strip():
                    return m.group(0)
                changed += 1
                return line
            new = pat.sub(repl, text)
            if changed:
                ast.parse(new)
                f.write_text(new, encoding="utf-8")
                n += changed
                log(f"  {f.name}: option_by_text now picks the option that EQUALS the value (any capitals), else the first that contains it")
        except Exception as exc:
            _log_exception("upgrading the dropdown option template", exc)
    return n


def _looks_like_selector(text: str) -> bool:
    t = text.strip()
    return bool(re.match(r"^(\(?//|xpath=|css=|text=)", t)) or ":has-text(" in t or bool(re.match(r"^(mat-|\.mat-|#[\w-]+|\[[\w-]+)", t))


def _slug(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return s or "selector"


def hoist_inline_selectors(page_src: str, loc_src: str, sink: dict | None = None) -> tuple[str, str, list[str]]:
    notes: list[str] = []
    try:
        ptree = ast.parse(page_src)
        ltree = ast.parse(loc_src)
    except SyntaxError:
        return page_src, loc_src, notes
    existing: dict[str, str] = {}
    for cls in [n for n in ltree.body if isinstance(n, ast.ClassDef)]:
        for st in cls.body:
            if isinstance(st, ast.Assign) and len(st.targets) == 1 and isinstance(st.targets[0], ast.Name) \
                    and isinstance(st.value, ast.Constant) and isinstance(st.value.value, str):
                existing.setdefault(st.targets[0].id, st.value.value)
    line_starts = [0]
    for ln in page_src.split("\n"):
        line_starts.append(line_starts[-1] + len(ln) + 1)
    off = lambda ln, col: line_starts[ln - 1] + col   # noqa: E731  (col_offset is in UTF-8 bytes; ASCII code assumed)
    new_attrs: dict[str, str] = {}
    by_value: dict[str, str] = {v: k for k, v in existing.items()}
    edits: list[tuple[int, int, str]] = []

    def pick_name(text: str, label: str | None, has_ph: bool) -> str:
        if text in by_value:
            return by_value[text]
        if "mat-option" in text and has_ph:
            base = "option_by_text"
        elif "mat-error" in text and has_ph:
            base = "error_message_by_text"
        elif label:
            base = _slug(label) + ("_template" if has_ph else "")
        else:
            base = "inline_selector"
        name, k = base, 2
        while name in existing or name in new_attrs:
            if existing.get(name) == text or new_attrs.get(name) == text:
                return name
            name, k = f"{base}_{k}", k + 1
        return name

    for fn in [n for n in ast.walk(ptree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
        loc_name = next((n.value.id for n in ast.walk(fn) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)
                         and (n.value.id in _LOCS_NAMES or n.value.id.endswith("Locators"))), None)
        if not loc_name and any(a.arg in _LOCS_NAMES for a in fn.args.args):
            loc_name = next(a.arg for a in fn.args.args if a.arg in _LOCS_NAMES)
        if not loc_name:
            continue
        for call in [n for n in ast.walk(fn) if isinstance(n, ast.Call) and n.args]:
            fname = call.func.attr if isinstance(call.func, ast.Attribute) else getattr(call.func, "id", "")
            if not _CLICKABLE_NAME_RE.search(fname):
                continue
            a0 = call.args[0]
            placeholders: list[str] = []
            if isinstance(a0, ast.Constant) and isinstance(a0.value, str):
                text = a0.value
            elif isinstance(a0, ast.JoinedStr):
                parts = []
                for v in a0.values:
                    if isinstance(v, ast.Constant):
                        parts.append(str(v.value).replace("{", "{{").replace("}", "}}"))
                    elif isinstance(v, ast.FormattedValue):
                        placeholders.append(ast.get_source_segment(page_src, v.value) or "")
                        parts.append("{value}" if len(placeholders) == 1 else f"{{value{len(placeholders)}}}")
                text = "".join(parts)
                if not placeholders:
                    text = text.replace("{{", "{").replace("}}", "}")
            else:
                continue
            raw_check = re.sub(r"\{value\d*\}", "", text)
            if not _looks_like_selector(raw_check):
                continue
            label = call.args[1].value if len(call.args) > 1 and isinstance(call.args[1], ast.Constant) and isinstance(call.args[1].value, str) else None
            name = pick_name(text, label, bool(placeholders))
            if name not in existing:
                new_attrs[name] = OPTION_TEMPLATE if (name == "option_by_text") else text
                by_value[text] = name
            if placeholders:
                fmt = ", ".join(("value" if i == 0 else f"value{i + 1}") + "=" + src for i, src in enumerate(placeholders))
                repl = f"{loc_name}.{name}.format({fmt})"
            else:
                repl = f"{loc_name}.{name}"
            edits.append((off(a0.lineno, a0.col_offset), off(a0.end_lineno, a0.end_col_offset), repl))
            notes.append(f"{fn.name}: inline selector -> {loc_name}.{name}")
    if not edits:
        return page_src, loc_src, notes
    new_page = page_src
    for a, b, rep in sorted(edits, reverse=True):
        new_page = new_page[:a] + rep + new_page[b:]
    lines = loc_src.split("\n")
    inserts: list[tuple[int, list[str]]] = []
    for cls in [n for n in ltree.body if isinstance(n, ast.ClassDef) and n.name.endswith("Locators")]:
        have = {st.targets[0].id for st in cls.body if isinstance(st, ast.Assign) and isinstance(st.targets[0], ast.Name)}
        add = [f"    {k} = {v!r}" for k, v in new_attrs.items() if k not in have]
        if add:
            inserts.append((cls.end_lineno, ["", "    # selectors that were written inline in the page code (templates use .format(value=...))"] + add))
    for at, block in sorted(inserts, key=lambda x: -x[0]):
        lines[at:at] = block
    new_loc = "\n".join(lines)
    try:
        ast.parse(new_page)
        ast.parse(new_loc)
    except SyntaxError:
        return page_src, loc_src, []
    if sink is not None:
        sink.update(new_attrs)
    return new_page, new_loc, notes


_HARDCODED_OPTION_ATTR_RE = re.compile(r"\bloc\.(\w+_(?:active|inactive|yes|no|enabled|disabled|male|female|true|false)_(?:radio|checkbox|toggle|option))\b")


def find_hardcoding_in_page(page_src: str) -> list[str]:
    """What is still HARD-CODED in a page method: a selector literal, a typed / asserted literal that is not read from data, a
    radio / checkbox option fixed in the locator's name (…_active_radio always picks 'Active')."""
    issues: list[str] = []
    try:
        tree = ast.parse(page_src)
    except SyntaxError:
        return issues
    for fn in [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
        for call in [n for n in ast.walk(fn) if isinstance(n, ast.Call) and n.args]:
            fname = call.func.attr if isinstance(call.func, ast.Attribute) else getattr(call.func, "id", "")
            if not _CLICKABLE_NAME_RE.search(fname):
                continue
            a0 = call.args[0]
            txt = a0.value if isinstance(a0, ast.Constant) and isinstance(a0.value, str) else (
                "".join(str(v.value) for v in a0.values if isinstance(v, ast.Constant)) if isinstance(a0, ast.JoinedStr) else "")
            if txt and _looks_like_selector(txt):
                issues.append(f"{fn.name}: a selector is written inline ({txt[:50]}...)")
            if fname.startswith(("fill", "type")) and len(call.args) > 1 and isinstance(call.args[1], ast.Constant) \
                    and isinstance(call.args[1].value, str) and call.args[1].value.strip():
                issues.append(f"{fn.name}: types the literal '{call.args[1].value[:30]}' instead of a data[...] value")
        seg = ast.get_source_segment(page_src, fn) or ""
        for m in _DATA_GET_FIXED_RE.finditer(seg):
            issues.append(f"{fn.name}: data.get('{m.group(2)}', '{m.group(4)}') - a fixed fallback value")
        for m in _HARDCODED_OPTION_ATTR_RE.finditer(seg):
            issues.append(f"{fn.name}: {m.group(1)} fixes the option in the locator's name (the Excel column is ignored)")
    return list(dict.fromkeys(issues))


DROPDOWN_HELPER_MARKER = "# dropdown_helper v2 (generated by the test generator)"
DROPDOWN_HELPER_SOURCE = r'''# dropdown_helper v2 (generated by the test generator)
"""select_mat_option(page, trigger, value, label): opens an Angular Material dropdown and picks ONE option, reliably.

 - waits until the dropdown is ENABLED (a dependent dropdown stays disabled until the earlier field is filled)
 - opens it again when the panel did not appear (a click that missed, options that load from the server)
 - picks the option whose text EQUALS the value; else equals it ignoring capitals; else the first that contains it
 - waits for the panel to close, so the next dropdown is not covered by it
 - when something is wrong the error says WHAT: still disabled / no options / the options the portal offers"""
import re


def _norm(text) -> str:
    return re.sub(r"\s+", " ", str(text)).strip()


def _dismiss(page) -> None:
    """Close any panel / cdk-overlay-backdrop left open by an earlier (multi-)select."""
    for _ in range(3):
        try:
            bd = page.locator(".cdk-overlay-backdrop-showing")
            if bd.count() == 0 and page.locator("mat-option").count() == 0:
                return
            page.keyboard.press("Escape")
            page.wait_for_timeout(250)
            if bd.count() > 0:
                try:
                    bd.last.click(timeout=1000, force=True, position={"x": 2, "y": 2})
                except Exception:
                    pass
                page.wait_for_timeout(250)
        except Exception:
            return


def select_mat_option(page, trigger: str, value, label: str = "dropdown", timeout: int = 15000) -> None:
    wanted = _norm(value)
    _dismiss(page)
    t = page.locator(trigger).first
    t.wait_for(state="visible", timeout=timeout)
    try:
        t.scroll_into_view_if_needed(timeout=3000)
    except Exception:
        pass
    waited = 0
    while True:                                   # a dependent dropdown is disabled until the earlier one is filled
        if not (t.get_attribute("aria-disabled") == "true" or t.get_attribute("disabled") is not None):
            break
        if waited >= timeout:
            raise AssertionError(f"Dropdown '{label}' stayed DISABLED for {timeout // 1000} s - it depends on an earlier field "
                                 f"that was not filled (or was filled with a value that does not enable it).")
        page.wait_for_timeout(300)
        waited += 300
    options = page.locator("mat-option")
    opened = False
    for _attempt in range(3):
        try:
            t.click(timeout=5000)
        except Exception:
            t.click(force=True, timeout=3000)
        try:
            options.first.wait_for(state="visible", timeout=5000)
            opened = True
            break
        except Exception:
            try:
                page.keyboard.press("Escape")
            except Exception:
                pass
    if not opened:
        raise AssertionError(f"Dropdown '{label}': no option appeared after 3 clicks (the options load from the server, "
                             f"or the click did not open the panel).")
    visible = [(i, _norm(options.nth(i).inner_text())) for i in range(options.count()) if options.nth(i).is_visible()]
    texts = [x for _i, x in visible]
    pick = next((i for i, x in visible if x == wanted), None)
    if pick is None:
        pick = next((i for i, x in visible if x.lower() == wanted.lower()), None)
    if pick is None:
        pick = next((i for i, x in visible if wanted.lower() in x.lower()), None)
    if pick is None:
        try:
            page.keyboard.press("Escape")
        except Exception:
            pass
        raise AssertionError(f"Dropdown '{label}': no option matches '{wanted}'. The portal offers: {texts}")
    options.nth(pick).click(timeout=5000)
    try:
        options.first.wait_for(state="hidden", timeout=2500)      # the panel is closed
    except Exception:
        _dismiss(page)                                            # multi-select keeps its panel open
'''


def ensure_dropdown_helper(repo_root: Path, log=print) -> Path | None:
    """src/common/utilities/dropdown_helper.py (select_mat_option). Never overwrites a file that is not ours."""
    p = repo_root / "src" / "common" / "utilities" / "dropdown_helper.py"
    try:
        if p.exists():
            head = p.read_text(encoding="utf-8", errors="ignore")[:200]
            if "# dropdown_helper v" in head and p.read_text(encoding="utf-8") != DROPDOWN_HELPER_SOURCE:
                p.write_text(DROPDOWN_HELPER_SOURCE, encoding="utf-8")
            return p
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(DROPDOWN_HELPER_SOURCE, encoding="utf-8")
        log(f"  Created {p} (select_mat_option: waits for a dependent dropdown, retries the open, picks the option reliably).")
        return p
    except Exception as exc:
        _log_exception("creating dropdown_helper.py", exc)
        return None


def _base_page_has_page_attr(repo_root: Path) -> bool:
    """The helper needs the Playwright page: the BasePage must keep it as self.page."""
    for f in (repo_root / "src" / "common" / "base").glob("*.py"):
        try:
            if re.search(r"self\.page\b", f.read_text(encoding="utf-8", errors="ignore")):
                return True
        except OSError:
            continue
    return False


def convert_dropdowns_to_helper(page_src: str, page_attr: str = "page") -> tuple[str, int]:
    """   self.click_by_locator(loc.x_dropdown, "X dropdown")
          self.click_by_locator(loc.option_by_text.format(value=data["X"]), "X option")
       ->  select_mat_option(self.page, loc.x_dropdown, data["X"], "X")"""
    try:
        tree = ast.parse(page_src)
    except SyntaxError:
        return page_src, 0
    line_starts = [0]
    for ln in page_src.split("\n"):
        line_starts.append(line_starts[-1] + len(ln) + 1)
    off = lambda ln, col: line_starts[ln - 1] + col   # noqa: E731
    edits: list[tuple[int, int, str]] = []

    def clickish(st):
        return isinstance(st, ast.Expr) and isinstance(st.value, ast.Call) and isinstance(st.value.func, ast.Attribute) \
            and "click" in st.value.func.attr and "locator" in st.value.func.attr and st.value.args

    for node in ast.walk(tree):
        body = getattr(node, "body", None)
        if not isinstance(body, list):
            continue
        i = 0
        while i < len(body) - 1:
            s1, s2 = body[i], body[i + 1]
            if clickish(s1) and clickish(s2):
                a2 = s2.value.args[0]
                if isinstance(a2, ast.Call) and isinstance(a2.func, ast.Attribute) and a2.func.attr == "format" \
                        and isinstance(a2.func.value, ast.Attribute) and a2.func.value.attr == "option_by_text" and a2.keywords:
                    value_src = ast.get_source_segment(page_src, a2.keywords[0].value)
                    trig_src = ast.get_source_segment(page_src, s1.value.args[0])
                    obj_src = ast.get_source_segment(page_src, s1.value.func.value) or "self"
                    lab = s1.value.args[1].value if len(s1.value.args) > 1 and isinstance(s1.value.args[1], ast.Constant) else "dropdown"
                    lab = re.sub(r"\s*dropdown\s*$", "", str(lab), flags=re.I).strip() or "dropdown"
                    if value_src and trig_src:
                        edits.append((off(s1.lineno, s1.col_offset), off(s2.end_lineno, s2.end_col_offset),
                                      f"select_mat_option({obj_src}.{page_attr}, {trig_src}, {value_src}, {lab!r})"))
                        i += 2
                        continue
            i += 1
    if not edits:
        return page_src, 0
    out = page_src
    for a, b, rep in sorted(edits, reverse=True):
        out = out[:a] + rep + out[b:]
    if "select_mat_option" in out and not re.search(r"import[^\n]*\bselect_mat_option\b", out):
        imps = [n for n in ast.parse(out).body if isinstance(n, (ast.Import, ast.ImportFrom))]
        ls = out.split("\n")
        ls.insert(imps[-1].end_lineno if imps else 0, "from src.common.utilities.dropdown_helper import select_mat_option")
        out = "\n".join(ls)
    try:
        ast.parse(out)
    except SyntaxError:
        return page_src, 0
    return out, len(edits)


def convert_dropdowns_in_module(repo_root: Path, bank: str, module: str, log=print) -> int:
    """Every 'click the dropdown, click the option' pair in the module's page files becomes ONE select_mat_option call.
    AI_DROPDOWN_HELPER=0 turns it off."""
    if os.environ.get("AI_DROPDOWN_HELPER", "1").strip().lower() in ("0", "false", "no"):
        return 0
    total = 0
    pages = sorted((repo_root / "src" / "common" / "pages" / module).glob("*_page.py"))
    if not pages:
        return 0
    if not _base_page_has_page_attr(repo_root):
        log("  Dropdown helper not used: src/common/base/*.py has no self.page (select_mat_option needs the Playwright page).")
        return 0
    for f in pages:
        try:
            text = f.read_text(encoding="utf-8")
            new, n = convert_dropdowns_to_helper(text)
            if n:
                ensure_dropdown_helper(repo_root, log=log)
                bak = repo_root / "debug_logs" / "backups"
                bak.mkdir(parents=True, exist_ok=True)
                (bak / (f.name + ".before_dropdown_helper")).write_text(text, encoding="utf-8")
                f.write_text(new, encoding="utf-8")
                total += n
                log(f"  {f.name}: {n} dropdown(s) now use select_mat_option (waits while disabled, re-opens, picks exact / any-case / first "
                    f"match, and says what is wrong when it fails)")
        except Exception as exc:
            _log_exception("converting dropdowns to the helper", exc)
    return total


# ======================================================================
# A page method that the POSITIVE code calls but that was written into the NEGATIVE page class (or whose locator template sits only in
# the negative locators class). The merged page file holds  class XPage  and  class XPageNegative(XPage): the positive test creates
# XPage, so  bin_page.click_expand_icons(...)  raises AttributeError - the method exists only one level down. Such methods (and the
# locators they use) are PULLED UP into the positive class. Also: fixed fallback values  data.get("Country", "Nigeria")  and leftover
# debug prints are removed from the page code.
# ======================================================================
def pull_up_shared_methods(page_src: str, test_srcs: list[str]) -> tuple[str, list[str], set[str]]:
    """-> (new page source, notes, names of the methods that were moved)."""
    notes: list[str] = []
    moved_names: set[str] = set()
    try:
        tree = ast.parse(page_src)
    except SyntaxError:
        return page_src, notes, moved_names
    classes = {c.name: c for c in tree.body if isinstance(c, ast.ClassDef)}
    lines = page_src.split("\n")
    edits: list[tuple[int, int, list[str]]] = []                      # (first line idx, last line idx, replacement)
    for neg in classes.values():
        for b in neg.bases:
            if not (isinstance(b, ast.Name) and b.id in classes and b.id != neg.name):
                continue
            pos = classes[b.id]
            pos_methods = {f.name for f in pos.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
            neg_methods = {f.name: f for f in neg.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))}
            used: set[str] = set()
            for t in test_srcs:                                       # test code: instances of the POSITIVE class
                for var in re.findall(rf"(\w+)\s*=\s*{re.escape(pos.name)}\(", t):
                    used |= set(re.findall(rf"\b{re.escape(var)}\.(\w+)\(", t))
                used |= set(re.findall(rf"{re.escape(pos.name)}\([^)]*\)\.(\w+)\(", t))
            for f in pos.body:                                        # the positive class' own methods
                used |= {n.attr for n in ast.walk(f) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "self"}
            todo = [m for m in used if m in neg_methods and m not in pos_methods]
            move: dict[str, ast.AST] = {}
            while todo:                                               # + the negative methods those methods call (self.x)
                m = todo.pop()
                if m in move:
                    continue
                move[m] = neg_methods[m]
                for n in ast.walk(neg_methods[m]):
                    if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "self" \
                            and n.attr in neg_methods and n.attr not in pos_methods and n.attr not in move:
                        todo.append(n.attr)
            if not move:
                continue
            blocks: list[list[str]] = []
            for name, f in sorted(move.items(), key=lambda kv: kv[1].lineno):
                first = min([d.lineno for d in f.decorator_list] + [f.lineno]) - 1
                blocks.append(lines[first:f.end_lineno])
                end = f.end_lineno - 1 + (1 if f.end_lineno < len(lines) and not lines[f.end_lineno].strip() else 0)
                edits.append((first, end, []))                        # leaves the negative class (it inherits it from the positive one)
                moved_names.add(name)
            ins: list[str] = []
            for blk in blocks:
                ins += [""] + blk
            edits.append((pos.end_lineno, pos.end_lineno - 1, ins))   # pure insertion after the positive class' last line
            notes.append(f"{', '.join(sorted(move))}: moved from {neg.name} up into {pos.name} (the positive code calls "
                         f"{'it' if len(move) == 1 else 'them'}; {pos.name} did not have {'it' if len(move) == 1 else 'them'})")
    if not edits:
        return page_src, notes, moved_names
    new_lines = list(lines)
    for a, b, rep in sorted(edits, key=lambda e: -e[0]):
        new_lines[a:b + 1] = rep
    out = "\n".join(new_lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return page_src, [], set()
    return out, notes, moved_names


def pull_up_shared_locators(loc_src: str, attrs: set[str]) -> tuple[str, list[str]]:
    """Copies  attr = '...'  from the NEGATIVE locators class into every POSITIVE locators class that lacks it."""
    notes: list[str] = []
    try:
        tree = ast.parse(loc_src)
    except SyntaxError:
        return loc_src, notes
    lines = loc_src.split("\n")
    loc_classes = [c for c in tree.body if isinstance(c, ast.ClassDef) and c.name.endswith(("Locators", "LocatorsNegative", "Negative"))]
    def names_of(c):
        return {st.targets[0].id: st for st in c.body if isinstance(st, ast.Assign) and isinstance(st.targets[0], ast.Name)}
    neg_cls = [c for c in loc_classes if "Negative" in c.name]
    pos_cls = [c for c in loc_classes if "Negative" not in c.name and c.name.endswith("Locators")]
    inserts: list[tuple[int, list[str]]] = []
    for pc in pos_cls:
        have = names_of(pc)
        add: list[str] = []
        for a in sorted(attrs):
            if a in have:
                continue
            for nc in neg_cls:
                st = names_of(nc).get(a)
                if st is not None:
                    add += [f"    {l.strip()}" if k == 0 else l for k, l in enumerate(lines[st.lineno - 1:st.end_lineno])]
                    notes.append(f"{a}: copied into {pc.name} (it was only in {nc.name})")
                    break
        if add:
            inserts.append((pc.end_lineno, [""] + add))
    for at, block in sorted(inserts, key=lambda x: -x[0]):
        lines[at:at] = block
    out = "\n".join(lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return loc_src, []
    return out, notes


_DATA_GET_FIXED_RE = re.compile(r"""\bdata\.get\(\s*(['"])([^'"]+)\1\s*,\s*(['"])([^'"]+)\3\s*\)""")


def strip_hardcoded_page_noise(page_src: str) -> tuple[str, list[str]]:
    """data.get("Country", "Nigeria") -> data.get("Country", "")  (a fixed fallback value is a hard-coded value: with the column missing
    the test silently used 'Nigeria'), and leftover debug prints  print(f"Bank = {bank}")  are removed."""
    notes: list[str] = []
    out, n = _DATA_GET_FIXED_RE.subn(lambda m: f'data.get({m.group(1)}{m.group(2)}{m.group(1)}, "")', page_src)
    if n:
        notes.append(f"{n} data.get(key, '<fixed value>') fallback(s) emptied - no value is invented when an Excel column is missing")
    try:
        tree = ast.parse(out)
    except SyntaxError:
        return page_src, []
    lines = out.split("\n")
    kill: list[tuple[int, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) \
                and node.value.func.id == "print" and len(node.value.args) == 1 and isinstance(node.value.args[0], ast.JoinedStr):
            const = "".join(str(v.value) for v in node.value.args[0].values if isinstance(v, ast.Constant))
            if re.search(r"=\s*$|\bdebug\b|^\s*(Bank|BIN|Locator|Final|Expand)\b", const, re.I) and any(isinstance(v, ast.FormattedValue) for v in node.value.args[0].values):
                kill.append((node.lineno - 1, node.end_lineno - 1))
    if kill:
        for a, b in sorted(kill, reverse=True):
            del lines[a:b + 1]
        cand = "\n".join(lines)
        try:
            ast.parse(cand)
            out = cand
            notes.append(f"{len(kill)} leftover debug print(...) line(s) removed")
        except SyntaxError:                                          # an emptied block: keep the prints rather than break the file
            pass
    return out, notes


def pull_up_in_module(repo_root: Path, bank: str, module: str, log=print) -> int:
    """pull_up_shared_methods / pull_up_shared_locators / strip_hardcoded_page_noise for the module's page and locators files."""
    pages = sorted((repo_root / "src" / "common" / "pages" / module).glob("*_page.py"))
    tests = [f.read_text(encoding="utf-8", errors="ignore") for f in sorted((repo_root / "src" / "testcase" / module).glob("test_*.py"))]
    total = 0
    moved_all: set[str] = set()
    for f in pages:
        try:
            src = f.read_text(encoding="utf-8")
            new, notes, moved = pull_up_shared_methods(src, tests)
            new2, notes2 = strip_hardcoded_page_noise(new)
            if new2 != src:
                bak = repo_root / "debug_logs" / "backups"
                bak.mkdir(parents=True, exist_ok=True)
                (bak / (f.name + ".before_pullup")).write_text(src, encoding="utf-8")
                f.write_text(new2, encoding="utf-8")
                total += len(notes) + len(notes2)
                for n in notes + notes2:
                    log(f"  {f.name}: {n}")
                moved_all |= moved
        except Exception as exc:
            _log_exception("pulling shared methods up", exc)
    if moved_all:                                                    # the locators those methods use must be in the positive classes
        used_attrs: set[str] = set()
        for f in pages:
            try:
                tree = ast.parse(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            for fn in ast.walk(tree):
                if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and fn.name in moved_all:
                    used_attrs |= {n.attr for n in ast.walk(fn) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name)
                                   and n.value.id in _LOCS_NAMES}
        for lf in _all_bank_locator_files(repo_root, module, f"{module}*locators"):
            try:
                text = lf.read_text(encoding="utf-8")
                new, notes = pull_up_shared_locators(text, used_attrs)
                if new != text:
                    (repo_root / "debug_logs" / "backups").mkdir(parents=True, exist_ok=True)
                    (repo_root / "debug_logs" / "backups" / (lf.name + ".before_pullup")).write_text(text, encoding="utf-8")
                    lf.write_text(new, encoding="utf-8")
                    total += len(notes)
                    for n in notes:
                        log(f"  {lf.name}: {n}")
            except Exception as exc:
                _log_exception("pulling shared locators up", exc)
    return total


def harden_module_files(repo_root: Path, bank: str, module: str, log=print) -> int:
    """For the module: mat-option XPaths fixed, then every inline selector of the page files moved into the locators class."""
    total = pull_up_in_module(repo_root, bank, module, log=log)
    total += repair_option_xpaths_in_module(repo_root, bank, module, log=log)
    loc_files = sorted((repo_root / "src" / "banks" / bank / "locators").glob(f"{module}_locators.py"))
    if not loc_files:
        return total
    loc_path = loc_files[0]
    for page_path in sorted((repo_root / "src" / "common" / "pages" / module).glob("*_page.py")):
        try:
            page_src, loc_src = page_path.read_text(encoding="utf-8"), loc_path.read_text(encoding="utf-8")
            sink: dict = {}
            new_page, new_loc, notes = hoist_inline_selectors(page_src, loc_src, sink)
            if notes:
                for other in _all_bank_locator_files(repo_root, module, f"{module}_locators"):
                    if other == loc_path:
                        continue
                    o_new, o_n = _insert_attrs_into_locators(other.read_text(encoding="utf-8"), sink)
                    if o_n:                                                    # the page is SHARED: every bank's class needs them
                        (repo_root / "debug_logs" / "backups").mkdir(parents=True, exist_ok=True)
                        (repo_root / "debug_logs" / "backups" / (other.parent.parent.name + "_" + other.name + ".before_hoist")).write_text(
                            other.read_text(encoding="utf-8"), encoding="utf-8")
                        other.write_text(o_new, encoding="utf-8")
                        log(f"  {other.parent.parent.name}: {o_n} selector(s) added to {other.name} (the page code is shared by all banks)")
                bak = repo_root / "debug_logs" / "backups"
                bak.mkdir(parents=True, exist_ok=True)
                (bak / (page_path.name + ".before_hoist")).write_text(page_src, encoding="utf-8")
                (bak / (loc_path.name + ".before_hoist")).write_text(loc_src, encoding="utf-8")
                page_path.write_text(new_page, encoding="utf-8")
                loc_path.write_text(new_loc, encoding="utf-8")
                total += len(notes)
                log(f"  {page_path.name}: {len(notes)} inline selector(s) moved into {loc_path.name} (the page holds no XPath / CSS)")
        except Exception as exc:
            _log_exception("hoisting inline selectors", exc)
    total += upgrade_option_templates(repo_root, bank, module, log=log)
    total += convert_dropdowns_in_module(repo_root, bank, module, log=log)
    for page_path in sorted((repo_root / "src" / "common" / "pages" / module).glob("*_page.py")):
        try:
            for issue in find_hardcoding_in_page(page_path.read_text(encoding="utf-8"))[:8]:
                log(f"  WARNING hard-coded in {page_path.name}: {issue}")
        except Exception:
            pass
    return total


def rename_duplicate_methods(src: str) -> tuple[str, list[str]]:
    """Two methods with the same name in ONE class: Python keeps only the LAST. After the negative class is merged into the
    positive one both have a fixture called `setup`, so the first one (which creates self.binmanagement_page ...) is silently
    thrown away. The later duplicates are renamed (setup -> setup_2) so every autouse fixture still runs."""
    notes: list[str] = []
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src, notes
    lines = src.split("\n")
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
        seen: dict[str, int] = {}
        for f in cls.body:
            if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)):
                seen[f.name] = seen.get(f.name, 0) + 1
                if seen[f.name] > 1:
                    new_name = f"{f.name}_{seen[f.name]}"
                    ln = f.lineno - 1
                    lines[ln] = re.sub(rf"(def\s+){re.escape(f.name)}(\s*\()", rf"\g<1>{new_name}\g<2>", lines[ln], count=1)
                    notes.append(f"class {cls.name} defined '{f.name}' twice (the first one was being overridden) -> renamed the later one to '{new_name}'")
    out = "\n".join(lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return src, []
    return out, notes


def normalize_test_self_usage(src: str, module: str, bank: str) -> tuple[str, list[str]]:
    """Repairs a generated test file (self.<attr>, bare RuntimeData.resolve, duplicate fixtures) and gives every test class the
    markers the root conftest needs to keep it (bank + test_type)."""
    out, notes = _normalize_self_usage_core(src, module, bank)
    if bank:
        out, mnotes = ensure_test_markers(out, required_test_markers(bank), bank)
        notes = notes + mnotes
    return out, notes


def _normalize_self_usage_core(src: str, module: str, bank: str) -> tuple[str, list[str]]:
    notes: list[str] = []
    src, _dup_notes = rename_duplicate_methods(src)
    notes += _dup_notes
    if runtime_data_enabled() and "RuntimeData" in src:
        fixed_src = fix_runtime_resolve_calls(src, module, bank)
        if fixed_src != src:
            notes.append(f'RuntimeData.resolve(...) now assigns its result and uses the module key "{module}" '
                         f"(a bare call throws the resolved values away; a different key breaks View/Edit/Delete)")
            src = fixed_src
        if "RuntimeData.resolve" in src and not re.search(r"import[^\n]*\bRuntimeData\b", src):
            try:
                imps = [n for n in ast.parse(src).body if isinstance(n, (ast.Import, ast.ImportFrom))]
                ls = src.split("\n")
                ls.insert(imps[-1].end_lineno if imps else 0, "from src.common.utilities.runtime_data import RuntimeData")
                src = "\n".join(ls)
                notes.append("added the missing  from src.common.utilities.runtime_data import RuntimeData")
            except SyntaxError:
                pass
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src, notes
    lines = src.split("\n")
    bank_ref = "BANK_NAME" if re.search(r"^BANK_NAME\s*=", src, re.M) else repr(bank)
    known_classes = {n.name for n in tree.body if isinstance(n, ast.ClassDef)} | \
        {a.name for n in tree.body if isinstance(n, ast.ImportFrom) for a in n.names}
    page_classes = sorted(c for c in known_classes if c.endswith("Page"))

    def is_self_attr(n, ctx=None) -> bool:
        return isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == "self"

    edits: list[tuple[int, int, list[str]]] = []      # (first line idx, last line idx, replacement) - applied bottom-up
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name.startswith("Test")]:
        funcs = [f for f in cls.body if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))]
        fixtures = [f for f in funcs if any("fixture" in ast.unparse(d) for d in f.decorator_list)
                    or f.name in ("setup", "setup_method")]
        tests = [f for f in funcs if f.name.startswith("test_") and f not in fixtures]
        helpers = [f for f in funcs if f not in tests and f not in fixtures]
        method_names = {f.name for f in funcs}
        # attributes assigned by the class' fixtures (ordered) and anywhere else in the class
        inl: dict[str, tuple[str, ast.Assign, ast.AST]] = {}
        for fx in fixtures:
            for st in fx.body:
                if isinstance(st, ast.Assign) and len(st.targets) == 1 and is_self_attr(st.targets[0]):
                    expr = ast.get_source_segment(src, st.value)
                    if expr:
                        inl[st.targets[0].attr] = (expr, st, fx)
        assigned = {t.attr for n in ast.walk(cls) if isinstance(n, (ast.Assign, ast.AnnAssign, ast.AugAssign))
                    for t in (n.targets if isinstance(n, ast.Assign) else [n.target]) if is_self_attr(t)}
        class_level = {t.id for n in cls.body if isinstance(n, ast.Assign) for t in n.targets if isinstance(t, ast.Name)}
        helper_used = {n.attr for h in helpers for n in ast.walk(h) if is_self_attr(n) and isinstance(n.ctx, ast.Load)}
        removable: set[str] = set()
        for t in tests:
            used = [n.attr for n in ast.walk(t) if is_self_attr(n) and isinstance(n.ctx, ast.Load)]
            used = list(dict.fromkeys(a for a in used if a not in method_names and a not in class_level))
            if not used:
                continue
            exprs: dict[str, str] = {}
            order: list[str] = [a for a in inl if a in used or any(f"self.{u}" in inl[a][0] for u in used)]
            for a in used:
                if a in inl:
                    continue
                if a == "page":
                    continue
                if a == "bank_name":
                    continue
                if a in assigned:
                    continue                         # assigned somewhere we cannot inline (a helper) - leave it
                cands = [c for c in page_classes if _tokens_of_name(a) and _tokens_of_name(a) <= _tokens_of_name(c)] or \
                        ([c for c in page_classes if module.lower() in c.lower()][:1] if "page" in a.lower() else [])
                if cands:
                    exprs[a] = f"{cands[0]}(page)"
                    order.append(a)
                    notes.append(f"{t.name}: self.{a} was never assigned -> created it inside the test as {cands[0]}(page)")
                else:
                    notes.append(f"{t.name}: self.{a} is used but never assigned and no page class matches it - fix by hand")
            for a in order:
                if a in inl:
                    exprs[a] = inl[a][0]
            direct: dict[str, str] = {}                 # attributes that are just `page` / BANK_NAME: no local variable needed
            for a in list(order):
                if exprs[a].strip() in ("page", "BANK_NAME", bank_ref):
                    direct[a] = exprs[a].strip()
                    order.remove(a)
            order.sort(key=lambda n: (0 if "login" in n.lower() else 1))          # login first, like the reference chain
            local_names = set(exprs) - set(direct)
            subst = {"page": "page", "bank_name": bank_ref}
            subst.update(direct)
            subst.update({a: a for a in local_names})
            def conv(text: str) -> str:
                return re.sub(r"\bself\.(\w+)\b(?!\s*\()", lambda m: subst.get(m.group(1), m.group(0)), text)
            body_first = t.body[0].lineno - 1
            doc_skip = 0
            if isinstance(t.body[0], ast.Expr) and isinstance(getattr(t.body[0], "value", None), ast.Constant) \
                    and isinstance(t.body[0].value.value, str) and len(t.body) > 1:
                doc_skip = 1
            anchor_stmt = t.body[doc_skip]
            insert_at = anchor_stmt.lineno - 1
            if "RuntimeData.resolve" in "\n".join(lines[anchor_stmt.lineno - 1:anchor_stmt.end_lineno]):
                insert_at = anchor_stmt.end_lineno
            indent = " " * anchor_stmt.col_offset
            new_locals = [f"{indent}{a} = {conv(exprs[a])}" for a in order]
            seg = lines[t.lineno - 1:t.end_lineno]
            rel_insert = insert_at - (t.lineno - 1)
            seg_conv = [conv(l) if k >= rel_insert or k > 0 else l for k, l in enumerate(seg)]
            seg_conv = seg_conv[:rel_insert] + new_locals + seg_conv[rel_insert:]
            # ensure the test receives the `page` fixture when a local needs it
            needs_page = any(re.search(r"\bpage\b", e) for e in exprs.values()) or any(
                re.search(r"\bpage\b", l) for l in new_locals)
            has_page = any(a.arg == "page" for a in t.args.args)
            if needs_page and not has_page:
                for k in range(0, min(rel_insert, len(seg_conv))):
                    if re.search(r"def\s+\w+\(\s*self\b", seg_conv[k]):
                        seg_conv[k] = re.sub(r"(def\s+\w+\(\s*self)", r"\1, page", seg_conv[k], count=1)
                        break
            edits.append((t.lineno - 1, t.end_lineno - 1, seg_conv))
            removable |= {a for a in list(order) + list(direct) if a in inl and a not in helper_used}
            if order or "page" in used or "bank_name" in used:
                notes.append(f"{t.name}: self.{{{', '.join(sorted(set(used)))}}} -> local variables inside the test")
        # the fixtures lose the assignments that every test now creates itself
        for fx in fixtures:
            stmts = [st for st in fx.body if not (isinstance(st, ast.Expr) and isinstance(getattr(st, "value", None), ast.Constant))]
            keep = [st for st in stmts if not (isinstance(st, ast.Assign) and len(st.targets) == 1 and is_self_attr(st.targets[0])
                                               and st.targets[0].attr in removable)
                    and not (isinstance(st, ast.Assign) and len(st.targets) == 1 and is_self_attr(st.targets[0])
                             and st.targets[0].attr in ("page", "bank_name") and "page" not in helper_used and "bank_name" not in helper_used)]
            if len(keep) < len(stmts):
                if not keep or all(isinstance(st, ast.Pass) for st in keep):
                    first = min([d.lineno for d in fx.decorator_list] + [fx.lineno]) - 1
                    end = fx.end_lineno - 1 + (1 if fx.end_lineno < len(lines) and not lines[fx.end_lineno].strip() else 0)
                    edits.append((first, end, []))
                    notes.append(f"fixture '{fx.name}' only created attributes the tests now create themselves -> removed")
                else:
                    for st in stmts:
                        if st not in keep:
                            edits.append((st.lineno - 1, st.end_lineno - 1, []))
    if not edits:
        return src, notes
    new_lines = list(lines)
    for a, b, rep in sorted(edits, key=lambda e: -e[0]):
        new_lines[a:b + 1] = rep
    out = "\n".join(new_lines)
    try:
        ast.parse(out)
    except SyntaxError:
        return src, ["(self-attribute normalisation skipped: the result would not parse)"]
    return out, notes


# ======================================================================
# ONE place that turns the run-time tokens into real values BEFORE every test body runs.
# Screenshot symptom: the portal's search box contained the text {{FROM_ADD}} - the token was typed literally because the
# test never replaced it (RuntimeData.resolve(...) was called without using its result, or not at all). A folder-level
# conftest.py now resolves the row of data in place, so Add / View / Edit / Delete / negative tests all get real values no
# matter what the generated test code does.
# ======================================================================
DATA_PREPARE_MARKER = "# data_prepare v5 (generated by the test generator)"
DATA_PREPARE_SOURCE = r'''# data_prepare v5 (generated by the test generator)
"""Puts REAL VALUES into the module's test-data workbook, so Add, View, Edit, Delete and every negative case use values that
BELONG TOGETHER - for ANY module, not only BIN management:

    Add      the unique value(s) Add creates (a BIN, a Merchant ID, a Name ... = the columns that hold a {{RANDOM..}} / {{LUHN..}} token)
             plus anything derived from them (e.g. 'BIN low range' = BIN + zeros, 'BIN high range' = BIN + nines)
    View / Edit / Delete / ...   the SAME value(s) (the record Add creates is the record that is searched, edited, deleted)
    Negative / NegativeEdit      a valid base + the ONE bad value per row (the duplicate row = the value of Add)

The workbook the tests read (<Module>.xlsx) always holds real values. The generator's version with {{...}} tokens is kept as
<Module>.template.xlsx; every call regenerates NEW values from that template (a record that already exists in the portal cannot
be added twice). Values are written as TEXT (a 19-digit number does not fit an Excel number)."""
import os
import re
import shutil
from pathlib import Path

_NOISE = {"field", "input", "dropdown", "select", "radio", "checkbox", "textbox", "text", "box"}
_STD_COLS = {"scenarioid", "testcaseid", "description", "expectedmessage", "expectedmessage1", "priority", "negativetype"}
_RUN_TAG_RE = re.compile(r"^(.*\S)_(\d{6}|\d{4})$")


def _strip_run_tag(value: str) -> str:
    """'Visa_144400' -> 'Visa': an OLD uniqueness guard appended the time to dropdown values; the portal has no such option.
    (The template is the source of every run, so cleaning only the workbook by hand is undone by the next run.)"""
    m = _RUN_TAG_RE.match(value)
    if not m or "@" in value:
        return value
    tag = m.group(2)
    h, mi = int(tag[:2]), int(tag[2:4])
    return m.group(1) if h < 24 and mi < 60 and (len(tag) == 4 or int(tag[4:6]) < 60) else value
_REMEMBER_RE = re.compile(r"^\{\{\s*(RANDOM|LUHN)\b", re.I)


def _has_token(value) -> bool:
    return isinstance(value, str) and "{{" in value


def _tokens(text: str) -> set[str]:
    words = re.sub(r"[^a-z0-9]+", " ", re.sub(r"([a-z])([A-Z])", r"\1 \2", str(text)).lower()).split()
    return {w for w in words if w not in _NOISE}


def _luhn_digit(payload: str) -> int:
    total = 0
    for i, ch in enumerate(reversed(payload)):
        d = int(ch)
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10


def luhn_valid(number: str) -> bool:
    return number.isdigit() and len(number) > 1 and _luhn_digit(number[:-1]) == int(number[-1])


def _luhn_hints() -> list[str]:
    return [h.strip().lower() for h in os.environ.get("AI_LUHN_COLUMNS", "bin").split(",") if h.strip()]


def _is_luhn_column(col: str) -> bool:
    return any(h in _tokens(col) for h in _luhn_hints()) and "range" not in col.lower()


def _range_kind(col: str, id_col: str) -> str | None:
    """A low / high column that is built FROM the identifier ('BIN low range' for the identifier 'BIN'); an unrelated
    'Amount low range' is None."""
    hints = os.environ.get("AI_RANGE_IDENTIFIERS", "").strip() or os.environ.get("AI_LUHN_COLUMNS", "bin")
    if not id_col or not ({h.strip().lower() for h in hints.split(",") if h.strip()} & _tokens(id_col)):
        return None                       # ranges follow the identifier only for card-prefix identifiers (AI_RANGE_IDENTIFIERS)
    if not (_tokens(id_col) <= _tokens(col)) or _tokens(col) == _tokens(id_col):
        return None
    low = col.lower()
    if re.search(r"\b(low|from|min|start)\b", low):
        return "low"
    if re.search(r"\b(high|to|max|end)\b", low):
        return "high"
    return None


def _rows(ws) -> tuple[list[str], list[dict]]:
    it = ws.iter_rows(values_only=True)
    header = [str(c).strip() if c is not None else "" for c in next(it, [])]
    rows = [{h: ("" if v is None else str(v)) for h, v in zip(header, r) if h} for r in it if any(v not in (None, "") for v in r)]
    return header, rows


def remembered_columns(workbook) -> list[str]:
    """The columns Add GENERATES (a RANDOM / LUHN token in the template): the values every other sheet refers to. When the
    workbook has no tokens the template next to it is read; AI_IDENTIFIER_COLUMN forces one column."""
    import openpyxl
    forced = os.environ.get("AI_IDENTIFIER_COLUMN", "").strip()
    if forced:
        return [forced]
    workbook = Path(workbook)
    template = workbook.with_name(workbook.stem + ".template.xlsx")
    src = workbook
    try:
        wb = openpyxl.load_workbook(src, read_only=True)
        has_tokens = any(_has_token(c) for ws in wb.worksheets for row in ws.iter_rows(values_only=True) for c in row)
        wb.close()
        if not has_tokens and template.exists():
            src = template
        wb = openpyxl.load_workbook(src, read_only=True)
        cols: list[str] = []
        for ws in wb.worksheets:
            if ws.title.lower() != "add":
                continue
            header, rows = _rows(ws)
            for h in header:
                if h and any(_REMEMBER_RE.match(r.get(h, "")) for r in rows) and h not in cols:
                    cols.append(h)
        if not cols:                                          # a template-less workbook: columns that {{FROM_ADD}} points at
            for ws in wb.worksheets:
                header, rows = _rows(ws)
                for h in header:
                    if h and any("{{FROM_ADD}}" in r.get(h, "") for r in rows) and h not in cols:
                        cols.append(h)
        wb.close()
        return cols
    except Exception:
        return []


def materialize(workbook, module: str, bank: str, log=print) -> dict:
    """Replaces every {{...}} token of the template with a real value and saves the workbook. Returns a summary dict."""
    import openpyxl
    from src.common.utilities.runtime_data import RuntimeData

    workbook = Path(workbook)
    template = workbook.with_name(workbook.stem + ".template.xlsx")
    if not workbook.exists():
        raise FileNotFoundError(f"test-data workbook not found: {workbook}")
    probe = openpyxl.load_workbook(workbook, read_only=True)
    has_tokens = any(_has_token(c) for ws in probe.worksheets for row in ws.iter_rows(values_only=True) for c in row)
    probe.close()
    if has_tokens:
        shutil.copy2(workbook, template)           # a freshly generated workbook IS the new template
    elif not template.exists():
        return {"status": "no tokens and no template - the values in the workbook are used as they are", "sheets": {}, "adds": []}
    id_cols = remembered_columns(workbook)
    _sheetnames = [n.lower() for n in openpyxl.load_workbook(template, read_only=True).sheetnames]
    if "add" not in _sheetnames:                   # update-only module: there is no Add, so no identifier is remembered
        id_cols = []
    wb = openpyxl.load_workbook(template)
    order = sorted(wb.sheetnames, key=lambda n: (0 if n.lower() == "add" else 2 if n.lower().startswith("negative") else 1))
    adds: list[dict] = []                              # per Add row: {column: the value Add generated}
    add_full: list[dict] = []                          # per Add row: every column's final value
    done: dict[str, int] = {}
    stripped = 0
    for name in order:
        ws = wb[name]
        header = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
        is_add = name.lower() == "add"
        is_neg = name.lower().startswith("negative")
        count = 0
        for r in range(2, ws.max_row + 1):
            row = {h: ("" if ws.cell(r, i + 1).value is None else str(ws.cell(r, i + 1).value))
                   for i, h in enumerate(header) if h}
            if not any(row.values()):
                continue
            for i, h in enumerate(header):                      # old run tags out of every non-standard column
                v = row.get(h, "")
                if h and v and h.lower().replace(" ", "") not in _STD_COLS and not v.startswith("{{"):
                    clean = _strip_run_tag(v)
                    if clean != v:
                        ws.cell(r, i + 1).value = row[h] = clean
                        stripped += 1
            if add_full and not is_add:
                # row k of View / Edit / Delete -> the value(s) of row k of Add; the negatives -> those of the first Add row
                src_row = adds[0] if is_neg else adds[min(r - 2, len(adds) - 1)]
                for col, val in src_row.items():
                    RuntimeData.set(bank, module, col, val)
                # a {{FROM_ADD}} in a column Add did NOT generate (e.g. 'Persona Reference ID' while Add remembers
                # 'Country Code'): use what the Add row of the SAME column holds, instead of failing / leaving it empty
                _add_full = add_full[0] if is_neg else add_full[min(r - 2, len(add_full) - 1)]
                for _h, _v in row.items():
                    if _h and "FROM_ADD" in str(_v) and _h not in src_row and _add_full.get(_h):
                        RuntimeData.set(bank, module, _h, _add_full[_h])
            if any(_has_token(v) for v in row.values()):
                try:
                    resolved = RuntimeData.resolve(row, module, bank)
                except RuntimeError as exc:
                    if "FROM_ADD" not in str(row.values()) and "has been generated yet" not in str(exc):
                        raise
                    log(f"  [prepare] {name} row {r}: {{{{FROM_ADD}}}} has no Add value (update-only module) - left empty, "
                        f"fill that cell with the real record value if the form needs it")
                    row = {h: ("" if "FROM_ADD" in str(v) else v) for h, v in row.items()}
                    resolved = RuntimeData.resolve(row, module, bank)
                    for i, h in enumerate(header):
                        if h and ws.cell(r, i + 1).value is not None and "FROM_ADD" in str(ws.cell(r, i + 1).value):
                            ws.cell(r, i + 1).value = None
                for i, h in enumerate(header):
                    if h and _has_token(row.get(h, "")):
                        ws.cell(r, i + 1).value = str(resolved[h])
                        row[h] = str(resolved[h])
                count += 1
            if is_add:
                adds.append({c: row.get(c, "") for c in id_cols if row.get(c, "")})
                add_full.append(dict(row))
        done[name] = count
    tmp = workbook.with_name(workbook.stem + ".tmp.xlsx")
    wb.save(tmp)
    wb.close()
    try:
        os.replace(tmp, workbook)
    except PermissionError:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"Cannot write {workbook.name}: it is OPEN in Excel - close it and run again.")
    summary = {"status": "prepared", "sheets": done, "adds": adds, "id_columns": id_cols, "stripped": stripped,
               "problems": check_consistency(workbook)}
    if stripped:
        log(f"  [prepare] removed an old run tag (_144400 ...) from {stripped} value(s) - dropdown values must be the portal's exact option")
    shown = "; ".join(", ".join(f"{k}={v}" for k, v in a.items()) for a in adds) or "(no generated value)"
    log(f"  [prepare] {workbook.name}: real values written (" + ", ".join(f"{k}: {v} row(s)" for k, v in done.items() if v)
        + f"). Generated by Add: {shown}")
    for p in summary["problems"]:
        log(f"  [prepare] WARNING: {p}")
    return summary


def check_consistency(workbook, id_cols: list[str] | None = None) -> list[str]:
    """The values must belong together: what Add generates is what View / Edit / Delete use; a Luhn column (AI_LUHN_COLUMNS,
    default 'bin') passes the Luhn check; a range built from the identifier starts with it and low / high have the same length.
    Returns the list of problems (empty = consistent)."""
    import openpyxl
    problems: list[str] = []
    id_cols = id_cols if id_cols is not None else remembered_columns(workbook)
    wb = openpyxl.load_workbook(workbook, read_only=True, data_only=True)
    sheets = {ws.title: _rows(ws)[1] for ws in wb.worksheets}
    wb.close()
    add_values: dict[str, set[str]] = {c: set() for c in id_cols}
    for k, row in enumerate(sheets.get("Add", sheets.get("add", [])), 2):
        for c in id_cols:
            if row.get(c):
                add_values[c].add(row[c])
                if _is_luhn_column(c) and not luhn_valid(row[c]):
                    problems.append(f"Add row {k}: {c} '{row[c]}' does not pass the Luhn check")
    for name, rows in sheets.items():
        low = name.lower()
        if low.startswith("negative"):
            continue
        for k, row in enumerate(rows, 2):
            for c in id_cols:
                v = row.get(c, "")
                if low != "add" and add_values.get(c) and v and v not in add_values[c]:
                    problems.append(f"{name} row {k}: {c} '{v}' is not a value that the Add sheet creates {sorted(add_values[c])}")
                for col, val in row.items():
                    kind = _range_kind(col, c)
                    if kind and v and val and not (val.isdigit() and val.startswith(v)):
                        problems.append(f"{name} row {k}: {col} '{val}' does not start with the {c} {v}")
            for c in id_cols:
                los = [row[col] for col in row if _range_kind(col, c) == "low" and row[col]]
                his = [row[col] for col in row if _range_kind(col, c) == "high" and row[col]]
                if los and his and len(los[0]) != len(his[0]):
                    problems.append(f"{name} row {k}: the low and high range of {c} have different lengths")
    return problems
'''


def ensure_data_prepare_util(repo_root: Path, log=print) -> Path | None:
    """Creates src/common/utilities/data_prepare.py (writes REAL numbers into the test-data workbook)."""
    p = repo_root / "src" / "common" / "utilities" / "data_prepare.py"
    try:
        if p.exists() and "# data_prepare v" in p.read_text(encoding="utf-8", errors="ignore")[:200]:     # ours, any version
            if p.read_text(encoding="utf-8") != DATA_PREPARE_SOURCE:
                p.write_text(DATA_PREPARE_SOURCE, encoding="utf-8")                                        # -> the current one
            return p
        if p.exists():
            return p                                    # somebody else's file with that name: never overwrite
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(DATA_PREPARE_SOURCE, encoding="utf-8")
        log(f"  Created {p} (writes real BIN / range numbers into the test-data workbook before a run).")
        return p
    except Exception as exc:
        _log_exception("creating data_prepare.py", exc)
        return None


def materialize_testdata_numbers(repo_root: Path, bank: str, module: str, log=print) -> dict:
    """Writes REAL numbers (no {{...}} tokens) into <Module>.xlsx: Add / View / Edit / Delete / Negative / NegativeEdit all use
    values that belong together (see data_prepare.py). AI_PREPARE_DATA=0 turns this off."""
    if os.environ.get("AI_PREPARE_DATA", "1").strip().lower() in ("0", "false", "no") or not runtime_data_enabled():
        return {}
    import importlib.util
    xlsx = repo_root / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    if not xlsx.exists():
        return {}
    ensure_runtime_data_util(repo_root, log=lambda m: None)
    util = ensure_data_prepare_util(repo_root, log=lambda m: None)
    if not util:
        return {}
    try:
        for m in [k for k in list(sys.modules) if k.startswith("src.common.utilities.runtime_data")]:
            del sys.modules[m]
        if str(repo_root) not in sys.path:
            sys.path.insert(0, str(repo_root))
        spec = importlib.util.spec_from_file_location("data_prepare_dynamic", util)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.materialize(xlsx, module, bank, log=log)
    except Exception as exc:
        _log_exception("writing real numbers into the test-data workbook", exc)
        log(f"  [prepare] could not write the numbers: {str(exc).splitlines()[0][:160]}")
        return {}


CONFTEST_MARKER = "# runtime-token resolver (generated by the test generator)"
CONFTEST_BLOCK = r'''@@MARKER@@
import os
import re
import pytest
from pathlib import Path
from @@CM_IMPORT@@ import ConfigManager
from src.common.utilities.runtime_data import RuntimeData


def pytest_collection_finish(session):
    """One line that explains 'collected N items': how many test cases of each kind (by test function name)."""
    if os.environ.get("AI_TEST_BANNER", "1").strip() == "0" or not session.items:
        return
    counts: dict = {}
    for it in session.items:
        name = (getattr(it, "originalname", None) or it.name.split("[")[0]).lower()
        parts = re.split(r"[^a-z0-9]+", name)
        kind = "negative" if "negative" in parts else next((k for k in ("approve", "approval", "delete", "edit", "view", "add", "create") if k in parts), "other")
        counts[kind] = counts.get(kind, 0) + 1
    print("\n[collected] " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) + f"  (total {len(session.items)})")


def pytest_collection_modifyitems(config, items):
    """AI_TEST_PHASE=add runs only the Add tests, =rest everything else (run_tests.py uses it). It looks at the TEST FUNCTION
    NAME only, so a module / class name that contains 'add' cannot confuse it (pytest's -k also matches parent names)."""
    phase = os.environ.get("AI_TEST_PHASE", "").strip().lower()
    if phase not in ("add", "approve", "rest"):
        return

    add_words = {w.strip().lower() for w in os.environ.get("AI_ADD_WORDS", "add,create").split(",") if w.strip()}
    approve_words = {w.strip().lower() for w in os.environ.get("AI_APPROVE_WORDS", "approve,approval,approved,authorize,authorise,checker").split(",") if w.strip()}

    def parts_of(item):
        name = getattr(item, "originalname", None) or item.name.split("[")[0]
        return set(re.split(r"[^a-z0-9]+", name.lower()))

    def is_add(item) -> bool:
        p = parts_of(item)
        return "negative" not in p and bool(add_words & p)

    def is_approve(item) -> bool:
        p = parts_of(item)
        return "negative" not in p and bool(approve_words & p) and not is_add(item)

    pick = {"add": is_add, "approve": is_approve, "rest": lambda it: not is_add(it) and not is_approve(it)}[phase]
    keep = [i for i in items if pick(i)]
    drop = [i for i in items if i not in keep]
    print(f"\n[phase={phase}] running {len(keep)} of {len(items)} test(s)"
          + ("" if keep else "  <- NO test name contains 'add' / 'create' (phase 'add') - nothing is selected"))
    if drop:
        config.hook.pytest_deselected(items=drop)
    items[:] = keep


def pytest_sessionstart(session):
    """BEFORE the Excel sheets are read: write fresh REAL numbers (BIN, low / high range ...) into the workbook so Add, View,
    Edit, Delete and the negative cases use values that belong together. Skipped for -k / node-id / --collect-only runs (they
    keep the numbers of the last full run) and when AI_PREPARE_DATA=0."""
    if os.environ.get("AI_PREPARE_DATA", "1").strip().lower() in ("0", "false", "no"):
        return
    opt = session.config.option
    if getattr(opt, "keyword", "") or getattr(opt, "collectonly", False):
        return
    if any("::" in str(a) for a in session.config.args):
        return
    here = Path(__file__).resolve()
    module = here.parent.name
    bank = ConfigManager.get("bank")
    workbook = here.parents[3] / "src" / "banks" / bank / "testdata" / (module[:1].upper() + module[1:] + ".xlsx")
    if not workbook.exists():
        return
    try:
        from src.common.utilities.data_prepare import materialize
        materialize(workbook, module, bank)
    except ImportError:
        return
    except RuntimeError as exc:
        pytest.exit(str(exc), returncode=2)


@pytest.fixture(autouse=True)
def _resolve_runtime_tokens(request):
    """Replaces {{LUHN:6}}, {{FROM_ADD}}, {{LOW:BIN:19}} ... in this test's row of data BEFORE the test body runs, so
    View / Edit / Delete / negative tests never type a literal token into the portal. The row is restored afterwards, so a
    re-run gets fresh values."""
    callspec = getattr(request.node, "callspec", None)
    data = None
    if callspec is not None:
        data = next((v for v in callspec.params.values()
                     if isinstance(v, dict) and ("ScenarioID" in v or "TestcaseID" in v)), None)
    if data is None:
        yield
        return
    node_path = getattr(request.node, "path", None) or request.node.fspath
    module = Path(str(node_path)).parent.name            # test_<module>.py lives in src/testcase/<module>/
    bank = getattr(request.module, "BANK_NAME", None) or ConfigManager.get("bank")
    original = dict(data)
    data.update(RuntimeData.resolve(data, module, bank))
    if os.environ.get("AI_TEST_BANNER", "1").strip() != "0":      # what THIS test is about to type / select (shown with -s, or on failure)
        std = {"scenarioid", "testcaseid", "description", "expectedmessage", "expectedmessage1", "priority", "negativetype"}
        shown = " | ".join(f"{k}={str(v)[:26]}" for k, v in data.items() if str(k).lower().replace(" ", "") not in std and str(v).strip())
        expected = str(data.get("ExpectedMessage", "")).strip()
        print(f"\n[data] {data.get('TestcaseID', '')}  {str(data.get('Description', ''))[:60]}  |  {shown}"
              + (f"  ->  expects: {expected[:60]}" if expected else ""))
    try:
        yield
    finally:
        data.clear()
        data.update(original)
'''


def ensure_module_conftest(repo_root: Path, module: str, test_path: Path | None = None, log=print) -> Path | None:
    """Creates src/testcase/<module>/conftest.py with the token-resolving fixture (appends it to an existing conftest.py that
    does not have it yet, after a backup). Returns the path, or None when nothing was written."""
    if not runtime_data_enabled():
        return None
    folder = repo_root / "src" / "testcase" / module
    if not folder.exists():
        return None
    cm_import = "src.common.utilities.config_loader"
    try:
        src_text = (test_path or next(folder.glob("test_*.py"), None)).read_text(encoding="utf-8")
        m = re.search(r"^from\s+([\w.]+)\s+import\s+[^\n]*\bConfigManager\b", src_text, re.M)
        if m:
            cm_import = m.group(1)
    except Exception:
        pass
    ensure_data_prepare_util(repo_root, log=lambda m: None)
    block = CONFTEST_BLOCK.replace("@@MARKER@@", CONFTEST_MARKER).replace("@@CM_IMPORT@@", cm_import)
    target = folder / "conftest.py"
    try:
        if target.exists():
            current = target.read_text(encoding="utf-8")
            if CONFTEST_MARKER in current:
                if current.strip() == block.strip():
                    return target
                target.write_text(block, encoding="utf-8")          # ours, an older version: refresh
                return target
            bak = repo_root / "debug_logs" / "backups"
            bak.mkdir(parents=True, exist_ok=True)
            (bak / f"{module}_conftest.py.bak").write_text(current, encoding="utf-8")
            target.write_text(current.rstrip() + "\n\n\n" + block, encoding="utf-8")
        else:
            target.write_text(block, encoding="utf-8")
        log(f"  Wrote {target}: it replaces every {{{{...}}}} token in a test's data (BIN from Add, ranges ...) BEFORE the test runs.")
        return target
    except Exception as exc:
        _log_exception("writing the module conftest.py", exc)
        return None


_RUN_TAG_RE = re.compile(r"^(.*\S)_(\d{6}|\d{4})$")


def _plausible_time_tag(tag: str) -> bool:
    """HHMMSS / HHMM, the format the old uniqueness guard used (a real option like 'Plan_2024' still passes - hence a backup)."""
    h, m = int(tag[:2]), int(tag[2:4])
    return h < 24 and m < 60 and (len(tag) == 4 or int(tag[4:6]) < 60)


def strip_run_tags_in_workbook(xlsx: Path, only_columns=None, facts=None, log=print) -> list[tuple[str, str, str, str]]:
    """Removes a run tag (_144400 / _1857) the old uniqueness guard appended to option values. only_columns=None: every column
    except the standard ones, identifiers (tokens / numbers), e-mails; facts given: only columns the live form shows as a select /
    radio / checkbox. Returns [(sheet, column, before, after)]. The original is saved as <name>.bak.xlsx first."""
    import openpyxl
    changed: list[tuple[str, str, str, str]] = []
    if not xlsx.exists():
        return changed
    wb = openpyxl.load_workbook(xlsx)
    for ws in wb.worksheets:
        header = [str(c.value).strip() if c.value is not None else "" for c in ws[1]]
        for ci, col in enumerate(header, 1):
            if not col or col.strip().lower().replace(" ", "") in _STD_COLS:
                continue
            if facts is not None:
                fact = _fact_for_column(col, facts)
                if not fact or not (fact.get("tag") in ("select", "mat-select") or fact.get("options") or fact.get("type") in ("radio", "checkbox")):
                    continue
            for r in range(2, ws.max_row + 1):
                v = ws.cell(r, ci).value
                if not isinstance(v, str) or v.startswith("{{") or "@" in v:
                    continue
                m = _RUN_TAG_RE.match(v)
                if m and _plausible_time_tag(m.group(2)):
                    ws.cell(r, ci).value = m.group(1)
                    changed.append((ws.title, col, v, m.group(1)))
    if changed:
        import shutil
        bak = xlsx.with_name(xlsx.stem + ".bak.xlsx")
        if not bak.exists():
            shutil.copy2(xlsx, bak)
        try:
            wb.save(xlsx)
        except PermissionError:
            raise RuntimeError(f"Cannot write {xlsx.name}: it is OPEN in Excel - close it and run again.")
    wb.close()
    return changed


def clean_choice_suffixes(repo_root: Path, bank: str, module: str, facts: list[dict], log=print) -> int:
    """After the dry run (the live form tells which columns are dropdowns / radios): removes run tags from those columns in the
    workbook and its template."""
    if not facts:
        return 0
    base = repo_root / "src" / "banks" / bank / "testdata" / f"{module[:1].upper() + module[1:]}.xlsx"
    total = 0
    for f in (base, base.with_name(base.stem + ".template.xlsx")):
        try:
            ch = strip_run_tags_in_workbook(f, facts=facts)
        except Exception as exc:
            _log_exception("removing run tags from dropdown values", exc)
            continue
        total += len(ch)
        for sh, col, a, b in ch[:6]:
            log(f"  Testdata '{sh}' / {col}: '{a}' -> '{b}' (a dropdown value must stay the portal's exact option)")
    return total


def read_all_testdata_rows(xlsx_path: Path, sheet_name: str = "Add") -> list[dict[str, str]]:
    """Like read_first_testdata_row, but every row, not just the first -
    used to drive EVERY positive AND negative case through a real
    browser, not just the one happy-path Add row."""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
        sheet = wb[sheet_name] if sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
        rows_iter = sheet.iter_rows(values_only=True)
        header = next(rows_iter, None)
        if not header:
            wb.close()
            return []
        result = [{str(h): ("" if v is None else str(v)) for h, v in zip(header, data_row) if h}
                   for data_row in rows_iter if data_row and any(v is not None for v in data_row)]
        wb.close()
        return result
    except Exception:
        return []


def verify_all_testdata_assertions(repo_root: Path, bank: str, portal_type: str,
                                    module: str, scenario: str,
                                    testdata_rows: list[dict[str, str]]) -> list[str]:
    """FEATURE: real, per-row assertion capture and validation - the
    generalization of verify_result_locator_against_testdata to EVERY
    row, not just the Add/positive one. Exactly what was asked for:
    POSITIVE rows (however many - 5, 10) are expected to converge on
    the SAME real success message (reported if any positive row's
    captured message diverges from the others), while EVERY NEGATIVE
    row gets its OWN real, captured validation error - never an AI
    GUESS at what the message might say. For each row: fills every
    field with THAT row's own values (including a deliberately
    out-of-range value for whichever field the row is testing), submits
    for real, reads whatever message/error text ACTUALLY appears, and
    compares it against the row's own ExpectedMessage column -
    reporting the REAL captured text whenever it doesn't match what's
    in the Excel, so the Excel can be corrected to the real wording
    rather than an invented guess.

    SAFER than it might sound for the negative rows specifically: a
    genuinely invalid submission is normally REJECTED by the real
    form's own validation, not persisted - only rows that validation
    actually ACCEPTS (the positive ones, and any negative row whose
    "violation" turns out not to be enforced) create real records.
    Still opt-in (see AI_VERIFY_RESULT_LOCATORS) since it does perform
    real submits.

    Returns a list of warning strings - one per row whose captured
    real message doesn't match its ExpectedMessage, naming both."""
    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not locators_path.exists():
        return []
    content = locators_path.read_text(encoding="utf-8")
    entries = LOCATOR_LINE_RE.findall(content)
    RESULT_LOCATOR_HINTS = ("message", "error", "success", "toast", "alert",
                             "notification", "validation", "warning", "banner")
    FINALIZING_HINTS = ("save", "submit", "confirm", "send")
    result_fields = [(attr, val) for _, attr, val in entries
                      if any(h in attr.lower() for h in RESULT_LOCATOR_HINTS)
                      and not val.startswith("#TODO")]
    submit_field = next(((attr, val) for _, attr, val in entries
                          if any(h in attr.lower() for h in FINALIZING_HINTS)
                          and not val.startswith("#TODO")), None)
    if not result_fields or not submit_field:
        return []

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return ["(skipped - playwright not available)"]
    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]
    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n:
            config_path.write_text(new_text, encoding="utf-8")

    warnings: list[str] = []
    positive_captured: list[tuple[str, str]] = []  # (ScenarioID, captured text) across positive rows
    try:
        import sys as _sys
        repo_str = str(repo_root)
        if repo_str not in _sys.path:
            _sys.path.insert(0, repo_str)
        login_module = __import__(
            f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
        LoginPageClass = getattr(login_module, class_name)

        for row in testdata_rows:
            expected_message = (row.get("ExpectedMessage") or "").strip()
            if not expected_message:
                continue
            scenario_id = row.get("ScenarioID") or "(unknown row)"
            desc = (row.get("Description") or "").lower()
            NEGATIVE_HINTS = ("blank", "invalid", "negative", "boundary", "past the", "past its",
                               "required", "max", "min", "missing", "wrong", "incorrect",
                               "below", "above", "exceed", "less than", "more than")
            is_negative = any(h in desc for h in NEGATIVE_HINTS)

            with sync_playwright() as p:
                browser = p.chromium.launch(headless=_headless())
                page = browser.new_page()
                try:
                    LoginPageClass(page).login(bank)
                    page.wait_for_load_state("networkidle", timeout=15000)
                    if scenario:
                        navigate_via_scenario_text(page, scenario)

                    for _, attr_name, value in entries:
                        if value.startswith("#TODO"):
                            continue
                        if any(h in attr_name.lower() for h in RESULT_LOCATOR_HINTS):
                            continue
                        if (attr_name, value) == submit_field:
                            continue
                        norm_attr = re.sub(r"[_\s]", "", attr_name.lower())
                        fill_value = None
                        for col, val in row.items():
                            if col == "ExpectedMessage" or not val or not val.strip():
                                continue
                            norm_col = re.sub(r"[_\s]", "", col.lower())
                            if norm_col in norm_attr or norm_attr in norm_col:
                                fill_value = val
                                break
                        if fill_value is None:
                            continue
                        try:
                            loc = page.locator(value)
                            if loc.count() == 1:
                                tag = loc.evaluate("el => el.tagName.toLowerCase()")
                                if tag in ("input", "textarea"):
                                    loc.fill(fill_value, timeout=3000)
                        except Exception:
                            pass

                    submit_attr, submit_value = submit_field
                    page.locator(submit_value).first.click(timeout=5000)
                    page.wait_for_timeout(1500)

                    captured_text = None
                    for attr_name, value in result_fields:
                        try:
                            loc = page.locator(value)
                            if loc.count() == 1:
                                captured_text = loc.inner_text().strip()
                                break
                        except Exception:
                            continue

                    if captured_text is None:
                        warnings.append(f"[{scenario_id}] no result/message locator resolved "
                                         f"after submitting - could not capture a real message "
                                         f"to compare against ExpectedMessage '{expected_message}'.")
                    elif expected_message.lower() in captured_text.lower() or \
                         captured_text.lower() in expected_message.lower():
                        if not is_negative:
                            positive_captured.append((scenario_id, captured_text))
                    else:
                        warnings.append(
                            f"[{scenario_id}] real captured message is '{captured_text}', but "
                            f"testdata's ExpectedMessage says '{expected_message}' - update the "
                            f"Excel to the real captured wording.")
                        if not is_negative:
                            positive_captured.append((scenario_id, captured_text))

                    attempt_logout(page)
                except Exception as exc:
                    warnings.append(f"[{scenario_id}] row verification failed to run: {exc}")
                finally:
                    browser.close()

        # Cross-check: every POSITIVE row should converge on the SAME
        # real success message - if they diverge, that's worth flagging
        # even when each one individually "matched" its own row's
        # ExpectedMessage (the Excel itself may have inconsistent
        # positive-case wording across rows).
        if len(positive_captured) > 1:
            distinct = {text for _, text in positive_captured}
            if len(distinct) > 1:
                detail = ", ".join(f"{sid}='{text}'" for sid, text in positive_captured)
                warnings.append(f"Positive rows captured DIFFERENT real success messages "
                                 f"(expected all positive cases to share one): {detail}")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    return warnings


def verify_result_locator_against_testdata(repo_root: Path, bank: str, portal_type: str,
                                            module: str, scenario: str,
                                            testdata_values: dict[str, str]) -> list[str]:
    """FEATURE: result/assertion locator verification (success_message,
    error locators etc) - the ONE thing dry_run_verify_interactions and
    verify_and_heal_locators_file BOTH deliberately leave unverified,
    since a result locator only exists on the page AFTER the real
    action is actually submitted, not on the static pre-action page
    either of those checks operate on.

    OPT-IN AND OFF BY DEFAULT (AI_VERIFY_RESULT_LOCATORS=1) - UNLIKE
    dry-run, this performs a REAL submit (fills every field with real
    testdata values, then actually clicks the real save/submit button),
    which genuinely creates/modifies real data on whatever environment
    this runs against. This is a deliberate, informed trade-off: it is
    the ONLY way to verify a result locator for real, but it has real
    side effects dry-run intentionally avoids - so it must be explicitly
    opted into, never run by default alongside the other, side-effect-
    free checks.

    After submitting, reads the ACTUAL text of whatever element the
    result/message locator resolves to, and compares it against the
    testdata row's own ExpectedMessage column - an exact match is
    silently fine; any mismatch becomes a warning naming BOTH the
    locator's real text and what the testdata expected, so a wrong
    ExpectedMessage in the Excel and a wrong locator in locators.py are
    both visible and distinguishable from each other, not just a single
    generic pytest assertion failure."""
    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if not locators_path.exists():
        return []
    content = locators_path.read_text(encoding="utf-8")
    entries = LOCATOR_LINE_RE.findall(content)

    RESULT_LOCATOR_HINTS = ("message", "error", "success", "toast", "alert",
                             "notification", "validation", "warning", "banner")
    FINALIZING_HINTS = ("save", "submit", "confirm", "send")
    result_fields = [(attr, val) for _, attr, val in entries
                      if any(h in attr.lower() for h in RESULT_LOCATOR_HINTS)
                      and not val.startswith("#TODO")]
    submit_field = next(((attr, val) for _, attr, val in entries
                          if any(h in attr.lower() for h in FINALIZING_HINTS)
                          and not val.startswith("#TODO")), None)
    if not result_fields or not submit_field:
        return []  # nothing to verify, or no real way to actually submit - skip silently

    expected_message = (testdata_values.get("ExpectedMessage") or "").strip()
    if not expected_message:
        return []  # no expected value to compare against - nothing meaningful to verify

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return ["(skipped result-locator verification - playwright not available)"]

    if portal_type not in PORTAL_CLASS_MAP:
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]
    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n:
            config_path.write_text(new_text, encoding="utf-8")

    warnings: list[str] = []
    try:
        import sys as _sys
        repo_str = str(repo_root)
        if repo_str not in _sys.path:
            _sys.path.insert(0, repo_str)
        login_module = __import__(
            f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
        LoginPageClass = getattr(login_module, class_name)

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            if scenario:
                navigate_via_scenario_text(page, scenario)

            # Fill every real, non-result, non-submit field with its real
            # testdata value (same fuzzy name-matching dry-run uses).
            for _, attr_name, value in entries:
                if value.startswith("#TODO"):
                    continue
                if any(h in attr_name.lower() for h in RESULT_LOCATOR_HINTS):
                    continue
                if (attr_name, value) == submit_field:
                    continue
                norm_attr = re.sub(r"[_\s]", "", attr_name.lower())
                fill_value = None
                for col, val in testdata_values.items():
                    if not val or not val.strip():
                        continue
                    norm_col = re.sub(r"[_\s]", "", col.lower())
                    if norm_col in norm_attr or norm_attr in norm_col:
                        fill_value = val
                        break
                if fill_value is None:
                    continue  # no matching testdata for this field - leave it alone
                try:
                    loc = page.locator(value)
                    if loc.count() != 1:
                        continue
                    tag = loc.evaluate("el => el.tagName.toLowerCase()")
                    if tag in ("input", "textarea"):
                        loc.fill(fill_value, timeout=3000)
                except Exception:
                    pass  # best-effort fill - a field that fails to fill still lets the
                          # overall submit proceed, this check cares about the RESULT locator

            # The real, deliberate submit - this is what actually creates/
            # modifies real data, and the entire reason this function
            # requires explicit opt-in.
            submit_attr, submit_value = submit_field
            page.locator(submit_value).first.click(timeout=5000)
            page.wait_for_timeout(1500)  # let the result message actually render

            for attr_name, value in result_fields:
                try:
                    loc = page.locator(value)
                    if loc.count() != 1:
                        warnings.append(f"'{attr_name}' does not resolve to exactly one "
                                         f"element after submitting - cannot verify its text.")
                        continue
                    actual_text = loc.inner_text().strip()
                    if expected_message.lower() in actual_text.lower() or \
                       actual_text.lower() in expected_message.lower():
                        pass  # close enough match - real wording often has minor punctuation/casing differences
                    else:
                        warnings.append(
                            f"'{attr_name}' resolved and shows '{actual_text}', but testdata's "
                            f"ExpectedMessage says '{expected_message}' - these don't match. "
                            f"Either the locator points at the wrong element, or "
                            f"ExpectedMessage in the Excel needs correcting to the real wording.")
                except Exception as exc:
                    warnings.append(f"'{attr_name}' - could not read its text after "
                                     f"submitting: {exc}")

            # DATA PERSISTENCE CHECK: beyond "does the success message
            # say the right thing", does the actual identifying value
            # (a BIN, an ID, a code - the same field the testdata-
            # continuity enforcement in make_testdata_unique keeps
            # consistent across Add/View/Edit/Delete) genuinely show up
            # anywhere on the page after submitting? A real Add commonly
            # redirects back to the listing with the new row visible, or
            # shows a confirmation screen quoting the value back - if
            # that value is nowhere on the page, something is wrong even
            # if the success message itself happened to look right (a
            # generic "Request submitted" message, say, could pass the
            # text check above while the real row never actually
            # appeared with the expected value at all).
            UNIQUENESS_HINTS = ("email", "name", "code", "id", "username", "subscription",
                                 "trackid", "track_id", "number", "bin", "ip", "phone",
                                 "account", "mobile")
            identifying_value = None
            for col, val in testdata_values.items():
                if col == "ExpectedMessage" or not val or not val.strip():
                    continue
                if any(h in col.lower() for h in UNIQUENESS_HINTS):
                    identifying_value = val.strip()
                    break
            if identifying_value:
                try:
                    body_text = page.locator("body").inner_text()
                except Exception:
                    body_text = ""
                if identifying_value not in body_text:
                    warnings.append(
                        f"The identifying value '{identifying_value}' used for this Add "
                        f"(and shared with its linked View/Edit/Delete rows) does not appear "
                        f"anywhere on the page after submitting - the record may not have "
                        f"genuinely persisted, or the page after submit isn't showing it "
                        f"where expected.")

            attempt_logout(page)
            browser.close()
    except Exception as exc:
        warnings.append(f"(result-locator verification pass failed to run at all: {exc})")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    return warnings


def login_via_real_framework(repo_root: Path, bank: str, portal_type: str,
                              scenario: str = "") -> tuple[str, dict[str, str]]:
    """The most reliable way to get real locators: instead of guessing at a
    URL or relying on a manually-captured session, this ACTUALLY RUNS your
    framework's real login page class (AdminLoginPage/BankLoginPage/etc.)
    exactly the way a real pytest run would - same navigate_to_portal(),
    same credentials from credentials.yaml, same dispatch/login logic.

    It then uses the SCENARIO text to click through the real menu path
    (Configuration -> Brand Type -> Add, etc.) using visible-text matching
    only - no locators needed for navigation itself - landing on the
    actual target page before scanning for elements. This is what makes
    locators reflect the real target page instead of just the dashboard.

    Finally attempts a best-effort logout so the account isn't left
    logged in, which is what causes "User already logged in" to block the
    NEXT run.

    Temporarily rewrites config.yaml's "bank:" line to match the target
    bank if it doesn't already, since ConfigManager reads that file
    directly - and restores the original value afterward no matter what
    happens (even on error)."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed - run: pip install playwright --break-system-packages && playwright install chromium")
        return "", {}

    if portal_type not in PORTAL_CLASS_MAP:
        print(f"Unknown portal type '{portal_type}' - falling back to 'bank'.")
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]

    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n and f"bank: {bank}" not in original_config_text.split("\n")[0:3]:
            config_path.write_text(new_text, encoding="utf-8")
            print(f"  (temporarily set config.yaml bank to '{bank}' for this login - will restore after)")

    html = ""
    phrase_xpaths: dict[str, str] = {}
    try:
        import sys as _sys
        repo_str = str(repo_root)
        if repo_str not in _sys.path:
            _sys.path.insert(0, repo_str)

        try:
            from src.common.utilities.config_loader import ConfigManager
            ConfigManager._cached = None
        except Exception:
            pass

        module = __import__(
            f"src.common.pages.authentication.{module_name}", fromlist=[class_name]
        )
        LoginPageClass = getattr(module, class_name)

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            login_page = LoginPageClass(page)
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"  Logged in via the real {class_name}.login('{bank}').")

            if scenario:
                all_phrases = [p for _, p in extract_nav_phrases(scenario)]
                clicked, nav_elements_html, phrase_xpaths = navigate_via_scenario_text(page, scenario)
                if clicked:
                    print(f"  Navigated through: {' -> '.join(clicked)}")
                    missed = [p for p in all_phrases if p not in clicked]
                    if missed:
                        print(f"  Stopped before: {', '.join(missed)} - scanning "
                              f"whatever page was reached (could be the target page already, "
                              f"or that element may be behind a hover/animation/AJAX delay).")
                else:
                    print(f"  Could not click through any scenario menu text - scanning the "
                          f"landing page as-is.")
                    _nav_diagnostics(page, scenario, repo_root / "ai_debug_dom" / f"{bank}_nav_stopped.png")
            else:
                nav_elements_html = []
                print("  NOTE: no scenario text was given to this scan, so NO menu was clicked - only the page right after the login "
                      "is scanned (the dashboard).")

            final_page_html = page.eval_on_selector_all(
                "input, button, a, select, textarea, [role='button'], [role='menuitem'], "
                "li, span[onclick], div[onclick], [class*='menu'], [class*='nav'], "
                "[class*='tab'], [id*='menu'], [data-testid]",
                "els => els.slice(0, 300).map(e => e.outerHTML.slice(0, 300)).join('\\n')",
            )
            # Combine the elements actually navigated through (menu items on
            # PREVIOUS pages, which the final scan alone would miss) with the
            # final landed page's elements - so the AI gets locators for the
            # whole path, not just the last page.
            html = "\n\n".join(nav_elements_html + [final_page_html])
            print(f"  Scanned the real target page for elements.")

            if attempt_logout(page):
                print(f"  Logged out after scanning - next run won't hit a stale session.")
            else:
                print(f"  Could not find a Logout link to click - if the next run shows "
                      f"'already logged in', that's expected until this app times the session out.")

            browser.close()
    except Exception as exc:
        _log_exception("Real-login inspection failed", exc)
        print(f"  Real-login inspection failed ({exc}) - falling back to placeholder selectors.")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    return html, phrase_xpaths


def _pick_scan_target(page):
    """Real enterprise/legacy admin panels (this WIO portal's FSS_PG_iPay
    JSP-style app included) sometimes render their actual page content
    INSIDE AN IFRAME, not directly in the top-level document - the
    top-level page then has almost nothing (just a nav shell), and
    Playwright's page.locator()/eval_on_selector_all() do NOT reach into
    an iframe's content by default, silently returning empty results as
    if the real page had no dropdown/table/form at all (this is exactly
    what "No dropdown found on this page" meant on a page that visibly
    has one - the dropdown was inside an iframe the scan never looked
    inside). Checks every frame and returns whichever one actually has
    the most form/table content - prefers the main page whenever it
    already looks reasonably non-empty, since most modules aren't
    iframed and this must never slow down or break the common case.
    Called FRESH before each individual scan (not once for the whole
    function) since a click can navigate a frame to a new document,
    making a previously-picked frame reference stale."""
    try:
        main_count = page.locator("input, select, table, a, button").count()
        if main_count >= 5:
            return page
        best_target, best_count = page, main_count
        for frame in page.frames:
            if frame == page.main_frame:
                continue
            try:
                count = frame.locator("input, select, table, a, button").count()
                if count > best_count:
                    best_target, best_count = frame, count
            except Exception:
                continue
        return best_target
    except Exception:
        return page


def scan_conditional_fields(page, scan) -> str:
    """FEATURE: conditional-field detection - a static scan only sees
    the form as it FIRST opens. Real forms often have a toggle
    (a checkbox, an Enable/Disable radio pair, a Yes/No select) that
    reveals EXTRA fields when turned on and hides them again when
    turned off (e.g. eCentric's "Choose helpdesk contacts" checkbox
    group already documented in bank_notes as checkbox-driven
    conditional fields). Without actively exercising these toggles,
    the AI never sees the extra fields at all - they simply aren't
    present in the DOM until something is enabled - which is exactly
    what produces incomplete Add/Edit methods that don't handle the
    enabled state correctly.

    For every toggle-like control found (checkbox, a 2-option radio
    group whose labels look like Enable/Disable/Yes/No/Active/Inactive,
    or a <select> with those same 2-ish options), this: (1) records
    the field count before, (2) turns it ON (checks the checkbox,
    selects "Enable"/"Yes"/"Active"), (3) settles (same SPA-timing
    reasoning as _scan_listing_and_add_form), (4) re-scans and diffs
    for NEWLY-appeared fields, (5) turns it back OFF and confirms
    those fields disappear again, restoring the form to how it
    started. Returns a text block describing what it found (empty
    string if no toggle-like controls exist at all, or none of them
    revealed anything when toggled) - appended to the main scan's HTML
    so the AI has real evidence for the enabled-state's extra fields
    instead of only ever seeing the form's default/disabled state.

    Capped at checking 5 toggles per form and reverts every one back
    to its original state before returning - this is exploratory
    scanning, not meant to leave the real form in a different state
    than the tester found it in."""
    TOGGLE_SELECTOR = "input[type='checkbox'], select"
    ON_LABELS = ("enable", "enabled", "yes", "active", "on")
    findings = []
    try:
        toggles = scan.locator(TOGGLE_SELECTOR).all()[:5]
    except Exception:
        return ""

    for idx, toggle in enumerate(toggles):
        try:
            tag = toggle.evaluate("el => el.tagName.toLowerCase()")
            name_attr = toggle.evaluate("el => el.name || el.id || ''") or f"toggle_{idx}"
            before_count = scan.locator(TOGGLE_SELECTOR + ", input, textarea").count()
            before_html = scan.evaluate("() => document.body.innerHTML.length")

            turned_on = False
            if tag == "input":  # checkbox
                if not toggle.is_checked():
                    toggle.check(timeout=2000)
                    turned_on = True
            elif tag == "select":
                options = toggle.locator("option").all_text_contents()
                on_option = next((o for o in options if any(k in o.lower() for k in ON_LABELS)), None)
                if on_option and toggle.input_value() != on_option:
                    toggle.select_option(label=on_option, timeout=2000)
                    turned_on = True

            if not turned_on:
                continue

            page.wait_for_timeout(700)  # let any conditional fields render
            after_count = scan.locator(TOGGLE_SELECTOR + ", input, textarea").count()
            after_html_len = scan.evaluate("() => document.body.innerHTML.length")

            if after_count > before_count or after_html_len > before_html * 1.15:
                new_fields_html = scan.eval_on_selector_all(
                    "input, select, textarea",
                    "els => els.slice(0, 40).map(e => e.outerHTML.slice(0, 200)).join('\\n')",
                )
                findings.append(
                    f"Toggling '{name_attr}' ON revealed additional field(s) "
                    f"(field count {before_count} -> {after_count}):\n{new_fields_html}"
                )

            # Always revert back to how the form started.
            if tag == "input":
                toggle.uncheck(timeout=2000)
            elif tag == "select" and on_option:
                off_option = next((o for o in options if o != on_option), None)
                if off_option:
                    toggle.select_option(label=off_option, timeout=2000)
            page.wait_for_timeout(400)
        except Exception:
            continue  # one toggle failing must not abort scanning the rest

    if not findings:
        return ""
    return ("\n\n[CONDITIONAL FIELDS - found by toggling controls on/off during the scan, "
            "NOT visible in the form's default state]\n" + "\n\n".join(findings))


def expand_collapsed_sections(page, scan) -> int:
    """FEATURE: accordion/collapsed-section auto-expansion - a real gap
    flagged earlier: a module like "PG information" or "Risk profile"
    often groups its fields into collapsible sections (Angular Material
    mat-expansion-panel, or any generic accordion using the standard
    aria-expanded="false" ARIA pattern). A field sitting inside a
    COLLAPSED section is frequently not just visually hidden but
    genuinely ABSENT from the DOM (Angular's *ngIf removes collapsed
    panel content entirely rather than just hiding it with CSS) - so a
    scan taken before expanding these sections silently misses every
    field inside them, with no error or warning, just fields that
    quietly never made it into the generated locators/page/test at all.

    Finds every element on the page whose aria-expanded="false" (the
    standard, framework-agnostic way an accordion/expansion-panel header
    marks itself as collapsed - covers Angular Material's own
    mat-expansion-panel-header along with plain custom accordions built
    the same accessible way) and clicks each one once to expand it,
    confirming via a field-count check (same before/after diffing
    approach as scan_conditional_fields) that the click genuinely
    revealed new content rather than being a no-op. Capped at 10 sections
    so a page with an unusually large number of them doesn't turn into
    an excessively long scan. Returns the number of sections it
    successfully expanded (0 means either there were none, or expanding
    them didn't reveal anything new)."""
    expanded_count = 0
    # IMPORTANT: re-query "[aria-expanded='false']" fresh on EVERY
    # iteration rather than capturing a snapshot list up front - once a
    # header is expanded its own aria-expanded flips to "true" and it
    # drops out of this selector's matches, which SHIFTS the position of
    # every header after it. A pre-captured list of .nth(i)-style
    # locators would then point at the wrong element (or nothing at
    # all) for every header past the first one clicked - re-querying
    # ".first" each time always gets whichever real header is still
    # actually collapsed right now, regardless of how the list shifted.
    for _ in range(10):  # capped so an unusual page can't loop excessively
        try:
            remaining = scan.locator("[aria-expanded='false']")
            if remaining.count() == 0:
                break
            header = remaining.first
            before_count = scan.locator(
                "input:visible, select:visible, textarea:visible, mat-select:visible, "
                "mat-chip-list:visible, mat-checkbox:visible, mat-radio-group:visible"
            ).count()
            header.click(timeout=3000)
            page.wait_for_timeout(500)  # let the panel's expand animation/render settle
            after_count = scan.locator(
                "input:visible, select:visible, textarea:visible, mat-select:visible, "
                "mat-chip-list:visible, mat-checkbox:visible, mat-radio-group:visible"
            ).count()
            if after_count > before_count:
                expanded_count += 1
            # else: this particular header's click didn't add any new
            # visible field - don't count it, but keep looping so OTHER
            # still-collapsed headers still get their turn (the overall
            # range(10) cap is what bounds a header that's stuck
            # unresponsive rather than a single failed click here).
        except Exception:
            break  # a header failing to expand must not loop forever on the same one
    return expanded_count


def _scan_listing_and_add_form(page) -> str:
    """Shared by both DOM-exploration entry points (menu-navigated and
    direct-URL) - scans whatever page the caller has already landed on:
    the listing page's structure (table, search box or not, per-row
    links, global buttons) plus a real DATA-ENTRY FORM's actual fields.
    Automatically looks inside an iframe instead of just the top-level
    page if that's where the real content actually lives (see
    _pick_scan_target) - transparent either way, every call below scans
    whichever one actually has the content.

    Tries, in order:
      1. Click "Add" and scan its form - the common case.
      2. If there's no Add at all (many real modules only configure
         pre-existing records, never create new ones - e.g. a Password
         Security screen keyed by User Type): if a dropdown-based search
         exists (a <select> next to a Search button - see
         SEARCH-SELECT-ACTION PATTERN's dropdown case), select its first
         real option and click Search to populate the results table,
         then click "Edit" on the first result row and scan THAT form
         instead - this is usually the richest field set (radio Yes/No
         toggles, numeric dropdowns, min/max hints in the labels) since
         View is normally read-only and doesn't reveal input types the
         way Edit's actual form controls do. Falls back to "View" if no
         "Edit" link exists.
    Kept as one function so every navigation path scans identically.

    SETTLES BEFORE SCANNING - important for SPA/Angular-style portals
    (hash-based routing, e.g. "#/dashboard/..."): a client-side route
    change often does NOT trigger new network requests at all, so
    "networkidle" (waited for earlier, right after the click that got us
    here) can resolve almost immediately even though the framework's own
    change-detection/rendering hasn't actually painted the new content
    into the DOM yet. Scanning right on the heels of networkidle in that
    case captures the OLD page's leftover markup - which is exactly what
    produces wrong/mismatched fields for Add/View/Edit/Search on an
    Angular-style portal. A short fixed settle-wait here, independent of
    network activity, gives the framework's own rendering cycle time to
    finish first."""
    page.wait_for_timeout(1200)
    SCAN_SELECTOR = ("input, button, a, select, textarea, [role='button'], [role='menuitem'], "
                      "li, span[onclick], div[onclick], table, thead, tr, td, "
                      "[class*='menu'], [class*='nav'], [class*='tab'], [id*='menu'], [data-testid]")
    scan = _pick_scan_target(page)
    if scan is not page:
        print(f"  (the real content is inside an iframe, not the top-level page - scanning that instead)")
    listing_html = scan.eval_on_selector_all(
        SCAN_SELECTOR, "els => els.slice(0, 300).map(e => e.outerHTML.slice(0, 300)).join('\\n')",
    )
    has_text_search = scan.locator(
        "input[type='search'], input[placeholder*='earch' i], input[name*='search' i]"
    ).count() > 0
    # A dropdown-based search (e.g. "User Type: [dropdown] [Search]") has
    # NO text input at all - the earlier version only checked for a text
    # input here, so a real dropdown-driven search page was wrongly
    # reported as "No search - plain table" even with a <select> and a
    # Search button sitting right there.
    has_dropdown_search = (scan.locator("select").count() > 0
                           and scan.get_by_text(re.compile(r"^\s*Search\s*$", re.IGNORECASE)).count() > 0)
    if has_text_search:
        search_desc = "a text search/filter input was found"
    elif has_dropdown_search:
        search_desc = "a dropdown-based search (a <select> next to a Search button) was found"
    else:
        search_desc = "NO search/filter mechanism found - this looks like a DOM-row-match layout"
    print(f"  Scanned the listing page ({search_desc}).")

    # PARENT-CONTEXT SCAN: captures each field's closest labeled container
    # too, not just the field element itself. This is what makes label
    # text visible at all on component-library UIs (Angular Material,
    # PrimeNG, etc.) where the real label lives in a CUSTOM element tag
    # (e.g. <mat-label>Gateway/FI name</mat-label>) rather than a plain
    # <label>, and the input itself carries no name/placeholder at all
    # (just an auto-generated id like "mat-input-47") - a selector list
    # of "input, select, textarea, button, label" only ever matches the
    # literal <label> tag, so it silently captures NOTHING for a
    # component-library form's real label text, leaving the AI to guess
    # field names from meaningless auto-generated IDs alone. Walking up
    # to each field's containing block (a couple of ancestor levels,
    # capped so it doesn't pull in the whole page) and grabbing ITS
    # outerHTML instead captures the label sitting alongside the field
    # regardless of what tag name or class the UI library gave it -
    # generic across component libraries rather than hardcoded to
    # Angular Material's own tag names specifically.
    FIELD_WITH_CONTEXT_JS = (
        "els => {"
        "  const blocks = els.slice(0, 200).map(e => {"
        "    let container = e;"
        "    for (let i = 0; i < 3; i++) {"
        "      if (!container.parentElement) break;"
        "      container = container.parentElement;"
        "      const txt = container.textContent.trim();"
        "      if (txt && txt.length > 0 && txt.length < 150) break;"
        "    }"
        "    return container.outerHTML.slice(0, 400);"
        "  });"
        "  return [...new Set(blocks)].join('\\n---\\n');"
        "}"
    )
    form_html = ""
    form_label = "ADD FORM"

    try:
        add_locator = scan.get_by_text(re.compile(r"^\s*Add\s*$", re.IGNORECASE)).first
        if add_locator.count() > 0:
            add_locator.click(timeout=5000)
            page.wait_for_load_state("networkidle", timeout=10000)
            scan = _pick_scan_target(page)  # re-pick: the click may have loaded a new document
            expanded = expand_collapsed_sections(page, scan)
            if expanded:
                print(f"  Expanded {expanded} collapsed accordion section(s) before scanning fields.")
            form_html = scan.eval_on_selector_all(
                "input, select, textarea, mat-select, mat-chip-list, mat-checkbox, mat-radio-group",
                FIELD_WITH_CONTEXT_JS)
            print(f"  Clicked 'Add' and scanned the resulting form's fields (with surrounding "
                  f"label context, for component-library UIs like Angular Material).")
            conditional = scan_conditional_fields(page, scan)
            if conditional:
                form_html += conditional
                print(f"  Also found conditional field(s) revealed by toggling a control on this form.")
            page.go_back(wait_until="networkidle", timeout=15000)
        else:
            print(f"  Could not find an 'Add' element - this module likely has no create flow. "
                  f"Trying to open an existing record's Edit/View form instead, for its real fields...")
            # Dropdown-based search (e.g. "User Type: [dropdown] [Search]")
            # needs a real option picked before the table has any rows to
            # open - a bare Search click with any dropdown still on
            # "- Select -" usually returns nothing. Handles EVERY
            # dropdown on the page, not just the first - a real search
            # form can have more than one filter dropdown (e.g. "User
            # Type" AND "Status"), and leaving a second one unset could
            # still make Search return nothing even after the first is
            # set correctly.
            dropdowns = scan.locator("select").all()
            if not dropdowns:
                print("  No dropdown found on this page.")
            for idx, dropdown in enumerate(dropdowns, start=1):
                try:
                    options = dropdown.locator("option").all_inner_texts()
                    real_options = [o for o in options if o.strip() and "select" not in o.lower()]
                    if not real_options:
                        continue
                    # Generic, not tied to any one module's option
                    # wording: prefer whichever option says "ALL" (a
                    # common convention across many such dropdowns,
                    # regardless of what the OTHER options are named)
                    # since it's the option most likely to return at
                    # least one row for ANY module - only falls back to
                    # the first option in the list if no "ALL" is
                    # present at all.
                    chosen = next((o for o in real_options if o.strip().upper() == "ALL"),
                                 real_options[0])
                    dropdown.select_option(label=chosen)
                    print(f"  Dropdown {idx}/{len(dropdowns)}: selected '{chosen}' "
                          f"({'an ALL option was found' if chosen.strip().upper() == 'ALL' else 'no ALL option existed, used the first real option instead'}).")
                except Exception as exc:
                    print(f"  Dropdown {idx}/{len(dropdowns)}: couldn't select an option ({exc}) - "
                          f"leaving it as-is.")
            search_btn = scan.get_by_text(re.compile(r"^\s*Search\s*$", re.IGNORECASE)).first
            if search_btn.count() > 0:
                search_btn.click(timeout=5000)
                page.wait_for_load_state("networkidle", timeout=10000)
                scan = _pick_scan_target(page)  # re-pick: results may now be in/back in an iframe
                print(f"  Clicked Search to populate the results table.")

            for label, pattern in (("EDIT FORM", r"^\s*Edit\s*$"), ("VIEW FORM", r"^\s*View\s*$")):
                row_link = scan.get_by_text(re.compile(pattern, re.IGNORECASE)).first
                if row_link.count() > 0:
                    row_link.click(timeout=5000)
                    page.wait_for_load_state("networkidle", timeout=10000)
                    scan = _pick_scan_target(page)  # re-pick after navigating to the Edit/View form
                    form_html = scan.eval_on_selector_all(
                        "input, select, textarea, mat-select, mat-chip-list, mat-checkbox, "
                        "mat-radio-group, [class*='radio'], [class*='checkbox']",
                        FIELD_WITH_CONTEXT_JS)
                    form_label = label
                    print(f"  Clicked the first row's '{label.split()[0].title()}' link and "
                          f"scanned its fields.")
                    conditional = scan_conditional_fields(page, scan)
                    if conditional:
                        form_html += conditional
                        print(f"  Also found conditional field(s) revealed by toggling a control on this form.")
                    page.go_back(wait_until="networkidle", timeout=15000)
                    break
            else:
                # DIRECT SETTINGS-FORM PAGE: no Add button, no list/table
                # with rows to open Edit/View on - but the CURRENT page
                # itself may simply BE the form already (a single,
                # persistent settings/configuration page, e.g. "PG
                # information" - loaded pre-filled with existing values,
                # no create/list flow at all, just fields plus a Save
                # button). This is a real, common module shape, not a
                # scan failure - check for real fields directly on the
                # current page before giving up.
                # Expand any collapsed accordion sections FIRST - both the
                # field-count check below and the detailed scan after it
                # need collapsed-section fields to already be in the DOM,
                # not just the fields visible before expanding anything.
                expanded = expand_collapsed_sections(page, scan)
                if expanded:
                    print(f"  Expanded {expanded} collapsed accordion section(s) before scanning fields.")
                direct_fields = scan.locator(
                    "input, select, textarea, mat-select, mat-chip-list, mat-checkbox, mat-radio-group"
                ).count()
                if direct_fields > 0:
                    form_html = scan.eval_on_selector_all(
                        "input, select, textarea, mat-select, mat-chip-list, mat-checkbox, "
                        "mat-radio-group, [class*='radio'], [class*='checkbox']",
                        FIELD_WITH_CONTEXT_JS)
                    form_label = "DIRECT SETTINGS FORM (no Add/Edit/View flow - the page itself is the form)"
                    print(f"  No Add button and no list/rows to open - but this page already has "
                          f"{direct_fields} real field(s) directly on it (a settings/configuration "
                          f"page, not a list). Scanning those fields directly.")
                    conditional = scan_conditional_fields(page, scan)
                    if conditional:
                        form_html += conditional
                        print(f"  Also found conditional field(s) revealed by toggling a control on this form.")
                else:
                    print(f"  No row with a View/Edit link was found either (table may be empty), and "
                          f"no fields exist directly on this page either - proceeding with the "
                          f"listing page's elements only.")
    except Exception as exc:
        print(f"  Scanning a data-entry form didn't work ({exc}) - proceeding with the "
              f"listing page's elements only.")

    return f"[LISTING PAGE - has_text_search={has_text_search}, has_dropdown_search={has_dropdown_search}]\n{listing_html}\n\n[{form_label}]\n{form_html or '(not captured)'}"


def extract_add_form_fields_detailed(page_html: str, max_fields: int = 40) -> list[dict]:
    """Pulls a clean, human-readable list of a data-entry form's fields
    out of a DOM scan (see _scan_listing_and_add_form) - checks for
    '[ADD FORM]' first, then falls back to '[EDIT FORM]' or
    '[VIEW FORM]' (whichever the scan actually captured - for modules
    with no Add flow at all, _scan_listing_and_add_form opens an
    existing record's Edit/View form instead, since that's the only
    place real field names/types are visible). Unlike a plain
    text-field list, this correctly TYPES each field so
    collect_field_values_interactively can ask the right kind of
    question for each:
      "text"     - a plain input/textarea - free-text value
      "select"   - a <select> dropdown - shows its <option> choices if
                   the scan captured them, asks for ONE
      "radio"    - a group of same-name radio inputs - shows the
                   option values, asks for ONE
      "checkbox" - a group of same-name checkbox inputs (a real
                   MULTI-SELECT, e.g. a permissions list) - shows the
                   option values, asks for ONE OR MORE (comma-separated)
    A single standalone checkbox (its own unique name, not part of a
    group) is treated as a yes/no toggle field, not skipped outright
    the way it used to be - real forms often have a lone "Active?"
    or "Send notification?" checkbox that's still a real value to set.

    Returns [] if no form section was captured or it has no fields -
    the caller then skips value-collection entirely (no minimum
    required). Capped at max_fields (default 40, counting each field
    ONCE even if it's a multi-input radio/checkbox group) - asking for
    50+ values one at a time isn't practical, so once the cap is hit
    the rest are left for AI to fill in itself."""
    for marker in ("[ADD FORM]", "[EDIT FORM]", "[VIEW FORM]"):
        if marker in page_html:
            page_html = page_html.split(marker, 1)[1]
            break

    def _label_for(attrs: str) -> str | None:
        for attr in ("placeholder", "name", "id"):
            m = re.search(rf'{attr}=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
            if m and m.group(1).strip():
                return m.group(1).strip()
        return None

    def _attr(attrs: str, name: str) -> str | None:
        m = re.search(rf'{name}=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
        return m.group(1).strip() if m else None

    # group_key -> {"label": str, "type": str, "options": [str, ...]}
    groups: dict[str, dict] = {}
    order: list[str] = []

    for tag_match in re.finditer(r"<(input|select|textarea)\b([^>]*?)/?>", page_html, re.IGNORECASE):
        tag = tag_match.group(1).lower()
        attrs = tag_match.group(2)
        input_type = (_attr(attrs, "type") or "text").lower()

        if tag == "input" and input_type in ("hidden", "submit", "button", "image", "file"):
            continue

        if tag == "input" and input_type in ("radio", "checkbox"):
            name = _attr(attrs, "name") or _attr(attrs, "id")
            if not name:
                continue
            key = f"{input_type}:{name.lower()}"
            value = _attr(attrs, "value") or _label_for(attrs) or name
            if key not in groups:
                groups[key] = {"label": name, "type": input_type, "options": [], "constraint": ""}
                order.append(key)
            if value not in groups[key]["options"]:
                groups[key]["options"].append(value)
            continue

        label = _label_for(attrs)
        if not label:
            continue
        key = f"text:{label.lower()}" if tag != "select" else f"select:{label.lower()}"
        if key in groups:
            continue
        # Pull a length constraint straight from the real HTML attributes
        # if present (maxlength/minlength) - this is what lets the value-
        # collection prompt show "(max length: 15)" right next to the
        # field, so the person knows what's expected and the generated
        # negative testdata can target THIS field's real limit instead
        # of a generic guess.
        maxlen = _attr(attrs, "maxlength")
        minlen = _attr(attrs, "minlength")
        constraint = ""
        if minlen and maxlen:
            constraint = f"length {minlen}-{maxlen}"
        elif maxlen:
            constraint = f"max length {maxlen}"
        elif minlen:
            constraint = f"min length {minlen}"
        if tag == "select":
            # Scope option extraction to just THIS <select>...</select> -
            # a fixed-length lookahead window bled into the NEXT
            # <select>'s options too when two dropdowns sit close
            # together in the scanned HTML (e.g. Min/Max Password Length
            # right next to each other), silently merging their option
            # lists into one.
            close_match = re.search(r"</select\s*>", page_html[tag_match.end():], re.IGNORECASE)
            select_body = (page_html[tag_match.end():tag_match.end() + close_match.start()]
                          if close_match else page_html[tag_match.end():tag_match.end() + 500])
            options = re.findall(r'<option[^>]*value=["\']([^"\']+)["\']', select_body, re.IGNORECASE)
            groups[key] = {"label": label, "type": "select", "options": options[:15], "constraint": constraint}
        else:
            groups[key] = {"label": label, "type": "text", "options": [], "constraint": constraint}
        order.append(key)

        if len(order) >= max_fields:
            break

    return [groups[k] for k in order[:max_fields]]


def collect_field_values_interactively(fields: list[dict], log=print, ask=input) -> dict[str, str]:
    """Asks the person for a real value for each detected Add-form field,
    one at a time, asking the RIGHT KIND of question for each field's
    actual type (see extract_add_form_fields_detailed):
      text     -> free-text value
      select / radio -> shows the real options seen in the scan (if
                 any) and asks for ONE of them
      checkbox -> a real multi-select (e.g. a permissions list) - shows
                 the options and asks for ONE OR MORE, comma-separated
    This is what lets Add use REAL, person-supplied data instead of
    AI-guessed placeholder-looking testdata, and lets View/Edit/
    ChangeStatus search for the SAME record afterward. Leaving a field
    blank skips it (AI fills that one in itself); the person doesn't
    have to give every field.

    fields: list of dicts as returned by extract_add_form_fields_detailed
    (also accepts a plain list[str] for backward compatibility, treating
    each as a "text" field with no known options)."""
    # Backward-compat: allow a plain list of field-name strings too.
    normalized: list[dict] = []
    for f in fields:
        if isinstance(f, str):
            normalized.append({"label": f, "type": "text", "options": []})
        else:
            normalized.append(f)

    if not normalized:
        log("  (No Add-form fields were detected in the scan - skipping value collection.)")
        return {}

    log(f"\nDetected {len(normalized)} Add-form field(s). Give a real value to use for each "
        f"(press Enter to skip one and let AI fill it in itself):")
    values: dict[str, str] = {}
    for field in normalized:
        label, ftype, options = field["label"], field.get("type", "text"), field.get("options") or []
        constraint = field.get("constraint") or ""
        constraint_tag = f" ({constraint})" if constraint else ""
        if ftype == "checkbox" and len(options) > 1:
            log(f"  {label}{constraint_tag} (select one or more, comma-separated): {', '.join(options)}")
            val = ask(f"  {label}: ").strip()
        elif ftype == "checkbox":
            # A single standalone checkbox (its own unique name, no
            # sibling options) is a yes/no toggle, not a multi-select -
            # asked as a plain value (e.g. "yes"/"checked"/blank to skip)
            # rather than the "select one or more" phrasing above.
            val = ask(f"  {label} (check it? type yes, or leave blank to skip): ").strip()
        elif ftype in ("select", "radio") and options:
            log(f"  {label}{constraint_tag} (options: {', '.join(options)})")
            val = ask(f"  {label}: ").strip()
        else:
            val = ask(f"  {label}{constraint_tag}: ").strip()
        if val:
            values[label] = val
    return values


def _login_for_dom_exploration(repo_root: Path, bank: str, portal_type: str):
    """Shared login/setup for both DOM-exploration entry points - returns
    a context manager-friendly tuple (LoginPageClass, original_config_text,
    config_path) so each caller can do its own sync_playwright block
    around it (menu-click needs the scenario-nav helper, direct-URL needs
    page.goto - different enough not to force into one giant function)."""
    if portal_type not in PORTAL_CLASS_MAP:
        print(f"Unknown portal type '{portal_type}' - falling back to 'bank'.")
        portal_type = "bank"
    module_name, class_name = PORTAL_CLASS_MAP[portal_type]

    config_path = repo_root / "src" / "config.yaml"
    original_config_text = None
    if config_path.exists():
        original_config_text = config_path.read_text(encoding="utf-8")
        new_text, n = re.subn(r"^bank:\s*\S+", f"bank: {bank}", original_config_text,
                               count=1, flags=re.MULTILINE)
        if n and f"bank: {bank}" not in original_config_text.split("\n")[0:3]:
            config_path.write_text(new_text, encoding="utf-8")
            print(f"  (temporarily set config.yaml bank to '{bank}' for this login - will restore after)")

    import sys as _sys
    repo_str = str(repo_root)
    if repo_str not in _sys.path:
        _sys.path.insert(0, repo_str)
    try:
        from src.common.utilities.config_loader import ConfigManager
        ConfigManager._cached = None
    except Exception:
        pass

    module = __import__(f"src.common.pages.authentication.{module_name}", fromlist=[class_name])
    LoginPageClass = getattr(module, class_name)
    return LoginPageClass, class_name, original_config_text, config_path


def explore_module_via_menu(repo_root: Path, bank: str, portal_type: str, menu_name: str) -> tuple[str, dict[str, str]]:
    """The preferred NO-SCENARIO exploration path when a menu/submenu
    path was already given (e.g. "Configuration > Currency") - reuses
    the SAME real menu-click navigation as the scenario-based flow
    (navigate_via_scenario_text), so there's no need to separately paste
    the module's raw URL - the menu path you already typed IS the
    navigation instruction. Converts "A > B > C" into a synthetic
    "Navigate to A, click B, click C" scenario text purely to reuse that
    existing click-through logic; nothing about it is shown to the AI,
    it's only for driving the browser here."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed - run: pip install playwright --break-system-packages && playwright install chromium")
        return "", {}

    segments = [s.strip() for s in menu_name.split(">") if s.strip()]
    if not segments:
        print("  Menu path was empty after parsing - nothing to navigate through.")
        return "", {}
    if len(segments) == 1:
        synthetic_nav_scenario = f"Navigate to {segments[0]}"
    else:
        # Every segment EXCEPT THE LAST is a parent menu that needs
        # HOVERING to reveal its child item (the common enterprise-portal
        # pattern - e.g. "My Accounts" only shows "Password Security" as
        # a clickable link once the mouse is over it, exactly like this
        # framework's own scenario convention "Hover My Accounts menu,
        # click Password Security sub-menu"). Only the LAST segment (the
        # actual destination) gets clicked. Building this as a plain
        # "Navigate to X, click Y" defaulted every segment to click,
        # which for a hover-only parent menu either did nothing useful
        # or navigated to that parent's own unrelated default page
        # instead of revealing the intended submenu - landing on the
        # wrong page entirely with no relation to the real target module.
        # Lowercase "hover"/"click" throughout (never capitalized, even
        # at the start) - extract_nav_phrases' phrase-matching regex
        # greedily merges a CAPITALIZED action word straight into the
        # following Title-Case phrase (e.g. "Hover My Accounts" got read
        # as one single phrase literally containing the verb, instead of
        # recognizing "hover" as the action for "My Accounts") when
        # there's no lowercase word or punctuation breaking them apart.
        parts = [f"hover {segments[0]}"] + [f"hover {s}" for s in segments[1:-1]] + [f"click {segments[-1]}"]
        synthetic_nav_scenario = ", ".join(parts)

    try:
        LoginPageClass, class_name, original_config_text, config_path = _login_for_dom_exploration(
            repo_root, bank, portal_type)
    except Exception as exc:
        _log_exception("DOM exploration setup failed", exc)
        print(f"  DOM exploration setup failed ({exc}) - falling back to placeholder selectors.")
        return "", {}

    html = ""
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            login_page = LoginPageClass(page)
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"  Logged in via the real {class_name}.login('{bank}').")

            clicked, _nav_html, _phrases = navigate_via_scenario_text(page, synthetic_nav_scenario)
            if clicked:
                print(f"  Navigated through: {' -> '.join(clicked)}")
            else:
                print(f"  Could not click through the menu path '{menu_name}' - scanning "
                      f"whatever page was reached (could still be usable).")

            html = _scan_listing_and_add_form(page)

            if attempt_logout(page):
                print(f"  Logged out after scanning.")
            browser.close()
    except Exception as exc:
        _log_exception("DOM exploration failed", exc)
        print(f"  DOM exploration failed ({exc}) - falling back to placeholder selectors.")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    if html:
        save_scanned_dom_snapshot(repo_root, bank, menu_name, html)
    return html, {}


def save_scanned_dom_snapshot(repo_root: Path, bank: str, identifier: str, html: str) -> None:
    """FEATURE: persists exactly what a real scan captured to a plain
    .html file on disk, so the person can open it directly in a browser
    or text editor and compare it side-by-side against the generated
    locators.py - without needing to describe fields in chat or share a
    screenshot at all. This is the SAME html string handed to the AI for
    generation, so if a locator looks wrong, this file is the ground
    truth for what the AI actually had to work with: either the AI
    mis-read something that WAS genuinely there (a real generation bug,
    fixable), or the scan itself never captured the field at all (a
    scan-timing/navigation issue, a different kind of fix entirely) -
    this file is what tells the two apart at a glance.

    Saved under <repo_root>/ai_debug_dom/, one file per bank+module/menu
    combination (overwritten on each fresh scan, so it always reflects
    the MOST RECENT run - not an ever-growing archive)."""
    try:
        debug_dir = repo_root / "ai_debug_dom"
        debug_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^a-zA-Z0-9]+", "_", f"{bank}_{identifier}").strip("_").lower()
        snapshot_path = debug_dir / f"{safe_name}_scanned_dom.html"
        snapshot_path.write_text(html, encoding="utf-8")
        print(f"  Saved the exact scanned DOM to {snapshot_path} - open it directly to "
              f"compare against the generated locators.py, field by field.")
    except Exception as exc:
        print(f"  (could not save the DOM snapshot for reference: {exc})")


def explore_module_via_url(repo_root: Path, bank: str, portal_type: str, module_url: str) -> tuple[str, dict[str, str]]:
    """The FALLBACK no-scenario exploration path, used only when no menu
    path was given (explore_module_via_menu is preferred whenever a menu
    path IS available, since it exercises the real navigation instead of
    jumping straight to a pasted URL) - navigates DIRECTLY to the
    module's own URL (the address bar URL of that module's listing page,
    e.g. '.../Currency.htm?pgconfig=prcsCurr').

    Captures the SAME two states as explore_module_via_menu (see
    _scan_listing_and_add_form) - the listing page's structure and the
    Add form's actual fields - so both entry points feed the AI
    identically shaped DOM information regardless of how the page was
    reached."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed - run: pip install playwright --break-system-packages && playwright install chromium")
        return "", {}

    try:
        LoginPageClass, class_name, original_config_text, config_path = _login_for_dom_exploration(
            repo_root, bank, portal_type)
    except Exception as exc:
        _log_exception("DOM exploration setup failed", exc)
        print(f"  DOM exploration setup failed ({exc}) - falling back to placeholder selectors.")
        return "", {}

    html = ""
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            login_page = LoginPageClass(page)
            LoginPageClass(page).login(bank)
            page.wait_for_load_state("networkidle", timeout=15000)
            print(f"  Logged in via the real {class_name}.login('{bank}').")

            page.goto(module_url, wait_until="networkidle", timeout=30000)
            print(f"  Navigated directly to module URL: {module_url}")

            html = _scan_listing_and_add_form(page)

            if attempt_logout(page):
                print(f"  Logged out after scanning.")
            browser.close()
    except Exception as exc:
        _log_exception("DOM exploration failed", exc)
        print(f"  DOM exploration failed ({exc}) - falling back to placeholder selectors.")
    finally:
        if original_config_text is not None:
            config_path.write_text(original_config_text, encoding="utf-8")

    if html:
        save_scanned_dom_snapshot(repo_root, bank, module_url, html)
    return html, {}


DESCRIBE_FINDINGS_SYSTEM_PROMPT = """You are given DOM elements scanned
live from one bank's version of a module (a listing page, and possibly
an Add form) - describe in PLAIN ENGLISH, compactly, what you can see,
using this EXACT structure so it stays consistent across banks and is
easy for the person to review and correct:

ACTIONS: <comma-separated list of what this module appears to support -
choose from Add, View, Edit, Change Status, or name any OTHER custom
action you can see (e.g. Assign Menu) - only list what the scanned
elements actually show evidence of, never guess one that isn't there>
SEARCH: <one of: "Plain search box" (a single text input to filter/find
records) / "Search-by dropdown (<field options seen>)" (a dropdown
paired with a value input) / "No search - plain table" (no search
input at all, just a listing) - based on what was actually scanned>
ADD FIELDS: <comma-separated list of the Add form's actual field names/
labels, if an Add form was scanned - or "not scanned" if it wasn't>
LOCATORS:
<one line per key element actually found in the scan - format exactly
"<short name>: <real xpath built from the scanned element's own
attributes/text>", one per line, e.g.:
add_button: //button[contains(text(),'Add')]
search_field: //input[@name='searchValue']
change_status_button: //button[contains(text(),'Change Status')]
If an element you'd expect wasn't actually in the scan, write
"<name>: #TODO-not-found-in-scan" instead of guessing a plausible-
looking xpath - never invent one that isn't grounded in what was
scanned. If NOTHING usable was scanned at all, write exactly one line:
"(none - scan returned nothing usable)">
NOTES: <anything else worth flagging in one short sentence, or "none">

Do not add any other section, explanation, or commentary - just these
five sections in this exact order."""


def describe_module_findings(page_html: str, module: str, bank: str) -> str:
    """One lightweight AI call that turns raw scanned DOM elements into a
    short, structured, PLAIN-ENGLISH description of what this bank's
    version of the module actually looks like (which actions it has,
    what search mechanism it uses, what fields its Add form has, and a
    preliminary LOCATORS list built from the real scanned elements) -
    this is what gets shown to the person for review/correction BEFORE
    any full generation call is made, in run_multibank_discovery, so a
    wrong guess - or a locator the scan genuinely couldn't find (flagged
    as #TODO-not-found-in-scan, never silently invented) - gets caught
    and fixed at this cheap "description" stage rather than discovered
    only after a full generation call was already spent on it."""
    if not page_html:
        return ("ACTIONS: (could not scan - no page elements captured)\nSEARCH: unknown\n"
                "ADD FIELDS: not scanned\nLOCATORS:\n(none - scan returned nothing usable)\n"
                "NOTES: DOM scan returned nothing - describe this bank's module manually instead.")
    user_prompt = f"Bank: {bank}\nModule: {module}\n\nScanned DOM elements:\n{page_html[:6000]}"
    reply = ask_ai(DESCRIBE_FINDINGS_SYSTEM_PROMPT, user_prompt)
    return reply.strip() if reply else (
        "ACTIONS: (AI call failed)\nSEARCH: unknown\nADD FIELDS: not scanned\n"
        "LOCATORS:\n(none - AI call failed)\nNOTES: describe this bank's module manually instead."
    )


def count_placeholder_locators(description: str) -> int:
    """Counts how many lines in a describe_module_findings LOCATORS
    section are flagged #TODO-not-found-in-scan - i.e. elements the live
    scan genuinely couldn't find real evidence for, rather than a
    plausible-looking guess. Used to print a clear "N locator(s) need
    manual attention" warning at the discovery/review stage, before
    generation, so the person knows exactly what to double-check instead
    of finding out only after a full generation call already ran."""
    return description.count("#TODO-not-found-in-scan")


def summarize_bank_comparison(confirmed: dict[str, dict]) -> str:
    """After every bank has been discovered and confirmed, prints a
    quick side-by-side ACTIONS/SEARCH comparison - lets the person spot
    at a glance which banks are missing an action the others have, or
    use a different search pattern, before generation starts. Parses
    just the first two lines (ACTIONS:/SEARCH:) out of each bank's
    confirmed description text - purely a readability aid, doesn't
    affect what actually gets generated."""
    lines = ["\nCROSS-BANK COMPARISON:"]
    for bank, data in confirmed.items():
        desc = data["description"] if isinstance(data, dict) else data
        actions_line = next((l for l in desc.splitlines() if l.upper().startswith("ACTIONS:")), "ACTIONS: ?")
        search_line = next((l for l in desc.splitlines() if l.upper().startswith("SEARCH:")), "SEARCH: ?")
        lines.append(f"  {bank:<12} {actions_line}")
        lines.append(f"  {'':<12} {search_line}")
    return "\n".join(lines)


def run_multibank_discovery(repo_root: Path, banks: list[str], portal_type: str, menu_name: str,
                             collect_field_values: bool = True,
                             log=print, ask=input) -> dict[str, dict]:
    """For EACH bank given (up to 7 or so - one at a time, not parallel,
    since each is a real login+navigation+scan): logs in, navigates via
    the given menu path, scans the module's real DOM, and gets back a
    short structured description (see describe_module_findings) of what
    that bank's version of this module actually has - which actions,
    what search pattern, what Add fields. Shows the description to the
    person and lets them either accept it as-is or type a corrected
    version (e.g. if the scan missed something or got the search
    pattern wrong) before moving to the next bank. This is the "check
    what's actually there before generating anything" step - each
    bank's real screen can differ (different actions, different search
    UI) even for the "same" module name, which is exactly what this is
    for.

    If collect_field_values (default True), also asks the person for
    real Add-form field values for THIS bank specifically (same
    text/select/radio/checkbox-aware flow as the single-bank DOM mode -
    see extract_add_form_fields_detailed/collect_field_values_interactively)
    right after they confirm the description, since different banks
    commonly need different real values (e.g. a Code that's already
    taken on one bank but free on another).

    One bank's login/scan failing (an exception, not just an empty
    scan - explore_module_via_menu already returns "" gracefully on
    its own failures) never aborts the whole batch: it's caught, the
    person is asked whether to type the description manually or skip
    this bank entirely, and the loop continues to the next one either
    way.

    Returns {bank: {"description": str, "field_values": dict,
    "page_html": str}} for every bank that wasn't skipped - "page_html"
    is the RAW scan already captured here, meant to be passed straight
    through to run_full_module_pipeline's pre_scanned_html parameter so
    generation reuses this exact scan instead of logging in and
    re-scanning a second time (which would be redundant - double the
    login attempts, double the time, and risks a confusing mismatch if
    the page looks even slightly different between the two scans, e.g.
    re-searching for an "Add" button generation-side even though
    discovery already confirmed this bank has none). "description" and
    "field_values" are ready to feed into run_full_module_pipeline as
    that bank's own base_scenario/field_values too (the description
    itself doubles as a natural-language spec: it already states the
    actions and search pattern, so the normal View/Edit/ChangeStatus
    auto-derive logic and SEARCH-SELECT-ACTION PATTERN both work
    directly off it)."""
    confirmed: dict[str, dict] = {}
    for i, bank in enumerate(banks, start=1):
        log(f"\n{'#' * 60}")
        log(f"# Bank {i}/{len(banks)}: {bank}")
        log(f"{'#' * 60}")
        try:
            page_html, _ = explore_module_via_menu(repo_root, bank, portal_type, menu_name)
            log("  Scanned - asking AI to describe what it found...")
            description = describe_module_findings(page_html, menu_name, bank)
        except Exception as exc:  # noqa: BLE001 - one bank's failure must not abort the batch
            log(f"  ERROR: login/scan for '{bank}' failed unexpectedly ({exc}).")
            choice = ask(f"  Type this bank's description manually, or press Enter to skip "
                         f"'{bank}' entirely: ").strip()
            if not choice:
                log(f"  Skipping '{bank}'.")
                continue
            confirmed[bank] = {"description": choice, "field_values": {}, "page_html": ""}
            continue

        log(f"\n--- {bank}: detected structure ---")
        log(description)
        log("---")
        todo_count = count_placeholder_locators(description)
        if todo_count:
            log(f"  NOTE: {todo_count} locator(s) above are flagged #TODO-not-found-in-scan - "
                f"the live scan couldn't confirm these, they'll need manual attention after "
                f"generation (or correct them below with what you know is actually there).")
        answer = ask(f"\nIs this correct for '{bank}'? Press Enter to accept as-is, or type "
                     f"corrections (they replace the description above entirely - restate the "
                     f"full ACTIONS/SEARCH/ADD FIELDS/LOCATORS/NOTES, not just the fix): ").strip()
        final_description = answer if answer else description

        field_values = {}
        if collect_field_values and page_html:
            detected_fields = extract_add_form_fields_detailed(page_html)
            if detected_fields:
                log(f"\nField values for '{bank}' specifically (different banks often need "
                    f"different real values, e.g. a Code that's free here but taken elsewhere):")
                field_values = collect_field_values_interactively(detected_fields, log=log, ask=ask)

        confirmed[bank] = {"description": final_description, "field_values": field_values,
                           "page_html": page_html}

    log(summarize_bank_comparison(confirmed))
    return confirmed


def load_real_login_files(repo_root: Path, bank: str, portal_type: str | None) -> str:
    """Reads the REAL, already-existing login page classes and this bank's
    REAL login locators directly from the live repo at runtime - not from
    a static copy in reference/. These files always exist in a working
    checkout of the framework (every bank has a login_locators.py, every
    portal type has its *_login_page.py), so there is never a need to ask
    the AI to guess or regenerate any of this - it is handed the exact,
    already-correct code and told to import and call it as-is.

    Only the login page(s) relevant to portal_type are loaded (falls back
    to bank_login_page.py alone if portal_type is unknown), plus this
    specific bank's login_locators.py - not every bank's, and not every
    portal type's, to keep the prompt focused and small."""
    auth_dir = repo_root / "src" / "common" / "pages" / "authentication"
    parts = []

    login_files_to_load = [f"{portal_type}_login_page.py"] if portal_type else ["bank_login_page.py"]
    for fname in login_files_to_load:
        f = auth_dir / fname
        if f.exists():
            parts.append(f"--- REAL FILE (already exists, use exactly as-is): {fname} ---\n"
                         + f.read_text(encoding="utf-8", errors="ignore"))

    bank_locators = repo_root / "src" / "banks" / bank / "locators" / "login_locators.py"
    if bank_locators.exists():
        parts.append(f"--- REAL FILE (already exists, this bank's actual login selectors - "
                     f"NOT placeholders): {bank_locators.name} ---\n"
                     + bank_locators.read_text(encoding="utf-8", errors="ignore"))

    return "\n\n".join(parts)


# ======================================================================
# ONE-FILE MODE: locators + page + tests (positive AND negative) in ONE .py file per bank+module
#   src/testcase/<module>/test_<module>_<bank>.py
# The generator still works on the separate files internally (heal, dry run, negative generation, validation
# all need them) and merges them as the LAST step; the separate files are moved to debug_logs\backups.
# ======================================================================
def single_file_path(repo_root: Path, bank: str, module: str) -> Path:
    return repo_root / "src" / "testcase" / module / f"test_{module}_{bank}.py"


def _split_py(src: str):
    """-> (tree, lines, imports[(node,start,end)], others[(node,start,end)]) with 0-based inclusive line ranges
    (decorators included for defs/classes)."""
    tree = ast.parse(src)
    lines = src.split("\n")
    imports, others = [], []
    for i, node in enumerate(tree.body):
        start = min([d.lineno for d in getattr(node, "decorator_list", [])] + [node.lineno]) - 1
        end = node.end_lineno - 1
        is_doc = i == 0 and isinstance(node, ast.Expr) and isinstance(getattr(node, "value", None), ast.Constant) \
            and isinstance(node.value.value, str)
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            imports.append((node, start, end))
        elif is_doc:
            continue
        else:
            others.append((node, start, end))
    return tree, lines, imports, others


def _defined_names(others) -> list[str]:
    names = []
    for node, _s, _e in others:
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            names.append(node.name)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                names.extend(n.id for n in ast.walk(t) if isinstance(n, ast.Name))
    return names


# ======================================================================
# REFERENCE LAYOUT for the one-file module (matches the team's reference/sample_test.py):
#   imports -> BANK_NAME = ConfigManager.get("bank") -> _rows_<Sheet> = ExcelUtil.get_sheet("<File>", "<Sheet>") (one per
#   sheet, ALL at the top) -> locators classes -> page classes -> ONE test class Test<Module>Module whose methods are
#   grouped under  # ====ADD====  style banners, each one straight chain: login -> page -> navigate -> action -> save,
#   with @pytest.mark.parametrize("data", _rows_X, ids=[...ScenarioID - TestcaseID - Description...]).
# ======================================================================
_SECTION_WORDS = (("negative", "NEGATIVE"), ("delete", "DELETE"), ("changestatus", "CHANGESTATUS"),
                  ("change_status", "CHANGESTATUS"), ("status", "CHANGESTATUS"), ("edit", "EDIT"),
                  ("view", "VIEW"), ("add", "ADD"))
_IDS_TEMPLATE = "ids=[f'{{data[\"ScenarioID\"]}} - {{data[\"TestcaseID\"]}} - {{data[\"Description\"]}}' for data in {rows}]"
_GET_SHEET_CALL_RE = re.compile(r"""ExcelUtil\.get_sheet\(\s*["']([^"']+)["']\s*,\s*["']([^"']+)["']\s*\)""")


def _section_of(method_name: str) -> str:
    low = method_name.lower()
    for word, label in _SECTION_WORDS:
        if word in low:
            return label
    return "TESTS"


def _method_text(node, lines: list[str], is_module_level: bool) -> str:
    import textwrap
    start = min([d.lineno for d in node.decorator_list] + [node.lineno]) - 1
    text = textwrap.dedent("\n".join(lines[start:node.end_lineno]))
    if is_module_level:                                       # a plain test function becomes a method
        text = re.sub(r"(def\s+\w+\()\s*\)", r"\1self)", text, count=1)
        if not re.search(r"def\s+\w+\(\s*self\b", text):
            text = re.sub(r"(def\s+\w+\()", r"\1self, ", text, count=1)
    return text


def _add_ids_to_parametrize(text: str) -> str:
    """parametrize("data", _rows_X)  ->  parametrize("data", _rows_X, ids=[ScenarioID - TestcaseID - Description ...])"""
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return text
    fn = tree.body[0]
    lines = text.split("\n")
    for deco in sorted(getattr(fn, "decorator_list", []), key=lambda d: -d.lineno):
        if not (isinstance(deco, ast.Call) and isinstance(deco.func, ast.Attribute) and deco.func.attr == "parametrize"):
            continue
        if len(deco.args) != 2 or any(k.arg == "ids" for k in deco.keywords):
            continue
        names, values = (ast.get_source_segment(text, a) for a in deco.args)
        if not (isinstance(deco.args[0], ast.Constant) and deco.args[0].value == "data"
                and isinstance(deco.args[1], ast.Name)):
            continue
        extra = "".join(f",\n    {k.arg}={ast.get_source_segment(text, k.value)}" for k in deco.keywords if k.arg)
        new = ("@pytest.mark.parametrize(\n    " + names + ",\n    " + values + ",\n    "
               + _IDS_TEMPLATE.format(rows=values) + extra + "\n)")
        lines[deco.lineno - 1:deco.end_lineno] = new.split("\n")
        text = "\n".join(lines)
    return text


def _hoist_sheet_calls(text: str, file_title: str, sheet_vars: dict[str, str]) -> str:
    """Moves every ExcelUtil.get_sheet("<File>", "<Sheet>") that sits INSIDE a test to a module-level
    _rows_<Sheet> variable (created on first use) and rewrites the test to use it."""
    def var_for(sheet: str) -> str:
        return sheet_vars.setdefault(sheet, f"_rows_{re.sub(r'[^0-9A-Za-z_]', '_', sheet)}")
    # 1) alias lines:   rows = ExcelUtil.get_sheet(...)   -> drop the line, use the variable everywhere
    def alias(m):
        return ""
    out_lines = []
    renames: dict[str, str] = {}
    for ln in text.split("\n"):
        m = re.match(r"""^\s*(\w+)\s*=\s*ExcelUtil\.get_sheet\(\s*["']([^"']+)["']\s*,\s*["']([^"']+)["']\s*\)\s*$""", ln)
        if m:
            renames[m.group(1)] = var_for(m.group(3))
            continue
        out_lines.append(ln)
    text = "\n".join(out_lines)
    for local, var in renames.items():
        text = re.sub(rf"\b{re.escape(local)}\b", var, text)
    # 2) direct calls anywhere else in the test
    return _GET_SHEET_CALL_RE.sub(lambda m: var_for(m.group(2)), text)


def _assemble_reference_layout(repo_root: Path, bank: str, module: str, analysed: list, hoisted: dict,
                               future: dict, docstring: str | None = None) -> str:
    import textwrap
    module_title = module[:1].upper() + module[1:]
    file_title = module_title
    locator_chunks: list[str] = []
    page_chunks: list[str] = []
    extra_chunks: list[str] = []
    header_assigns: dict[tuple, str] = {}
    test_classes, test_funcs = [], []
    for kind, p, _t, lines, imps, others in analysed:
        skip = set()
        for _n, s, e in imps:
            skip.update(range(s, e + 1))
        if kind in ("locators", "page"):
            if others:
                first, last = others[0][1], others[-1][2]
                chunk = "\n".join(ln for idx, ln in enumerate(lines[first:last + 1], start=first) if idx not in skip).strip("\n")
                (locator_chunks if kind == "locators" else page_chunks).append(chunk)
            continue
        for node, s, e in others:                              # test + negative parts: classify node by node
            text = "\n".join(lines[s:e + 1])
            if isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
                test_classes.append((node, lines))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                test_funcs.append((node, lines))
            elif isinstance(node, ast.ClassDef):
                (locator_chunks if "Locators" in node.name else page_chunks).append(text)
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                names = tuple(_defined_names([(node, s, e)]))
                if names and all(n == "BANK_NAME" or n.startswith("_rows") or n.isupper() for n in names):
                    header_assigns.setdefault(names, text)
                else:
                    extra_chunks.append(text)
            else:
                extra_chunks.append(text)

    sheet_vars: dict[str, str] = {}                            # sheet -> module-level variable
    for names, text in header_assigns.items():
        m = _GET_SHEET_CALL_RE.search(text)
        if m and len(names) == 1:
            sheet_vars.setdefault(m.group(2), names[0])

    methods: list[tuple[str, str]] = []                        # (section, method text, dedented)
    class_attrs: list[str] = []
    for node, lines in test_classes:
        class_marks = [textwrap.dedent("\n".join(lines[d.lineno - 1:d.end_lineno])).strip() for d in node.decorator_list]
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                text = _method_text(item, lines, False)
                for mark in reversed(class_marks):             # class-level marks go onto every method
                    if mark and mark not in text:
                        text = mark + "\n" + text
                methods.append((_section_of(item.name), text))
            elif isinstance(item, (ast.Assign, ast.AnnAssign)):
                class_attrs.append(textwrap.dedent("\n".join(lines[item.lineno - 1:item.end_lineno])))
    for node, lines in test_funcs:
        methods.append((_section_of(node.name), _method_text(node, lines, True)))
    if not methods:
        raise RuntimeError("no test methods found to lay out")

    body_methods: list[tuple[str, str]] = []
    for section, text in methods:
        text = _hoist_sheet_calls(text, file_title, sheet_vars)
        text = _add_ids_to_parametrize(text)
        body_methods.append((section, textwrap.indent(text, "    ")))

    # ---- module-level header: BANK_NAME + one _rows_<Sheet> per sheet ----
    all_text = "\n".join(t for _s, t in body_methods)
    defined_header = {n for names in header_assigns for n in names}
    header_lines: list[str] = []
    if "BANK_NAME" in all_text and "BANK_NAME" not in defined_header:
        index = _build_repo_symbol_index(repo_root)
        if "ConfigManager" in index:
            hoisted.setdefault("ConfigManager", f"from {index['ConfigManager'][0]} import ConfigManager")
            header_lines.append('BANK_NAME = ConfigManager.get("bank")')
        else:
            header_lines.append(f'BANK_NAME = "{bank}"')
    for names, text in header_assigns.items():
        if "BANK_NAME" in names:
            header_lines.insert(0, text)
        else:
            header_lines.append(text)
    existing_vars = {n for names in header_assigns for n in names}
    for sheet, var in sheet_vars.items():
        if var not in existing_vars:
            header_lines.append(f'{var} = ExcelUtil.get_sheet("{file_title}", "{sheet}")')

    cls_lines = [f"class Test{module_title}Module:"] + ([textwrap.indent(a, "    ") for a in class_attrs] if class_attrs else [])
    last_section = None
    for section, text in body_methods:
        if section != last_section:
            cls_lines.append(f"\n    # {'=' * 34}{section}{'=' * 34}\n")
            last_section = section
        cls_lines.append(text + "\n")
    test_class_text = "\n".join(cls_lines).rstrip("\n")

    def banner(title: str) -> str:
        return f"# {'=' * 66}\n# {title}\n# {'=' * 66}\n"
    parts = [(docstring or (f'"""{module}: locators, page object and tests (positive + negative) for bank \'{bank}\' in ONE file.\n\n'
                            f'Test data lives in src/banks/{bank}/testdata/{module_title}.xlsx\n"""\n'))
             + "\n".join(future.values()) + ("\n" if future else "") + "\n".join(hoisted.values()) + "\n"]
    if header_lines:
        parts.append("\n".join(header_lines) + "\n")
    if locator_chunks:
        parts.append(banner("LOCATORS") + "\n\n\n".join(locator_chunks) + "\n")
    if page_chunks or extra_chunks:
        parts.append(banner("PAGE OBJECT") + "\n\n\n".join(page_chunks + extra_chunks) + "\n")
    parts.append(banner("TESTS") + test_class_text + "\n")
    return "\n\n".join(parts)


def merge_module_into_single_file(repo_root: Path, bank: str, module: str, written: dict, log=print,
                                  include_negative: bool | None = None) -> Path | None:
    """Merges the module's locators + page + test (+ the single negative file when it exists) into ONE file.
    All-or-nothing: on any doubt (name collision, unresolved own-module import, syntax) nothing is changed."""
    parts: list[tuple[str, Path]] = []
    for kind in ("locators", "page", "test"):
        p = written.get(kind)
        if not p or not Path(p).exists():
            log(f"  [one-file] skipped: the {kind} file is missing, so there is nothing complete to merge.")
            return None
        parts.append((kind, Path(p)))
    if include_negative is None:
        include_negative = negative_layout() == "single"      # 'separate' = the negative files stay separate
    neg = repo_root / "src" / "testcase" / module / f"test_{module}_negative.py"
    if include_negative and neg.exists() and neg.resolve() not in {p.resolve() for _, p in parts}:
        parts.append(("negative", neg))
    for _k, _p in parts:
        repair_python_string_lines(_p)                 # e.g. a heal that left  "span:has-text("X")"  in locators.py
    dest = single_file_path(repo_root, bank, module)
    own_modules = {f"src.banks.{bank}.locators.{module}_locators", f"src.common.pages.{module}.{module}_page",
                   f"src.testcase.{module}.test_{module}", f"src.testcase.{module}.test_{module}_negative",
                   f"src.banks.{bank}.locators.{module}_negative_locators",
                   f"src.common.pages.{module}.{module}_negative_page"}
    try:
        analysed = []
        for kind, p in parts:
            src = p.read_text(encoding="utf-8")
            analysed.append((kind, p, *_split_py(src)))
        # ---- every name defined anywhere (to prove removed own-module imports are satisfied) ----
        all_defined: dict[str, str] = {}
        assign_sig: dict[str, str] = {}            # name -> ast dump of an IDENTICAL module-level assignment
        for kind, p, _t, _l, _imps, others in analysed:
            for node_o in others:
                for n in _defined_names([node_o]):
                    sig = ast.dump(node_o[0]) if isinstance(node_o[0], (ast.Assign, ast.AnnAssign)) else None
                    if n in all_defined and all_defined[n] != kind:
                        if sig is not None and assign_sig.get(n) == sig:
                            continue               # same constant defined twice (e.g. BANK_NAME) - harmless, deduped later
                        log(f"  [one-file] NOT merged: '{n}' is defined in both the {all_defined[n]} part and the "
                            f"{kind} part with DIFFERENT code - merging would silently shadow one of them.")
                        return None
                    all_defined[n] = kind
                    if sig is not None:
                        assign_sig[n] = sig
        hoisted: dict[str, str] = {}
        future: dict[str, str] = {}
        for kind, p, _t, lines, imps, _others in analysed:
            for node, s, e in imps:
                text = "\n".join(lines[s:e + 1])
                modname = (node.module or "") if isinstance(node, ast.ImportFrom) else ""
                if isinstance(node, ast.ImportFrom) and node.level == 0 and modname in own_modules:
                    missing = [a.name for a in node.names if a.name != "*" and a.name not in all_defined]
                    if missing:
                        log(f"  [one-file] NOT merged: the {kind} part imports {missing} from its own module "
                            f"'{modname}' but nothing in the merged code defines them.")
                        return None
                    continue                                   # defined in the same file now
                key = ast.dump(node)
                (future if modname == "__future__" else hoisted).setdefault(key, text)
        banners = {"locators": "LOCATORS", "page": "PAGE OBJECT", "test": "TESTS (positive)",
                   "negative": "NEGATIVE CASES (locators + page + tests)"}
        body_chunks = []
        for kind, p, _t, lines, imps, others in analysed:
            skip = set()
            for _n, s, e in imps:
                skip.update(range(s, e + 1))
            if not others:
                continue
            first, last = others[0][1], others[-1][2]
            # keep comments/blank lines BETWEEN code, drop only the import lines
            chunk = [ln for idx, ln in enumerate(lines[first:last + 1], start=first) if idx not in skip]
            body_chunks.append(f"# {'=' * 66}\n# {banners[kind]}\n# {'=' * 66}\n" + "\n".join(chunk).strip("\n"))
        merged = (f'"""{module}: locators, page object and tests (positive + negative) for bank \'{bank}\' in ONE file.\n\n'
                  f'Test data lives in src/banks/{bank}/testdata/{module[:1].upper() + module[1:]}.xlsx\n"""\n'
                  + "\n".join(future.values()) + ("\n" if future else "")
                  + "\n".join(hoisted.values()) + "\n\n\n" + "\n\n\n".join(body_chunks) + "\n")
        ast.parse(merged)
        try:                                       # the team's reference layout (one test class, rows at the top)
            laid_out = _assemble_reference_layout(repo_root, bank, module, analysed, dict(hoisted), dict(future))
            laid_out = normalize_test_self_usage(laid_out, module, bank)[0]
            ast.parse(laid_out)
            if len(re.findall(r"^class\s+Test\w+", laid_out, re.M)) != 1:
                raise RuntimeError("expected exactly one Test class")
            if len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", laid_out, re.M)) != \
                    len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", merged, re.M)):
                raise RuntimeError("test count changed while laying out")
            for rv in set(re.findall(r"\b(_rows_\w+)\b", laid_out)):
                if not re.search(rf"^{rv}\s*=", laid_out, re.M):
                    raise RuntimeError(f"{rv} is used but never defined at module level")
            merged = laid_out
            log("  [one-file] laid out in the reference format: ONE test class, _rows_* sheet loads at the top, "
                "parametrize ids, section banners.")
        except Exception as exc:
            log(f"  [one-file] reference layout skipped ({exc}); wrote the simple merged layout instead.")
        n_tests_before = sum(len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", p.read_text(encoding="utf-8"), re.M))
                             for _, p in parts)
        n_tests_after = len(re.findall(r"^\s*(?:async\s+)?def\s+test_\w+", merged, re.M))
        if n_tests_before != n_tests_after:
            log(f"  [one-file] NOT merged: test count changed ({n_tests_before} -> {n_tests_after}).")
            return None
        bad = find_nonexistent_src_import(merged, repo_root)
        if bad:
            log(f"  [one-file] NOT merged: the merged file would import '{bad}', which does not exist.")
            return None
    except SyntaxError as exc:
        log(f"  [one-file] NOT merged: a part has a syntax error at line {exc.lineno}: {(exc.text or '').strip()[:120]} "
            f"- fix that line (the separate files are untouched).")
        return None
    except Exception as exc:
        _log_exception("one-file merge", exc)
        log("  [one-file] NOT merged (see the error above) - the separate files are untouched.")
        return None

    import shutil
    import time as _t
    bdir = repo_root / "debug_logs" / "backups" / f"{module}_parts_{_t.strftime('%Y%m%d_%H%M%S')}"
    bdir.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        shutil.copy2(dest, bdir / f"{dest.name}.previous")
    dest.parent.mkdir(parents=True, exist_ok=True)
    (dest.parent / "__init__.py").touch(exist_ok=True)
    dest.write_text(merged, encoding="utf-8")
    for kind, p in parts:
        if p.resolve() != dest.resolve():
            shutil.move(str(p), str(bdir / p.name))
    log(f"  [one-file] wrote ONE file with locators + page + tests: {dest}")
    log(f"  [one-file] the separate files were moved to {bdir} (nothing was deleted).")
    return dest


def extract_parts_from_merged(src: str) -> dict[str, str]:
    """Splits a merged one-file module back into {'locators','page','test'} source text (positive classes
    only) so the generator can still show the AI the existing locators / page / test when it regenerates."""
    try:
        _tree, lines, imps, others = _split_py(src)
    except Exception:
        return {}
    header = "\n".join("\n".join(lines[s:e + 1]) for _n, s, e in imps)
    out = {"locators": [], "page": [], "test": []}
    for node, s, e in others:
        text = "\n".join(lines[s:e + 1])
        name = getattr(node, "name", "")
        if "Negative" in name:
            continue
        if isinstance(node, ast.ClassDef) and name.endswith("Locators"):
            out["locators"].append(text)
        elif isinstance(node, ast.ClassDef) and name.endswith("Page"):
            out["page"].append(text)
        elif (isinstance(node, ast.ClassDef) and name.startswith("Test")) or name.startswith("test_") \
                or isinstance(node, (ast.Assign, ast.AnnAssign)) or name == "":
            out["test"].append(text)
    return {k: (header + "\n\n" + "\n\n".join(v)).strip() for k, v in out.items() if v}


def _merged_part(repo_root: Path, bank: str | None, module: str, kind: str) -> str | None:
    if not bank:
        return None
    p = single_file_path(repo_root, bank, module)
    if not p.exists():
        return None
    return extract_parts_from_merged(p.read_text(encoding="utf-8", errors="ignore")).get(kind)


def find_existing_locators(repo_root: Path, bank: str, module: str) -> str | None:
    """Checks if a REAL locators file for this module already exists in the
    repo (e.g. someone already built it by hand, or a previous run already
    produced real, verified selectors). If found, its content is returned
    so the AI reuses those exact original selectors instead of guessing or
    falling back to placeholders - this is the authoritative source of
    truth over anything the AI would invent."""
    candidate = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if candidate.exists():
        content = candidate.read_text(encoding="utf-8", errors="ignore")
        if "#TODO-verify" not in content:  # only trust it if it's not itself full of placeholders
            return content
        return None
    merged = _merged_part(repo_root, bank, module, "locators")      # one-file mode
    if merged and "#TODO-verify" not in merged:
        return merged
    return None


def extract_action_from_scenario(scenario: str) -> str:
    """Determines which action this scenario is (add/view/edit/
    changestatus/delete/...) from its wording, so this action's method,
    test, and testdata sheet can coexist alongside other actions already
    built for the SAME module - instead of one scenario overwriting
    another.

    Checks the actual clicked BUTTON/MENU phrases first (the same ones
    extract_nav_phrases() finds, e.g. "Add", "Edit", "View", "Change
    Status") since these are the literal labels being clicked and the
    most reliable signal - a scenario always ends with an assertion like
    "success message is displayed", and generic keyword-scanning the
    whole sentence previously matched "display" there and misclassified
    almost every scenario as "view" regardless of the real action. Only
    falls back to scanning the full text if no clear action button/menu
    phrase was found. Falls back to "default" if nothing recognizable is
    found at all, which still works fine for a module that only ever has
    one action."""
    nav_phrases = [p.lower() for _, p in extract_nav_phrases(scenario)]

    phrase_action_map = [
        ("changestatus", ["change status", "toggle status", "activate", "deactivate",
                          "enable", "disable", "status"]),
        ("delete", ["delete", "remove"]),
        ("edit", ["edit", "update", "modify"]),
        ("view", ["view", "search", "list"]),
        ("add", ["add", "create", "new"]),
    ]
    for phrase in nav_phrases:
        for action_name, keywords in phrase_action_map:
            if any(kw == phrase or phrase.startswith(kw + " ") for kw in keywords):
                return action_name

    # No clear action button/menu phrase found - fall back to scanning the
    # whole scenario text, but exclude generic assertion words like
    # "display"/"displayed" that appear in almost every scenario's
    # assertion regardless of the actual action.
    text = scenario.lower()
    text_keywords = [
        ("changestatus", ["change status", "toggle status", "enable", "disable",
                          "activate", "deactivate"]),
        ("delete", ["delete", "remove"]),
        ("edit", ["edit", "update", "modify"]),
        ("view", ["view the", "search for", "list of"]),
        ("add", ["add ", "create ", "new "]),
    ]
    for action_name, keywords in text_keywords:
        if any(kw in text for kw in keywords):
            return action_name
    return "default"


SCENARIO_EXPAND_SYSTEM_PROMPT = """You take ONE "Add" test scenario for a
web admin-panel module, written in plain English, and produce three more
one-line scenario descriptions for the SAME module, reusing the SAME menu
navigation wording and the SAME field names already present in the Add
scenario - only the action verb, the button clicked, and the final
assertion change:

  VIEW          - navigate the same menu path, open/search the record
                  that was added, and assert its field values are
                  displayed correctly (read-only, no Save).
  EDIT          - navigate the same menu path, click Edit on the
                  existing record, change the SAME field(s) named in the
                  Add scenario, click Save, and assert an
                  updated/success message is displayed.
  CHANGESTATUS  - navigate the same menu path, click Change Status (or
                  Activate/Deactivate/Enable/Disable - use whatever this
                  module's own wording would realistically be) on the
                  existing record, confirm, and assert a status-changed
                  message is displayed.

Reply in EXACTLY this format and nothing else - no preamble, no
markdown, no extra commentary:

VIEW: <one line>
EDIT: <one line>
CHANGESTATUS: <one line>
"""


def derive_action_variants(scenario: str, module: str, bank: str) -> dict[str, str]:
    """Given a single Add scenario, asks the AI to derive matching
    View/Edit/ChangeStatus scenario lines for the SAME module and SAME
    fields - this is what lets the person type ONE scenario and get all
    four CRUD actions generated in one run, instead of writing out four
    near-duplicate scenario sentences by hand. Falls back to simple
    keyword-substitution templates (still using the same field wording
    from the original scenario) if the AI call fails, so this step can
    never hard-block the pipeline."""
    user_prompt = f"Bank: {bank}\nModule: {module}\nAdd scenario: {scenario}"
    reply = ask_ai(SCENARIO_EXPAND_SYSTEM_PROMPT, user_prompt)
    variants: dict[str, str] = {}
    if reply:
        for line in reply.splitlines():
            line = line.strip()
            for key in ("VIEW", "EDIT", "CHANGESTATUS"):
                prefix = f"{key}:"
                if line.upper().startswith(prefix):
                    variants[key.lower()] = line[len(prefix):].strip()
    # Fallback templates for any variant the AI didn't return (or if the
    # whole call failed) - crude but keeps the batch/expand flow moving
    # instead of stopping on an AI hiccup.
    if "view" not in variants:
        variants["view"] = (f"{scenario} Then navigate back and view the same record, "
                             f"verifying the field values are displayed correctly.")
    if "edit" not in variants:
        variants["edit"] = (f"{scenario} Then click Edit on the same record, update the same "
                             f"fields, click Save, and verify a success message is displayed.")
    if "changestatus" not in variants:
        variants["changestatus"] = (f"{scenario} Then click Change Status on the same record, "
                                     f"confirm, and verify a status-changed message is displayed.")
    return variants


def load_manual_dom_capture(path_str: str) -> str:
    """Reads HTML/text the person manually saved from their OWN already-
    working browser session (View Source, or Inspect Element -> Copy
    outerHTML, pasted into a .txt/.html file) - the most reliable input
    source there is, since it completely bypasses Playwright driving a
    real login/navigation/click sequence, which is exactly where things
    have been failing (login timing, element-not-found, menu clicks not
    landing). If the person can see the page correctly in their own
    Chrome, this always works regardless of what's wrong with the
    automated browser path. Returns the file's content as-is, or an
    empty string (with a clear message) if the path doesn't exist."""
    path = Path(path_str.strip().strip('"').strip("'"))
    if not path.exists():
        print(f"  ERROR: file not found: {path}")
        return ""
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        print(f"  Read {len(content)} characters from {path}")
        return content
    except Exception as exc:
        print(f"  ERROR reading {path}: {exc}")
        return ""


def retry_with_split_calls(bank: str, module: str, base_scenario: str, ref_text: str,
                            page_html: str, existing_locators: str | None, url: str | None,
                            real_login_code: str, existing_page_class: str | None,
                            existing_test_file: str | None, phrase_xpaths: dict,
                            explicit_scenarios: dict | None, no_add_needed: bool,
                            search_by_fields: list | None) -> str | None:
    """FEATURE: split-call fallback for complex modules - when the single
    COMBINED call (locators + page + test + testdata all in one AI reply)
    fails outright (the AI backend returns nothing at all - e.g. a
    free-tier model returning empty/null choices on an oversized prompt,
    which is exactly what a module with a dozen-plus fields across
    several accordion sections, chip multi-selects, and conditional
    checkboxes produces - see scan_conditional_fields and the
    COMPONENT-LIBRARY FORMS rule elsewhere in this file), retrying the
    EXACT SAME oversized prompt again usually fails the same way.

    Instead, this splits the work into two smaller, focused calls:
      1. LOCATORS ONLY - a compact prompt asking for just the locators
         file from the real scan. Much smaller than the combined prompt
         (no page-class/test-file style guidance, no multi-action
         instructions), so it fits comfortably even for a model that
         choked on the full combined request.
      2. PAGE + TEST + TESTDATA - built from the NOW-CONFIRMED locators
         file's own content (a clean, compact list of real field names)
         instead of the raw, noisy scan HTML - meaningfully smaller and
         less ambiguous than re-sending the full scan a second time,
         since the field names are now settled, real Python identifiers
         rather than raw markup the AI would otherwise have to re-parse.

    Returns a combined reply text in the SAME "### FILE: ..." block
    format the normal combined call produces (so the caller's existing
    auto_write_into_repo parsing works unchanged), or None if either
    half of the split still fails - at which point this really is a
    deeper problem (a genuine backend outage, not just prompt size)."""
    print("  Combined call failed - this module's scan is large/complex; retrying as TWO smaller "
          "calls instead of one (locators first, then page+test+testdata from the confirmed "
          "locators) rather than repeating the same oversized prompt.")

    # --- Call 1: locators only ---
    locators_prompt = (
        f"Generate ONLY the locators file for bank '{bank}', module '{module}'. Do not generate "
        f"a page class, test file, or testdata - just the locators class, using EXACTLY the real "
        f"scanned elements below. Ground every locator in real evidence from the scan; use "
        f"#TODO-not-found-in-scan for anything not actually confirmed there.\n\n"
        f"REAL SCAN:\n{page_html[:6000]}\n\n"
        f"Output exactly one '### FILE: src/banks/{bank}/locators/{module}_locators.py' block."
    )
    locators_reply = ask_ai(SYSTEM_PROMPT, locators_prompt)
    if not locators_reply or "### FILE:" not in locators_reply:
        print("  Split-call locators-only attempt also failed - this looks like a genuine "
              "backend problem, not just prompt size. Try a different AI_BACKEND/model, or retry "
              "later.")
        return None
    print("  Locators-only call succeeded.")

    # Extract just the locators class body to hand to call 2 as a compact,
    # already-settled field reference (real Python identifiers, not raw
    # scan markup).
    locators_match = re.search(r"### FILE:[^\n]*locators\.py\s*\n(.*?)(?=\n### FILE:|\Z)",
                                locators_reply, re.DOTALL)
    confirmed_locators_text = locators_match.group(1).strip() if locators_match else locators_reply

    # --- Call 2: page + test + testdata, using the confirmed locators
    # instead of the raw scan (smaller, cleaner, already-settled field
    # names rather than noisy markup the AI would otherwise re-derive) ---
    page_test_prompt = build_user_prompt(
        bank, module, base_scenario, ref_text,
        page_html=f"[Field names are already confirmed - see the real locators class below, do "
                  f"not re-derive them from scratch]\n{confirmed_locators_text}",
        existing_locators=confirmed_locators_text, url=url, real_login_code=real_login_code,
        existing_page_class=existing_page_class, existing_test_file=existing_test_file,
        action="add", phrase_xpaths=phrase_xpaths, omit_ref_text=False,
    )
    if explicit_scenarios:
        page_test_prompt += "\n" + build_multi_action_instructions(
            explicit_scenarios, include_add=not no_add_needed, search_by_fields=search_by_fields)
    else:
        page_test_prompt += "\n" + MULTI_ACTION_INSTRUCTIONS
    page_test_prompt += (
        "\n\nIMPORTANT: the locators file already exists (shown above) - do NOT regenerate a "
        "'### FILE: .../locators.py' block this time, only the page class, test file, and "
        "testdata."
    )
    page_test_prompt += _negative_scope_note() + _runtime_data_note()
    page_test_reply = ask_ai(SYSTEM_PROMPT, page_test_prompt)
    if not page_test_reply:
        print("  Split-call page+test attempt failed after locators succeeded - partial progress "
              "only (locators reply is still available above if needed manually).")
        return None
    print("  Page+test+testdata call succeeded.")

    # Combine both replies into one, in the same "### FILE:" format the
    # normal single-call path already knows how to parse.
    return locators_reply.strip() + "\n\n" + page_test_reply.strip()


def _scan_for_scenarios_without_add(repo_root: Path, bank: str, portal_type: str, explicit_scenarios: dict | None,
                                    log=print) -> tuple[str, dict[str, str], str]:
    """No Add scenario, no menu path, no URL: the menu path is read from the scenarios that WERE given ('Navigate to Administration >
    Channel Support, click ...' of the Update / Edit / ... scenario) and clicked through before the DOM is scanned. Without this the scan
    stayed on the dashboard right after the login and the AI got the elements of the DASHBOARD, not of the module's page."""
    for key, text in (explicit_scenarios or {}).items():
        head = (text or "")[:220]
        # a real menu path: 'Navigate to ...', 'Go to ...', 'Open ...', a menu / sub-menu, or an arrow  A > B
        if re.search(r"\b(navigate\s+to|go\s+to|open)\b|>|\bmenu\b|\bsub-?menu\b", head, re.I) and extract_nav_phrases(text or ""):
            shown = re.split(r"(?<=[a-z\)])\.\s", head)[0][:110]
            log(f"  No menu path was given separately - using the one written in the '{key}' scenario: {shown}")
            html, xp = login_via_real_framework(repo_root, bank, portal_type, text)
            return html, xp, f"the menu path written in the '{key}' scenario"
    log("  !!! WARNING: none of the scenarios starts with a menu path ('Navigate to Administration > ...') and no menu path / URL was "
        "given, so NO menu is clicked: the DOM of the DASHBOARD (the page right after the login) is what the AI gets. The locators will "
        "mostly be guesses (they are corrected against the real page afterwards, but it is far better to start the scenario with "
        "'Navigate to <menu> > <submenu>').")
    html, xp = login_via_real_framework(repo_root, bank, portal_type, "")
    return html, xp, "the post-login landing page (no menu path or URL was given)"


def run_full_module_pipeline(repo_root: Path, bank: str, module: str, portal_type: str,
                              url: str | None, base_scenario: str | None, ref_text: str,
                              expand_actions: bool = True, inspect_choice: str = "1",
                              explicit_scenarios: dict[str, str] | None = None,
                              module_url: str | None = None, menu_name: str | None = None,
                              manual_html_path: str | None = None,
                              screenshot_paths: list[str] | None = None,
                              search_by_fields: list[str] | None = None,
                              confirmed_description: str | None = None,
                              pre_scanned_html: str | None = None,
                              field_values: dict[str, str] | None = None,
                              field_constraints: dict[str, str] | None = None,
                              bank_notes: str | None = None,
                              log=print) -> dict[str, dict]:
    """Runs the Add scenario given, then - if expand_actions is True -
    runs View/Edit/ChangeStatus for the SAME module/fields too, all in a
    SINGLE combined AI call (locators + page + test + 4 testdata CSVs
    all in one reply) instead of 4 separate calls, since each separate
    call would resend the same large reference/system-prompt/page-scan
    context and burn tokens 4x over for no benefit. The live page is
    scanned ONCE either way (real admin-grid listing pages normally show
    Add/Edit/View/ChangeStatus controls together on one screen). Used by
    BOTH the interactive single-scenario flow and the non-interactive
    --batch-file flow, so the two never drift out of sync.

    explicit_scenarios: optional {"view": "...", "edit": "...",
    "changestatus": "..."} - for any of these three the person typed
    their OWN scenario (instead of "give Add only, auto-derive the
    rest"), that exact text is sent to the AI as a hard instruction to
    follow verbatim - see build_multi_action_instructions. Any action
    left out of this dict (or the dict itself omitted) is still
    auto-derived from the Add scenario as before - explicit and
    auto-derived actions can be freely mixed.

    base_scenario=None (or blank): ZERO-SCENARIO MODE - no English
    description at all, the DOM tells the AI everything instead. Reaches
    the module page one of two ways, in this preference order:
      1. menu_name given (e.g. "Configuration > Currency") - clicks
         through that real menu path, same navigation the scenario-based
         flow uses (see explore_module_via_menu). Preferred whenever
         available since it exercises the real navigation.
      2. module_url given (no menu_name) - jumps straight to that URL
         (see explore_module_via_url), for when pasting the address is
         easier than describing the menu path.
    Either way, captures the listing page's structure (search box or
    not, per-row links or checkboxes, global buttons) AND the Add form's
    actual fields (by clicking whatever says "Add"), then derives ALL
    FOUR actions purely from what was scanned, with a short synthetic
    scenario standing in for the missing description so the rest of
    this pipeline (build_user_prompt, MULTI_ACTION_INSTRUCTIONS) doesn't
    need a separate code path.

    Returns {"add": {...}} (single action, expand_actions=False) or
    {"combined": {"written": {...}, "scenario": base_scenario}} on
    success (expand_actions=True) - "written" keys are locators/page/test/
    testdata_add/testdata_view/testdata_edit/testdata_changestatus. A
    failure has an "error" key instead of "written", under the same dict
    key ("add" or "combined").
    """
    results: dict[str, dict] = {}
    if ensure_screenshot_on_failure_fixture(repo_root):
        log("  Added a screenshot-on-failure hook to conftest.py (failures saved under "
            "<repo_root>/failures/ the moment any test fails).")
    real_login_code = load_real_login_files(repo_root, bank, portal_type)
    existing_locators = find_existing_locators(repo_root, bank, module)
    existing_page_class = find_existing_page_class(repo_root, module, bank)
    existing_test_file = find_existing_test_file(repo_root, module, bank)

    # No Add scenario given this time, but SOME other action(s) were -
    # two real cases this covers:
    #   1. Add already implemented (existing_page_class found) - the
    #      person is adding new action(s) without re-typing Add (see
    #      read_multiline_scenario_block's require_add=False path).
    #   2. This module has NO Add flow at all in the real application
    #      (e.g. a "Password Security" screen that only configures
    #      pre-existing User Types - there's nothing to "create") - Add
    #      was never going to be described because it doesn't exist,
    #      not because it was already generated. existing_page_class
    #      will be empty/None here since nothing's been written yet.
    # Either way, the action(s) actually given are generated as-is - the
    # message shown to the AI differs slightly (see add_already_exists's
    # use below) but the exclude-Add mechanics are identical.
    no_add_needed = not (base_scenario or "").strip() and bool(explicit_scenarios)

    # MULTI-BANK + DOM ENFORCEMENT: generating a bank's INITIAL Add flow
    # via a fresh, unguided DOM scan (menu_name/module_url given, no
    # base_scenario text) when this module ALREADY has an established
    # page class for another bank risks each bank's page ending up with
    # a subtly different, inconsistent method structure (see the
    # MULTI-BANK MODULES rule in SYSTEM_PROMPT for the full reasoning) -
    # scenario text keeps every bank's generation anchored to the same
    # described flow instead of however this bank's own scan happened to
    # look. Explicitly requested (twice) to be enforced, not just warned
    # about - this bank's DOM-mode entry is skipped outright rather than
    # generated inconsistently, with a clear message telling the person
    # exactly what to change in their batch file.
    zero_scenario_mode_pending = not (base_scenario or "").strip() and (module_url or menu_name)
    if zero_scenario_mode_pending and existing_page_class and not no_add_needed:
        log(f"  SKIPPED: '{module}' already has an established page class for another bank, but "
            f"this line uses DOM mode (no scenario text) for '{bank}' - a module shared across "
            f"banks must be generated from scenario text, not an independent DOM scan per bank "
            f"(see multi-bank guidance), so this bank was not generated. Fix: replace 'DOM' in "
            f"this line with the same MULTI-style scenario text (\"Add: ... ;; ...\") used for "
            f"this module's other bank(s), then re-run.")
        return {"combined": {"error": "multi-bank DOM mode not allowed - use scenario text instead",
                              "scenario": None}}
    add_already_exists = no_add_needed and bool(existing_page_class)

    zero_scenario_mode = not (base_scenario or "").strip() and bool(
        module_url or menu_name or manual_html_path or screenshot_paths or no_add_needed)

    page_html = ""
    phrase_xpaths: dict[str, str] = {}
    if pre_scanned_html:
        # The caller (e.g. the DOM-mode flow that first scans once to
        # collect Add-form field names from the person, then generates)
        # already has a scan in hand - never re-scan/re-login for the
        # same run, just reuse it directly.
        page_html = pre_scanned_html
        log("  Reusing the already-captured DOM scan (no second login/scan needed).")
        if not (base_scenario or "").strip():
            base_scenario = (
                f"(No scenario was described - derive the Add flow, and the View/Edit/ChangeStatus "
                f"flows, ENTIRELY from the live DOM elements given below. Do not invent any field, "
                f"button, or navigation step that isn't actually present in what was scanned.)"
            )
    elif screenshot_paths:
        # HIGHEST priority, even easier than manual_html_path - no
        # Inspect Element / Copy outerHTML skill needed at all, just
        # screenshots (listing page + the Add form after clicking Add).
        # No Playwright browser is launched for DOM capture here either.
        log(f"  Using {len(screenshot_paths)} screenshot(s) - AI will read them directly, "
            f"no DOM/browser capture needed.")
        if not (base_scenario or "").strip():
            base_scenario = (
                f"(No scenario was described - derive the Add flow, and the View/Edit/"
                f"ChangeStatus flows, ENTIRELY from the SCREENSHOT IMAGES given (not text DOM) "
                f"- read the visible labels, fields, buttons, and table columns directly from "
                f"the image(s). Do not invent any field, button, or navigation step that isn't "
                f"actually visible in the screenshot(s).)"
            )
    elif manual_html_path:
        # Highest priority, regardless of scenario/menu/url given - this
        # is the "nothing else is working" escape hatch: no Playwright
        # browser is launched AT ALL for DOM capture, so login timing,
        # element-not-found, and menu-click failures simply can't happen
        # here. The person captured this themselves from their own
        # already-working browser session.
        page_html = load_manual_dom_capture(manual_html_path)
        log("  Manually captured DOM loaded." if page_html
            else "  Manual DOM file couldn't be read - falling back to placeholders.")
        if not (base_scenario or "").strip():
            base_scenario = (
                f"(No scenario was described - derive the Add flow, and the View/Edit/"
                f"ChangeStatus flows, ENTIRELY from the DOM elements given below, which were "
                f"manually captured from the real page by the person (not live-scanned). Do "
                f"not invent any field, button, or navigation step that isn't actually "
                f"present in what was captured.)"
            )
    elif zero_scenario_mode:
        if menu_name:
            page_html, phrase_xpaths = explore_module_via_menu(repo_root, bank, portal_type, menu_name)
            reached_via = f"the menu path '{menu_name}'"
        elif module_url:
            page_html, phrase_xpaths = explore_module_via_url(repo_root, bank, portal_type, module_url)
            reached_via = f"the URL {module_url}"
        else:
            # add_already_exists with no menu_name/module_url given -
            # best-effort: no scenario text to click through with, so
            # this just scans whatever page the login lands on. The
            # EXISTING page file's own content (given to the AI
            # separately below) still carries real field/navigation
            # info either way.
            page_html, phrase_xpaths, reached_via = _scan_for_scenarios_without_add(
                repo_root, bank, portal_type, explicit_scenarios, log=log)
        log("  Live DOM captured." if page_html
            else "  DOM exploration didn't return elements - falling back to placeholders.")
        if add_already_exists:
            base_scenario = (
                f"(This module ALREADY has Add implemented - see the EXISTING page/test file "
                f"content given below for its real field names and navigation. Do NOT "
                f"regenerate or change execute_add_{module} - only add the NEW action(s) "
                f"whose scenarios are given separately below: "
                f"{', '.join(k.upper() for k in explicit_scenarios)}. Reached this module via "
                f"{reached_via} for a fresh DOM scan of these new action(s)' actual elements.)"
            )
        elif no_add_needed:
            base_scenario = (
                f"(This module has NO Add/create flow at all in the real application - it only "
                f"configures or acts on records that already exist (e.g. a settings screen keyed "
                f"by a pre-existing value, not something you create). Do NOT generate an "
                f"execute_add_{module} method or invent an Add scenario - generate ONLY the "
                f"action(s) whose scenarios are given separately below: "
                f"{', '.join(k.upper() for k in explicit_scenarios)}. Reached this module via "
                f"{reached_via} for a DOM scan of these action(s)' actual elements.)"
            )
        elif "[DIRECT SETTINGS FORM" in page_html:
            # Our own live scan already detected this shape (see
            # _scan_listing_and_add_form's DIRECT SETTINGS-FORM PAGE
            # branch) - no Add button, no list of rows, just a single
            # persistent settings page with fields already pre-filled.
            # Do NOT let the usual "derive Add + View/Edit/ChangeStatus"
            # instruction apply here - there is no create flow and no
            # second record to view/edit/search for. Also force
            # expand_actions off for this call - the multi-action
            # harness's "output 4 separate testdata CSVs" instruction
            # would directly conflict with "generate exactly ONE action"
            # below, so this module goes through the single-action path
            # instead, consistent with the instruction it's actually
            # being given.
            expand_actions = False
            base_scenario = (
                f"(This is a DIRECT SETTINGS FORM module - the live scan below found no Add "
                f"button and no list of rows to search/edit; the page itself, reached via "
                f"{reached_via}, IS the form, already pre-filled with existing values. Generate "
                f"exactly ONE action - name it update_{module} or save_{module} (whichever fits "
                f"the reference's own naming convention) - that fills every real field found in "
                f"the scan below, clicks the real Save/Update button, and asserts the real success "
                f"message. Do NOT generate execute_add_{module}, or any View/Edit/ChangeStatus "
                f"method - they do not apply to this module shape. If the scan below also includes "
                f"a '[CONDITIONAL FIELDS...]' section, follow the CONDITIONAL FIELDS rule elsewhere "
                f"in this prompt - two separate test methods, one per toggle state, never a branch "
                f"inside one method.)"
            )
        else:
            # Scan-aware ChangeStatus vs Delete detection: the fixed
            # "derive ChangeStatus" wording below used to apply
            # regardless of what the listing page ACTUALLY shows - a
            # module with a trash/delete icon per row and no status
            # toggle at all would still be told to look for
            # ChangeStatus, biasing the AI toward inventing one instead
            # of correctly generating Delete. Check the real listing
            # HTML for which signal is actually present before deciding
            # which word to use in the instruction.
            listing_lower = page_html.lower()
            has_delete_signal = any(kw in listing_lower for kw in
                                     ("delete", "trash", "remove"))
            has_status_signal = any(kw in listing_lower for kw in
                                     ("change status", "activate", "deactivate",
                                      "enable", "disable", "toggle", "is-active", "status"))
            if has_delete_signal and not has_status_signal:
                fourth_action_instruction = (
                    "a DELETE flow (not ChangeStatus - the scan below shows a delete/remove "
                    "control per row, not a status toggle)"
                )
            elif has_status_signal and not has_delete_signal:
                fourth_action_instruction = "the ChangeStatus flow"
            else:
                # Both signals present, or neither - genuinely ambiguous
                # from the scan alone; let the AI decide from the real
                # elements rather than this instruction asserting one
                # over the other without real evidence either way.
                fourth_action_instruction = (
                    "either a ChangeStatus or a Delete flow - whichever the scan below actually "
                    "shows evidence of (a status toggle vs a delete/remove control); do not invent "
                    "one that isn't really there"
                )
            base_scenario = (
                f"(No scenario was described - derive the Add flow, the View/Edit flows, and "
                f"{fourth_action_instruction}, ENTIRELY from the live DOM elements given below: the "
                f"listing page's actual structure and the Add form's actual fields, both captured by "
                f"navigating to {reached_via}. Do not invent any field, button, or navigation step "
                f"that isn't actually present in what was scanned.)"
            )
        if confirmed_description:
            # From run_multibank_discovery - a person-confirmed summary of
            # this SPECIFIC bank's actions/search-pattern/Add-fields,
            # already reviewed and corrected if needed. Appended as
            # authoritative extra context alongside the fresh DOM re-scan
            # above (the re-scan still happens for real, precise locators -
            # this confirmed summary reduces the AI's chance of
            # mis-detecting the pattern from raw HTML alone).
            base_scenario += (
                f"\n\nCONFIRMED STRUCTURE for this bank (reviewed by the person, treat as "
                f"authoritative alongside the live DOM scan above):\n{confirmed_description}"
            )
    elif inspect_choice == "1":
        page_html, phrase_xpaths = login_via_real_framework(repo_root, bank, portal_type, base_scenario)
        log("  Real page elements captured." if page_html
            else "  Real login inspection didn't return elements - falling back to placeholders.")
    else:
        log("  Skipping live inspection - placeholder selectors will be used.")

    if field_values:
        # Real, person-supplied values for the Add form's fields (see
        # collect_field_values_interactively) - not AI-guessed testdata.
        # Applies regardless of which exploration branch above built
        # base_scenario, since the person's confirmed data is always
        # authoritative once given. These same values are what
        # View/Edit/ChangeStatus's search-and-select step should look
        # for, so every action operates on the SAME real record.
        values_text = "\n".join(f"  {k}: {v}" for k, v in field_values.items())
        base_scenario = (base_scenario or "") + (
            f"\n\nUSE THESE EXACT FIELD VALUES for Add (the person supplied these "
            f"themselves - use them character-for-character, do not substitute a "
            f"different placeholder value):\n{values_text}\nWhen View/Edit/ChangeStatus "
            f"need to find this record afterward, search/match using whichever of "
            f"these values is the record's identifying field (e.g. its Name or Code)."
        )

    if field_constraints:
        # Real length/value constraints per field (from a maxlength/
        # minlength HTML attribute, or given directly when the person
        # described a field by hand - see collect_fields_manually) -
        # this is exactly the "concrete evidence" the FIELD-LEVEL
        # VALIDATION COVERAGE rule needs to generate a real, targeted
        # negative case (a value one character past the ACTUAL max)
        # instead of guessing a plausible-looking length.
        constraints_text = "\n".join(f"  {k}: {v}" for k, v in field_constraints.items())
        base_scenario = (base_scenario or "") + (
            f"\n\nCONFIRMED FIELD CONSTRAINTS (real limits the person has given for these "
            f"fields - use these exact numbers for boundary/negative testdata, e.g. a value "
            f"exactly at the max is a positive case, one character past it is negative):\n"
            f"{constraints_text}"
        )

    if bank_notes:
        # Persistent, person-documented notes about THIS bank's known
        # architectural differences (see load_bank_notes) - applies
        # regardless of mode/branch above, exactly like field_values,
        # since these notes are relevant to every module generated for
        # this bank, not just whichever scenario happened to be typed
        # this run. This is what supplies the "concrete evidence" the
        # MULTI-BANK DISPATCH instructions require before giving a bank
        # its own dedicated method instead of assuming every bank's flow
        # is identical.
        base_scenario = (base_scenario or "") + (
            f"\n\nKNOWN ARCHITECTURAL NOTES for bank '{bank}' (the person has documented "
            f"these as persistent, always-true facts about this bank - treat as authoritative, "
            f"concrete evidence for the MULTI-BANK DISPATCH pattern, not something to verify "
            f"against the live scan):\n{bank_notes}"
        )

    # On Anthropic, ref_text (this framework's base_page.py + sample
    # conventions - identical on every call in a session) is sent as its
    # own prompt-cache block instead of inline in the prompt text, so
    # repeat calls (view/edit/changestatus, or the next module/bank) are
    # billed at a fraction of that block's cost. Other backends keep it
    # inline exactly as before - see ask_ai's cache_prefix docstring.
    use_cache = (BACKEND == "anthropic")

    if not expand_actions:
        action = extract_action_from_scenario(base_scenario)
        log(f"\n  -- Action: {action} --")
        try:
            user_prompt = build_user_prompt(
                bank, module, base_scenario, ref_text, page_html, existing_locators,
                url, real_login_code, existing_page_class, existing_test_file,
                action, phrase_xpaths, omit_ref_text=use_cache,
            )
            reply = ask_ai(SYSTEM_PROMPT, user_prompt, cache_prefix=ref_text if use_cache else None)
            if not reply:
                results[action] = {"error": "AI call failed", "scenario": base_scenario}
                return results
            written = auto_write_into_repo(reply, repo_root, bank, module, action,
                                            existing_page_class, existing_test_file, real_login_code)
            written.pop("_truncated", None)  # internal signal only, not a real written file
            if not written:
                results[action] = {"error": "no files parsed", "scenario": base_scenario}
                return results
            for kind, path in written.items():
                log(f"    {kind}: {path}")
            results[action] = {"written": written, "scenario": base_scenario}
        except Exception as exc:  # noqa: BLE001
            log(f"  ERROR: action '{action}' failed unexpectedly ({exc}).")
            results[action] = {"error": str(exc), "scenario": base_scenario}
        return results

    # --- combined single-call multi-action generation ---
    log(f"\n  -- Combined single AI call: {'add + ' if not no_add_needed else ''}"
        f"{'/'.join(explicit_scenarios) if explicit_scenarios else 'view + edit + changestatus'} --")
    try:
        user_prompt = build_user_prompt(
            bank, module, base_scenario, ref_text, page_html, existing_locators,
            url, real_login_code, existing_page_class, existing_test_file,
            "add", phrase_xpaths, omit_ref_text=use_cache,
        )
        if explicit_scenarios:
            # Contains the person's own scenario text, which is different
            # per module/run - NOT safe to cache (caching only pays off
            # for content that's byte-identical across many calls), so it
            # always rides in the plain (uncached) part of the prompt.
            instructions = build_multi_action_instructions(explicit_scenarios,
                                                             include_add=not no_add_needed,
                                                             search_by_fields=search_by_fields)
            cache_prefix = ref_text if use_cache else None
            user_prompt = user_prompt + "\n" + instructions
        elif use_cache:
            # The fully-auto-derive instructions are IDENTICAL on every
            # combined call regardless of module/bank, so they ride in
            # the SAME cached block as ref_text instead of being paid
            # for fresh each time.
            cache_prefix = ref_text + "\n" + MULTI_ACTION_INSTRUCTIONS
        else:
            cache_prefix = None
            user_prompt = user_prompt + "\n" + MULTI_ACTION_INSTRUCTIONS

        if screenshot_paths:
            # Vision calls don't support prompt caching the same way -
            # ref_text just goes back into the plain prompt text.
            if cache_prefix:
                user_prompt = cache_prefix + "\n" + user_prompt
            reply = ask_ai_vision(SYSTEM_PROMPT, user_prompt, screenshot_paths)
        else:
            reply = ask_ai(SYSTEM_PROMPT, user_prompt, cache_prefix=cache_prefix)
        if not reply:
            log("  ERROR: AI call failed for combined multi-action generation.")
            # FEATURE: split-call fallback - a complex, large-scan module
            # (many fields/accordion sections/chips - see
            # retry_with_split_calls) is exactly the shape that makes a
            # single combined call most likely to fail outright on a
            # free-tier/overloaded backend. Rather than giving up
            # immediately, retry as two smaller, focused calls before
            # reporting failure.
            reply = retry_with_split_calls(
                bank, module, base_scenario, ref_text, page_html, existing_locators, url,
                real_login_code, existing_page_class, existing_test_file, phrase_xpaths,
                explicit_scenarios, no_add_needed, search_by_fields,
            )
            if not reply:
                results["combined"] = {"error": "AI call failed", "scenario": base_scenario}
                return results
            log("  Split-call fallback succeeded - continuing with its combined reply.")

        written = auto_write_into_repo(reply, repo_root, bank, module, "add",
                                        existing_page_class, existing_test_file, real_login_code)
        if not written:
            log("  WARNING: could not parse any files from the AI reply.")
            results["combined"] = {"error": "no files parsed", "scenario": base_scenario}
            return results

        if written.pop("_truncated", False):
            # The combined reply got cut off mid-file (hit
            # ANTHROPIC_MAX_TOKENS) before finishing page.py/test.py -
            # auto_write_into_repo already dropped whatever didn't parse
            # as valid Python rather than write broken code. Retrying the
            # EXACT SAME oversized combined prompt again would very
            # likely truncate the same way a second time - the
            # split-call fallback (locators alone, THEN page+test+
            # testdata from the now-confirmed locators) is meaningfully
            # smaller per call, so it's worth trying automatically here
            # rather than making the person notice the truncation
            # warning, raise ANTHROPIC_MAX_TOKENS by hand, and re-run
            # from scratch themselves.
            log("  The reply was truncated mid-file - retrying the missing file(s) via the "
              "smaller split-call path instead of the same oversized combined prompt.")
            split_reply = retry_with_split_calls(
                bank, module, base_scenario, ref_text, page_html, existing_locators, url,
                real_login_code, existing_page_class, existing_test_file, phrase_xpaths,
                explicit_scenarios, no_add_needed, search_by_fields,
            )
            if split_reply:
                split_written = auto_write_into_repo(
                    split_reply, repo_root, bank, module, "add",
                    existing_page_class, existing_test_file, real_login_code)
                split_written.pop("_truncated", None)
                if split_written:
                    written.update(split_written)  # fills in whatever was missing (e.g. page/test)
                    log("  Split-call retry recovered the file(s) the truncated reply was missing.")
                else:
                    log("  Split-call retry also didn't produce valid files for the missing "
                        "piece(s) - consider raising ANTHROPIC_MAX_TOKENS in .env and re-running.")
            else:
                log("  Split-call retry itself failed - consider raising ANTHROPIC_MAX_TOKENS in "
                    ".env and re-running this module.")

        for kind, path in written.items():
            log(f"    {kind}: {path}")
        expected_actions = compute_multi_action_list(explicit_scenarios, include_add=not no_add_needed)
        expected_sheets = {f"testdata_{a}" for a in expected_actions}
        missing_sheets = expected_sheets - written.keys()
        if missing_sheets:
            log(f"  NOTE: AI reply didn't include testdata for: {', '.join(sorted(missing_sheets))} "
                f"- add those sheet(s) manually or re-run for just that action if needed.")
        results["combined"] = {"written": written, "scenario": base_scenario}
    except Exception as exc:  # noqa: BLE001
        log(f"  ERROR: combined multi-action generation failed unexpectedly ({exc}).")
        results["combined"] = {"error": str(exc), "scenario": base_scenario}

    return results


def parse_labeled_scenarios(text: str) -> dict[str, str]:
    """Parses a block of text where the person described multiple actions
    at once, each starting its own line with a label followed by a colon
    - 'Add:', 'View:', 'Edit:', 'Change Status:', or ANY OTHER action
    name a real module actually has (e.g. 'Assign Menu:', 'Approve:',
    'Delete:') - not limited to the 4 standard ones, since plenty of
    real modules (like a User Role screen with Add/View/Edit/Assign Menu
    but no Change Status at all) don't fit that fixed set. A label's
    text can span several lines - it runs until the next recognized
    label or the end of the block. Returns a dict keyed by the
    lowercased, space-stripped label (e.g. "assignmenu") - "add" is
    the only one the caller treats as required; every other key,
    standard or custom, is used as given (see build_multi_action_instructions
    for how "view"/"edit"/"changestatus" get auto-derive fallback while
    any other key is always used explicitly, never auto-derived, since
    there's no sensible generic template for an arbitrary custom action)."""
    pattern = re.compile(r"(?m)^[ \t]*([A-Za-z][A-Za-z ]{1,25}?)[ \t]*:[ \t]*(?=\S|$)")
    parts = pattern.split(text)
    # re.split with a capturing group returns [pre-text, label, content, label, content, ...]
    result: dict[str, str] = {}
    for i in range(1, len(parts) - 1, 2):
        label = parts[i].strip().lower().replace(" ", "")
        content = parts[i + 1].strip()
        if content:
            result[label] = content
    # A SECOND paragraph (after a blank line) that starts with its own navigation and is an approval step ("Navigate to ... Approval
    # sub-menu ... click approve") is a SEPARATE scenario of the same module - the checker step after Add. Left in place it would be
    # glued to the previous action's text and never run. It becomes the action 'approve' (or 'reject').
    for label in list(result):
        paras = [p for p in re.split(r"\n[ \t]*\n", result[label]) if p.strip()]
        if len(paras) < 2:
            continue
        keep = [paras[0]]
        for extra in paras[1:]:
            lead_nav = re.match(r"\s*(navigate|go to|open|login)\b", extra, re.I)
            kind = "reject" if re.search(r"\breject", extra, re.I) and not re.search(r"\bapprov", extra, re.I) else \
                ("approve" if re.search(r"\b(approv|authori[sz]e|checker)", extra, re.I) else None)
            if lead_nav and kind and kind != label and kind not in result:
                result[kind] = extra.strip()
            else:
                keep.append(extra)
        result[label] = "\n\n".join(keep).strip()
    return result


def read_multiline_scenario_block(require_add: bool = False, log=print, ask=input) -> dict[str, str]:
    """Interactively reads a labeled multi-action scenario block from the
    terminal - the person types 'Add:', 'View:', 'Edit:', 'ChangeStatus:'
    (whichever they want to describe themselves) each on its own line,
    with the scenario text after the colon (can continue on following
    lines until the next label), and finishes by typing END on its own
    line. ask/log are injected for easy testing without real input().

    require_add: False (default) - Add: is always optional. This covers
    TWO real cases the same way: (1) the module already has Add
    implemented (an existing page/test file was found) - the person
    describes only the NEW action(s) they want, or (2) this module has
    NO Add/create flow at all in the real application (e.g. a settings
    screen that only configures pre-existing records, never creates
    new ones) - Add was never going to be typed because it doesn't
    exist. run_full_module_pipeline tells these apart by whether an
    existing page file is found, and messages the AI accordingly - this
    function doesn't need to know which case it is. Pass True only when
    the caller specifically wants to force Add to be described (rare -
    the interactive flow that calls this always passes False)."""
    if require_add:
        log("\nType your scenario(s) below. Start each one on its own line with 'Add:', "
            "'View:', 'Edit:', or 'Change Status:' - only Add: is required, the rest are "
            "optional (left out = AI derives that one from Add). A label's text can "
            "continue on the following lines. Finish by typing END on its own line.\n")
    else:
        log("\nType your scenario(s) below. Start each one on its own line with a label + "
            "colon (e.g. 'View:', 'Edit:', 'Change Status:', or any other action name this "
            "module actually has) - 'Add:' is OPTIONAL: include it only if this module "
            "actually has a create/add flow, skip it entirely if it doesn't (e.g. a "
            "settings screen that only edits pre-existing records) or if it's already been "
            "generated before. A label's text can continue on the following lines. Finish "
            "by typing END on its own line.\n")
    while True:
        lines = []
        while True:
            line = ask("")
            if line.strip().upper() == "END":
                break
            lines.append(line)
        parsed = parse_labeled_scenarios("\n".join(lines))
        if not require_add:
            if parsed:
                return parsed
            log("\nNothing was parsed - type at least one 'Label: scenario' line, or END "
                "alone to cancel.\n")
            continue
        if parsed.get("add", "").strip():
            return parsed
        log("\nNo 'Add:' section found (or it was empty) - Add is required. Please retype, "
            "starting the Add line with 'Add:' exactly.\n")


def run_guided_scenario_collection(log=print, ask=input) -> tuple[dict[str, str], list[str] | None]:
    """A structured, question-by-question alternative to typing a raw
    MULTI: block by hand - walks through Add/View/Edit/ChangeStatus one
    at a time asking a plain y/n "does this module have this action?"
    and only then asking for its scenario text, then separately asks
    whether the module uses a "Search by" dropdown (search by ID/Name/
    Email/etc, common in real modules and different from both a plain
    search box and no search box at all) and collects the field options
    if so, then offers to collect any further custom action(s) beyond
    the standard four (e.g. "Assign Menu"). This is for real modules
    that vary a lot in shape - some have all four actions, some have
    only View/Edit, some have a totally different action name, some
    search by a single box, some by a dropdown-plus-value, some by
    nothing at all - rather than needing to remember the MULTI: block's
    label syntax, the person just answers each question as it comes.

    Returns (explicit_scenarios, search_by_fields) - explicit_scenarios
    has whichever of "add"/"view"/"edit"/"changestatus"/<custom> the
    person confirmed having, each mapped to the scenario text they gave;
    search_by_fields is the confirmed dropdown options list, or None if
    the module doesn't have that kind of search."""
    def yn(prompt: str) -> bool:
        return ask(f"{prompt} (y/n): ").strip().lower() in ("y", "yes")

    explicit_scenarios: dict[str, str] = {}
    log("\nLet's go through this module's actions one at a time.\n")
    for action, label in (("add", "Add"), ("view", "View"), ("edit", "Edit"),
                          ("changestatus", "Change Status")):
        if yn(f"Does this module have {label}?"):
            log(f"Describe the {label} scenario in plain English:")
            text = ask("> ").strip()
            if text:
                explicit_scenarios[action] = text
        else:
            log(f"({label} - skipped, this module doesn't have it.)\n")

    while yn("\nDoes this module have any OTHER action beyond those four "
             "(e.g. 'Assign Menu', 'Approve', 'Reset Password')?"):
        custom_name = ask("What is this action called? ").strip()
        if not custom_name:
            break
        log(f"Describe the {custom_name} scenario in plain English:")
        text = ask("> ").strip()
        if text:
            explicit_scenarios[custom_name.lower().replace(" ", "")] = text

    search_by_fields = None
    if yn('\nDoes this module use a "Search by" DROPDOWN to find records for View/Edit/etc '
          "(e.g. a dropdown to search by ID, Name, Email - not just a single plain search box)?"):
        raw = ask("What are the dropdown's field options, comma-separated "
                   "(e.g. ID, Name, Email): ").strip()
        search_by_fields = [f.strip() for f in raw.split(",") if f.strip()] or None

    return explicit_scenarios, search_by_fields


def collect_fields_manually(action_label: str, log=print, ask=input) -> list[dict]:
    """The fully manual alternative to DOM-scanned field detection - for
    when live scanning keeps failing (an iframe, a JS-rendered widget, a
    legacy portal quirk it can't see through) and the person would
    rather just look at the real page in front of them and describe it
    directly than keep debugging why the scan isn't finding it. Loops
    asking for ONE field at a time - name, type, and (for select/radio/
    checkbox) its real option values - and keeps asking "add another
    field?" until the person says no, so it never assumes a fixed field
    count or stops early. Returns the SAME [{"label":..., "type":...,
    "options":[...]}, ...] shape extract_add_form_fields_detailed
    produces, so collect_field_values_interactively (and everything
    downstream) works identically either way - the rest of the pipeline
    never needs to know whether the fields came from a scan or from the
    person describing them by hand.

    Also asks for an OPTIONAL length/value constraint per field (e.g.
    "max length 15", "min 5 max 15") - a scanned form can sometimes pull
    this straight from a maxlength attribute, but manual description has
    no HTML to read it from, so it's asked directly here instead. This
    is what lets the FIELD-LEVEL VALIDATION COVERAGE rule generate a
    real, targeted negative case (a value one character past the actual
    max) instead of a generic guess."""
    log(f"\nLet's go through the {action_label} page's fields one at a time - look at the "
        f"real page and describe what you see. Type DONE (instead of a field name) when "
        f"there are no more fields to add.\n")
    fields: list[dict] = []
    while True:
        name = ask(f"Field {len(fields) + 1} name (or DONE to finish): ").strip()
        if not name or name.upper() == "DONE":
            break
        ftype = ""
        while ftype not in ("text", "select", "radio", "checkbox"):
            ftype = ask(f"  '{name}' type - text / select / radio / checkbox: ").strip().lower()
            if ftype not in ("text", "select", "radio", "checkbox"):
                log("  Please type exactly one of: text, select, radio, checkbox")
        options: list[str] = []
        if ftype in ("select", "radio", "checkbox"):
            raw = ask(f"  '{name}' real option values, comma-separated (e.g. Yes, No): ").strip()
            options = [o.strip() for o in raw.split(",") if o.strip()]
        constraint = ""
        if ftype == "text":
            constraint = ask(f"  '{name}' length/value constraint if any (e.g. 'max length 15', "
                             f"'min 5 max 15') - press Enter to skip: ").strip()
        fields.append({"label": name, "type": ftype, "options": options, "constraint": constraint})
        extra = (', ' + ', '.join(filter(None, [
            'options: ' + ', '.join(options) if options else '',
            constraint,
        ]))) if (options or constraint) else ''
        log(f"  Added '{name}' ({ftype}{extra}).\n")
    return fields


def derive_module_name_from_url(url: str) -> str:
    """Guesses a reasonable module name straight from a URL, for the
    "just give me URLs" flow (see parse_url_list_file) - takes the last
    meaningful path segment (e.g. '.../admin/BinManagement.htm' ->
    'binmanagement'), strips any file extension and query string,
    lowercases it, and removes anything that isn't a letter or digit
    (module names elsewhere in this tool are always plain lowercase,
    no spaces/punctuation - see the interactive prompt's own "NO
    spaces" rule) so the result is safe to use directly as a folder/
    file name. Common filler segments ('htm', 'html', 'jsp', 'index',
    'default') are skipped if they'd otherwise be picked as the name,
    falling back to the segment before them instead."""
    from urllib.parse import urlparse
    path = urlparse(url).path
    segments = [s for s in path.split("/") if s]
    FILLER = {"htm", "html", "jsp", "aspx", "php", "index", "default", "home"}
    for seg in reversed(segments):
        name = re.sub(r"\.\w+$", "", seg)  # drop a file extension if present
        name = re.sub(r"[^a-zA-Z0-9]", "", name).lower()
        if name and name not in FILLER:
            return name
    return "module"


def parse_url_list_file(list_path: Path, bank: str, portal_type: str) -> list[dict]:
    """The simplest possible batch input: a plain text file with just ONE
    URL per line - no bank/module/scenario columns, no '|' separators,
    no scenario text to write at all. bank and portal_type are given
    ONCE (as arguments here, from --bank=/--portal-type= on the command
    line) and apply to every URL in the file. The module name for each
    line is auto-derived from its own URL (see derive_module_name_from_url)
    rather than typed - every line becomes a DOM-only entry (equivalent
    to typing "DOM" at the interactive prompt): the tool logs in,
    navigates straight to that URL, scans the real page, and derives
    the Add flow (plus auto-derived View/Edit/ChangeStatus) entirely
    from what it finds - zero scenario text, zero per-line typing at
    all beyond pasting the URLs themselves.

    Lines starting with '#' or blank lines are skipped. A line may
    optionally give its own module name by adding ' => modulename'
    after the URL, overriding the auto-derived guess for just that
    one line (useful when the URL's last path segment doesn't produce
    a good name, e.g. a query-string-only URL)."""
    entries = []
    for line_no, raw_line in enumerate(list_path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=>" in line:
            url_part, override_name = line.split("=>", 1)
            url = url_part.strip()
            module = re.sub(r"[^a-zA-Z0-9]", "", override_name.strip()).lower()
        else:
            url = line
            module = derive_module_name_from_url(url)
        if not url:
            continue
        entries.append({
            "bank": bank.lower(),
            "module": module,
            "portal_type": portal_type.lower(),
            "url": None,
            "scenario": None,
            "menu_name": None,
            "module_url": url,
        })
    return entries


def parse_batch_file(batch_path: Path) -> list[dict]:
    """Parses a plain-text batch file, one scenario-set per line:

        bank | module | portal_type | url | scenario

    - url may be left empty (two consecutive '|' with nothing between) -
      UNLESS scenario is the literal word DOM (see below), where url
      becomes required and takes on a new meaning.
    - Lines starting with '#' or blank lines are skipped.
    - portal_type must be one of admin/bank/merchant/superadmin.

    SPECIAL CASE - scenario is the literal word "DOM" (case-insensitive):
    skips writing any scenario text at all for this line - the module's
    Add flow (and auto-derived View/Edit/ChangeStatus) is fully derived
    from a live DOM scan instead, exactly like typing "DOM" at the
    interactive scenario prompt for a single module. This is for modules
    that don't need a hand-written description - the person just wants
    the tool to log in, look at the real page, and derive everything
    from what it finds. In this case the url column means whichever of
    these it looks like:
      - contains ">"  -> treated as a MENU PATH (e.g. "Administration >
        PG configuration > User administration") - the tool logs in and
        clicks/hovers through this path itself (hover for every level
        except the last, click for the last - see explore_module_via_menu).
      - otherwise      -> treated as a direct MODULE URL to navigate to.
    This lets a batch file mix both styles freely, line by line - some
    modules described in detail, others just pointed at and left to the
    live scan, whichever fits each module.

    SPECIAL CASE - MULTI-ACTION scenario (custom actions, e.g. a module
    with Add+Search+Delete and NO ChangeStatus - a real, common shape,
    not just the standard Add+View+Edit+ChangeStatus one): write the
    scenario column as multiple "ActionName: description" segments
    separated by " ;; " (a double-semicolon, since '|' is already the
    column separator and a plain ';' is common inside ordinary English
    sentences):

        Add: click Add, fill X, click Save ;; Search: enter X, click \
        Search ;; Delete: click delete icon, confirm

    Recognized action names here work exactly like the interactive
    MULTI prompt's own action names - "add" (case-insensitive) becomes
    the base Add scenario; any OTHER name (view, edit, changestatus, or
    a genuinely custom one like "search"/"delete"/"approve") goes into
    explicit_scenarios and is passed straight to run_full_module_pipeline
    exactly as the interactive MULTI flow already does. Per
    compute_multi_action_list's existing rule, including ANY custom
    (non-view/edit/changestatus) action name here automatically turns
    OFF auto-deriving the standard View/Edit/ChangeStatus trio - so a
    line with "Add: ... ;; Search: ... ;; Delete: ..." generates exactly
    those three actions and nothing else, never a surprise ChangeStatus
    method the real module doesn't have. A line with no "Add:" segment
    at all (only named actions) is also valid - same as leaving Add
    blank in the interactive MULTI prompt for a module with no create
    flow (see no_add_needed elsewhere in this file).

    This is what lets multiple scenarios/modules run in one unattended
    pass instead of typing each one into the interactive prompts."""
    entries = []
    for line_no, raw_line in enumerate(batch_path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 5:
            print(f"  WARNING: batch file line {line_no} doesn't have 5 '|'-separated fields "
                  f"(bank|module|portal_type|url|scenario) - skipping: {line}")
            continue
        bank, module, portal_type, url, scenario = parts[0], parts[1], parts[2], parts[3], "|".join(parts[4:])
        if not bank or not module:
            print(f"  WARNING: batch file line {line_no} is missing bank/module - skipping.")
            continue
        is_dom = scenario.strip().upper() == "DOM"
        if is_dom and not url:
            print(f"  WARNING: batch file line {line_no} says DOM but the url column is empty - "
                  f"need a menu path (e.g. 'Administration > PG configuration') or a module URL "
                  f"there for DOM mode to know where to look - skipping: {line}")
            continue
        if not is_dom and not scenario:
            print(f"  WARNING: batch file line {line_no} is missing bank/module/scenario - skipping.")
            continue

        add_scenario = None
        explicit_scenarios: dict[str, str] = {}
        # Trigger on either ";;" (multiple named actions) OR a single
        # segment that still starts with a recognizable "ActionName: "
        # prefix (e.g. just "Update: ..." alone, no Add at all, no ";;"
        # needed when there's only one action to name) - checked against
        # the very start of the scenario text specifically, so ordinary
        # sentences that happen to contain a colon later on are never
        # mistaken for this syntax.
        looks_like_named_action = bool(re.match(r"^\s*[A-Za-z][A-Za-z ]{0,30}:\s", scenario)) if not is_dom else False
        if not is_dom and (";;" in scenario or looks_like_named_action):
            segments = [s.strip() for s in scenario.split(";;") if s.strip()]
            parsed_any = False
            for seg in segments:
                seg_match = re.match(r"^([A-Za-z][A-Za-z ]{0,30}):\s*(.+)$", seg, re.DOTALL)
                if not seg_match:
                    continue
                action_name = seg_match.group(1).strip().lower().replace(" ", "")
                action_text = seg_match.group(2).strip()
                if action_name == "add":
                    add_scenario = action_text
                else:
                    explicit_scenarios[action_name] = action_text
                parsed_any = True
            if parsed_any:
                scenario = add_scenario  # may be None - valid for no-Add modules
            else:
                print(f"  WARNING: batch file line {line_no} looks like it uses ';;' multi-action "
                      f"syntax but no 'ActionName: text' segment could be parsed from it - treating "
                      f"the whole thing as one plain Add scenario instead: {line}")

        entries.append({
            "bank": bank.lower(),
            "module": module.lower(),
            "portal_type": portal_type.lower() or "bank",
            "url": None if is_dom else (url or None),
            "scenario": None if is_dom else scenario,
            "menu_name": (url if (is_dom and ">" in url) else None),
            "module_url": (url if (is_dom and ">" not in url) else None),
            "explicit_scenarios": explicit_scenarios or None,
        })
    return entries


def find_existing_page_class(repo_root: Path, module: str, bank: str | None = None) -> str | None:
    """Checks if a page class for this module already exists - meaning
    ANOTHER bank already has this module built. The page class is meant
    to be SHARED across every bank that has this module (one Add Brand
    Type page class, used by wio, alrajhi, or any other bank via a
    BANK_LOCATORS dispatch dict - each bank's own locators file supplies
    its own selectors). If found, its content is returned so the AI can
    ADD the new bank's entry to the existing dispatch dict, without
    touching or removing any other bank's existing entry - this is what
    prevents a second bank's generation run from silently breaking the
    first bank's already-working test."""
    candidate = repo_root / "src" / "common" / "pages" / module / f"{module}_page.py"
    if candidate.exists():
        return candidate.read_text(encoding="utf-8", errors="ignore")
    return _merged_part(repo_root, bank, module, "page")            # one-file mode


def find_existing_test_file(repo_root: Path, module: str, bank: str | None = None) -> str | None:
    """Checks if a test file for this module already exists - meaning
    another action (Add/View/Edit/ChangeStatus) or another bank already
    has a test method here. Returned so the AI can ADD a new test method
    for the current action, preserving every existing test method rather
    than overwriting the whole file."""
    candidate = repo_root / "src" / "testcase" / module / f"test_{module}.py"
    if candidate.exists():
        return candidate.read_text(encoding="utf-8", errors="ignore")
    return _merged_part(repo_root, bank, module, "test")            # one-file mode


DOC_SYSTEM_PROMPT = """You write a short Markdown section documenting ONE
action of a test automation module, for a README.md that will hold one
section per action (Add/View/Edit/ChangeStatus/etc.). Keep it brief: a
one-line summary of what the action does, which bank(s) it's verified
for, and 2-3 bullet points of what the test covers (positive case, key
negative cases). No fluff, no repeated boilerplate. Reply with ONLY the
markdown for this one action's section, starting with a "## <Action>"
heading - nothing else, no surrounding commentary."""


def generate_module_documentation(module: str, bank: str, action: str, scenario: str) -> str | None:
    """Generates a short Markdown section documenting this action, to be
    merged into the module's README.md (one section per action, banks
    listed as they're added) - so future readers get a plain-language
    summary of what's covered without opening the test file itself."""
    user_prompt = f"Module: {module}\nAction: {action}\nBank: {bank}\nScenario: {scenario}"
    return ask_ai(DOC_SYSTEM_PROMPT, user_prompt)


COVERAGE_GAP_SYSTEM_PROMPT = """You look at which actions (Add/View/Edit/
ChangeStatus/Delete/etc.) a test module currently covers, and suggest, in
ONE short sentence, the single most likely MISSING common action for
this kind of module - the one a QA team would most likely want to add
next. If coverage already looks reasonably complete for a typical CRUD-
style module, reply exactly: COVERAGE LOOKS REASONABLE"""


def analyze_coverage_gaps(module: str, existing_test_file: str | None) -> str | None:
    """After a successful run, looks at which actions this module's test
    file already covers (by scanning its execute_<action>_<module> method
    names) and asks the AI what's likely still missing - e.g. a module
    with Add/Edit/View built but no ChangeStatus or Delete. This is
    advisory only, printed for the user's awareness - never blocks
    anything or auto-generates the missing action.

    OFF by default - one more optional AI call on every passing run.
    Set AI_COVERAGE_SUGGESTIONS=true in .env to turn it on."""
    if os.environ.get("AI_COVERAGE_SUGGESTIONS", "false").lower() != "true":
        return None
    if not existing_test_file:
        return None
    covered_actions = sorted(set(re.findall(r"execute_(\w+?)_" + re.escape(module), existing_test_file)))
    if not covered_actions:
        return None
    reply = ask_ai(COVERAGE_GAP_SYSTEM_PROMPT,
                   f"Module: {module}\nActions currently covered: {', '.join(covered_actions)}")
    if not reply or "COVERAGE LOOKS REASONABLE" in reply.upper():
        return None
    return reply.strip()


def update_module_readme(repo_root: Path, module: str, bank: str, action: str, scenario: str) -> Path | None:
    """Writes/updates src/testcase/<module>/README.md - merges the new
    action's section in without touching any other action's existing
    section (same merge-not-overwrite principle as the page/test files).
    Also tracks which banks have been verified for this action, appending
    a new bank to an existing action's line rather than duplicating the
    whole section. Best-effort: any failure just skips documentation,
    never blocks the actual test generation."""
    new_section = generate_module_documentation(module, bank, action, scenario)
    if not new_section:
        return None
    new_section = new_section.strip()

    readme_path = repo_root / "src" / "testcase" / module / "README.md"
    action_heading = f"## {action.capitalize()}"

    if readme_path.exists():
        existing = readme_path.read_text(encoding="utf-8")
        # Replace just this action's section if it already exists, else append.
        pattern = re.compile(
            rf"^{re.escape(action_heading)}\b.*?(?=^## |\Z)", re.MULTILINE | re.DOTALL
        )
        if pattern.search(existing):
            updated = pattern.sub(new_section + "\n\n", existing)
        else:
            updated = existing.rstrip() + "\n\n" + new_section + "\n"
    else:
        updated = f"# {module.capitalize()} module\n\n" + new_section + "\n"

    readme_path.parent.mkdir(parents=True, exist_ok=True)
    readme_path.write_text(updated, encoding="utf-8")
    return readme_path


def detect_bank_from_url(repo_root: Path, url: str | None) -> str | None:
    """Scans every bank's real *_credentials.yaml file for a URL whose
    host:port matches the given URL - so the bank name can be determined
    automatically from the login URL you give, instead of you having to
    know and type it. Returns the matching bank folder name, or None if
    no confident match was found (ambiguous or url not given)."""
    if not url:
        return None
    from urllib.parse import urlparse
    target_netloc = urlparse(url).netloc  # e.g. "10.136.2.146:8320"
    if not target_netloc:
        return None

    banks_dir = repo_root / "src" / "banks"
    if not banks_dir.exists():
        return None

    for bank_dir in banks_dir.iterdir():
        if not bank_dir.is_dir():
            continue
        for yaml_file in bank_dir.glob("*_credentials.yaml"):
            try:
                text = yaml_file.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            if target_netloc in text:
                return bank_dir.name
    return None


def guess_portal_type(url: str | None, scenario: str) -> str | None:
    """Best-effort guess of which login page class applies (admin/bank/
    merchant/superadmin), based on keywords in the URL path and the
    scenario text. Returns None if genuinely ambiguous - the AI is then
    told explicitly to ask via a TODO comment rather than guess blindly."""
    haystack = f"{url or ''} {scenario}".lower()
    # Order matters - check more specific terms first
    if "superadmin" in haystack or "super admin" in haystack:
        return "superadmin"
    if "merchant" in haystack:
        return "merchant"
    if "admin" in haystack:
        return "admin"
    if "bank" in haystack or "banklogin" in haystack:
        return "bank"
    return None


def build_user_prompt(bank: str, module: str, scenario: str, ref_text: str, page_html: str,
                       existing_locators: str | None = None, url: str | None = None,
                       real_login_code: str | None = None, existing_page_class: str | None = None,
                       existing_test_file: str | None = None, action: str = "default",
                       phrase_xpaths: dict[str, str] | None = None,
                       omit_ref_text: bool = False) -> str:
    """omit_ref_text: when True, skips embedding ref_text in the returned
    string - used when the CALLER is instead sending ref_text as a
    separate Anthropic prompt-cache block (see run_full_module_pipeline
    and ask_ai's cache_prefix) so it isn't paid for/sent twice. Every
    other backend always gets ref_text inline as before (the caller only
    sets this True when it also passes ref_text via cache_prefix)."""
    module_title = module[:1].upper() + module[1:]
    portal_guess = guess_portal_type(url, scenario)
    prompt = [
        f"Bank: {bank}",
        f"Module name: {module}  (class prefix: {module_title})",
        f"Action: {action}  (method suffix: execute_{action}_{module})",
        f"Scenario (plain English): {scenario}",
        "",
    ]
    if phrase_xpaths:
        prompt.append(
            "PRECOMPUTED XPATH VALUES (mandatory - use these EXACT strings, do not build your "
            "own XPath for these specific navigation elements, do not add 'or' conditions or any "
            "other variation): these were built deterministically from the REAL element captured "
            "live during navigation - not guessed, not AI-generated. For each menu/button phrase "
            "below, use its given XPath value verbatim as that locator's value in the locators "
            "file:\n" + "\n".join(f'  "{phrase}" -> {xpath}' for phrase, xpath in phrase_xpaths.items())
        )
    if existing_page_class:
        prompt.append(
            "EXISTING PAGE FILE (critical - this module already exists, for this or another "
            "bank/action): the module's page class ALREADY EXISTS in the repo, shown below. It "
            "must be SHARED across every bank AND every action for this module - it follows this "
            "framework's real convention (see admin_login_page.py-style shown in the MULTI-BANK "
            "DISPATCH rule above): self._dispatch is an INSTANCE dict built in __init__ from "
            "ALIASED per-bank imports (from src.banks.<bank>.locators.<module>_locators import "
            f"{module_title}Locators as <BankTitle>{module_title}Locators), mapping bank -> "
            "(method, locators) tuples, and every public method takes bank as an explicit "
            "parameter, doing '_, loc = self._dispatch[bank.lower()]' (or 'method, loc = "
            "self._dispatch[bank.lower()]' when it needs to call the flow method) as its first "
            "line. Your job: ADD this bank's import line and self._dispatch entry inside __init__ "
            "if not already there (pointing at the SAME shared flow method other banks use, unless "
            "you have concrete evidence this bank needs a different flow), and ADD (or, if this "
            "exact action's methods already exist, REPLACE only those specific methods) the small "
            "step-methods for the CURRENT action given above - do NOT remove, rename, or change any "
            "OTHER action's methods, any OTHER bank's import/dispatch entry, or unrelated parts of "
            "__init__. Output the FULL updated file (everything else preserved, plus this "
            "action/bank's part added or updated) - not a diff, not just the new part. Only a field "
            "you were explicitly told differs across banks should be accessed defensively with "
            "getattr(loc, 'field_name', None) - every core field named in the current scenario is "
            "called directly, no guard.\n"
            + existing_page_class
        )
    else:
        prompt.append(
            "PAGE FILE (first creation for this module): this page class must be built so future "
            "runs for OTHER banks or OTHER actions (View/Edit/ChangeStatus/etc.) can reuse it. "
            "Structure it exactly as shown in the MULTI-BANK DISPATCH rule above (self._dispatch "
            "instance dict built inside __init__ from an aliased per-bank import, mapping bank -> "
            f"(method, locators), __init__ calling super().__init__(page, "
            f"module_name=\"{module_title}\"), small step-methods each taking bank as an explicit "
            "parameter and doing '_, loc = self._dispatch[bank.lower()]' first) - this bank's "
            "import/dispatch entry only, for now. This is what lets a later run simply ADD another "
            "bank's import/dispatch entry, or another action's methods, without rewriting existing "
            "code."
        )
    if existing_test_file:
        prompt.append(
            "\nEXISTING TEST FILE (this module already has test(s) for another action and/or "
            "bank) - shown below. ADD a new test method for the CURRENT action (or replace only "
            "that action's existing test method if re-running the same action), calling this "
            "action's page methods in sequence, passing bank to each one explicitly (matching "
            "user_role's real test file convention: page.navigate_to_x(bank), "
            "page.click_add_button(bank), page.fill_x_form(bank, data), "
            "page.click_save_button(bank), page.assert_x_message(bank, "
            "data[\"ExpectedMessage\"])). Do NOT remove or change any OTHER action's "
            "test method. Output the FULL updated file, not a diff:\n" + existing_test_file
        )
    prompt.append("")
    if real_login_code:
        prompt.append(
            "LOGIN PAGE TO USE: the exact, real, already-working login page class and this bank's "
            "real login locators are given below - loaded live from your actual repo, not "
            "guessed. Import and call this exactly as shown. Do NOT write your own login logic, "
            "do NOT invent a different import path, and do NOT use placeholder selectors for "
            "login - real selectors are already given:"
        )
        prompt.append(real_login_code)
    elif portal_guess:
        class_name = portal_guess.capitalize() + "LoginPage"
        prompt.append(
            f"LOGIN PAGE TO USE: based on the URL/scenario wording, this is the '{portal_guess}' "
            f"portal - use {class_name} (from src.common.pages.authentication."
            f"{portal_guess}_login_page import {class_name}) for login. Do not use a different "
            f"login page class than this, and do not invent its internal implementation - only "
            f"import and call it."
        )
    else:
        prompt.append(
            "LOGIN PAGE TO USE: could not confidently determine whether this is the admin, bank, "
            "merchant, or superadmin portal from the URL/scenario. Do NOT guess - instead, default "
            "to BankLoginPage but add a comment '# TODO: confirm this is the correct login page "
            "(admin/bank/merchant/superadmin)' directly above the login call so it's easy to fix."
        )
    prompt.append("")
    if not omit_ref_text:
        prompt.append("Reference framework conventions to match exactly:")
        prompt.append(ref_text)
    if existing_locators:
        prompt.append(
            "\nEXISTING REAL LOCATORS FILE for this exact module already exists in the repo - "
            "this is the authoritative, already-verified source of truth. Reuse these EXACT "
            "selector values and attribute names unchanged in your generated locators file. "
            "Only ADD new locator attributes if the scenario needs a field/button not already "
            "present here - never invent a different selector for something already defined below, "
            "and never replace a real selector with a placeholder:"
        )
        prompt.append(existing_locators)
    elif page_html:
        prompt.append("\nLive page interactive elements (use REAL selectors from here, do not "
                       "guess). Elements marked with a '<!-- navigated: \"X\" (hover/click) -->' "
                       "comment are the ACTUAL menu/button elements the scenario navigated "
                       "through to reach the target page - use these exact selectors for the "
                       "corresponding navigation steps in your generated locators/page code, not "
                       "just for the final target page's own fields:")
        prompt.append(page_html)
    else:
        prompt.append("\nNo live page was inspected - use clearly-marked PLACEHOLDER selectors "
                       "(e.g. '#TODO-verify-add-button') that I will replace after checking the real app.")
    _note = _negative_scope_note() + _runtime_data_note()
    if _note:
        prompt.append(_note)
    return "\n".join(prompt)


def strip_code_fence(content: str) -> str:
    """Strips a markdown code fence (```python ... ``` / ```csv ... ``` /
    plain ``` ... ```) wrapped around a block's content, if present. The
    AI is explicitly told not to add these (SYSTEM_PROMPT's OUTPUT
    FORMAT section), but models still do it often enough that a real run
    hit EVERY SINGLE ".py" AND ".csv" block failing with "invalid syntax
    (line 1)" purely because the literal ``` characters were left in as
    the file's first line - ast.parse (and any CSV header check) chokes
    on that immediately, and the block gets rejected wholesale even
    though the actual code inside was fine. This must run BEFORE any
    validation (ast.parse, CSV header check) - never after."""
    text = content.strip()
    if not text.startswith("```"):
        return content
    lines = text.splitlines()
    # First line is the fence + optional language tag (```python, ```csv,
    # ``` alone) - always dropped since it's never real file content.
    lines = lines[1:]
    # Last line is the closing fence, if present - a truncated/malformed
    # reply might be missing it, so don't require it.
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines)


def parse_blocks(ai_output: str) -> list[tuple[str, str]]:
    """Returns [(filename, content), ...] parsed from ### FILE: blocks."""
    blocks = re.split(r"^### FILE: (.+)$", ai_output, flags=re.MULTILINE)
    parsed = []
    for i in range(1, len(blocks), 2):
        name = blocks[i].strip()
        content = blocks[i + 1].strip("\n") if i + 1 < len(blocks) else ""
        parsed.append((name, strip_code_fence(content)))
    return parsed


def parse_and_write(ai_output: str, out_dir: Path) -> list[Path]:
    """Preview mode - flattens everything into out_dir, no real repo paths touched."""
    written = []
    for name, content in parse_blocks(ai_output):
        dest = out_dir / Path(name).name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content + "\n", encoding="utf-8")
        written.append(dest)
        print(f"  wrote preview: {dest}  (real target: {name})")
    return written


VISUAL_VERIFY_SYSTEM_PROMPT = """You look at a screenshot from a passing
automated test and give a one-sentence sanity check: does the page
visually look like a normal, successfully-completed state (a form, a
success message, a populated list - whatever fits) rather than an error
page, a blank page, or a broken layout? Also note if any visible text
looks like it's in an unexpected language, mixed languages, or shows
untranslated placeholder keys (e.g. "error.brand.required" instead of
real text) - a common localization bug. Reply with one short sentence,
plain language - flag anything that looks visually or linguistically
wrong even if the test's text-based assertion passed."""


def visually_verify_latest_screenshot(repo_root: Path, module: str) -> None:
    """After a test PASSES (text-based assertions all succeeded), this
    takes the most recent screenshot the framework itself already saved
    (base_page.py's attach_screenshot writes to reports/screenshots/) and
    asks a vision-capable AI to sanity-check it visually - catching the
    case where the text assertion technically passed but the page
    actually looks broken (e.g. a success message present in the DOM but
    hidden behind a layout bug, which a text assertion alone wouldn't
    catch). Best-effort and silent on any failure - vision support isn't
    available on every AI_BACKEND, and this is a bonus check, never a
    requirement for the run to be considered passing.

    OFF by default - this is one extra (image) AI call every time a run
    passes, on top of the generation/self-review/fix calls already spent
    getting there. Set AI_VISUAL_VERIFY=true in .env to turn it on."""
    if os.environ.get("AI_VISUAL_VERIFY", "false").lower() != "true":
        return
    screenshots_dir = repo_root / "reports" / "screenshots"
    if not screenshots_dir.exists():
        return
    candidates = sorted(
        screenshots_dir.rglob(f"*{module}*.png"), key=lambda p: p.stat().st_mtime, reverse=True
    )
    if not candidates:
        candidates = sorted(
            screenshots_dir.rglob("*.png"), key=lambda p: p.stat().st_mtime, reverse=True
        )
    if not candidates:
        return
    latest = candidates[0]
    reply = ask_ai_vision(VISUAL_VERIFY_SYSTEM_PROMPT,
                          f"Screenshot from a passing test for module '{module}'.", str(latest))
    if reply:
        print(f"  Visual verification ({latest.name}): {reply.strip()}")


def run_pytest(repo_root: Path, module: str) -> tuple[bool, str]:
    """Runs pytest -k <module> and returns (passed, combined_output)."""
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-k", module, "-v"],
        cwd=str(repo_root), capture_output=True, text=True,
    )
    output = (result.stdout or "") + "\n" + (result.stderr or "")
    return result.returncode == 0, output


def run_pytest_multi(repo_root: Path, modules: list[str]) -> tuple[bool, str]:
    """Runs pytest across SEVERAL modules in one process (via a single
    -k "modulea or moduleb or ..." filter) instead of one full pytest
    process per module - used by the --full-auto orchestration below to
    run the WHOLE just-generated batch's tests in one pass, so
    triage_pytest_failures gets one combined output covering everything
    (which is exactly what it needs to spot failures that share a root
    cause across several modules) instead of needing to be called once
    per module. Returns (all_passed, combined_output) the same shape as
    run_pytest."""
    if not modules:
        return True, "(no modules to run)"
    k_expr = " or ".join(modules)
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-k", k_expr, "-v"],
        cwd=str(repo_root), capture_output=True, text=True,
    )
    output = (result.stdout or "") + "\n" + (result.stderr or "")
    return result.returncode == 0, output


FIX_SYSTEM_PROMPT = """You are fixing a failing Playwright Python test file.
You will be given the pytest failure output, the full current content of
ONE file that is a likely cause (a locators file, a page-method file, or
a test file - never base_page.py, which is correct and must not be
touched or referenced as broken), the REAL list of methods that exist on
base_page.py, and - if this isn't the first attempt - a history of what
was already tried and still failed.

If the failure is an AttributeError saying the Page object "has no
attribute 'X'": X is an INVENTED method name that never existed - do not
try to "add" it or work around it. Replace the call with the correct
REAL method from the base_page.py methods list given below (pick
whichever real method's purpose/signature actually matches what the code
was trying to do - e.g. a hover action needs hover_by_role /
hover_by_getbyrole / hover_by_getbytext, not a nonexistent
hover_by_locator).

If the failure is "Hover failed for: X" or a similar action-timeout on a
specific element (not a login-stage failure): the current selector's
value is the most likely cause. If it's an id/attribute that looks
auto-generated or session-specific (e.g. containing a pattern like
"stUI17_txt", a bare numeric suffix, a hash-like string, or anything
that doesn't read as a stable, human-chosen name), that ID may change
between sessions - switch to a text-based or role-based XPath instead
(e.g. "//span[contains(text(),'Configuration')]" or
"//*[@role='menuitem' and contains(text(),'Configuration')]"), which is
far more stable across sessions than a dynamic-looking id. If the
element likely needs to be scrolled into view or the page needs more
time to render before the hover, that's a secondary possibility, but try
the selector-stability fix first since it's the more common root cause.

Common causes to check for: wrong CSS/XPath selector, wrong menu text,
element not visible yet (needs a wait), wrong Excel column name, wrong
sheet/file name in ExcelUtil.get_sheet(), incorrect import path.

If the error is specifically about a missing "login" method or attribute
on the module's own Page class (e.g. "BrandtypePage object has no
attribute 'login'"): the module's Page class NEVER has login - that is
always wrong. The fix is to import and call the framework's real login
page class instead - e.g.:
    from src.common.pages.authentication.bank_login_page import BankLoginPage
    login_page = BankLoginPage(page)
    login_page.login(BANK_NAME)
Never invent a different import path (e.g. never write
"src.common.pages.login.login_page" - that module does not exist
anywhere in this framework). If you are not certain of the exact login
import path from what you've been given, do not guess a path - reply
NO_FIX instead of fabricating one.

CRITICAL: if a fix history is provided, you MUST NOT repeat the same
change that was already tried and still failed - that has been proven
not to work. Diagnose WHY the previous attempt didn't fix it and take a
genuinely different approach this time: e.g. if the previous attempt
changed a CSS selector and it still timed out, try an XPath or role-based
locator instead, or add an explicit wait, or reconsider whether the
target element is on a different page/frame - not just a slightly
reworded version of the same selector.

Reply in EXACTLY this format - a one-line diagnosis, a separator, then
the full corrected file (this replaces a separate root-cause-analysis
call with one combined call, so diagnosis and fix are never two
round-trips):

ROOT_CAUSE: <1-2 sentence plain-language diagnosis of what actually
went wrong and why - e.g. "the selector for the Save button no longer
matches the real page" or "the test data references a column that
doesn't exist in the Excel sheet">
---FIX---
<the full corrected file content - nothing else on these lines, no
markdown fences, no "### FILE:" header>

If you cannot determine a genuinely different fix from the given output
and history, reply exactly: NO_FIX
"""


RCA_SYSTEM_PROMPT = """You are analyzing why a Playwright test failed. Given
the pytest failure output, explain the ROOT CAUSE in exactly 1-2 short
sentences - plain language, no code, no fix yet. Just the diagnosis:
what actually went wrong and why (e.g. "the selector for the Save button
no longer matches the real page - it's likely using an outdated class
name" or "the test data references a column that doesn't exist in the
Excel sheet")."""


def ai_analyze_failure(pytest_output: str) -> str | None:
    """Asks the AI to explain WHY the test failed, in plain language,
    BEFORE attempting any fix. This is printed to the user so the root
    cause analysis is visible and explicit, not hidden inside the fix
    generation - and it also becomes part of what's given to the fix
    step next, so the fix is grounded in a stated diagnosis rather than
    the model jumping straight to guessing a code change."""
    trimmed = pytest_output[-3000:]
    reply = ask_ai(RCA_SYSTEM_PROMPT, f"pytest failure output:\n{trimmed}")
    return reply.strip() if reply else None


def attempt_ai_fix(repo_root: Path, module: str, written: dict, pytest_output: str,
                    fix_history: list[dict] | None = None, bank: str = "") -> tuple[str, str] | None:
    """Picks the most likely broken file from the failure text, asks the AI
    for a corrected version - explicitly told about prior failed attempts
    so it tries something genuinely different each time - and writes it
    back if we got one. Returns (kind, description-of-what-changed) or
    None if no fix was applied. Never touches base_page.py."""
    output_lower = pytest_output.lower()

    if "attributeerror" in output_lower and "has no attribute" in output_lower:
        # An invented method call (e.g. self.hover_by_locator not existing)
        # lives in the PAGE file, even if the missing method's name happens
        # to contain the word "locator" (like "hover_by_locator") - check
        # this BEFORE the generic locator/selector keyword match below,
        # which would otherwise misdirect the fix to the locators file.
        target_kind = "page" if "page" in written else "locators"
    elif "locator" in output_lower or "selector" in output_lower or "timeout" in output_lower:
        target_kind = "locators" if "locators" in written else "page"
    elif "excel" in output_lower or "sheet" in output_lower or "keyerror" in output_lower:
        target_kind = "test"
    else:
        target_kind = "page"

    # If we already tried fixing this exact file kind before and it's
    # failing again, that approach is proven insufficient - broaden to a
    # different file so attempt 2/3 isn't just repeating attempt 1's target.
    if fix_history:
        already_tried_kinds = [h["kind"] for h in fix_history]
        if target_kind in already_tried_kinds:
            fallback_order = ["locators", "page", "test"]
            for candidate in fallback_order:
                if candidate not in already_tried_kinds and candidate in written:
                    target_kind = candidate
                    break

    target_path = written.get(target_kind)
    if not target_path or not target_path.exists():
        return None

    current_content = target_path.read_text(encoding="utf-8")
    trimmed_output = pytest_output[-4000:]

    history_text = ""
    if fix_history:
        history_lines = ["Previous attempts that did NOT fix this (do not repeat these):"]
        for i, h in enumerate(fix_history, 1):
            history_lines.append(f"Attempt {i}: changed {h['kind']} file - {h['summary']}")
            history_lines.append(f"  Result: still failed with: {h['error_snippet'][:300]}")
        history_text = "\n".join(history_lines) + "\n\n"

    base_page_methods = load_base_page_methods(repo_root)
    methods_text = f"Real base_page.py methods available: {sorted(base_page_methods)}\n\n"

    # GROUND-TRUTH DOM CONTEXT (accuracy improvement): without this, a
    # fix attempt only ever sees the pytest error text and the file's
    # own current content - it can rephrase or restructure the locator
    # it already has, but has no way to know what the REAL page actually
    # looked like at scan time to ground a genuinely better guess in.
    # Reusing the same DOM snapshot deep_triage_single_failure uses
    # gives this earlier, in-the-loop fix attempt the same real
    # ground-truth advantage, not just the separate manual deep-triage
    # command.
    dom_context = ""
    if bank:
        dom_dir = repo_root / "ai_debug_dom"
        if dom_dir.exists():
            matches = sorted(dom_dir.glob(f"{bank}_*{module}*_scanned_dom.html"))
            if matches:
                dom_context = (f"REAL SCANNED DOM from when this module was generated "
                                f"(ground truth for what fields/elements genuinely exist - "
                                f"cross-check any locator fix against this, don't just "
                                f"rephrase the existing guess):\n"
                                f"{matches[0].read_text(encoding='utf-8')[:6000]}\n\n")

    user_prompt = (
        f"{history_text}"
        f"{methods_text}"
        f"{dom_context}"
        f"Current pytest failure output:\n{trimmed_output}\n\n"
        f"Current content of {target_path.name} (this is the file to fix):\n{current_content}"
    )

    reply = ask_ai(FIX_SYSTEM_PROMPT, user_prompt)
    if not reply or reply.strip().upper() == "NO_FIX":
        return None

    # Parses the combined "ROOT_CAUSE: ...\n---FIX---\n<content>" format -
    # one AI call now covers both the diagnosis (printed to the person)
    # and the fix itself, instead of a separate root-cause-analysis call
    # before every single fix attempt.
    root_cause = None
    fix_text = reply
    if "---FIX---" in reply:
        head, fix_text = reply.split("---FIX---", 1)
        m = re.search(r"ROOT_CAUSE:\s*(.+)", head, re.DOTALL)
        if m:
            root_cause = m.group(1).strip()
    if root_cause:
        print(f"  Root cause analysis: {root_cause}")

    fixed_content = strip_code_fence(fix_text.strip())
    if fixed_content == current_content:
        return None

    if target_kind == "page":
        still_invented = find_invented_method_calls(fixed_content, base_page_methods)
        if still_invented:
            print(f"  (AI's fix for {target_path.name} still calls invented method(s) "
                  f"{still_invented} - rejected. Leaving the file as it was.)")
            return None

    # SAFETY CHECK: never write a fix that isn't even valid Python. This is
    # what stops a garbled/hallucinated AI response (e.g. stray text mixed
    # into an import line) from corrupting a file that was at least
    # syntactically parseable before. If invalid, reject this fix entirely
    # and leave the previous file content untouched.
    try:
        ast.parse(fixed_content)
    except SyntaxError as syn_err:
        print(f"  (AI's fix for {target_path.name} was not valid Python - rejected: {syn_err}. "
              f"Leaving the file as it was.)")
        return None

    # SAFETY CHECK 2: reject any "from src.X.Y import Z" whose module path
    # doesn't actually exist as a .py file in the repo - this is what
    # catches a fabricated import (like an invented login page path) that
    # is syntactically valid Python but would fail at runtime anyway.
    bad_import = find_nonexistent_src_import(fixed_content, repo_root)
    if bad_import:
        print(f"  (AI's fix for {target_path.name} imports '{bad_import}' which doesn't exist "
              f"in the repo - rejected. Leaving the file as it was.)")
        return None

    # SAFETY CHECK 3: for a test file fix, reject if it still calls .login()
    # on the module's own Page class - the recurring real bug seen in
    # practice, where "fixing" the import doesn't fix the actual misuse.
    if target_kind == "test":
        page_path = written.get("page")
        page_class_name = extract_class_name(page_path.read_text(encoding="utf-8")) if page_path and page_path.exists() else None
        if uses_own_page_for_login(fixed_content, page_class_name):
            print(f"  (AI's fix for {target_path.name} still calls .login() on the module's own "
                  f"{page_class_name} - rejected. Login belongs to BankLoginPage/AdminLoginPage/etc, "
                  f"not the module's page. Leaving the file as it was.)")
            return None

    target_path.write_text(fixed_content + "\n", encoding="utf-8")
    # Short summary of the diff for the history, without sending full file contents back next round
    summary = f"{len(current_content)} -> {len(fixed_content)} chars changed"
    return target_kind, summary


def is_transient_network_failure(pytest_output: str) -> bool:
    """Detects pytest failures that look like network/environment flakiness
    rather than an actual code bug - connection resets, DNS failures,
    generic navigation timeouts unrelated to a specific selector, SSL
    errors. When this is the cause, changing code would be pointless (and
    risks introducing a WRONG fix for a problem that wasn't really a code
    issue) - the right move is just to retry the same code again."""
    markers = [
        "net::err_", "econnreset", "econnrefused", "connection reset",
        "connection refused", "getaddrinfo", "name or service not known",
        "ssl: certificate_verify_failed", "temporary failure in name resolution",
        "err_network_changed", "err_connection_timed_out",
    ]
    lower = pytest_output.lower()
    return any(m in lower for m in markers)


def is_login_session_failure(pytest_output: str) -> bool:
    """Detects failures that happen at the LOGIN stage itself - "Dashboard
    not visible", "already logged in", etc. - as opposed to a failure
    inside the module's own action flow. This distinction matters a lot:
    if login itself never succeeded, the module's locators/page/test code
    is completely irrelevant to why the test failed, and asking the AI to
    "fix" those files wastes an AI call on the wrong file entirely (this
    was reported as a real, frustrating waste in practice). A login-stage
    failure is a session/environment problem, not a code problem - the
    right response is to wait for any stale server-side session to settle
    and retry the SAME code, never edit module files for it."""
    markers = [
        "dashboard not visible", "already logged in", "login failed",
        "user already logged in",
    ]
    lower = pytest_output.lower()
    return any(m in lower for m in markers)


USER_GUIDED_FIX_SYSTEM_PROMPT = """You are fixing a failing Playwright test
file. Automatic AI fix attempts already ran out without success. The
person running this has now told you, in their own words, what they
think the actual problem is or how to fix it - treat their input as the
most reliable signal you have, more trustworthy than your own previous
guesses. Apply their guidance to fix the given file.

Reply with ONLY the full corrected file content - nothing else, no
markdown fences, no explanation. If their guidance doesn't make sense
for this file or you cannot apply it confidently, reply exactly: NO_FIX"""


def attempt_user_guided_fix(repo_root: Path, module: str, written: dict, pytest_output: str,
                             user_guidance: str) -> tuple[str, str] | None:
    """Last-resort escalation after run_with_auto_fix() exhausts its
    attempts: takes the person's own explanation of what's wrong (or how
    to fix it) and gives the AI one more attempt, grounded in that human
    input instead of guessing blind again. Uses the same file-selection
    logic as attempt_ai_fix() and the same validation (must stay valid
    Python, must not introduce an invented base_page method)."""
    output_lower = pytest_output.lower()
    if "attributeerror" in output_lower and "has no attribute" in output_lower:
        target_kind = "page" if "page" in written else "locators"
    elif "locator" in output_lower or "selector" in output_lower or "timeout" in output_lower:
        target_kind = "locators" if "locators" in written else "page"
    elif "excel" in output_lower or "sheet" in output_lower or "keyerror" in output_lower:
        target_kind = "test"
    else:
        target_kind = "page"

    target_path = written.get(target_kind)
    if not target_path or not target_path.exists():
        return None
    current_content = target_path.read_text(encoding="utf-8")
    base_page_methods = load_base_page_methods(repo_root)

    user_prompt = (
        f"The person's own explanation of the problem/fix: {user_guidance}\n\n"
        f"Real base_page.py methods available: {sorted(base_page_methods)}\n\n"
        f"Current pytest failure output:\n{pytest_output[-4000:]}\n\n"
        f"Current content of {target_path.name} (this is the file to fix):\n{current_content}"
    )
    reply = ask_ai(USER_GUIDED_FIX_SYSTEM_PROMPT, user_prompt)
    if not reply or reply.strip().upper() == "NO_FIX":
        return None
    fixed_content = strip_code_fence(reply.strip())
    if fixed_content == current_content:
        return None
    try:
        ast.parse(fixed_content)
    except SyntaxError as exc:
        print(f"  (User-guided fix for {target_path.name} was not valid Python - rejected: {exc})")
        return None
    if target_kind == "page":
        still_invented = find_invented_method_calls(fixed_content, base_page_methods)
        if still_invented:
            print(f"  (User-guided fix still calls invented method(s) {still_invented} - rejected.)")
            return None

    target_path.write_text(fixed_content + "\n", encoding="utf-8")
    return target_kind, f"applied user guidance: {user_guidance[:80]}"


def run_with_auto_fix(repo_root: Path, module: str, written: dict, max_attempts: int = 3,
                       addon_root: Path | None = None, bank: str = "", action: str = "",
                       max_login_retries: int = 3) -> tuple[bool, str]:
    """Runs pytest; on failure, asks AI to fix the most likely file -
    explicitly informed of what earlier attempts already tried and failed,
    so each retry takes a genuinely different approach instead of repeating
    the same change - and retries, up to max_attempts total CODE-FIXING
    runs. Login-stage failures (Dashboard not visible / already logged
    in) and transient network blips get their OWN separate retry budget
    (max_login_retries) that does NOT consume a code-fixing attempt -
    since editing locators/page/test code would do nothing for a session
    problem, burning through the valuable AI-fix attempts on pure waiting
    would be wasteful. Returns (passed, last_pytest_output) - the output
    is included so a caller can offer a user-guided fix escalation using
    the actual failure text if every automatic attempt still failed. Also
    logs each run's outcome to a local history file (if addon_root given)
    for flaky-test pattern analysis."""
    fix_history: list[dict] = []
    final_passed = False
    final_attempts_used = 0
    last_output = ""
    login_retries_used = 0
    attempt = 1
    while True:
        print(f"\nRunning: pytest -k {module}  (code-fix attempt {attempt}/{max_attempts}"
              + (f", login/network retry {login_retries_used}/{max_login_retries}"
                 if login_retries_used else "") + ")")
        passed, output = run_pytest(repo_root, module)
        print(output[-2000:])  # tail is usually the useful part
        final_attempts_used = attempt
        last_output = output

        if passed:
            print(f"PASSED.")
            final_passed = True
            visually_verify_latest_screenshot(repo_root, module)
            break

        if is_transient_network_failure(output) or is_login_session_failure(output):
            if login_retries_used >= max_login_retries:
                print(f"FAILED after {max_login_retries} login/network retries too. "
                      f"This looks like a persistent session/environment problem, not something "
                      f"this tool can resolve by waiting or editing code - stopping.")
                break
            login_retries_used += 1
            reason = ("network/environment blip" if is_transient_network_failure(output)
                      else "LOGIN-stage failure (Dashboard not visible / already logged in) - "
                           "not a bug in the module's own code, editing it would fix nothing")
            wait_seconds = 20 if is_login_session_failure(output) else 3
            print(f"FAILED - {reason}. Waiting {wait_seconds}s and retrying the SAME code "
                  f"(this doesn't use up a code-fix attempt)...")
            import time
            time.sleep(wait_seconds)
            continue

        if attempt == max_attempts:
            root_cause = ai_analyze_failure(output)
            print(f"FAILED (attempt {attempt}/{max_attempts}) - stopping, not retrying.")
            if root_cause:
                print(f"Why it failed: {root_cause}")
            break

        print(f"FAILED. Asking AI to fix the likely file with a different approach and retrying...")
        fix_result = attempt_ai_fix(repo_root, module, written, output, fix_history, bank=bank)
        if not fix_result:
            print("AI could not determine a genuinely different fix from this failure. Stopping auto-fix - "
                  "review the output above and fix manually.")
            break
        fixed_kind, summary = fix_result
        print(f"AI updated: {written[fixed_kind]} ({summary})")
        fix_history.append({
            "kind": fixed_kind,
            "summary": summary,
            "error_snippet": output[-500:],
        })
        attempt += 1

    if addon_root:
        log_run_history(addon_root, module, bank, action, final_passed, final_attempts_used)
        check_flakiness(addon_root, module, bank, action)

    return final_passed, last_output


def log_run_history(addon_root: Path, module: str, bank: str, action: str,
                     passed: bool, attempts_used: int) -> None:
    """Appends this run's outcome to a local JSON history file, so repeated
    runs of the same module/bank/action can be pattern-analyzed for
    flakiness later. Best-effort - a logging failure never affects the
    actual test run's result."""
    import json
    from datetime import datetime, timezone

    history_path = addon_root / "run_history.json"
    try:
        history = json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else []
    except Exception:
        history = []
    history.append({
        "module": module, "bank": bank, "action": action, "passed": passed,
        "attempts_used": attempts_used,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })
    history = history[-200:]  # keep the file bounded - most recent 200 runs
    try:
        history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    except Exception:
        pass


FLAKY_SYSTEM_PROMPT = """You look at a short history of pass/fail results
for the same automated test (same module/bank/action) run repeatedly, and
give a one-sentence verdict: does this look like a FLAKY test (inconsistent
results suggesting timing/environment issues) or a CONSISTENT
failure/pass (a real, stable bug or a genuinely fixed test)? Reply with
one short sentence, plain language, no code."""


def check_flakiness(addon_root: Path, module: str, bank: str, action: str) -> None:
    """After logging this run, checks recent history for the SAME module/
    bank/action - if there's a MIX of pass and fail in the last several
    runs (not a clean streak either way), asks the AI for a one-line
    flakiness verdict and prints it. Silent (does nothing) if there's not
    yet enough history, or if every recent run agrees (not flaky by
    definition)."""
    import json

    history_path = addon_root / "run_history.json"
    if not history_path.exists():
        return
    try:
        history = json.loads(history_path.read_text(encoding="utf-8"))
    except Exception:
        return

    relevant = [h for h in history if h["module"] == module and h["bank"] == bank
                and h["action"] == action]
    recent = relevant[-5:]
    if len(recent) < 3:
        return  # not enough history yet to say anything meaningful

    results = [r["passed"] for r in recent]
    if len(set(results)) == 1:
        return  # all agree - not flaky, nothing to report

    summary_lines = [f"Run {i+1}: {'PASSED' if r['passed'] else 'FAILED'} "
                     f"({r['attempts_used']} attempt(s)) at {r['timestamp']}"
                     for i, r in enumerate(recent)]
    reply = ask_ai(FLAKY_SYSTEM_PROMPT, "\n".join(summary_lines))
    if reply:
        print(f"\nFlakiness check ({module}/{bank}/{action}, last {len(recent)} runs): {reply.strip()}")


DUPLICATE_SYSTEM_PROMPT = """You look at a list of test case descriptions
for the same test module and flag any that are SEMANTICALLY duplicate -
different wording but testing the same thing (not just identical text,
which would already be caught separately). Reply with ONLY a list of
duplicate pairs found, one per line, like:
TC_002 and TC_007 both test the same empty-field validation
If none are duplicates, reply exactly: NONE"""


def ai_detect_semantic_duplicates(csv_text: str) -> list[str]:
    """Beyond exact-ID duplicate detection (validate_and_dedupe_testdata_csv
    handles that deterministically), this catches a DIFFERENT problem: two
    rows with different IDs and different wording that actually test the
    same thing (e.g. "Brand Type Name left empty" and "Submit without
    entering brand name" - same test, described two ways). AI-based since
    this requires understanding intent, not just string matching. Returns
    a list of warning strings (empty if none found or AI unavailable)."""
    import csv
    import io

    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    if len(rows) < 3:
        return []  # not enough rows for duplicates to be meaningful
    header, data_rows = rows[0], rows[1:]
    try:
        tc_idx = header.index("TestcaseID")
        desc_idx = header.index("Description")
    except ValueError:
        return []

    listing = "\n".join(f"{r[tc_idx]}: {r[desc_idx]}" for r in data_rows if len(r) > desc_idx)
    reply = ask_ai(DUPLICATE_SYSTEM_PROMPT, listing)
    if not reply or reply.strip().upper() == "NONE":
        return []
    return [f"Possible duplicate test intent: {line.strip()}"
            for line in reply.strip().splitlines() if line.strip()]


SENSITIVE_PATTERNS = [
    (re.compile(r"\b(?:\d[ -]*?){13,19}\b"), "a credit-card-number-shaped value"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "a US SSN-shaped value"),
    (re.compile(r"@(gmail|yahoo|outlook|hotmail)\.com\b", re.IGNORECASE),
     "a real-looking personal email domain"),
]


def make_testdata_unique(csv_text: str, run_tag: str | None = None) -> str:
    """FEATURE: test-data uniqueness guard - re-running the SAME generated
    testdata against a real application a second time often fails with
    "already exists" (a duplicate email, username, code, or name that
    was accepted the first run and is now taken) - not a real bug in
    the generated code at all, just stale sample data. This appends a
    short, run-specific tag to values in columns whose NAME suggests
    they need to be unique (email, name, code, id, username,
    subscription, etc.) so every run gets its own fresh values
    automatically.

    Two things this deliberately does NOT touch, so it never corrupts
    a test's actual intent:
      - ScenarioID/TestcaseID/Description/ExpectedMessage - these are
        never real field data, always metadata about the test itself.
      - Any row whose Description reads like a negative/boundary case
        (mentions "blank", "invalid", "required", "past the", "max",
        "min", "missing", etc.) - a boundary test's exact value (an
        empty string, a value one character over some limit) is the
        POINT of that row; appending a tag to it would silently break
        the very thing it's testing.

    run_tag defaults to the current time (HHMMSS) so two runs in the
    same session still get different values; pass an explicit tag
    (e.g. a batch/CI run ID) to make it reproducible/traceable instead."""
    import csv as _csv
    import io as _io
    from datetime import datetime as _datetime

    run_tag = run_tag or _datetime.now().strftime("%H%M%S")
    reader = _csv.DictReader(_io.StringIO(csv_text))
    fieldnames = reader.fieldnames
    if not fieldnames:
        return csv_text

    SKIP_COLUMNS = {"ScenarioID", "TestcaseID", "Description", "ExpectedMessage"}
    UNIQUENESS_HINTS = ("email", "name", "code", "id", "username", "subscription", "trackid",
                        "track_id", "number", "bin", "ip", "phone", "account", "mobile")
    NEGATIVE_HINTS = ("blank", "invalid", "negative", "boundary", "past the", "past its",
                      "max", "min", "required", "missing", "exceed", "over the", "outside")

    rows = list(reader)

    # A column whose value is picked from a list (a dropdown / radio) must keep the portal's EXACT option text: appending a run
    # tag turned 'Visa' into 'Visa_144400' and 'Active' into 'Active_144400', options that do not exist, so the selection failed
    # and the test never ran. Hints are matched as WHOLE words ('Interchange code' is a dropdown, not an identifier).
    CHOICE_WORDS = {"type", "status", "category", "country", "currency", "interchange", "product", "scheme", "mode", "channel",
                    "role", "group", "language", "region", "state", "gender", "acquiring", "flag", "dropdown", "select", "radio",
                    "checkbox", "toggle", "option", "network"}

    def _words(col: str) -> set[str]:
        return set(re.sub(r"[^a-z0-9]+", " ", re.sub(r"([a-z])([A-Z])", r"\1 \2", col).lower()).split())

    def _needs_unique(col: str) -> bool:
        w = _words(col)
        if w & CHOICE_WORDS:
            return False
        return any(h in w for h in UNIQUENESS_HINTS) or ("track" in w and "id" in w)

    # TESTDATA CONTINUITY ENFORCEMENT (a real, concrete safety net - the
    # SYSTEM_PROMPT already tells the AI to reuse the Add row's
    # identifying-field value across Search/Edit/Delete/View rows for the
    # same record, but a prompt instruction isn't always reliably
    # followed - exactly like the mat-select rule needing its own
    # deterministic post-generation check. Without this, Add might get
    # BIN "111111" while Edit/Delete independently got "222222" - a
    # completely disconnected, unusable end-to-end flow.
    #
    # Finds the row whose ScenarioID contains "add" (case-insensitive)
    # as the source-of-truth for each UNIQUENESS_HINT column, then
    # FORCES every other non-negative row's value for that same column
    # to match it - deterministically, regardless of what the AI
    # actually generated. This runs BEFORE uniquification below, so the
    # per-column memoization cache then correctly carries the SAME
    # enforced value through to a single, consistent unique replacement
    # for every linked row.
    RANGE_COL_RE = re.compile(r"\b(low|high|from|to|min|max|start|end|range|limit|length)\b", re.I)
    add_row = next((r for r in rows if "add" in (r.get("ScenarioID") or "").lower()), None)
    if add_row:
        for col in fieldnames:
            if col in SKIP_COLUMNS or not _needs_unique(col) or RANGE_COL_RE.search(col):
                continue
            add_value = (add_row.get(col) or "").strip()
            if not add_value or add_value.startswith("{{"):
                continue                                      # a run-time TOKEN: never copy / mangle it
            for row in rows:
                if row is add_row:
                    continue
                desc = (row.get("Description") or "").lower()
                if any(h in desc for h in NEGATIVE_HINTS):
                    continue  # a negative/boundary row's own distinct value is the point of it
                if (row.get(col) or "").strip() and row.get(col) != add_value:
                    row[col] = add_value

    # PER-COLUMN VALUE MEMOIZATION: the first time a given original value
    # is seen in a given column, generate its unique replacement once and
    # remember it - every LATER row with that exact same original value
    # in that same column reuses the SAME replacement. This is what keeps
    # an Add row's BIN/IP/ID and a linked Search/Edit/Delete row's copy
    # of that same value staying IDENTICAL to each other after
    # uniquification, without needing to know in advance which rows are
    # "linked" - two rows sharing a value before this runs is exactly
    # what "linked" means, and they still share a value (a different,
    # now-unique one) after it runs.
    replacement_cache: dict[tuple[str, str], str] = {}

    import random as _random

    for row in rows:
        desc = (row.get("Description") or "").lower()
        if any(h in desc for h in NEGATIVE_HINTS):
            continue  # boundary/negative row - leave its exact value alone
        for col in fieldnames:
            if col in SKIP_COLUMNS:
                continue
            if not _needs_unique(col) or RANGE_COL_RE.search(col):
                continue                                      # not an identifier (a dropdown, or 'BIN low range' 100 / 'BIN high range' 999)
            val = row.get(col, "")
            if not val or not val.strip() or val.strip().startswith("{{"):
                continue                                      # empty, or a run-time TOKEN ({{RANDOM:6}} / {{FROM_ADD}})

            cache_key = (col, val)
            if cache_key in replacement_cache:
                row[col] = replacement_cache[cache_key]
                continue

            if "@" in val:  # looks like an email address
                local, _, domain = val.partition("@")
                new_val = f"{local}_{run_tag}@{domain}"
            elif val.strip().isdigit():
                # PURE-NUMERIC FIELD (a BIN, an account/ID number, a
                # phone number): appending "_HHMMSS" as a text suffix
                # would turn a valid 6-digit BIN like "654321" into
                # "654321_143055" - no longer digits-only, no longer the
                # right length, and likely rejected outright by the
                # real application's own format validation before
                # uniqueness is even checked. Generate a fresh random
                # number of the SAME digit-length instead, so the value
                # stays genuinely unique AND stays in a format the real
                # field would actually accept.
                digit_length = len(val.strip())
                new_val = str(_random.randint(0, 10**digit_length - 1)).zfill(digit_length)
            else:
                new_val = f"{val}_{run_tag}"

            replacement_cache[cache_key] = new_val
            row[col] = new_val

    out = _io.StringIO()
    writer = _csv.DictWriter(out, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue()


def check_testdata_for_sensitive_values(csv_text: str) -> list[str]:
    """Deterministic (not AI) scan of the generated testdata's field
    values for patterns that look like REAL sensitive data accidentally
    used as a sample value (a real-shaped card number, SSN, or personal
    email domain) rather than an obviously-fake placeholder. This is a
    compliance safety net - test data should use obviously-fake values
    (test@example.com, 4111111111111111-style test card numbers), never
    anything that could be mistaken for real PII. Returns warnings;
    never modifies the data, since only a human can confirm intent."""
    warnings = []
    for pattern, description in SENSITIVE_PATTERNS:
        matches = pattern.findall(csv_text)
        if matches:
            warnings.append(f"Testdata contains {description} ({len(matches)} occurrence(s)) - "
                            f"verify this is an obviously-fake test value, not real data.")
    return warnings


def validate_and_dedupe_testdata_csv(csv_text: str) -> tuple[str, list[str]]:
    """Validates the AI-generated testdata CSV before it ever becomes a
    real Excel file: every row must have a non-empty ScenarioID and
    TestcaseID (the framework's own ExcelUtil.check_tcid_uniqueness()
    check at pytest_sessionstart will hard-fail the whole run on a
    duplicate/blank TCID across ANY sheet, so this is caught here first
    instead of surfacing as a confusing framework-level crash later).
    Rows with missing IDs are dropped; duplicate (ScenarioID, TestcaseID)
    pairs get a numeric suffix appended to stay unique. Returns
    (cleaned_csv_text, list of warning messages describing what was
    fixed/dropped, for visibility - nothing is silently discarded)."""
    import csv
    import io

    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    if not rows:
        return csv_text, []
    header, data_rows = rows[0], rows[1:]

    try:
        scenario_idx = header.index("ScenarioID")
        testcase_idx = header.index("TestcaseID")
    except ValueError:
        return csv_text, ["WARNING: CSV header missing ScenarioID/TestcaseID column - "
                          "skipping ID validation."]
    priority_idx = header.index("Priority") if "Priority" in header else None

    warnings = []
    seen_pairs = {}
    cleaned_rows = []
    for row in data_rows:
        if len(row) <= max(scenario_idx, testcase_idx):
            warnings.append(f"Dropped malformed row (too few columns): {row}")
            continue
        if priority_idx is not None and len(row) > priority_idx:
            if row[priority_idx].strip() not in ("High", "Medium", "Low"):
                warnings.append(f"Row had invalid Priority '{row[priority_idx]}' - defaulted to Medium.")
                row[priority_idx] = "Medium"
        scenario_id, testcase_id = row[scenario_idx].strip(), row[testcase_idx].strip()
        if not scenario_id or not testcase_id:
            warnings.append(f"Dropped row with empty ScenarioID/TestcaseID: {row}")
            continue
        key = (scenario_id, testcase_id)
        if key in seen_pairs:
            seen_pairs[key] += 1
            new_testcase_id = f"{testcase_id}_{seen_pairs[key]}"
            warnings.append(f"Duplicate TestcaseID '{testcase_id}' under '{scenario_id}' - "
                            f"renamed to '{new_testcase_id}' to stay unique.")
            row[testcase_idx] = new_testcase_id
        else:
            seen_pairs[key] = 0
        cleaned_rows.append(row)

    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(header)
    writer.writerows(cleaned_rows)
    return out.getvalue(), warnings


def csv_text_to_xlsx(csv_text: str, xlsx_path: Path, sheet_name: str) -> None:
    """Writes the CSV data into ONE SHEET of the xlsx file, named after the
    current action (e.g. "Add", "View", "Edit", "ChangeStatus") - if the
    workbook already exists (another action already added its own sheet
    here), that sheet is added/replaced WITHOUT touching any other
    action's existing sheet. This is what lets Add/View/Edit/ChangeStatus
    all live in the same <Module>.xlsx file, each on its own sheet,
    instead of one action's testdata overwriting another's."""
    import csv
    import io
    try:
        import openpyxl
    except ImportError:
        print("openpyxl not installed - run: pip install openpyxl --break-system-packages")
        raise
    reader = csv.reader(io.StringIO(csv_text))
    rows = list(reader)
    safe_sheet_name = (sheet_name[:31] or "Sheet1")  # Excel sheet-name length limit, never empty

    xlsx_path.parent.mkdir(parents=True, exist_ok=True)
    if xlsx_path.exists():
        wb = openpyxl.load_workbook(xlsx_path)
        if safe_sheet_name in wb.sheetnames:
            del wb[safe_sheet_name]  # replace just this action's sheet with fresh data
        ws = wb.create_sheet(title=safe_sheet_name)
        # If the workbook still has openpyxl's original blank default
        # sheet (only happens on a brand new file we just loaded oddly),
        # drop it so we don't leave an empty "Sheet" tab behind.
        if "Sheet" in wb.sheetnames and wb["Sheet"].max_row == 1 and wb["Sheet"].max_column == 1 \
                and wb["Sheet"]["A1"].value is None:
            del wb["Sheet"]
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = safe_sheet_name

    for row in rows:
        ws.append(row)
    wb.save(xlsx_path)


def find_arity_mismatches(content: str, reference_code: str | None) -> list[str]:
    """Checks method calls in generated content against the REAL required
    parameters of methods defined in reference_code (the real login page
    class, e.g. admin_login_page.py's assert_dashboard_visible(self,
    bank: str)) - catches a call that's missing a required argument
    (e.g. login_page.assert_dashboard_visible() with no bank passed),
    which is a TypeError at runtime but not something the syntax/import
    checks catch since it's syntactically valid Python."""
    if not reference_code:
        return []
    sig_pattern = re.compile(r"def (\w+)\(self,\s*([^)]*)\)")
    required_counts: dict[str, int] = {}
    for m in sig_pattern.finditer(reference_code):
        name = m.group(1)
        params = [p.strip() for p in m.group(2).split(",") if p.strip()]
        required = [p for p in params if "=" not in p]
        required_counts[name] = len(required)

    issues = []
    for name, req_count in required_counts.items():
        if req_count == 0:
            continue
        for call_match in re.finditer(rf"\.{re.escape(name)}\(([^)]*)\)", content):
            args_str = call_match.group(1).strip()
            arg_count = 0 if not args_str else len([a for a in args_str.split(",") if a.strip()])
            if arg_count < req_count:
                issues.append(f"{name}() called with {arg_count} arg(s) but needs {req_count} "
                              f"- this will raise TypeError at runtime")
    return issues


def uses_own_page_for_login(content: str, page_class_name: str | None) -> bool:
    """Detects the exact bug pattern seen in practice: the test file
    instantiates the MODULE'S OWN Page class (e.g. BrandtypePage) and then
    calls .login(...) on that same variable. The module's own page class
    never has a login() method - login always belongs to the separate
    BankLoginPage/AdminLoginPage/etc. This is checked independently of the
    import-path checks because the bug can exist even when the import
    line itself looks syntactically fine."""
    if not page_class_name:
        return False
    var_match = re.search(rf"(\w+)\s*=\s*{re.escape(page_class_name)}\(page\)", content)
    if not var_match:
        return False
    var = var_match.group(1)
    return bool(re.search(rf"\b{re.escape(var)}\.login\(", content))


def contains_unrequested_logout(page_method_content: str) -> bool:
    """Detects another real bug pattern seen in practice: the generated
    execute_<action>_<module>() method adds its own logout step (clicking
    a Logout button/link) that was never part of the scenario. Logout is
    handled entirely separately by this tool's login-session management -
    it must never be baked into a generated action method, since that
    would log the account out mid-test-suite for every OTHER test that
    still needs to be logged in. Matches both direct attribute access
    (loc.logout_button) and the getattr(loc, "logout_button", ...) form."""
    return bool(
        re.search(r'getattr\(\s*loc\s*,\s*["\']\w*logout\w*["\']', page_method_content, re.IGNORECASE)
        or re.search(r'\bloc\.\w*logout\w*\b', page_method_content, re.IGNORECASE)
    )


def find_nonexistent_src_import(content: str, repo_root: Path) -> str | None:
    """Scans for 'from src.X.Y.Z import ...' lines and checks whether that
    module path actually exists as a .py file (or package __init__.py) in
    the repo. Returns the first offending import string if one doesn't
    exist, or None if every src.* import resolves to a real file. This
    catches fabricated imports (e.g. an invented login page path) that are
    syntactically valid Python but reference something that was never
    real."""
    for m in re.finditer(r"^from (src\.[\w.]+) import", content, flags=re.MULTILINE):
        dotted = m.group(1)
        rel_path = Path(*dotted.split("."))
        py_file = repo_root / (str(rel_path) + ".py")
        pkg_init = repo_root / rel_path / "__init__.py"
        if not py_file.exists() and not pkg_init.exists():
            return dotted
    return None


def extract_class_name(page_content: str) -> str | None:
    """Pulls the actual class name defined in a generated page file, so the
    test file's import can be forced to match it exactly - even if the AI
    was inconsistent between the two files it generated."""
    m = re.search(r"^class\s+(\w+)", page_content, flags=re.MULTILINE)
    return m.group(1) if m else None


def fix_imports(content: str, bank: str, module: str, page_class_name: str | None = None,
                 locators_class_name: str | None = None) -> str:
    """Forces every import line that references the generated locators/page
    module to use the ACTUAL folder/file names this script writes to -
    regardless of what module name the AI happened to type in its own
    generated code. This is what guarantees "no ModuleNotFoundError" even
    if the AI is inconsistent about naming inside its own output.

    Login page imports (bank_login_page.py, admin_login_page.py, etc. under
    src/common/pages/authentication/) are a DIFFERENT, already-existing
    file - never the module's own page - so they are deliberately excluded
    from this rewrite. Rewriting them here previously caused a real bug:
    a correct "from src.common.pages.authentication.bank_login_page import
    BankLoginPage" was being silently mangled into pointing at the new
    module's own page file instead."""
    LOGIN_FILE_NAMES = {"bank_login_page", "admin_login_page",
                         "merchant_login_page", "superadmin_login_page"}

    def _page_repl(m):
        folder, filename, imported_name = m.group(2), m.group(3), m.group(4)
        if filename in LOGIN_FILE_NAMES or folder == "authentication" or "Login" in imported_name:
            return m.group(0)  # leave login imports untouched
        cls = page_class_name or imported_name
        return f"from src.common.pages.{module}.{module}_page import {cls}"

    def _locators_repl(m):
        # With module-level BANK_LOCATORS, a page file can have MULTIPLE
        # locators import lines - one per bank. Blindly forcing every line
        # to "src.banks.{current_run_bank}..." would corrupt every OTHER
        # bank's import line. So only the MODULE name segment (a common
        # AI typo, e.g. "brand" instead of "brandtype") is corrected here;
        # each line's own bank name is preserved exactly as found - it's
        # legitimately different per line in a multi-bank file.
        existing_bank = m.group(1)
        imported_part = m.group(2)
        return f"from src.banks.{existing_bank}.locators.{module}_locators import {imported_part}"

    content = re.sub(
        r"from (src\.common\.pages\.([\w]+)\.([\w]+_page)) import (\w+)",
        _page_repl,
        content,
    )
    content = re.sub(
        r"from src\.banks\.([\w]+)\.locators\.[\w]+_locators import ([\w]+(?:\s+as\s+[\w]+)?)",
        _locators_repl,
        content,
    )
    # If a page class name is known and the test file instantiates the page
    # under a different class name entirely (not just import path), fix
    # the constructor call too: SomeOtherName(page) -> ActualClass(page).
    # Exclude anything with "Login" in its name - that's always the
    # separate, already-existing login page class, never this module's own
    # page, and must never be rewritten here.
    if page_class_name:
        def _ctor_repl(m):
            if "Login" in m.group(1):
                return m.group(0)
            return f"{page_class_name}(page)"
        content = re.sub(
            r"\b(\w*Page)\(page\)",
            _ctor_repl,
            content,
        )
    return content


def check_for_regressions(existing_content: str | None, new_content: str) -> list[str]:
    """Cross-module/cross-bank/cross-action safety net: compares the page
    class's content BEFORE this AI edit against AFTER, and flags anything
    that silently disappeared - a bank's BANK_LOCATORS entry, or any
    method (navigate_to_x, click_add_button, fill_x_form, etc. - every
    instance method, not just a fixed naming pattern, since this
    framework's real convention uses varied small step-method names, not
    one execute_<action>_<module> method). This is what catches the AI
    accidentally dropping another bank's or action's support while
    "adding" the current one, BEFORE that damage ever reaches pytest for
    those other banks/actions. Returns a list of human-readable warnings
    (empty list means no regression detected)."""
    if not existing_content:
        return []

    # Matches both dispatch shapes: "bank": SomeLocators (module-level
    # BANK_LOCATORS style) and "bank": (self._method, SomeLocators)
    # (self._dispatch tuple style, this framework's real convention).
    bank_entry_re = r'"(\w+)":\s*(?:\([^)]*\w+Locators[^)]*\)|\w+Locators)'
    old_banks = set(re.findall(bank_entry_re, existing_content))
    new_banks = set(re.findall(bank_entry_re, new_content))
    missing_banks = old_banks - new_banks

    old_methods = set(re.findall(r'def (\w+)\(self', existing_content)) - {"__init__"}
    new_methods = set(re.findall(r'def (\w+)\(self', new_content)) - {"__init__"}
    missing_methods = old_methods - new_methods

    warnings = []
    if missing_banks:
        warnings.append(f"REGRESSION: bank(s) {sorted(missing_banks)} were in BANK_LOCATORS "
                        f"before this change but are MISSING now - their tests will break.")
    if missing_methods:
        warnings.append(f"REGRESSION: method(s) {sorted(missing_methods)} existed before this "
                        f"change but are MISSING now - other action(s)' tests will break.")
    return warnings


def load_base_page_methods(repo_root: Path) -> set[str]:
    """Reads the REAL base_page.py from the repo and extracts every real
    method name it defines - the authoritative list of what self.<x>(...)
    is actually allowed to call in generated page code. This is what
    catches an invented method name (e.g. AI writing self.hover_by_locator
    when the real method is self.hover_by_getbytext) deterministically,
    not by hoping the AI notices its own mistake."""
    base_page_path = repo_root / "src" / "common" / "base" / "base_page.py"
    if not base_page_path.exists():
        return set()
    content = base_page_path.read_text(encoding="utf-8", errors="ignore")
    return set(re.findall(r"def (\w+)\(", content))


def find_invented_method_calls(content: str, base_page_methods: set[str]) -> list[str]:
    """Scans generated page.py content for self.<method>(...) calls and
    flags any that are neither a real base_page.py method NOR a method
    defined within this same file (the file's own execute_<action>_
    <module>() methods, dunders, etc.) - this is the deterministic check
    that catches an invented method name like self.hover_by_locator
    (doesn't exist) when the real framework only has self.hover_by_role /
    hover_by_getbyrole / hover_by_getbytext."""
    own_methods = set(re.findall(r"def (\w+)\(", content))
    called_methods = set(re.findall(r"self\.(\w+)\(", content))
    known = base_page_methods | own_methods
    return sorted(called_methods - known)


SELF_REVIEW_SYSTEM_PROMPT = """You review generated Playwright Python test
automation code for bugs and convention violations - a second pass BEFORE
this code is written into the real repo, catching issues that are
syntactically valid but still wrong (using the wrong bank's locator class
name, an assertion that can never fail, a field never actually used, a
selector that looks like a placeholder guess dressed up as real).

You will be given ONE OR MORE files, each preceded by its own
"### FILE: <name>" marker (the same format they were originally
generated in) - review every one of them in this SAME reply, since
they all belong to the same module and often share the exact issue
(e.g. the same invented method called from both the page file and the
test file).

You will also be given, per file, the EXACT list of real methods that
exist on base_page.py (the ONLY self.<x>(...) calls that are ever valid
in generated code) and, separately, any self.<x>(...) calls that file
already makes that are NOT in that list - these are confirmed-invented
method names and MUST be fixed by replacing them with the closest real
equivalent from the list (e.g. self.hover_by_locator doesn't exist -
use self.hover_by_getbytext or self.hover_by_role instead, matching
whichever real method's signature fits how it's being called). Never
invent a new self.<x> call outside the given list, no matter how
plausible the name sounds.

Reply with ONLY ONE of:
- The exact word OK (nothing else) if EVERY file looks correct
- ONLY the file(s) that need a fix, each as its own
  "### FILE: <exact same name as given>" block containing the FULL
  corrected file content (not a diff, not an explanation) - omit any
  file that was already fine, don't repeat it back unchanged

Do not nitpick style. Only flag and fix things that would actually cause
a wrong result or a runtime error."""


# ======================================================================
# DETERMINISTIC REPAIRS for the two commonest reasons a generated file is rejected / broken
#   1. a fabricated import path for a class/function that DOES exist elsewhere in the repo
#      (e.g. ExcelUtil imported from 'src.common.utilities.excel_util' - real file is named differently)
#   2. a made-up page helper (e.g. self.wait_for_element) that is not in base_page.py
# ======================================================================
def _build_repo_symbol_index(repo_root: Path) -> dict[str, list[str]]:
    """{top-level class/function name: [dotted module paths that really define it]}."""
    index: dict[str, list[str]] = {}
    src = repo_root / "src"
    if not src.exists():
        return index
    for py in sorted(src.rglob("*.py")):
        parts = py.relative_to(repo_root).with_suffix("").parts
        if any(p in ("__pycache__", "venv", ".venv", "site-packages") for p in parts):
            continue
        try:
            tree = ast.parse(py.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            continue
        dotted = ".".join(parts[:-1] if parts[-1] == "__init__" else parts)
        for node in tree.body:
            if isinstance(node, (ast.ClassDef, ast.FunctionDef)):
                index.setdefault(node.name, []).append(dotted)
    return index


def _module_exists(dotted: str, repo_root: Path) -> bool:
    rel = Path(*dotted.split("."))
    return (repo_root / (str(rel) + ".py")).exists() or (repo_root / rel / "__init__.py").exists()


def repair_nonexistent_imports(content: str, repo_root: Path) -> tuple[str, list[str]]:
    """Rewrites 'from src.X import Name' lines whose module does not exist, when every imported
    name is really defined in exactly-one-best module of this repo. Returns (content, notes)."""
    notes: list[str] = []
    index = None
    out_lines = []
    for line in content.split("\n"):
        m = re.match(r"^(\s*)from (src\.[\w.]+) import ([^()#]+?)\s*$", line)
        if not m or _module_exists(m.group(2), repo_root):
            out_lines.append(line)
            continue
        if index is None:
            index = _build_repo_symbol_index(repo_root)
        indent, bad_mod, names_txt = m.groups()
        wanted = [n.strip() for n in names_txt.split(",") if n.strip()]
        by_module: dict[str, list[str]] = {}
        ok = True
        for item in wanted:
            base, _, alias = item.partition(" as ")
            base = base.strip()
            mods = index.get(base, [])
            if not mods:
                ok = False
                break
            # prefer the candidate sharing the longest dotted prefix with the fabricated path
            best = max(mods, key=lambda d: (len(os.path.commonprefix([d.split("."), bad_mod.split(".")])), -len(d)))
            by_module.setdefault(best, []).append(item)
        if not ok:
            out_lines.append(line)
            continue
        for mod, items in by_module.items():
            out_lines.append(f"{indent}from {mod} import {', '.join(items)}")
        notes.append(f"'{bad_mod}' does not exist -> the real module is "
                     f"{' / '.join(by_module)} (for {', '.join(w.split(' as ')[0] for w in wanted)})")
    return "\n".join(out_lines), notes


def load_base_page_signatures(repo_root: Path) -> str:
    """'def name(self, args)  # first docstring line' for every method of the real base_page.py."""
    p = repo_root / "src" / "common" / "base" / "base_page.py"
    if not p.exists():
        return ""
    try:
        tree = ast.parse(p.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return ""
    lines = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("__"):
            args = ast.unparse(node.args)
            doc = (ast.get_docstring(node) or "").strip().split("\n")[0][:90]
            lines.append(f"def {node.name}({args})" + (f"  # {doc}" if doc else ""))
    return "\n".join(sorted(lines))


INVENTED_FIX_SYSTEM_PROMPT = """You fix ONE Python page-object file that calls helper methods which do
NOT exist on its base class. You get the file, the list of invented method names, and the REAL base-class
method signatures. Replace EVERY call to an invented method with either (a) the closest REAL base method,
called with that method's real argument list, or (b) when no real method fits, a direct Playwright call
(self.page.wait_for_selector(...), self.page.locator(...).click(), ...). Change nothing else. Reply with
ONLY the complete corrected file, no explanation, no markdown fences."""


def repair_invented_methods(name: str, content: str, invented: list[str], base_methods: set[str],
                            signatures: str, log=print) -> str:
    """Tries to remove invented self.<method>() calls: up to 2 targeted AI attempts (given the REAL
    signatures), then a deterministic shim for unambiguous 'wait*' helpers. Returns the best content."""
    current, remaining = content, list(invented)
    for attempt in range(2):
        if not remaining:
            return current
        prompt = (f"FILE {name}:\n{current}\n\nINVENTED METHODS TO REMOVE: {remaining}\n\n"
                  f"REAL BASE-CLASS METHODS (use these exactly):\n{signatures or sorted(base_methods)}")
        try:
            reply = ask_ai(INVENTED_FIX_SYSTEM_PROMPT, prompt)
        except Exception:
            reply = ""
        cand = strip_code_fence((reply or "").strip())
        try:
            ast.parse(cand)
        except SyntaxError:
            continue
        # A reply like "NOFIX" or a half file is VALID Python too - never accept a candidate that
        # lost any class or method the original file defined.
        lost = (set(re.findall(r"^\s*(?:def|class)\s+(\w+)", current, re.M))
                - set(re.findall(r"^\s*(?:def|class)\s+(\w+)", cand, re.M)))
        if lost:
            continue
        still = find_invented_method_calls(cand, base_methods)
        if len(still) < len(remaining) or not still:
            current, remaining = cand, still
    if not remaining:
        log(f"  Repaired invented method(s) {invented} in '{name}' with a targeted fix.")
        return current
    # Deterministic last resort: a 'wait*' helper has one unambiguous meaning - wait for the element.
    shims, unresolved = [], []
    for m in remaining:
        if m.lower().startswith("wait") and ("element" in m.lower() or "visible" in m.lower() or "selector" in m.lower()
                                             or "locator" in m.lower()):
            shims.append(
                f"    def {m}(self, locator, timeout: int = 10000, *args, **kwargs):\n"
                f"        \"\"\"Auto-added shim (the generated code called {m}, which BasePage lacks): waits until visible.\"\"\"\n"
                f"        self.page.wait_for_selector(locator, state=\"visible\", timeout=timeout)\n")
        else:
            unresolved.append(m)
    if shims:
        mcls = re.search(r"^class\s+\w+[^\n]*:\s*$", current, re.M)
        if mcls:
            current = current[:mcls.end()] + "\n" + "\n".join(shims) + current[mcls.end():]
            log(f"  Added a safe wait-shim for {[m for m in remaining if m not in unresolved]} in '{name}' "
                f"(uses page.wait_for_selector - base_page.py has no such helper).")
    if unresolved:
        log(f"  Could not repair {unresolved} in '{name}' automatically - FIXME banner added.")
    return current if not unresolved else current


def ai_self_review_and_fix(blocks: list[tuple[str, str]], base_page_methods: set[str],
                           base_signatures: str = "") -> list[tuple[str, str]]:
    """Second pass over the just-generated code, BEFORE any of it is
    written into the real repo. Runs a DETERMINISTIC check first
    (find_invented_method_calls - catches a made-up method name for
    certain, no AI guesswork needed) for every .py file, then sends
    ALL of them to the AI in a SINGLE combined call (not one call per
    file - a module with locators+page+test used to cost 3 separate
    ask_ai calls here alone; now it's 1, regardless of how many .py
    files the module has). The AI returns only the file(s) it actually
    needed to fix, which are validated the same way as any other AI
    output (must still be valid Python, and must not introduce a NEW
    invented method) before being accepted - otherwise the original,
    already-validated content is kept unchanged. Non-.py blocks (the
    CSVs) pass through untouched and never enter this call at all."""
    py_blocks = [(name, content) for name, content in blocks if name.lower().endswith(".py")]
    if not py_blocks:
        return blocks

    invented_by_file: dict[str, list[str]] = {}
    prompt_parts = []
    for name, content in py_blocks:
        invented = find_invented_method_calls(content, base_page_methods)
        invented_by_file[name] = invented
        invented_note = ""
        if invented:
            invented_note = (
                f"\n\nCONFIRMED INVENTED METHOD(S) in this file - these do not exist and MUST be "
                f"replaced: {invented}\nReal base_page.py methods you can use instead: "
                f"{sorted(base_page_methods)}"
            )
        prompt_parts.append(f"### FILE: {name}\n\n{content}{invented_note}")
    combined_prompt = "\n\n".join(prompt_parts)

    reply = ask_ai(SELF_REVIEW_SYSTEM_PROMPT, combined_prompt)
    if not reply or reply.strip().upper() == "OK":
        repaired_blocks = []
        for name, content in blocks:
            if name.lower().endswith(".py") and invented_by_file.get(name):
                print(f"  Self-review: '{name}' has invented method(s) {invented_by_file[name]} - "
                      f"trying a targeted repair.")
                content = repair_invented_methods(name, content, invented_by_file[name],
                                                  base_page_methods, base_signatures)
            elif name.lower().endswith(".py"):
                print(f"  Self-review: '{name}' - no issues found.")
            repaired_blocks.append((name, content))
        return repaired_blocks

    def _flag_invented_methods(content: str, invented: list[str]) -> str:
        """Inserts an impossible-to-miss comment block at the very top of
        a file whose invented method call(s) could not be fixed by
        self-review - a print line in a long terminal scrollback is easy
        to miss entirely, but a FIXME comment sitting at the top of the
        actual file the person opens is not. This does not fix the code
        (the exact right base_page method to call instead isn't reliably
        knowable from here), it makes the problem impossible to overlook
        before this file gets run."""
        marker = (
            f"# FIXME (self-review): this file calls invented method(s) that do NOT exist on "
            f"BasePage - {', '.join(invented)}. This WILL raise AttributeError at runtime. "
            f"Check base_page.py for the real method name(s) to use instead and fix the call(s) "
            f"below before running.\n"
        )
        if content.startswith("#"):
            return marker + content
        return marker + "\n" + content

    fixed = dict(parse_blocks(reply))  # {name: candidate_content} - only files the AI chose to return
    reviewed = []
    for name, content in blocks:
        if name not in fixed:
            if name.lower().endswith(".py") and invented_by_file.get(name):
                print(f"  Self-review: '{name}' still has invented method(s) "
                      f"{invented_by_file[name]} after review - trying a targeted repair.")
                content = repair_invented_methods(name, content, invented_by_file[name],
                                                  base_page_methods, base_signatures)
                left = find_invented_method_calls(content, base_page_methods)
                if left:
                    content = _flag_invented_methods(content, left)
            elif name.lower().endswith(".py"):
                print(f"  Self-review: '{name}' - no issues found.")
            reviewed.append((name, content))
            continue

        candidate = strip_code_fence(fixed[name].strip())
        try:
            ast.parse(candidate)
        except SyntaxError:
            print(f"  Self-review suggested a fix for '{name}' but it wasn't valid Python - "
                  f"keeping the original.")
            reviewed.append((name, content))
            continue
        still_invented = find_invented_method_calls(candidate, base_page_methods)
        if still_invented:
            print(f"  Self-review's fix for '{name}' STILL calls invented method(s) "
                  f"{still_invented} - trying a targeted repair with the REAL base_page signatures.")
            repaired = repair_invented_methods(name, content, invented_by_file.get(name) or still_invented,
                                               base_page_methods, base_signatures)
            left = find_invented_method_calls(repaired, base_page_methods)
            reviewed.append((name, _flag_invented_methods(repaired, left) if left else repaired))
            continue
        print(f"  Self-review caught and fixed an issue in '{name}'.")
        reviewed.append((name, candidate))
    return reviewed


def check_mat_select_misuse(all_blocks: list[tuple[str, str]]) -> list[str]:
    """FEATURE: mat-select misuse safety net - the SYSTEM_PROMPT now
    explicitly tells the AI that a <mat-select> locator must NEVER be
    driven with a native-<select>-style helper (select_option()), since
    a mat-select has no real <option> children to select against - the
    correct pattern is clicking the trigger then clicking a separate
    <mat-option>. Instructions in a prompt are followed most of the
    time, not ALL of the time - this is the same kind of deterministic,
    no-AI-call safety net as find_invented_method_calls and
    check_locator_attribute_consistency: it doesn't trust the
    instruction alone, it checks the ACTUAL generated code for the
    specific mistake the instruction was written to prevent.

    Identifies which locator attribute names are mat-select locators by
    scanning locators.py for lines whose VALUE contains "mat-select",
    then scans every OTHER .py file for that same attribute name being
    passed to a native-select-style helper call (recognized by common
    naming: a call whose method name contains "select" and whose first
    argument is that attribute - e.g. select_by_locator(loc.x, ...),
    self.locator(loc.x).select_option(...)). Flags each such call - not
    an auto-fix, since the correct replacement (which real <mat-option>
    text/locator to click) isn't reliably derivable from here alone."""
    MAT_SELECT_ATTR_RE = re.compile(r"^\s{4,}([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*\"[^\"]*mat-select[^\"]*\"",
                                     re.MULTILINE)
    mat_select_attrs: set[str] = set()
    for filename, content in all_blocks:
        if "locators" not in filename.lower() or not filename.lower().endswith(".py"):
            continue
        mat_select_attrs.update(MAT_SELECT_ATTR_RE.findall(content))

    if not mat_select_attrs:
        return []  # no mat-select locators in this batch - nothing to check

    warnings = []
    for filename, content in all_blocks:
        if "locators" in filename.lower() or not filename.lower().endswith(".py"):
            continue
        for attr in mat_select_attrs:
            # A call is suspicious if a REAL native-<select>-style helper
            # is invoked with this specific mat-select attribute as (part
            # of) its argument - covers "select_by_locator(loc.attr, ...)"
            # (this framework's own real base_page helper name for a
            # plain <select>) and Playwright's own ".select_option(...)"
            # chained off this attribute. Deliberately NOT a broad
            # "\w*select\w*" wildcard - that would also match a
            # CORRECTLY-written custom helper whose own name merely
            # happens to contain the word "select" (e.g. a
            # "_select_mat_option" helper that itself does the right
            # click-based interaction internally) as a false positive,
            # flagging genuinely correct code as if it were the mistake
            # this check exists to catch.
            pattern = re.compile(
                rf"\bselect_by_locator\([^)]*\bloc\.{re.escape(attr)}\b"
                rf"|\bloc\.{re.escape(attr)}\b[^;\n]*\.select_option\("
            )
            if pattern.search(content):
                warnings.append(
                    f"'{filename}' appears to call a native-<select>-style method "
                    f"(select_by_locator/select_option) on loc.{attr}, but that locator's own "
                    f"value shows it's a <mat-select> (Angular Material) - a mat-select has no "
                    f"real <option> children to select against, so this will silently do nothing "
                    f"or fail at runtime. Use click_by_locator to open it, then click_by_locator "
                    f"on the matching <mat-option> instead."
                )
    return warnings


def check_locator_attribute_consistency(all_blocks: list[tuple[str, str]]) -> list[str]:
    """FEATURE (Step 6 extension - self-review): locator-attribute vs
    locators-class consistency check - the mirror-image bug to
    check_data_key_consistency below, but for locator attributes instead
    of testdata keys: page.py calls "loc.search_by_error" (or
    "BANK_LOCATORS[self.bank].search_by_error"), but the actual
    generated locators.py class - in the SAME AI reply - never defines
    an attribute by that exact name (maybe it's called
    "search_error_message" there instead, or was simply forgotten).
    Both files look fine individually - self-review's invented-BASE-
    PAGE-method check doesn't catch this (a locator attribute isn't a
    BasePage method), and nothing else in the pipeline checks locator
    attributes against their own class definition - so this would only
    surface as an AttributeError the moment pytest actually runs.

    Scans every locators.py file in this batch for its real class
    attribute names (simple "name = value" assignments at class body
    level), and every OTHER .py file for "loc.<name>" or
    "BANK_LOCATORS[...].<name>"-style attribute access, then flags any
    accessed name that isn't a real attribute on ANY locators class in
    this batch. Returns a list of warning strings, empty if everything
    lines up. Like check_data_key_consistency, this is a warning, not
    an auto-fix - only self-review's AI-driven fix (or a human) can
    safely decide whether to rename the locator or the page's reference
    to it."""
    ATTR_ASSIGN_RE = re.compile(r"^\s{4,}([a-zA-Z_][a-zA-Z0-9_]*)\s*=", re.MULTILINE)
    LOC_ACCESS_RE = re.compile(
        r"""(?:\bloc\.|BANK_LOCATORS\[[^\]]+\]\.)([a-zA-Z_][a-zA-Z0-9_]*)"""
    )
    # Attribute-ish names that are real Python/object mechanics, not
    # locator fields - never flag these even if they appear via loc.<x>.
    NON_LOCATOR_NAMES = {"__class__", "__dict__"}

    real_attrs: set[str] = set()
    for filename, content in all_blocks:
        if "locators" not in filename.lower() or not filename.lower().endswith(".py"):
            continue
        real_attrs.update(ATTR_ASSIGN_RE.findall(content))
        real_attrs.update(re.findall(r"^\s{4,}(?:async\s+)?def\s+([a-zA-Z_]\w*)\s*\(", content, re.M))   # parametrised row locators are METHODS

    if not real_attrs:
        return []  # no locators file in this batch to check against

    accessed: set[str] = set()
    for filename, content in all_blocks:
        if "locators" in filename.lower() or not filename.lower().endswith(".py"):
            continue  # only check page.py/test.py - not the locators file against itself
        accessed.update(LOC_ACCESS_RE.findall(content))

    warnings = []
    for name in sorted(accessed):
        if name in NON_LOCATOR_NAMES or name in real_attrs:
            continue
        close_match = next((a for a in real_attrs if a.lower().replace("_", "")
                             == name.lower().replace("_", "")), None)
        hint = f" (did you mean the real locator '{close_match}'?)" if close_match else ""
        warnings.append(
            f"loc.{name} is accessed in the generated code but no locators class in this batch "
            f"defines an attribute named '{name}'{hint} - this will raise AttributeError the "
            f"moment this test actually runs."
        )
    return warnings


def check_data_key_consistency(all_blocks: list[tuple[str, str]]) -> list[str]:
    """FEATURE: data-key vs testdata-column consistency check - a common,
    easy-to-miss real bug: a generated page.py/test.py method reads
    data["EmailAddress"], but the testdata CSV the AI generated in the
    SAME reply actually named that column "Email" (or "Email Address"
    with a space, or any other near-miss) - everything looks fine when
    reading each file on its own, but the test crashes with a KeyError
    the moment it actually runs, since the dict built from that CSV row
    simply doesn't have the key the code is asking for.

    This scans every non-CSV file's content for data["X"]/data['X']
    references, scans every CSV file's header row for its real column
    names, and cross-checks: any referenced key that isn't a real column
    in ANY of the CSV files being written this round (and isn't one of
    the standard metadata columns every testdata sheet has -
    ScenarioID/TestcaseID/Description/ExpectedMessage, which are never
    fed to a page method as field data) is flagged. Returns a list of
    warning strings, one per mismatched key found - empty list if
    everything lines up. This is a WARNING, not an auto-fix - the exact
    right fix (rename the CSV column, or rename the code's key) depends
    on which one is actually correct, which isn't knowable from the
    mismatch alone."""
    METADATA_COLUMNS = {"ScenarioID", "TestcaseID", "Description", "ExpectedMessage"}
    DATA_KEY_RE = re.compile(r"""data\[["']([^"']+)["']\]""")

    referenced_keys: set[str] = set()
    for filename, content in all_blocks:
        if filename.lower().endswith(".csv"):
            continue
        referenced_keys.update(DATA_KEY_RE.findall(content))

    if not referenced_keys:
        return []

    real_columns: set[str] = set()
    for filename, content in all_blocks:
        if not filename.lower().endswith(".csv"):
            continue
        first_line = content.strip().splitlines()[0] if content.strip() else ""
        real_columns.update(c.strip() for c in first_line.split(",") if c.strip())

    if not real_columns:
        return []  # no CSV in this batch to check against - nothing to compare

    warnings = []
    for key in sorted(referenced_keys):
        if key in METADATA_COLUMNS:
            continue
        if key not in real_columns:
            close_match = next((c for c in real_columns if c.lower().replace(" ", "")
                                 == key.lower().replace(" ", "")), None)
            hint = f" (did you mean the real column '{close_match}'?)" if close_match else ""
            warnings.append(
                f"data[\"{key}\"] is used in the generated code but there is no testdata "
                f"column named '{key}'{hint} - this will raise a KeyError the moment this "
                f"test actually runs."
            )
    return warnings


SCREENSHOT_ON_FAILURE_FIXTURE = '''

# --- AUTO-INSERTED: screenshot on test failure (debugging aid) ---
import pytest as _ai_pytest


@_ai_pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == "call" and report.failed:
        page = item.funcargs.get("page")
        if page is not None:
            try:
                from pathlib import Path as _Path
                failures_dir = _Path(__file__).parent / "failures"
                failures_dir.mkdir(exist_ok=True)
                safe_name = item.name.replace("[", "_").replace("]", "_").replace("/", "_")
                page.screenshot(path=str(failures_dir / f"{safe_name}.png"), full_page=True)
            except Exception:
                pass  # best-effort debugging aid - never let a screenshot failure mask the real test failure
'''


def ensure_screenshot_on_failure_fixture(repo_root: Path) -> bool:
    """FEATURE: auto-screenshot on any pytest failure - a real, visible
    .png saved under <repo_root>/failures/ the moment any generated test
    fails, without re-running anything to see what the page looked like
    at the point of failure. This is a standard pytest pattern
    (pytest_runtest_makereport hook) that belongs in conftest.py since
    it applies to every test, not one module's test file specifically.

    Appends this hook to the repo's REAL conftest.py if one exists and
    doesn't already have a screenshot-on-failure mechanism (checked by
    looking for "pytest_runtest_makereport" already being present -
    never duplicates it, and never touches anything else already in the
    file). Creates a new minimal conftest.py only if none exists at all.
    Returns True if it added the fixture, False if it was already
    present or nothing needed to change."""
    conftest_path = repo_root / "conftest.py"
    if conftest_path.exists():
        content = conftest_path.read_text(encoding="utf-8")
        if "pytest_runtest_makereport" in content:
            return False  # some screenshot/report hook already exists - don't duplicate or override it
        conftest_path.write_text(content + SCREENSHOT_ON_FAILURE_FIXTURE, encoding="utf-8")
        return True
    else:
        conftest_path.write_text(SCREENSHOT_ON_FAILURE_FIXTURE.lstrip("\n"), encoding="utf-8")
        return True


def auto_write_into_repo(ai_output: str, repo_root: Path, bank: str, module: str,
                          action: str = "default", existing_page_class: str | None = None,
                          existing_test_file: str | None = None,
                          real_login_code: str | None = None) -> dict:
    """FULL AUTO MODE: writes generated files directly into the real
    framework's real paths (no preview folder), converts the testdata CSV
    straight into a real .xlsx (one sheet per action - see
    csv_text_to_xlsx), and creates any missing __init__.py so the new
    package imports cleanly. Returns a dict of what was written, for the
    caller to print / feed into an automatic pytest run."""
    module_title = module[:1].upper() + module[1:]
    action_title = action[:1].upper() + action[1:]
    result = {}
    unmatched = []
    rejected = []  # blocks that DID match a category but failed validation - never reused as fallback
    blocks = parse_blocks(ai_output)
    base_page_methods = load_base_page_methods(repo_root)
    print(f"  Self-reviewing generated code before writing...")
    blocks = ai_self_review_and_fix(blocks, base_page_methods, load_base_page_signatures(repo_root))
    if runtime_data_enabled():
        ensure_runtime_data_util(repo_root)       # BEFORE the import check below: the AI imports RuntimeData itself

    key_warnings = check_data_key_consistency(blocks)
    for w in key_warnings:
        print(f"  WARNING (data-key mismatch): {w}")

    locator_attr_warnings = check_locator_attribute_consistency(blocks)
    for w in locator_attr_warnings:
        print(f"  WARNING (locator-attribute mismatch): {w}")

    mat_select_warnings = check_mat_select_misuse(blocks)
    for w in mat_select_warnings:
        print(f"  WARNING (mat-select misuse): {w}")

    # First pass: find the page file's and locators file's real class names,
    # so every other file's import can be forced to match them exactly
    # regardless of what the AI itself assumed.
    page_class_name = None
    locators_class_name = None
    for name, content in blocks:
        lname = name.lower()
        if "page" in lname and lname.endswith(".py") and page_class_name is None:
            page_class_name = extract_class_name(content)
        if "locator" in lname and lname.endswith(".py") and locators_class_name is None:
            locators_class_name = extract_class_name(content)

    global _MODULE_HAS_ADD_SHEET
    _MODULE_HAS_ADD_SHEET = any(re.search(r"_testdata_add\.csv$", n.lower()) for n, _c in blocks) or \
        not any(re.search(r"_testdata_[a-z0-9]+\.csv$", n.lower()) for n, _c in blocks)

    for name, content in blocks:
        lower = name.lower()
        content = fix_imports(content, bank, module, page_class_name, locators_class_name)
        if lower.endswith(".py"):
            content, import_notes = repair_nonexistent_imports(content, repo_root)
            for note in import_notes:
                print(f"  Repaired a fabricated import in '{name}': {note}")

        # SAFETY CHECK: reject any .py block that isn't valid Python before
        # it ever gets written - prevents a garbled AI response (stray text
        # merged into code) from landing in the repo in the first place.
        if lower.endswith(".py"):
            try:
                ast.parse(content)
            except SyntaxError as syn_err:
                # A handful of specific SyntaxError messages are the
                # unmistakable signature of the AI's reply getting CUT
                # OFF partway through (hit ANTHROPIC_MAX_TOKENS) rather
                # than an actual code-generation mistake - e.g. an open
                # paren/bracket that's never closed because the response
                # simply stopped mid-statement. Flagging this specific
                # case with a concrete fix (raise the token limit) saves
                # the person from treating it as a mysterious generation
                # bug when it's really just "ask for more room to answer".
                err_text = str(syn_err).lower()
                truncation_markers = ("was never closed", "unexpected eof", "eof in multi-line",
                                      "unexpected end of file")
                if any(m in err_text for m in truncation_markers):
                    print(f"  WARNING: AI output for '{name}' is not valid Python ({syn_err}) - "
                          f"skipping, not written.")
                    print(f"  This specific error (an unclosed bracket/paren right at the end) "
                          f"usually means the reply got CUT OFF before finishing - it likely hit "
                          f"ANTHROPIC_MAX_TOKENS. Raise ANTHROPIC_MAX_TOKENS in your .env (e.g. to "
                          f"16000 or higher) and re-run this module - a combined multi-action "
                          f"reply covering several actions and a form with many fields can "
                          f"genuinely need more room than the default.")
                    # Signal truncation back to the caller (run_full_module_pipeline) via
                    # a special result key - this is what lets the caller automatically
                    # retry via the smaller, less truncation-prone split-call path instead
                    # of the person having to notice this print, edit .env, and manually
                    # re-run. See "_truncated" handling where auto_write_into_repo's result
                    # is consumed.
                    result["_truncated"] = True
                else:
                    print(f"  WARNING: AI output for '{name}' is not valid Python ({syn_err}) - skipping, not written.")
                rejected.append(name)
                continue
            # Only the TEST file is checked for fabricated imports here -
            # its login/other imports must point at real, already-existing
            # framework files. Locators/page files are the module's own new
            # files and haven't been written yet at this point in the loop,
            # so checking them here would give false positives.
            if "test" in lower:
                bad_import = find_nonexistent_src_import(content, repo_root)
                if bad_import:
                    # The test file is NEVER dropped for one unresolved import (that stopped the negative step and the
                    # whole module before): it is written with a FIXME banner on top and a copy goes to generated_preview.
                    print(f"  WARNING: '{name}' imports '{bad_import}' which doesn't exist in the repo - the file is "
                          f"still written, with a FIXME on top (fix that one import).")
                    content = f"# FIXME (import): '{bad_import}' does not exist in this repo - fix this import.\n" + content
                    try:
                        prev = repo_root / "generated_preview"
                        prev.mkdir(exist_ok=True)
                        (prev / Path(name).name).write_text(content + "\n", encoding="utf-8")
                    except Exception:
                        pass
                if uses_own_page_for_login(content, page_class_name):
                    print(f"  WARNING: '{name}' calls .login() on the module's own {page_class_name} - "
                          f"that's always wrong, login belongs to BankLoginPage/AdminLoginPage/etc. "
                          f"Skipping, not written.")
                    rejected.append(name)
                    continue

        if lower.endswith(".csv"):
            if runtime_data_enabled():
                _sheet_ph = (re.search(r"_testdata_([a-z0-9]+)\.csv$", lower).group(1).capitalize()
                             if re.search(r"_testdata_([a-z0-9]+)\.csv$", lower) else action_title)
                content, _n_ph = apply_identifier_placeholders(content, _sheet_ph, module)
                if _n_ph:
                    print(f"  Testdata '{_sheet_ph}': {_n_ph} identifying value(s) are now run-time tokens "
                          f"(no literal number is stored in the sheet).")
            if _separate_negatives():
                _sheet_nm = (re.search(r"_testdata_([a-z0-9]+)\.csv$", lower).group(1).capitalize()
                             if re.search(r"_testdata_([a-z0-9]+)\.csv$", lower) else action_title)
                content, _moved = split_out_negative_rows(content, _sheet_nm, module)
                if _moved:
                    print(f"  Moved {_moved} negative row(s) out of the '{_sheet_nm}' sheet - they go into the "
                          f"single negative file instead.")
            content, id_warnings = validate_and_dedupe_testdata_csv(content)
            for w in id_warnings:
                print(f"  Testdata validation: {w}")
            content = make_testdata_unique(content)
            for w in check_testdata_for_sensitive_values(content):
                print(f"  Compliance check: {w}")
            # AI-based semantic duplicate check costs one EXTRA ask_ai call
            # PER CSV block (4 of them in combined mode) on top of the main
            # generation call - the exact-ID duplicate check just above
            # (validate_and_dedupe_testdata_csv) is deterministic/free and
            # already catches the common case, so this AI pass is OFF by
            # default. Set AI_DUPLICATE_CHECK=true in .env to re-enable it
            # if you want the deeper (but costlier) semantic check too.
            if os.environ.get("AI_DUPLICATE_CHECK", "false").lower() == "true":
                for w in ai_detect_semantic_duplicates(content):
                    print(f"  {w}")
            # MULTI-ACTION MODE: filename carries its own action suffix
            # (e.g. module_testdata_assignmenu.csv) so each action's rows
            # land on its OWN worksheet even though they all came back in
            # the SAME AI reply/call - see MULTI_ACTION_INSTRUCTIONS. Not
            # restricted to the 4 standard names - a real module's own
            # custom action (e.g. "Assign Menu") produces its own suffix
            # here too. A normal (non-multi) single-action call's CSV
            # filename never matches this pattern, so it keeps the
            # original "testdata" key untouched - existing single-action
            # callers are unaffected.
            csv_action_match = re.search(r"_testdata_([a-z0-9]+)\.csv$", lower)
            csv_action_title = csv_action_match.group(1).capitalize() if csv_action_match else action_title
            dest = repo_root / "src" / "banks" / bank / "testdata" / f"{module_title}.xlsx"
            csv_text_to_xlsx(content, dest, sheet_name=csv_action_title)
            result_key = f"testdata_{csv_action_match.group(1)}" if csv_action_match else "testdata"
            result[result_key] = dest

        elif "locator" in lower and lower.endswith(".py"):
            hedged = find_hedged_locators(content)
            if hedged:
                print(f"  NOTE: {len(hedged)} locator(s) still use the forbidden 'id-or-text' "
                      f"hedge pattern despite the rule: {hedged}. These will likely need manual "
                      f"DevTools verification - pick ONE real attribute/text, not both joined by 'or'.")
            dest = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
            dest.parent.mkdir(parents=True, exist_ok=True)
            (dest.parent / "__init__.py").touch(exist_ok=True)
            dest.write_text(content + "\n", encoding="utf-8")
            result["locators"] = dest
            placeholders = re.findall(r'(\w+)\s*=\s*"#TODO-verify[^"]*"', content)
            if placeholders:
                print(f"  NOTE: {len(placeholders)} locator(s) are still placeholders "
                      f"(no live page was available to verify them): {placeholders}")
                print(f"  These need manual selector confirmation, OR re-run with a live login "
                      f"session so verify_and_heal_locators_file() can resolve them automatically.")

        elif "page" in lower and lower.endswith(".py"):
            page_regressions = check_for_regressions(existing_page_class, content)
            if page_regressions:
                for w in page_regressions:
                    print(f"  {w}")
                print(f"  Skipping write of '{name}' - a regenerated version would have broken "
                      f"other banks/actions. Existing page file left untouched.")
                rejected.append(name)
                continue
            if contains_unrequested_logout(content):
                print(f"  WARNING: '{name}' appears to add a logout step that wasn't in the "
                      f"scenario - logout should be handled separately by this tool, never inside "
                      f"the action method. Review this file before trusting it in a larger suite.")
            dest = repo_root / "src" / "common" / "pages" / module / f"{module}_page.py"
            dest.parent.mkdir(parents=True, exist_ok=True)
            (dest.parent / "__init__.py").touch(exist_ok=True)
            dest.write_text(content + "\n", encoding="utf-8")
            result["page"] = dest

        elif "test" in lower and lower.endswith(".py"):
            test_regressions = check_for_regressions(existing_test_file, content)
            if test_regressions:
                for w in test_regressions:
                    print(f"  {w}")
                print(f"  Skipping write of '{name}' - a regenerated version would have broken "
                      f"other actions' tests. Existing test file left untouched.")
                rejected.append(name)
                continue
            arity_issues = find_arity_mismatches(content, real_login_code)
            if arity_issues:
                for issue in arity_issues:
                    print(f"  WARNING: '{name}' - {issue}")
                print(f"  Written anyway (this is a real bug that will surface as a clear "
                      f"TypeError at test time, easier to fix than a silent wrong-behavior bug).")
            content = ensure_test_loads_sheets(name, content, module_title,
                                               sheets_from_blocks(blocks, action_title), print)
            if runtime_data_enabled() and ensure_runtime_data_util(repo_root):
                content = inject_runtime_resolution(content, module, bank)
            content, _self_notes = normalize_test_self_usage(content, module, bank)
            for _n in _self_notes:
                print(f"  Test file: {_n}")
            dest = repo_root / "src" / "testcase" / module / f"test_{module}.py"
            dest.parent.mkdir(parents=True, exist_ok=True)
            (dest.parent / "__init__.py").touch(exist_ok=True)
            dest.write_text(content + "\n", encoding="utf-8")
            result["test"] = dest

        else:
            unmatched.append(name)

    # Fallback: if the AI gave a .py file we couldn't classify by name but we
    # are still missing "test" (the most common miss - AI sometimes names it
    # without "test" in the filename), use the leftover unmatched .py block.
    if "test" not in result:
        for name, content in blocks:
            if name.lower().endswith(".py") and name in unmatched:
                content = fix_imports(content, bank, module, page_class_name, locators_class_name)
                dest = repo_root / "src" / "testcase" / module / f"test_{module}.py"
                dest.parent.mkdir(parents=True, exist_ok=True)
                (dest.parent / "__init__.py").touch(exist_ok=True)
                dest.write_text(content + "\n", encoding="utf-8")
                result["test"] = dest
                unmatched.remove(name)
                break

    if unmatched:
        print(f"  (unmatched AI output blocks, not written anywhere: {unmatched})")
    if rejected:
        print(f"  (rejected AI output blocks, not written due to validation failure: {rejected})")

    try:
        harden_module_files(repo_root, bank, module)
    except Exception as exc:
        _log_exception("hardening the page / locators files", exc)
    if result.get("test") and runtime_data_enabled():
        ensure_module_conftest(repo_root, module, result["test"])
    if result.get("locators") and (result.get("page") or result.get("test")):
        try:
            synthesize_missing_row_locators(result["locators"], result.get("page"), result.get("test"))
        except Exception as exc:
            _log_exception("adding missing row locators", exc)
    if _separate_negatives() and result.get("locators") \
            and (result.get("page") or result.get("test")):
        try:
            strip_unused_error_locators(result["locators"], result.get("page"), result.get("test"))
        except Exception as exc:
            _log_exception("stripping error locators", exc)

    return result


def discover_full_menu_tree(repo_root: Path, bank: str, portal_type: str,
                             max_depth: int = 3, max_items: int = 200) -> list[dict]:
    """FEATURE: full menu auto-discovery - logs in ONCE, then crawls the
    ENTIRE visible navigation (sidebar or top-nav, click-based or
    hover-based - tries both per item) instead of the person having to
    click through it themselves and type out a URL/menu-path list by
    hand. Returns [{"path": "Administration > PG configuration > BIN
    Management", "url": "https://.../BinManagement.htm"}, ...] - one
    entry per LEAF item found (an item with no further sub-items of its
    own), ready to feed straight into parse_url_list_file-style
    generation (see run_scenario.py's --discover-menu flag).

    This is inherently best-effort/heuristic - real nav structures vary
    a lot (see bank_notes for hover-vs-click differences per bank) - so
    it tries clicking AND hovering on each item, checks whether new
    child items appeared or the URL itself changed, and recurses either
    way. Always meant to be reviewed (or fed through parse_url_list_file
    with its own module-name overrides) rather than blindly trusted for
    a huge, unfamiliar portal - but it removes the tedious, error-prone
    part of manually clicking through and copying every URL by hand.

    Capped at max_depth (avoids infinite recursion into a menu that
    cycles back on itself) and max_items (avoids a runaway crawl eating
    the whole session on a massive portal) - stops early past either
    limit and returns whatever was found so far."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed - run: pip install playwright --break-system-packages && playwright install chromium")
        return []

    LoginPageClass, class_name, original_config_text, config_path = _login_for_dom_exploration(
        repo_root, bank, portal_type)

    discovered: list[dict] = []
    visited_urls: set[str] = set()

    NAV_ITEM_SELECTOR = (
        "nav a, nav li, aside a, aside li, [class*='sidebar'] a, [class*='sidebar'] li, "
        "[class*='menu'] a, [class*='menu'] li, [role='menuitem']"
    )

    def _crawl(page, path_prefix: list[str], depth: int) -> None:
        if depth > max_depth or len(discovered) >= max_items:
            return
        try:
            items = page.locator(NAV_ITEM_SELECTOR).all()
        except Exception:
            return
        seen_labels_this_level = set()
        for item in items[:max_items]:
            if len(discovered) >= max_items:
                return
            try:
                label = (item.inner_text(timeout=1000) or "").strip().split("\n")[0]
            except Exception:
                continue
            if not label or label in seen_labels_this_level or len(label) > 60:
                continue
            seen_labels_this_level.add(label)
            url_before = page.url
            try:
                item.hover(timeout=1500)
                page.wait_for_timeout(300)
                child_appeared = page.locator(NAV_ITEM_SELECTOR).count() > len(items)
                if not child_appeared:
                    item.click(timeout=2500)
                    page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                continue
            url_after = page.url
            new_path = path_prefix + [label]
            if url_after != url_before and url_after not in visited_urls:
                visited_urls.add(url_after)
                # Leaf (URL actually changed) - record it, then recurse
                # one more level in case this "leaf" is itself a listing
                # page with its own sub-tabs (rare but happens).
                discovered.append({"path": " > ".join(new_path), "url": url_after})
                print(f"  [{len(discovered)}] {' > '.join(new_path)} -> {url_after}")
                _crawl(page, new_path, depth + 1)
                try:
                    page.go_back(wait_until="networkidle", timeout=8000)
                except Exception:
                    pass
            elif page.locator(NAV_ITEM_SELECTOR).count() > len(items):
                # A submenu expanded without navigating anywhere yet -
                # recurse into it at the same URL.
                _crawl(page, new_path, depth + 1)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=_headless())
            page = browser.new_page()
            try:
                login_page = LoginPageClass(page)
                LoginPageClass(page).login(bank)
                print(f"  Logged in via the real {class_name}.login('{bank}'). Crawling menu...")
                _crawl(page, [], 0)
            finally:
                try:
                    perform_logout(page)
                except Exception:
                    pass
                browser.close()
    except Exception as exc:
        print(f"  Menu crawl failed partway through ({exc}) - returning what was found so far.")
    finally:
        if original_config_text is not None and config_path.exists():
            config_path.write_text(original_config_text, encoding="utf-8")

    print(f"\n  Discovered {len(discovered)} leaf menu item(s) (capped at {max_items}, depth {max_depth}).")
    return discovered


def write_discovered_urls_file(discovered: list[dict], out_path: Path) -> None:
    """Writes discover_full_menu_tree's results out in the EXACT format
    parse_url_list_file already reads (one URL per line, optional
    ' => modulename' override) - a comment line above each URL records
    the real menu path it came from, purely for the person's own
    reference when reviewing the file before running it, since
    parse_url_list_file itself ignores '#' lines."""
    lines = []
    for entry in discovered:
        lines.append(f"# {entry['path']}")
        lines.append(entry["url"])
        lines.append("")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"  Written {len(discovered)} URL(s) to {out_path}")


def dedupe_failure_blocks_for_triage(pytest_output: str) -> tuple[str, int]:
    """FEATURE: token reduction for triage - across a big batch (e.g. 50
    modules), several failures often share the EXACT SAME error text
    (the same locator-not-found message, the same login timeout) just
    with a different module/test name in the header line. Sending all
    50 near-identical blocks to the AI wastes tokens on repetition it
    doesn't need to see 50 times to spot the pattern - one example of
    each distinct error, plus a count of how many times it repeated, is
    just as useful for triage_pytest_failures and costs a fraction of
    the tokens on a batch with a lot of shared root causes.

    Splits the output into per-test blocks (splitting on pytest's own
    "FAILED " / "ERROR " line markers), groups blocks whose text is
    IDENTICAL after stripping the test's own name/path out of it, and
    returns (deduped_text, original_block_count) - deduped_text lists
    each distinct error once with "(repeated N times, e.g. in: modA,
    modB, ...)" noted, original_block_count is how many blocks existed
    before deduping (for a person to see how much was collapsed).
    Falls back to returning the input unchanged if fewer than 4 failure
    blocks are found - not worth the complexity/risk of losing detail
    on a small run where the AI can just read all of it directly."""
    blocks = re.split(r"(?=^(?:FAILED|ERROR) )", pytest_output, flags=re.MULTILINE)
    failure_blocks = [b for b in blocks if b.startswith(("FAILED ", "ERROR "))]
    if len(failure_blocks) < 4:
        return pytest_output, len(failure_blocks)

    groups: dict[str, list[str]] = {}
    for block in failure_blocks:
        header_match = re.match(r"^(?:FAILED|ERROR)\s+(\S+)", block)
        test_name = header_match.group(1) if header_match else "unknown"
        # Normalize: drop the test's own name/path so two blocks that
        # differ ONLY in which module/test they're for still group
        # together if the actual error text is identical.
        normalized = block.replace(test_name, "<TEST>").strip()
        groups.setdefault(normalized, []).append(test_name)

    lines = []
    for normalized, test_names in groups.items():
        if len(test_names) > 1:
            lines.append(f"(repeated {len(test_names)} times, e.g. in: {', '.join(test_names[:5])}"
                        f"{', ...' if len(test_names) > 5 else ''})")
        lines.append(normalized)
        lines.append("")
    return "\n".join(lines), len(failure_blocks)


def deep_triage_single_failure(repo_root: Path, bank: str, module: str,
                                pytest_error_text: str) -> str:
    """FEATURE: deep-dive single-failure triage - the "most powerful"
    version of triage, for when one specific test's failure needs real
    root-causing rather than a quick one-line grouping across many. The
    plain-text triage_pytest_failures above only ever sees pytest's own
    error text; this instead gathers EVERY OTHER diagnostic artifact
    this file already produces for the SAME module and sends them to
    the AI TOGETHER, so it can cross-reference what pytest complained
    about against what the page actually looked like, what was actually
    scanned, and what locator was actually used - rather than guessing
    from an error message alone:

      1. The pytest error/traceback text itself (as given).
      2. The saved DOM snapshot from scan time (ai_debug_dom/*.html) -
         ground truth for what fields genuinely existed when scanned.
      3. The actual current locators.py content for this module - what
         selector was really used, not a guess at what it might be.
      4. A failure screenshot (failures/*.png), if the screenshot-on-
         failure conftest hook produced one for this test - sent via
         REAL vision (ask_ai_vision, not just described in text), so
         the AI can see exactly what the page showed at the moment of
         failure.

    Each source that can't be found (no snapshot saved yet, no
    screenshot for this particular test) is simply left out rather than
    failing the whole triage - this degrades gracefully from "everything
    available" down to "just the pytest text", never errors out for a
    missing optional piece. Returns the AI's plain-English root-cause
    analysis as text."""
    sources_used = ["pytest error text"]
    context_parts = [f"PYTEST ERROR:\n{pytest_error_text.strip()}"]

    dom_dir = repo_root / "ai_debug_dom"
    dom_snapshot = None
    if dom_dir.exists():
        matches = sorted(dom_dir.glob(f"{bank}_*{module}*_scanned_dom.html"))
        if matches:
            dom_snapshot = matches[0]
            dom_content = dom_snapshot.read_text(encoding="utf-8")[:8000]  # cap - this is
                                                                            # context, not the whole file
            context_parts.append(f"REAL SCANNED DOM (ground truth for what fields genuinely "
                                  f"existed):\n{dom_content}")
            sources_used.append(f"scanned DOM snapshot ({dom_snapshot.name})")

    locators_path = repo_root / "src" / "banks" / bank / "locators" / f"{module}_locators.py"
    if locators_path.exists():
        context_parts.append(f"ACTUAL LOCATORS CURRENTLY IN USE:\n"
                              f"{locators_path.read_text(encoding='utf-8')}")
        sources_used.append("current locators.py")

    screenshot_path = None
    failures_dir = repo_root / "failures"
    if failures_dir.exists():
        matches = sorted(failures_dir.glob(f"*{module}*.png"))
        if matches:
            screenshot_path = matches[0]
            sources_used.append(f"failure screenshot ({screenshot_path.name})")

    combined_context = "\n\n" + ("=" * 60) + "\n\n".join(context_parts)
    system_prompt = (
        "You are deep-root-causing ONE specific Playwright test failure. You have been given "
        "several real sources of ground truth together - the pytest error itself, the REAL DOM "
        "that was scanned when this module was generated, the ACTUAL locator currently being "
        "used, and (if included) a real screenshot of the page at the moment of failure. "
        "Cross-reference these against each other rather than treating the pytest error in "
        "isolation: does the locator currently in use actually match something that was really "
        "in the scanned DOM, or was it invented? Does the screenshot show a completely "
        "different page/state than what the scan captured (suggesting navigation drifted "
        "before this test even reached the right place)? Give: (1) the most likely root cause "
        "in 1-2 sentences, grounded in what you can actually see in the sources, not a generic "
        "guess, (2) the EXACT fix - which file, which line/locator, what it should become, "
        "(3) your confidence (high/medium/low) based on how directly the sources support your "
        "conclusion."
    )
    user_prompt = f"Module: {module}, Bank: {bank}\n{combined_context}"

    print(f"  Deep triage using: {', '.join(sources_used)}")
    if screenshot_path:
        reply = ask_ai_vision(system_prompt, user_prompt, [str(screenshot_path)])
    else:
        reply = ask_ai(system_prompt, user_prompt)
    return reply or "(deep triage call failed - review the sources above manually: " + \
           ", ".join(sources_used) + ")"


def triage_pytest_failures(pytest_output: str, module_results: list[tuple[str, bool]] | None = None) -> str:
    """FEATURE: full-suite failure triage - after a big multi-module run
    (batch file, URL list, or multi-bank) with several failures, reading
    each one individually to find the root cause is slow. This sends
    the WHOLE combined failure output to the AI in ONE call and asks it
    to GROUP failures that likely share the same underlying cause (e.g.
    "5 of these all fail on the same login-button timeout - probably
    one locator change affects every module") rather than treating each
    as an unrelated, isolated problem - turning a long list of red
    lines into a short list of things to actually go fix.

    module_results, if given (a list of (module_name, passed) pairs),
    is included as extra context so the AI can name which modules
    belong to which group by name, not just by guessing from stack
    traces alone. Returns the AI's plain-English triage summary as
    text - meant to be printed straight to the terminal or saved
    alongside the run's own output, not parsed further."""
    if not pytest_output.strip():
        return "(no pytest output given - nothing to triage)"
    deduped_output, original_count = dedupe_failure_blocks_for_triage(pytest_output)
    if original_count >= 4:
        print(f"  (deduped {original_count} failure block(s) before triage - repeated identical "
              f"errors are sent once with a count, not duplicated in full each time)")
    system_prompt = (
        "You are triaging a batch of pytest failures from a Playwright test automation run "
        "covering multiple modules. Read the combined failure output below and GROUP failures "
        "that likely share the same root cause - do not just list them one by one. Some entries "
        "are already marked '(repeated N times, e.g. in: ...)' - that means N tests failed with "
        "that EXACT same error already, treat all of them as one group without needing to see "
        "each individually. For each group, name: (1) which module(s)/test(s) are in it, (2) "
        "your best-guess root cause in one sentence, (3) a concrete next step to investigate or "
        "fix it. Keep it compact and scannable - this is meant to save someone from reading every "
        "failure individually, not to replace looking at the actual code. If two failures look "
        "unrelated, keep them in separate groups rather than forcing a false connection. End with "
        "a one-line overall summary (e.g. 'X of Y failures share this one root cause')."
    )
    user_prompt = deduped_output[:12000]
    if module_results:
        summary_line = ", ".join(f"{m}={'PASS' if ok else 'FAIL'}" for m, ok in module_results)
        user_prompt = f"Per-module results: {summary_line}\n\n{user_prompt}"
    reply = ask_ai(system_prompt, user_prompt)
    return reply.strip() if reply else "(AI triage call failed - review the raw output above manually.)"


def check_module_staleness(repo_root: Path, bank: str, module: str, menu_name: str) -> str:
    """FEATURE: proactive staleness detection - re-scans a module's REAL
    live page (the same way DOM mode originally generated it) and
    compares what's actually there now against the EXISTING locators
    file already in the repo, flagging drift BEFORE a scheduled/CI test
    run fails and someone has to debug why. This is a lightweight
    "does this still look right" check, not a full re-generation -
    nothing gets rewritten here, only reported.

    Returns the AI's plain-English drift report as text (e.g. "The Add
    button's real class name has changed - the existing locator
    '//button[contains(text(),\\'Add New\\')]' likely no longer matches; "
    "everything else still looks consistent with the existing
    locators."), meant for a person to read and decide whether
    regenerating that module is worth doing."""
    existing_locators = find_existing_locators(repo_root, bank, module)
    if not existing_locators:
        return f"No existing locators file found for {bank}/{module} - nothing to compare against."

    page_html, _ = explore_module_via_menu(repo_root, bank, "admin", menu_name)
    if not page_html:
        return "Live scan returned nothing - could not check for staleness right now."

    system_prompt = (
        "You are comparing a bank's EXISTING, already-in-use Playwright locators file against "
        "a FRESH live scan of the same real page, to catch drift before it causes a test "
        "failure. Report ONLY genuine mismatches - a locator whose target element doesn't "
        "appear to exist anymore in the fresh scan, or whose text/attributes look meaningfully "
        "different. Do not flag cosmetic non-issues (element ordering, whitespace, unrelated "
        "new elements on the page). If everything still looks consistent, say so plainly in one "
        "line - do not manufacture a finding just to have something to report."
    )
    user_prompt = f"EXISTING locators file:\n{existing_locators}\n\nFRESH live scan:\n{page_html[:6000]}"
    reply = ask_ai(system_prompt, user_prompt)
    return reply.strip() if reply else "(AI staleness check call failed.)"


def audit_dispatch_grouping(repo_root: Path, module: str) -> str:
    """FEATURE: cross-bank dispatch auditor - once a page class has
    accumulated several banks in its dispatch dict, it's easy for the
    grouping to drift from optimal without anyone noticing (e.g. two
    banks that actually have identical locators/flow ended up pointing
    at two separately-generated methods instead of sharing one, because
    they were generated in different sessions without the second one's
    generation being told the first was actually identical - or the
    reverse, a bank whose real flow diverged over time but is still
    pointed at a shared method it no longer truly matches). This is a
    read-only AUDIT, not a rewrite - it reports questionable grouping
    for a person to review and decide on.

    Returns the AI's plain-English audit findings as text - or an
    explicit "no existing page file found" message if this module
    hasn't been generated yet."""
    existing_page_class = find_existing_page_class(repo_root, module, bank)
    if not existing_page_class:
        return f"No existing page file found for module '{module}' - nothing to audit yet."

    system_prompt = (
        "You are auditing an existing Playwright page class's per-bank dispatch dict for "
        "grouping quality. Look at which banks share the same handler method vs which have "
        "their own, and compare each shared method's actual locator usage/logic against every "
        "bank pointed at it. Flag ONLY genuine, actionable findings: (a) two or more banks "
        "pointed at DIFFERENT methods whose bodies are functionally identical (same fields, "
        "same steps) - these could be merged into one shared method, or (b) a bank sharing a "
        "method whose real locators suggest its actual flow has meaningfully diverged (e.g. it "
        "has fields/locators that don't fit that method's field list) - this one might need its "
        "own dedicated method instead. If the grouping already looks reasonable, say so plainly "
        "in one line rather than inventing a finding."
    )
    reply = ask_ai(system_prompt, existing_page_class[:8000])
    return reply.strip() if reply else "(AI dispatch audit call failed.)"


def generate_regression_summary(module_results: list[tuple[str, str, bool, str]]) -> str:
    """FEATURE: plain-English regression summary - after a big multi-
    module run, turns the raw pass/fail list into a short, readable
    summary a person can skim (or paste into a status update) instead
    of scrolling back through the whole terminal log.

    module_results: list of (bank, module, passed, note) tuples - note
    is a short reason string for failures (blank for passes). Returns
    a markdown-formatted text summary - written to a .md file by the
    caller if desired, or just printed directly."""
    total = len(module_results)
    passed = sum(1 for *_, ok, _ in module_results if ok)
    failed = total - passed
    lines = [
        "# Regression Run Summary",
        "",
        f"**{passed}/{total} passed** ({failed} failed)" if total else "No modules were run.",
        "",
    ]
    if failed:
        lines.append("## Failed")
        for bank, module, ok, note in module_results:
            if not ok:
                lines.append(f"- **{bank} / {module}**{f' — {note}' if note else ''}")
        lines.append("")
    if passed:
        lines.append("## Passed")
        for bank, module, ok, _note in module_results:
            if ok:
                lines.append(f"- {bank} / {module}")
        lines.append("")
    return "\n".join(lines)


def record_test_run_result(repo_root: Path, bank: str, module: str, passed: bool) -> None:
    """FEATURE: flaky test detector, part 1 - appends this run's
    pass/fail result to a small persistent history file
    (reports/test_run_history.json), keyed by "bank/module". Call this
    once per module after EVERY pytest run (a single-module run, a
    batch run, a --full-auto run) so history accumulates naturally over
    time - detect_flaky_modules (below) is the part that actually reads
    this back and flags inconsistency. Keeps only the most recent 10
    results per module so the file never grows unbounded over months of
    runs - flakiness is about RECENT behavior, a result from months ago
    isn't relevant to whether a module is flaky today."""
    import json as _json
    from datetime import datetime as _datetime

    history_path = repo_root / "reports" / "test_run_history.json"
    history_path.parent.mkdir(exist_ok=True)
    try:
        history = _json.loads(history_path.read_text(encoding="utf-8")) if history_path.exists() else {}
    except Exception:
        history = {}
    key = f"{bank}/{module}"
    history.setdefault(key, [])
    history[key].append({"passed": passed, "timestamp": _datetime.now().isoformat(timespec="seconds")})
    history[key] = history[key][-10:]
    history_path.write_text(_json.dumps(history, indent=2), encoding="utf-8")


def detect_flaky_modules(repo_root: Path, min_runs: int = 3) -> list[dict]:
    """FEATURE: flaky test detector, part 2 - reads the history
    record_test_run_result has been accumulating and flags any module
    whose recent runs include BOTH a pass and a fail - that inconsistency
    is the actual signature of flakiness (a network blip, a timing race,
    a shared-state collision) as opposed to a real, consistently-broken
    test, which fails the SAME way every time. A module with fewer than
    min_runs recorded results is skipped - not enough history yet to
    tell flaky apart from "just failed once, first time seeing it".

    Returns a list of {"bank": ..., "module": ..., "pass_count": N,
    "fail_count": N, "recent": [True, False, True, ...]} dicts, one per
    flaky module found - empty list if none, or if no history exists
    yet at all (this is a genuinely empty result, not an error)."""
    import json as _json

    history_path = repo_root / "reports" / "test_run_history.json"
    if not history_path.exists():
        return []
    try:
        history = _json.loads(history_path.read_text(encoding="utf-8"))
    except Exception:
        return []

    flaky = []
    for key, runs in history.items():
        if len(runs) < min_runs:
            continue
        results = [r["passed"] for r in runs]
        if True in results and False in results:
            bank, _, module = key.partition("/")
            flaky.append({
                "bank": bank, "module": module,
                "pass_count": sum(results), "fail_count": len(results) - sum(results),
                "recent": results,
            })
    return flaky


def extract_failed_modules_from_pytest_output(pytest_output: str, candidate_modules: list[str]) -> list[str]:
    """Given a combined multi-module pytest output and the list of
    module names that were run together, returns just the subset that
    actually show a FAILED line - used by --full-auto to know exactly
    which modules to hand to run_with_auto_fix, rather than re-running
    every module's fix loop even for ones that already passed. A
    module name is considered failed if any line containing both
    "FAILED" and that module name appears in the output (matching how
    pytest's own -v output names each test, e.g.
    "src/testcase/<module>/test_<module>.py::...")."""
    failed = []
    for line in pytest_output.splitlines():
        if "FAILED" not in line:
            continue
        for module in candidate_modules:
            if module in line and module not in failed:
                failed.append(module)
    return failed





def main():
    ap = argparse.ArgumentParser(description="Generate locators/page/test/testdata from a plain-English scenario.")
    ap.add_argument("--bank", required=True)
    ap.add_argument("--module", required=True, help="e.g. brand, merchant")
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--url", default=None, help="Optional live URL for real selector inspection")
    ap.add_argument("--ref-dir", default=str(ROOT / "reference"),
                     help="Folder of real *.py files copied from your framework to teach conventions")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--storage-state", default=None,
                     help="Path to a saved Playwright login session (storage_state.json). "
                          "If given and it exists, inspect_url reuses it to reach login-required pages.")
    args = ap.parse_args()

    ref_dir = Path(args.ref_dir)
    if not ref_dir.exists() or not any(ref_dir.glob("*.py")):
        print(f"ERROR: no reference *.py files found in {ref_dir}")
        print("Copy a sample locators.py, page.py, and test_*.py from your real framework into that folder first.")
        sys.exit(1)

    ref_text = load_reference_files(ref_dir)
    storage_state_path = Path(args.storage_state) if args.storage_state else None
    page_html = inspect_url(args.url, storage_state_path) if args.url else ""
    user_prompt = build_user_prompt(args.bank, args.module, args.scenario, ref_text, page_html)

    print(f"Calling AI backend...")
    reply = ask_ai(SYSTEM_PROMPT, user_prompt)
    if not reply:
        print("ERROR: AI call failed or returned nothing. Check AI_BACKEND / API key / network and retry.")
        sys.exit(1)

    out_dir = Path(args.out_dir) if args.out_dir else ROOT / "generated_preview" / args.module
    out_dir.mkdir(parents=True, exist_ok=True)
    written = parse_and_write(reply, out_dir)

    if not written:
        print("WARNING: could not parse any ### FILE: blocks from the AI reply. Raw reply saved for inspection.")
        (out_dir / "raw_reply.txt").write_text(reply, encoding="utf-8")
    else:
        print(f"\nDone. Review the {len(written)} file(s) in {out_dir}, then copy each into its real "
              f"location in the framework (paths were printed above).")


if __name__ == "__main__":
    main()
