"""Repair an ALREADY GENERATED test file so it can run (no re-generation needed).

    python scripts\\repair_test.py src\\testcase\\binmanagement\\test_binmanagement.py

Fixes  AttributeError: 'TestX' object has no attribute 'binmanagement_page'  and every other  self.<page/bank>  that a test
reads but nothing assigns: each becomes a LOCAL variable created at the top of the test (the reference-chain style:
login_page = BankLoginPage(page); bin_page = BinmanagementPage(page); ...). A backup copy is saved first."""
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.generate_scenario import normalize_test_self_usage, ensure_module_conftest  # noqa: E402


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        return
    target = Path(sys.argv[1])
    if not target.is_absolute():
        target = (Path.cwd() / target).resolve()
    if not target.exists():
        print(f"File not found: {target}")
        return
    module = target.parent.name
    src = target.read_text(encoding="utf-8")
    bank = None
    if "--bank" in sys.argv:
        bank = sys.argv[sys.argv.index("--bank") + 1]
    else:                                                    # the bank comes from src\\config.yaml - no built-in default
        cfg = ROOT / "src" / "config.yaml"
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M) if cfg.exists() else None
        bank = m.group(1).strip("'\"") if m else None
    if not bank and not re.search(r"^BANK_NAME\s*=", src, re.M):
        print("The bank is not set in src\\config.yaml and the test file has no BANK_NAME - run again with  --bank <name>")
        return
    bank = bank or ""
    conf = ensure_module_conftest(ROOT, module, target)          # {{...}} tokens are replaced before every test
    if conf:
        print(f"conftest.py in place: {conf}")
    fixed, notes = normalize_test_self_usage(src, module, bank)
    if fixed == src:
        print("Nothing to repair: no test reads a self.<attribute> that is missing.")
        return
    backup = target.with_suffix(".py.bak")
    shutil.copy2(target, backup)
    target.write_text(fixed, encoding="utf-8")
    print(f"Repaired {target}\n(backup of the original: {backup})")
    for n in notes:
        print("  -", n)


if __name__ == "__main__":
    main()
