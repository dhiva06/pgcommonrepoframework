# clean_and_run.ps1
# Removes leftover/broken files from earlier attempts, then runs run_scenario.py.
# Usage:  .\scripts\clean_and_run.ps1 -Module brandtype -Bank wio

param(
    [Parameter(Mandatory=$true)][string]$Module,
    [Parameter(Mandatory=$true)][string]$Bank
)

Write-Host "Cleaning up any leftover files for module patterns matching '$Module' and 'brand'..." -ForegroundColor Cyan

# Kill Excel so testdata .xlsx files aren't locked
taskkill /F /IM EXCEL.EXE 2>$null | Out-Null

# Remove stray top-level test files from earlier empty/typo module names
Remove-Item "src\testcase\test_.py" -Force -ErrorAction SilentlyContinue
Remove-Item "src\testcase\test.py"  -Force -ErrorAction SilentlyContinue

# Remove any folder/file matching the module name or the word "brand" (broad safety net
# for past typo attempts) - adjust the "*brand*" pattern if you're working on a
# different module family and don't want this broad cleanup.
foreach ($pattern in @("*$Module*", "*brand*")) {
    Get-ChildItem "src\testcase\" -Filter $pattern -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Get-ChildItem "src\common\pages\" -Filter $pattern -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Get-ChildItem "src\banks\$Bank\locators\" -Filter $pattern -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem "src\banks\$Bank\testdata\" -Filter $pattern -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
}

# Clear Python bytecode cache
Get-ChildItem -Path . -Include __pycache__ -Recurse -Directory -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "Verifying cleanup..." -ForegroundColor Cyan
$leftover = Get-ChildItem "src\testcase\","src\common\pages\","src\banks\$Bank\locators\","src\banks\$Bank\testdata\" -Filter "*$Module*" -Recurse -ErrorAction SilentlyContinue
if ($leftover) {
    Write-Host "WARNING: some files still remain:" -ForegroundColor Yellow
    $leftover | ForEach-Object { Write-Host "  $($_.FullName)" }
} else {
    Write-Host "Clean." -ForegroundColor Green
}

Write-Host "`nStarting run_scenario.py..." -ForegroundColor Cyan
python scripts\run_scenario.py
