"""mini_agent.py - a lightweight "agent" using the Anthropic API directly,
for when the Claude Code CLI can't be installed (blocked download, IT
restrictions, offline machine, etc.).

This gives Claude the same kind of loop Claude Code itself uses: it can
run shell commands and read/write files in this repo, look at the real
result, and decide what to do next - repeated automatically across many
turns in ONE run of this script, instead of you copy-pasting output back
and forth in a chat.

Requires: ANTHROPIC_API_KEY set as an environment variable (see the
"API key without login" instructions you already have), and the
`anthropic` package installed (already in requirements.txt).

Built-in safety, per your requirements:
  - Asks y/n before EVERY command it runs or file it writes - never
    auto-approves.
  - Shows you exactly what it's about to run/change before asking.
  - Shows the full output/error after every command.
  - Hard-stops after MAX_PYTEST_ATTEMPTS pytest runs (default 2) - if it's
    still failing at that point, it must summarize and stop rather than
    keep trying a 3rd approach.
  - Can ask YOU a clarifying question mid-run (ask_user tool) when it hits
    genuine ambiguity, instead of silently guessing - types the question
    to the terminal, waits for your typed answer, then continues.

Usage:
    python scripts\\mini_agent.py "Run scripts\\auto_run_fix.py currency --bank wio.
    If it fails on the Configuration menu, try hover_native_by_getbytext then
    click_by_locator as fallback in currency_page.py, re-running after each change."

This is intentionally simple (a few hundred lines) - it is NOT a
replacement for Claude Code's full feature set (no built-in git awareness,
no IDE integration, no advanced sandboxing). It exists to unblock the one
specific workflow this framework needs: run -> observe -> fix -> re-run,
autonomously, with your explicit approval at each step.
"""
from __future__ import annotations

import difflib
import os
import subprocess
import sys
from pathlib import Path

try:
    import anthropic
except ImportError:
    print("ERROR: the 'anthropic' package isn't installed. Run:")
    print('  pip install "anthropic>=0.40.0,<1.0.0"')
    sys.exit(1)

REPO_ROOT = Path(__file__).resolve().parent.parent
MAX_PYTEST_ATTEMPTS = 2
MODEL = os.environ.get("MINI_AGENT_MODEL", "claude-sonnet-4-5-20250929")

SYSTEM_PROMPT = f"""You are an autonomous coding assistant working inside a
real Playwright + Python test automation repo at {REPO_ROOT}. You have four
tools: run_command (execute a shell command in this repo), read_file,
write_file (overwrite a file's full contents), and ask_user (ask the human
a clarifying question when you're genuinely blocked).

Rules you MUST follow:
- If you hit genuine ambiguity that you cannot resolve by reading files or
  running commands (e.g. two locators could both plausibly be the right
  one, an error message doesn't tell you which of several approaches to
  take, a value the task didn't specify is needed to proceed correctly),
  call ask_user with a clear, specific question BEFORE guessing. Do not
  call ask_user for things you can reasonably figure out yourself by
  reading the repo - only for real blockers. Once the user answers,
  continue the task using that answer; don't ask the same thing twice.
- Every run_command call whose command contains "pytest" or
  "auto_run_fix.py" counts as one "pytest attempt". You get a MAXIMUM of
  {MAX_PYTEST_ATTEMPTS} such attempts in this entire task. Track this
  yourself and count down out loud (e.g. "This is pytest attempt 1 of
  {MAX_PYTEST_ATTEMPTS}."). After attempt {MAX_PYTEST_ATTEMPTS}, if it is
  still failing, STOP - do not call run_command with pytest/auto_run_fix
  again. Instead write a final text summary: what you tried in each
  attempt, the exact final error, which file/line it's in, and what you
  believe is still wrong.
- Before making any code change, explain in one or two sentences WHY you
  believe it's the fix, referencing the actual error message you saw.
- Never claim something is fixed unless you have actually re-run it via
  run_command and seen the real pass/fail result in the tool output.
- Prefer the smallest change that could plausibly fix the observed error.
  Don't rewrite files wholesale when a one-line change would do.
- When you believe the task is complete (or you've hit the attempt cap),
  stop calling tools and give a plain-text final summary instead.
"""

TOOLS = [
    {
        "name": "run_command",
        "description": "Run a shell command in the repo root and return its stdout+stderr and exit code.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The shell command to run, e.g. 'python scripts\\\\auto_run_fix.py currency --bank wio'"},
            },
            "required": ["command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a file's full text content, given a path relative to the repo root.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path relative to the repo root, e.g. 'src/common/pages/currency/currency_page.py'"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Overwrite a file with new full content, given a path relative to the repo root. Creates the file if it doesn't exist.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path relative to the repo root"},
                "content": {"type": "string", "description": "The complete new content of the file"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "ask_user",
        "description": (
            "Ask the human a clarifying question when you're genuinely blocked "
            "and cannot proceed correctly without more information (e.g. two "
            "locators look equally plausible, an error is ambiguous about "
            "which fix to apply, a value isn't specified anywhere in the "
            "task or repo). Do NOT use this to ask permission to run a "
            "command or write a file - that's handled separately. Use "
            "sparingly; prefer figuring things out yourself first."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "The question to show the human in the terminal."},
                "options": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional short list of choices to display alongside the question.",
                },
            },
            "required": ["question"],
        },
    },
]


def ask_permission(prompt: str) -> bool:
    answer = input(f"\n{prompt}\n  Proceed? [y/n]: ").strip().lower()
    return answer == "y"


def run_command_tool(command: str) -> str:
    print(f"\n>>> Command: {command}")
    if not ask_permission("The agent wants to run the command above."):
        return "USER DECLINED to run this command. Do not retry the same command; ask a different question or try a different approach."
    result = subprocess.run(command, shell=True, cwd=str(REPO_ROOT), capture_output=True, text=True)
    output = (result.stdout or "") + (result.stderr or "")
    print(output[-3000:])  # tail is usually what matters
    print(f">>> Exit code: {result.returncode}")
    return f"Exit code: {result.returncode}\nOutput (may be truncated):\n{output[-6000:]}"


def read_file_tool(path: str) -> str:
    full_path = REPO_ROOT / path
    if not full_path.exists():
        return f"ERROR: file not found: {path}"
    return full_path.read_text(encoding="utf-8", errors="replace")


def write_file_tool(path: str, content: str) -> str:
    full_path = REPO_ROOT / path
    old_content = full_path.read_text(encoding="utf-8", errors="replace") if full_path.exists() else ""
    diff = "\n".join(difflib.unified_diff(
        old_content.splitlines(), content.splitlines(),
        fromfile=f"{path} (before)", tofile=f"{path} (after)", lineterm="",
    ))
    print(f"\n>>> Proposed change to: {path}")
    print(diff[:4000] if diff else "(new file, no prior content)")
    if not ask_permission("The agent wants to write the change above."):
        return "USER DECLINED this file change. Do not rewrite the same way; reconsider your approach."
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content, encoding="utf-8")
    print(f">>> Saved: {path}")
    return f"Saved successfully: {path}"


def ask_user_tool(question: str, options: list[str] | None = None) -> str:
    print(f"\n>>> The agent has a question and needs your input:")
    print(f"    {question}")
    if options:
        for i, opt in enumerate(options, 1):
            print(f"    {i}. {opt}")
    answer = input("Your answer: ").strip()
    if not answer:
        return "USER gave no answer (empty input). Ask again with a more specific question, or proceed with your best judgement and say so."
    return f"User answered: {answer}"


def call_tool(name: str, tool_input: dict) -> str:
    if name == "run_command":
        return run_command_tool(tool_input["command"])
    if name == "read_file":
        return read_file_tool(tool_input["path"])
    if name == "write_file":
        return write_file_tool(tool_input["path"], tool_input["content"])
    if name == "ask_user":
        return ask_user_tool(tool_input["question"], tool_input.get("options"))
    return f"ERROR: unknown tool {name}"


def main() -> None:
    if len(sys.argv) < 2:
        print('Usage: python scripts\\mini_agent.py "<task description>"')
        sys.exit(1)
    task = " ".join(sys.argv[1:])

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("ERROR: ANTHROPIC_API_KEY is not set. Set it first, e.g.:")
        print('  $env:ANTHROPIC_API_KEY = "sk-ant-api03-..."')
        sys.exit(1)

    client = anthropic.Anthropic(api_key=api_key)
    messages = [{"role": "user", "content": task}]

    print(f"=== mini_agent starting (model: {MODEL}, max pytest attempts: {MAX_PYTEST_ATTEMPTS}) ===")
    print(f"Task: {task}\n")

    while True:
        response = client.messages.create(
            model=MODEL,
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        text_parts = [block.text for block in response.content if block.type == "text"]
        if text_parts:
            print("\n--- Agent says ---")
            print("\n".join(text_parts))

        if response.stop_reason != "tool_use":
            print("\n=== mini_agent finished ===")
            break

        messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                result_text = call_tool(block.name, block.input)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result_text,
                })
        messages.append({"role": "user", "content": tool_results})


if __name__ == "__main__":
    main()
