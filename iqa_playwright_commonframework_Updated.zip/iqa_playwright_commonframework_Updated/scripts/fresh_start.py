"""fresh_start.py - put ONE module back to a clean slate, so run_scenario.py can generate EVERYTHING again from scratch.

    python scripts\\fresh_start.py binmanagement            (shows what will be moved, asks YES)
    python scripts\\fresh_start.py binmanagement --yes      (no question)
    python scripts\\fresh_start.py binmanagement --bank ecentric
    python scripts\\fresh_start.py binmanagement --include-shared   (when other banks use the same page / test code: move THAT too)

NOTHING IS DELETED: everything is MOVED to debug_logs\\backups\\fresh_start_<module>_<time>\\ (same folder structure), so you can
copy any file back. Moved: the module's locators, page folder, test folder (tests + conftest.py), Excel workbook (+ template / backups),
its reports and DOM snapshots, and its entries in runtime_data.json. When OTHER banks already have the module, the page and test code
(shared by all banks) and the module reports are KEPT, and only this bank's own files and runtime values are moved. NOT touched: base_page, login pages, runtime_data.py,
data_prepare.py, other modules, config.yaml, .env."""
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _bank_from_config() -> str | None:
    cfg = ROOT / "src" / "config.yaml"
    if cfg.exists():
        m = re.search(r"^bank:\s*(\S+)", cfg.read_text(encoding="utf-8"), re.M)
        if m:
            return m.group(1).strip("'\"")
    return None


def other_banks(module: str, bank: str) -> list[str]:
    """Banks (besides `bank`) that already have this module: their locators file or their workbook exists."""
    title = module[:1].upper() + module[1:]
    out = []
    banks = ROOT / "src" / "banks"
    for d in sorted(banks.iterdir()) if banks.exists() else []:
        if d.is_dir() and d.name != bank and ((d / "locators" / f"{module}_locators.py").exists() or (d / "testdata" / f"{title}.xlsx").exists()):
            out.append(d.name)
    return out


def collect(module: str, bank: str, include_shared: bool = True) -> list[Path]:
    title = module[:1].upper() + module[1:]
    items: list[Path] = []
    loc_dir = ROOT / "src" / "banks" / bank / "locators"
    items += sorted(loc_dir.glob(f"{module}_*locators.py"))
    if include_shared:                                  # the page + test folders are SHARED by every bank that has this module
        items += [ROOT / "src" / "common" / "pages" / module, ROOT / "src" / "testcase" / module]
    td = ROOT / "src" / "banks" / bank / "testdata"
    items += sorted(td.glob(f"{title}.*xlsx")) + sorted(td.glob(f"{title}.*.xlsx"))
    items += sorted((ROOT / "reports").glob(f"{module}_*")) if (ROOT / "reports").exists() and include_shared else []
    items += sorted((ROOT / "ai_debug_dom").glob(f"{bank}_{module}_*")) if (ROOT / "ai_debug_dom").exists() else []
    seen, out = set(), []
    for p in items:
        if p.exists() and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith("-"):
        print(__doc__)
        return 0
    module = argv[0].lower()
    bank = argv[argv.index("--bank") + 1] if "--bank" in argv and argv.index("--bank") + 1 < len(argv) else _bank_from_config()
    if not bank:
        print("The bank is not set in src\\config.yaml (bank: <name>) - run again with  --bank <name>")
        return 1
    others = other_banks(module, bank)
    include_shared = (not others) or "--include-shared" in argv
    if others and not include_shared:
        print(f"NOTE: the page and test code of '{module}' is SHARED with other bank(s): {', '.join(others)}. It is KEPT, so those banks "
              f"keep working - only {bank}'s own locators, test data, reports of this bank are moved.\n"
              f"      (To start the whole module over for ALL banks add  --include-shared)\n")
    items = collect(module, bank, include_shared)
    store = ROOT / "runtime_data.json"
    keys: list[str] = []
    if store.exists():
        try:
            keys = [k for k in json.loads(store.read_text(encoding="utf-8")) if k.startswith(f"{bank}.{module}.")]       # this bank's only
        except Exception:
            keys = []
    if not items and not keys:
        print(f"Nothing found for module '{module}' / bank '{bank}'.")
        return 0
    print(f"Module '{module}' / bank '{bank}' - these will be MOVED to a backup folder (nothing is deleted):")
    for p in items:
        print("   ", p.relative_to(ROOT) if p.is_relative_to(ROOT) else p, "(folder)" if p.is_dir() else "")
    for k in keys:
        print("    runtime_data.json entry:", k)
    if "--yes" not in argv and input("\nType YES to continue: ").strip() != "YES":
        print("Cancelled - nothing was changed.")
        return 0
    dest = ROOT / "debug_logs" / "backups" / f"fresh_start_{module}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    for p in items:
        target = dest / p.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.move(str(p), str(target))
        except PermissionError:
            print(f"   CANNOT MOVE {p.name}: it is open in another program (Excel?) - close it and run again.")
            return 1
    if keys:
        data = json.loads(store.read_text(encoding="utf-8"))
        dest.mkdir(parents=True, exist_ok=True)
        shutil.copy2(store, dest / "runtime_data.json")
        store.write_text(json.dumps({k: v for k, v in data.items() if k not in keys}, indent=2), encoding="utf-8")
    if include_shared:
        for pkg in (ROOT / "src" / "common" / "pages" / module, ROOT / "src" / "testcase" / module):
            pkg.mkdir(parents=True, exist_ok=True)     # empty packages, so the generated files import cleanly
            (pkg / "__init__.py").touch()
    print(f"\nMoved to {dest.relative_to(ROOT)}\\ . The module is now empty. Generate everything again:\n"
          f"    python scripts\\run_scenario.py\n    python scripts\\doctor.py {module}\n    python scripts\\run_tests.py {module}")
    return 0


if __name__ == "__main__":
    sys.exit(main())


