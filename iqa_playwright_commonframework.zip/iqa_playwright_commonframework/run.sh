#!/bin/bash
# Runs the whole suite using whatever bank/env/test_type is set in config.yaml
pytest src/testcase/
