"""
Root conftest.py:
  - filters collected tests to the configured bank (@pytest.mark.<bank>)
    and test_type (@pytest.mark.sanity / @pytest.mark.regression), both
    driven purely by config.yaml - dynamically registers a marker per
    folder under src/banks/
  - wraps every test with the ExtentReporter (start_test/end_test) so the
    final self-contained HTML report is built automatically
  - tracks TCID coverage (executed vs total defined for the bank) and
    prints a terminal summary at the end of the run
"""
import time
from pathlib import Path

import pytest

pytest_plugins = ["src.common.fixtures.browser_fixtures"]

from src.common.utilities.config_loader import ConfigManager, ConfigError, available_banks
from src.common.utilities.excel_utils import ExcelUtil, ExcelDataError
from src.common.utilities.extent_reporter import reporter

REPORTS_DIR = Path(__file__).resolve().parent / "reports"
_executed_tcids: set[str] = set()
_run_stamp = {"bank": "run", "timestamp": time.strftime("%Y%m%d_%H%M%S")}


def pytest_configure(config):
    config.addinivalue_line("markers", "sanity: quick smoke-level test case")
    config.addinivalue_line("markers", "regression: full regression-level test case")
    for bank_name in available_banks():
        config.addinivalue_line("markers", f"{bank_name}: test case applicable to the {bank_name} bank")

    try:
        _run_stamp["bank"] = ConfigManager.load_bank_config().get("bank", "run")
    except ConfigError:
        pass
    REPORTS_DIR.mkdir(exist_ok=True)


def pytest_sessionstart(session):
    try:
        cfg = ConfigManager.load_bank_config()
    except ConfigError as exc:
        pytest.exit(f"Config error - aborting run: {exc}", returncode=2)
        return
    try:
        ExcelUtil.check_tcid_uniqueness(cfg["bank"])
    except ExcelDataError as exc:
        pytest.exit(f"Test data error - aborting run: {exc}", returncode=2)


def pytest_collection_modifyitems(config, items):
    try:
        cfg = ConfigManager.load_bank_config()
    except ConfigError:
        return
    bank = cfg["bank"]
    test_type = cfg.get("test_type", "all")
    known_banks = set(available_banks())

    selected, deselected = [], []
    for item in items:
        item_bank_markers = {b for b in known_banks if item.get_closest_marker(b)}
        bank_mismatch = bool(item_bank_markers) and bank not in item_bank_markers
        type_mismatch = test_type != "all" and not item.get_closest_marker(test_type)

        if bank_mismatch or type_mismatch:
            deselected.append(item)
            continue
        selected.append(item)

    if deselected:
        items[:] = selected
        # Deliberately NOT calling config.hook.pytest_deselected(items=deselected)
        # here - firing that hook is what makes pytest print "N deselected" in
        # the terminal summary. Just trimming items[:] silently removes them
        # from the run with zero trace anywhere (terminal or report).


def _current_tcid(item) -> str:
    return getattr(item, "callspec", None) and item.callspec.id or item.name


@pytest.fixture(autouse=True)
def _extent_test_wrapper(request):
    tcid = _current_tcid(request.node)
    suite = request.node.cls.__name__ if request.node.cls else request.node.module.__name__.split(".")[-1]
    reporter.start_test(request.node.name, tcid, suite=suite)
    yield
    rep = getattr(request.node, "rep_call", None)
    status = "passed"
    if rep is not None:
        if rep.failed:
            status = "failed"
        elif rep.skipped:
            status = "skipped"
    else:
        rep_setup = getattr(request.node, "rep_setup", None)
        if rep_setup is not None and rep_setup.skipped:
            status = "skipped"
    reporter.end_test(status)
    if status != "skipped":
        _executed_tcids.add(tcid)


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)

    # Tests marked skip (via item.add_marker in pytest_collection_modifyitems)
    # never trigger the autouse fixture below - pytest skips fixture setup
    # entirely for them - so record skipped tests directly from this hook,
    # which fires unconditionally regardless of whether fixtures ran.
    if rep.when == "setup" and rep.skipped:
        tcid = _current_tcid(item)
        suite = item.cls.__name__ if item.cls else item.module.__name__.split(".")[-1]
        reporter.start_test(item.name, tcid, suite=suite)
        reporter.end_test("skipped")


def pytest_terminal_summary(terminalreporter, exitstatus, config):
    try:
        cfg = ConfigManager.load_bank_config()
    except ConfigError:
        return
    bank = cfg["bank"]
    test_type = cfg.get("test_type", "all")

    try:
        defined = ExcelUtil.all_tcids_for_bank(bank)
    except Exception:
        defined = {}

    terminalreporter.write_sep("=", f"TEST CASE COVERAGE ({bank.upper()})")
    total_defined = total_executed = 0
    for key, tcids in defined.items():
        sheet_total = len(tcids)
        sheet_executed = sum(1 for t in tcids if t in _executed_tcids)
        total_defined += sheet_total
        total_executed += sheet_executed
        pct = (sheet_executed / sheet_total * 100) if sheet_total else 0
        not_run = [t for t in tcids if t not in _executed_tcids]
        line = f"{key}: {sheet_executed}/{sheet_total} executed ({pct:.0f}%)"
        if not_run:
            line += f"  -> Not run: {', '.join(not_run)}"
        terminalreporter.write_line(line)

    overall_pct = (total_executed / total_defined * 100) if total_defined else 0
    terminalreporter.write_line(f"Overall: {total_executed}/{total_defined} ({overall_pct:.0f}%)")
    terminalreporter.write_sep("=")

    bank_reports_dir = REPORTS_DIR / bank
    bank_reports_dir.mkdir(parents=True, exist_ok=True)

    report_path = bank_reports_dir / f"{bank}_{test_type}_Automationreport_{_run_stamp['timestamp']}.html"
    reporter.generate_html(str(report_path), bank=bank, env=cfg.get("env", ""))
    terminalreporter.write_line(f"HTML report: {report_path}")

    failures_path = bank_reports_dir / f"{bank}_{test_type}_Automationreport_external_{_run_stamp['timestamp']}.html"
    reporter.generate_failure_screenshots_report(str(failures_path), bank=bank, env=cfg.get("env", ""))
    failed_count = sum(1 for t in reporter.tests if t.status == "failed")
    terminalreporter.write_line(f"Failure-screenshots report (all tests, {failed_count} failed w/ screenshots): {failures_path}")

    _maybe_send_report_email(cfg, bank, report_path, failures_path, failed_count, terminalreporter)


def _maybe_send_report_email(cfg, bank, report_path, failures_path, failed_count, terminalreporter):
    email_cfg = cfg.get("email") or {}
    if not email_cfg.get("enabled"):
        return
    if email_cfg.get("send_only_on_failure") and failed_count == 0:
        terminalreporter.write_line("Email skipped (send_only_on_failure=true, no failures this run)")
        return

    from src.common.utilities.email_reporter import send_report_email, build_summary_body

    passed = sum(1 for t in reporter.tests if t.status == "passed")
    skipped = sum(1 for t in reporter.tests if t.status == "skipped")
    total = len(reporter.tests)

    attachments = [str(report_path), str(failures_path)]

    status_word = "FAILED" if failed_count > 0 else "PASSED"
    subject = f"[{status_word}] Test Execution Report - {bank.upper()} - {passed}/{total} passed"
    body = build_summary_body(bank, cfg.get("env", ""), total, passed, failed_count, skipped)

    sent = send_report_email(
        recipients=email_cfg.get("recipients", []),
        subject=subject,
        body_html=body,
        attachments=attachments,
    )
    if sent:
        terminalreporter.write_line(f"Report email sent to: {', '.join(email_cfg.get('recipients', []))}")
    else:
        terminalreporter.write_line("Report email FAILED to send - check console log above for details")
