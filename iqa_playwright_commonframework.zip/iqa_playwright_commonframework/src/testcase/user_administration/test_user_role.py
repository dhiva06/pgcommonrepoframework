import pytest
from src.common.pages.authentication.admin_login_page import AdminLoginPage
from src.common.pages.user_administration.user_role_page import UserRolePage
from src.common.utilities.excel_utils import ExcelUtil
from src.common.utilities.config_manager import ConfigManager

BANK_NAME = ConfigManager.get("bank")

_rows = ExcelUtil.get_sheet("UserAdministration", "UserRole")

@pytest.mark.sanity
@pytest.mark.regression
class TestUserRoleModule:
    @pytest.mark.parametrize(
        "data",
        _rows,
        ids=[f'{data["ScenarioID"]} - {data["TestcaseID"]} - {data["Description"]}' for data in _rows]
    )
    def test_user_role_add(self, page, data):
        """Verify the add functionality of User Role"""
        # Portal is module‑specific → AdminLoginPage
        login_page = AdminLoginPage(page)
        login_page.login(BANK_NAME)
        login_page.assert_dashboard_visible()

        role_page = UserRolePage(page)
        role_page.navigate_to_user_role(BANK_NAME)
        role_page.click_add_button(BANK_NAME)
        role_page.click_save_button(BANK_NAME)
        role_page.assert_role_error_message(BANK_NAME, data["ExpectedMessage"])
