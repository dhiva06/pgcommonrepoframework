from src.common.pages.authentication.base_login_page import BaseLoginPage
from src.banks.neoleap.locators.login_locators import NeoleapLoginLocators
from src.banks.oab.locators.login_locators import OabLoginLocators
#from src.banks.alrajhi.locators.login_locators import AlrajhiLoginLocators
from src.banks.wio.locators.login_locators import WioLoginLocators
from src.banks.pinelabs.locators.login_locators import PinelabsLoginLocators

BANK_LOCATORS = {
    "neoleap": NeoleapLoginLocators.Admin,
    "oab": OabLoginLocators.Admin,
#   "alrajhi": AlrajhiLoginLocators.Admin,
    "wio": WioLoginLocators.Admin,
    "pinelabs": PinelabsLoginLocators.Admin,
    "oab": OabLoginLocators.Admin,

}

class AdminLoginPage(BaseLoginPage):
    def login(self, bank: str) -> None:
        creds = self.navigate_to_portal("admin")
        loc = BANK_LOCATORS[bank.lower()]
        self._login_standard(creds, loc)

    def assert_dashboard_visible(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.assert_visible(self.locator(loc.dashboard_marker), f"{bank.capitalize()} Admin Dashboard")
