from src.common.base.base_page import BasePage
from src.common.utilities.config_loader import ConfigManager
from src.common.utilities.captcha_utility import CaptchaUtility

class BaseLoginPage(BasePage):
    def __init__(self, page, module_name="Login"):
        super().__init__(page, module_name=module_name)

    def navigate_to_portal(self, portal: str) -> dict:
        creds = dict(ConfigManager.load_portal_config(portal))
        self.navigate(creds["url"])
        return creds

    def _login_standard(self, creds: dict, loc) -> None:
        self.click_by_locator(loc.login_button, "Login button")
        self.fill_by_locator(loc.username_field, creds["username"], "Username")
        self.fill_by_locator(loc.password_field, creds["password"], "Password")
        self.click_by_locator(loc.submit_button, "Login button")

    def _login_with_institution(self, creds: dict, loc) -> None:
        self.fill_by_locator(loc.institution_field, creds["institution_id"], "Institution ID")
        self.fill_by_locator(loc.username_field, creds["username"], "User ID")
        self.fill_by_locator(loc.password_field, creds["password"], "Password")
        self.click_by_locator(loc.login_button, "Login button")

    def _login_with_merchant(self, creds: dict, loc) -> None:
        self.fill_by_locator(loc.institution_name_field, creds["institution_name"], "Institution Name")
        self.fill_by_locator(loc.merchant_id_field, creds["merchant_id"], "Merchant ID")
        self.fill_by_locator(loc.username_field, creds["username"], "User ID")
        self.fill_by_locator(loc.password_field, creds["password"], "Password")
        self.click_by_locator(loc.login_button, "Login button")

    def _login_with_captcha(self, creds: dict, loc) -> None:
        max_attempts = 5
        for attempt in range(max_attempts):
            self.fill_by_locator(loc.username_field, creds["username"], "User ID")
            self.fill_by_locator(loc.password_field, creds["password"], "Password")

            captcha_image = self.page.locator(loc.captcha_image)
            captcha_image.wait_for(state="visible", timeout=5000)
            captcha_image.screenshot(path="captcha.png")

            captcha_text = CaptchaUtility.solve_captcha("captcha.png")

            captcha_input = self.page.locator(loc.captcha_field)
            captcha_input.click(click_count=3)
            captcha_input.press_sequentially(captcha_text, delay=50)

            self.click_by_locator(loc.login_button, "Login Button")

            captcha_error = self.page.locator(loc.captcha_error)
            try:
                captcha_error.wait_for(state="visible", timeout=5000)
                if attempt == max_attempts - 1:
                    raise Exception("Login failed after maximum captcha retry attempts.")
                self.click_by_locator(loc.captcha_refresh, "Captcha Refresh")
                self.page.wait_for_timeout(1000)
                continue
            except Exception:
                return
