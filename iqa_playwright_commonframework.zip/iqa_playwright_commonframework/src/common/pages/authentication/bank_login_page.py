from src.common.pages.authentication.base_login_page import BaseLoginPage
from src.banks.neoleap.locators.login_locators import NeoleapLoginLocators
from src.banks.oab.locators.login_locators import OabLoginLocators
from src.banks.alrajhi.locators.login_locators import AlrajhiLoginLocators
from src.banks.wio.locators.login_locators import WioLoginLocators
from src.banks.pinelabs.locators.login_locators import PinelabsLoginLocators
from src.banks.ecentric.locators.login_locators import EcentricLoginLocators

BANK_LOCATORS = {
    "neoleap": ("institution", NeoleapLoginLocators.Bank),
    "oab": ("standard", OabLoginLocators.Bank),
    "alrajhi": ("standard", AlrajhiLoginLocators.Bank),
    "wio": ("standard", WioLoginLocators.Bank),
    "pinelabs": ("standard", PinelabsLoginLocators.Bank),
    "ecentric": ("captcha", EcentricLoginLocators.Bank),
}

class BankLoginPage(BaseLoginPage):
    def login(self, bank: str) -> None:
        creds = self.navigate_to_portal("bank")
        mode, loc = BANK_LOCATORS[bank.lower()]
        if mode == "institution":
            self._login_with_institution(creds, loc)
        elif mode == "standard":
            self._login_standard(creds, loc)
        elif mode == "captcha":
            self._login_with_captcha(creds, loc)

    def assert_dashboard_visible(self, bank: str) -> None:
        _, loc = BANK_LOCATORS[bank.lower()]
        self.assert_visible(self.locator(loc.dashboard_marker), f"{bank.capitalize()} Bank Dashboard")
