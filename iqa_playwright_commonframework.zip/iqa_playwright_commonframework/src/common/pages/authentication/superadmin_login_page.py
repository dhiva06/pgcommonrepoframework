from src.common.pages.authentication.base_login_page import BaseLoginPage
from src.banks.neoleap.locators.login_locators import NeoleapLoginLocators

BANK_LOCATORS = {
    "neoleap": NeoleapLoginLocators.SuperAdmin,
}

class SuperAdminLoginPage(BaseLoginPage):
    def login(self, bank: str) -> None:
        creds = self.navigate_to_portal("superadmin")
        loc = BANK_LOCATORS[bank.lower()]
        self._login_standard(creds, loc)

    def assert_dashboard_visible(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.assert_visible(self.locator(loc.dashboard_marker), f"{bank.capitalize()} SuperAdmin Dashboard")
