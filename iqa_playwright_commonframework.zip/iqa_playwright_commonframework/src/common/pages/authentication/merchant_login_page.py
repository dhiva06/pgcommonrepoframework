from src.common.pages.authentication.base_login_page import BaseLoginPage
from src.banks.neoleap.locators.login_locators import NeoleapLoginLocators
from src.banks.oab.locators.login_locators import OabLoginLocators
from src.banks.alrajhi.locators.login_locators import AlrajhiLoginLocators
from src.banks.ecentric.locators.login_locators import EcentricLoginLocators

BANK_LOCATORS = {
    "neoleap": ("merchant", NeoleapLoginLocators.Merchant),
    "oab": ("merchant", OabLoginLocators.Merchant),
    "alrajhi": ("merchant", AlrajhiLoginLocators.Merchant),
    "ecentric": ("captcha", EcentricLoginLocators.Merchant),
}

class MerchantLoginPage(BaseLoginPage):
    def login(self, bank: str) -> None:
        creds = self.navigate_to_portal("merchant")
        mode, loc = BANK_LOCATORS[bank.lower()]
        if mode == "merchant":
            self._login_with_merchant(creds, loc)
        elif mode == "captcha":
            self._login_with_captcha(creds, loc)

    def assert_dashboard_visible(self, bank: str) -> None:
        _, loc = BANK_LOCATORS[bank.lower()]
        self.assert_visible(self.locator(loc.dashboard_marker), f"{bank.capitalize()} Merchant Dashboard")
