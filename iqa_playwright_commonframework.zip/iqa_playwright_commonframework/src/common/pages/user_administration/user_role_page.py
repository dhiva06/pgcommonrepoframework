from src.common.base.base_page import BasePage
from src.banks.neoleap.locators.user_role_locators import UserRoleLocators as NeoleapUserRoleLocators
from src.banks.oab.locators.user_role_locators import UserRoleLocators as OabUserRoleLocators
from src.banks.alrajhi.locators.user_role_locators import UserRoleLocators as AlrajhiUserRoleLocators
from src.banks.wio.locators.user_role_locators import UserRoleLocators as WioUserRoleLocators
from src.banks.pinelabs.locators.user_role_locators import UserRoleLocators as PinelabsUserRoleLocators
from src.banks.ecentric.locators.user_role_locators import UserRoleLocators as EcentricUserRoleLocators

BANK_LOCATORS = {
    "neoleap": NeoleapUserRoleLocators,
    "oab": OabUserRoleLocators,
    "alrajhi": AlrajhiUserRoleLocators,
    "wio": WioUserRoleLocators,
    "pinelabs": PinelabsUserRoleLocators,
    "ecentric": EcentricUserRoleLocators,
}

class UserRolePage(BasePage):
    def __init__(self, page, module_name="UserRole"):
        super().__init__(page, module_name=module_name)

    def navigate_to_user_role(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.menu_myaccount, f"{bank} My Account menu")
        self.click_by_locator(loc.menu_userrole, f"{bank} User Role menu")

    def click_add_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.add_button, "Add Role button")

    def click_save_button(self, bank: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.click_by_locator(loc.save_button, "Save Role button")

    def assert_role_error_message(self, bank: str, expected_message: str) -> None:
        loc = BANK_LOCATORS[bank.lower()]
        self.assert_text(self.locator(loc.error_message), expected_message, "Role error message")
