class WioLoginLocators:
    class Admin:
        login_button = "//span[contains(text(),'Login')]"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        submit_button = "input[name='button']"

    class Bank:
        institution_field = "input[name='instId']"
        username_field = "input[name='userId']"
        password_field = "input[name='password']"
        login_button = "button#login"
