import pytest
import allure
from pages.bank.terminal_page import TerminalPage
from utils.excel_utils import ExcelUtil


@allure.feature("Terminal Creation")
class TestTerminal:

    terminal_data = ExcelUtil.get_sheet("Datasheet", "Terminal")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", terminal_data)
    def test_terminal_add(self, page, data):

        terminal = TerminalPage(page)

        terminal.open_login(data["url"])

        terminal.login(
            data["user_id"],
            data["password"]
        )

        terminal.navigate_terminal()

        terminal.fill_terminal_details(
            data["bank_code"],
            data["terminal_id"],
            data["terminal_name"]
        )

        terminal.configure_plugin(
            data["success_url"],
            data["error_url"]
        )

        terminal.configure_processing()

        terminal.save_terminal()

        terminal.logout()