import pytest
import allure
from pages.admin.user_role_page import UserRolePage
from utils.excel_utils import ExcelUtil


@allure.feature("User Role Creation")
class TestUserRole:

    role_data = ExcelUtil.get_sheet("Datasheet", "UserRole")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", role_data)
    def test_user_role_creation(self, page, data):

        role = UserRolePage(page)

        role.open_login(data["url"])

        role.login(
            data["admin_user"],
            data["admin_password"]
        )

        role.navigate_user_role()

        role.click_add_role()

        role.fill_user_role_details(data)

        role.save_role()

        role.validate_role_created()

        role.logout()