import pytest
import allure
from pages.transaction.jpyAuth_txn_page import jpyAuth_txn
from utils.excel_utils import ExcelUtil


class TestHTGFlows:

    test_data = ExcelUtil.get_sheet("Datasheet", "htgAuthTxn")

    payment_id = None  # 🔥 shared across tests

    @pytest.mark.flaky(reruns=2)
    @pytest.mark.parametrize("data", test_data)
    @allure.feature("HTGAuth Transaction Flows")
    def test_flows(self, page, data):

        txn = jpyAuth_txn(page)

        # 🔹 AUTH FLOW
        if data["flow"] == "AUTH":

            txn.open_homepage(data["url"])
            txn.select_product(data["product"])
            txn.select_action(data["action"])

            txn.enter_merchant_details(
                data["tranportal_id"],
                data["tranportal_pwd"],
                data["resource_key"]
            )

            txn.click_buy()

            txn.enter_card_details(data)
            

            # txn.select_currency(data["currency"])
            txn.click_pay()
            txn.handle_3ds()

            # txn.verify_status(data["expected_status"])

            #  Capture Payment ID
            TestHTGFlows.payment_id = txn.get_payment_id()
            assert TestHTGFlows.payment_id.isdigit()

        # 🔹 INQUIRY / CAPTURE / VOID FLOWS
        else:
            assert TestHTGFlows.payment_id is not None, "Run AUTH first"

            txn.open_homepage(data["url"])
            txn.select_product(data["product"])
            txn.select_action(data["action"])

            txn.select_udf("PaymentID")
            txn.enter_comment(TestHTGFlows.payment_id)

            txn.enter_merchant_details(
                data["tranportal_id"],
                data["tranportal_pwd"],
                data["resource_key"]
            )

            txn.click_buy()
            txn.verify_status(data["expected_status"])