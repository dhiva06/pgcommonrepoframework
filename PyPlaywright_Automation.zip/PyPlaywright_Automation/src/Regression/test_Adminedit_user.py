import pytest
import allure
from pages.admin.edit_user_page import EditUserPage
from utils.excel_utils import ExcelUtil


@allure.feature("Edit User")
class TestEditUser:

    edit_user_data = ExcelUtil.get_sheet("Datasheet", "EditUser")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", edit_user_data)
    def test_edit_user(self, page, data):

        user = EditUserPage(page)

        user.open_login(data["url"])

        user.login(
            data["admin_user"],
            data["admin_password"]
        )

        user.navigate_create_user()

        user.search_user(
            data["search_user"],
            data["role"]
            )

        user.edit_user(data["new_username"])

        user.save_user()

        user.logout()