class EditUserLocators:

    ADMIN_USER = "#adminuserId"
    ADMIN_PASSWORD = "#adminpassword"

    SEARCH_DROPDOWN = "cuselFrame-cuSel-0"
    SEARCH_VALUE = "#nameValue"

    EDIT_USERNAME = ("role", "textbox", {"name": "Minimum Length : 5, Maximum"})