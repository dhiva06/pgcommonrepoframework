class TransactionLocators:

    # Homepage
    BODY_SOAPS_LINK = ("role", "link", {"name": "Body Soaps"})
    CHOCOLATES_LINK = ("role", "link", {"name": "Chocolates"})
    PURCHASE_BUTTON = ("role", "button", {"name": "Purchase"})
    BUY_BUTTON = ("role", "button", {"name": "Buy"})

    # Dropdowns
    AUTH_DROPDOWN = 'select[name="action"]'
    UDF5_DROPDOWN = 'select[name="udf5"]'
    COMMENT_FIELD = 'input[name="comment"]'

    # Credentials
    TRANPORTAL_ID = 'input[name="tranportalID"]'
    TRANPORTAL_PWD = 'input[name="tranportalPwd"]'
    RESOURCE_KEY = 'input[name="ResourceKey"]'

    # Card details
    CURRENCY_LIST = "#currencyConversionList"

    # OTP iframe
    OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'

    # Payment ID
    PAYMENT_ID = "//td[normalize-space()='Payment ID']/following-sibling::td"