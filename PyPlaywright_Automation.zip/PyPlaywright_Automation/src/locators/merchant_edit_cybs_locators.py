class MerchantEditCYBSLocators:

    USERNAME = "#instuserId"
    PASSWORD = "#instpassword"

    SEARCH_VALUE = "#columnValue"

    TRAN_ROUTE = "select[name='tranRoute']"

    CYBS_MERCHANT_ID = ("role", "textbox", {
        "name": "Minimum Length :1 , Maximum Length : 30, Type : Alphanumeric"
    })

    CYBS_KEY_ID = "#cybsKeyId"
    CYBS_KEY = "#cybsKey"