from playwright.sync_api import Page


class PaymentNegativeLocators:

    def __init__(self, page: Page):
        self.page = page

    # -------------------------------
    # Product Selection
    # -------------------------------
    def product(self, product_name):
        return self.page.get_by_role("cell", name=product_name, exact=True)

    PURCHASE_BUTTON = "role=button[name='Purchase']"

    # -------------------------------
    # Merchant Details
    # -------------------------------
    TRANPORTAL_ID = "input[name='tranportalID']"
    RESOURCE_KEY = "input[name='ResourceKey']"
    BUY_BUTTON = "role=button[name='Buy']"

    # -------------------------------
    # Card Details
    # -------------------------------
    CARD_NUMBER = "//input[@id='creditCardNumber']"
    EXPIRY_DATE = "//input[@id='creditExpiry']"
    CARD_HOLDER = "//input[@id='creditCardholderName']"
    CVV = "//input[@id='cardCvv']"

    PAY_BUTTON = "//*[@id='proceed_button']"

    # -------------------------------
    # Error Messages
    # -------------------------------
    CARD_ERROR = "//p[contains(@class,'errorReason')]"

    EXPIRY_ERROR = "//div[@id='ExpiryMandatory']"

    CVV_ERROR = "//div[@id='CVVMandatory']"

    ERROR_LOCATORS = {
        "Please enter valid Card Number": CARD_ERROR,
        "Please Enter Expiry Date.": EXPIRY_ERROR,
        "Please Enter CVV.": CVV_ERROR,
      
        
    }