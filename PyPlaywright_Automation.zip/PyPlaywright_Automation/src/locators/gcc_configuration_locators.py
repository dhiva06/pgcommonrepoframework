class GCCConfigurationLocators:
    HEADING = ("role", "heading", {})
    SEARCH_BY_DROPDOWN = ("css", "#searchBy")
    GCC_CELL = ("role", "cell", {"name": "BNFT1"})
    EDIT_ICON = ("css", "tr:nth-child(10) > td:nth-child(5) > a:nth-child(2)")
    ISSUER_TEXTBOX = ("role", "textbox", {"name": "Minimum Length : 1 ,Maximum"})
    SAVE_BUTTON = ("role", "button", {"name": "Save"})
    SUCCESS_ALERT = ("role", "alert", {})
