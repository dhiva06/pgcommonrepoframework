class DeclinedCardsLocators:

    USER_ID = "#instuserId"
    PASSWORD = "#instpassword"

    CARD_NUMBER = "#cardNumber1"