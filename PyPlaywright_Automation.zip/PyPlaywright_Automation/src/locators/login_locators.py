
class LoginLocators:
    Login_Button = "//li[@class='login']"
    Admin_User_Id = "//input[@id='adminuserId']"
    Admin_Password = "//input[@id='adminpassword']"
    Bank_User_Id = "//input[@id='instuserId']"
    Bank_Password = "//input[@id='instpassword']"
    Submit_Button = "//input[@value='Submit']"
    Reset_Button = "//input[@value='Reset']"
    Home_Page = "text=Home"
    Error_Message = "text=Invalid credentials"  # Example negative login message
    Logout_Button = "//li[@class='logout']"
