class COPTransactionLocators:

    # Credentials
    TRANPORTAL_ID = 'input[name="tranportalID"]'
    TRANPORTAL_PWD = 'input[name="tranportalPwd"]'
    RESOURCE_KEY = 'input[name="ResourceKey"]'
    EPP_AMT = 'input[name="eppAmount"]'
    TERMSANDCONDITIONURL = 'input[name="issuerTermsAndCondition"]'

    # Supporting txn
    ACTION_DROPDOWN = 'select[name="action"]'
    UDF5_DROPDOWN = 'select[name="udf5"]'
    COMMENT_FIELD = 'input[name="comment"]'

    # Payment ID
    PAYMENT_ID = "//td[normalize-space()='Payment ID']/following-sibling::td"

    # Currency
    CURRENCY = "#currencyConversionList"

    # OTP
    OTP_IFRAME_EPP='//*[@id="content"]/div[2]/form[1]/input[1]]'
    OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'
    Dhiram_Symbol_AR = '//*[@id="proceed_button"]/span[2]/span/img'
    Dhiram_Symbol_ARAmount='//*[@id="buyeramtvalue"]/label/span/span/img'