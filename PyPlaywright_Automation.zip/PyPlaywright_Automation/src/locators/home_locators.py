
class HomeLocators:
    CONFIGURATION_LINK = ("role", "link", {"name": "Configuration"})
    GCC_CONFIGURATION_LINK = ("role", "link", {"name": "GCC CONFIGURATION"})
    LOGOUT_LINK = ("role", "link", {"name": "Logout"})
