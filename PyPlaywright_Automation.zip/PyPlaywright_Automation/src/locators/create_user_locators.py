class CreateUserLocators:

    ADMIN_USER = "#adminuserId"
    ADMIN_PASSWORD = "#adminpassword"

    USER_NAME = ("role", "textbox", {"name": "Minimum Length : 2, Maximum Length : 25 , Type : Alphabetic with space"})
    LOGIN_ID = ("role", "textbox", {"name": "Minimum Length : 2, Maximum Length : 25 , Type : Alphanumeric"})
    PASSWORD = ("role", "textbox", {"name": "Minimum Length : 5, Maximum"})
    EMAIL = ("role", "textbox", {"name": "Maximum Length : 45 , Type :"})
    MOBILE = ("role", "textbox", {"name": "Minimum Length : 11, Maximum"})
    ROLE_DROPDOWN= "cuselFrame-cuSel-0"