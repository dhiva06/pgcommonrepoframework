class TestIDs:
    USERNAME = "username-input"
    PASSWORD = "password-input"
    LOGIN = "login-btn"
    DASHBOARD_TITLE = "dashboard-title"
    USER_MENU = "user-menu"
    LOGOUT = "logout-btn"
