class TerminalLocators:

    LOGIN_LINK = ("role", "link", {"name": "Login"})
    USER_ID = "#instuserId"
    PASSWORD = "#instpassword"
    SUBMIT_BUTTON = ("role", "button", {"name": "Submit"})

    CONFIGURATION_LINK = ("role", "link", {"name": "Configuration"})
    TERMINAL_LINK = ("role", "link", {"name": "Terminal"})
    ADD_BUTTON = ("role", "button", {"name": "Add"})

    SELECT_TERMINAL = ("role", "textbox", {"name": "- Select -"})

    TERMINAL_ID_FIELD = ("role", "textbox", {"name": "Minimum Length : 2 , Maximum"})
    TERMINAL_NAME_FIELD = ("role", "textbox", {"name": "Minimum Length : 5 , Maximum"})

    INSTRUMENT_TAB = ("role", "link", {"name": "Instruments & Actions"})
    PLUGIN_TAB = ("role", "link", {"name": "Plugin"})

    SUCCESS_URL = ("role", "textbox", {"name": "Maximum Length : 255 , Type:"})
    ERROR_URL = ("role", "textbox", {"name": "Maximum Length : 255 , Type : Alphanumeric, Sample: https://www.enbdmerch.com"})

    GENERATE_KEY = ("role", "button", {"name": "Generate Key"})

    EXTERNAL_CONNECTION = ("role", "link", {"name": "External Connection"})
    PROCESSING_OPTIONS = ("role", "link", {"name": "Processing Options & Action"})

    SAVE_BUTTON = ("role", "button", {"name": "Save"})
    LOGOUT = ("role", "link", {"name": "Logout"})