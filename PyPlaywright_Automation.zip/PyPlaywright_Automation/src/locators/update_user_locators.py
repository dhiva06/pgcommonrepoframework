class UpdateUserLocators:

    INST_USER = "#instuserId"
    INST_PASSWORD = "#instpassword"

    SEARCH_DROPDOWN = "#cuselFrame-cuSel-0 div"
    SEARCH_VALUE = "#nameValue"

    EDIT_USERNAME = ("role", "textbox", {"name": "Minimum Length : 5, Maximum"})