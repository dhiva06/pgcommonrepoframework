class MerchantLocators:

    LOGIN_LINK = "role=link[name='Login']"

    USER_ID = "#instuserId"
    PASSWORD = "#instpassword"
    SUBMIT = "role=button[name='Submit']"

    CONFIGURATION = "role=link[name='Configuration']"
    MERCHANT = "role=link[name='Merchant']"

    ADD_BUTTON = "role=button[name='Add']"

    MERCHANT_ID = "xpath=(//input[@type='text'])[1]"
    MERCHANT_NAME = "xpath=(//input[@type='text'])[2]"

    SELECT_DROPDOWN = "text=- Select -"
    SELECT_OPTION = ".select2-results__option"

    WEBSITE = "xpath=(//input[@type='text'])[3]"
    RETURN_URL = "xpath=(//input[@type='text'])[4]"

    NUMERIC1 = "xpath=(//input[@type='text'])[5]"
    NUMERIC2 = "xpath=(//input[@type='text'])[6]"

    ADDRESS_TAB = "text=Address"
    ADDRESS = "#address1"
    COUNTRY = "#country"

    PIN1 = "xpath=(//input[@type='text'])[7]"
    PIN2 = "xpath=(//input[@type='text'])[8]"

    CONTACT_TAB = "text=Contact"
    CONTACT_NAME = "xpath=(//input[@type='text'])[9]"
    EMAIL = "xpath=(//input[@type='text'])[10]"
    PHONE = "xpath=(//input[@type='text'])[11]"

    SAVE = "role=button[name='Save']"
    LOGOUT = "role=link[name='Logout']"