class TerminalUploadLocators:

    LOGIN_LINK = ("role", "link", {"name": "Login"})
    USER_ID = "#instuserId"
    PASSWORD = "#instpassword"
    SUBMIT_BUTTON = ("role", "button", {"name": "Submit"})

    CONFIGURATION_LINK = ("role", "link", {"name": "Configuration"})
    TERMINAL_UPLOAD_LINK = ("role", "link", {"name": "Terminal  Upload"})

    CHOOSE_FILE = ("role", "button", {"name": "Choose File"})
    VALIDATE_BUTTON = ("role", "button", {"name": "Validate"})

    VALIDATION_MESSAGE = "text=xClose Validation Failed"

    LOGOUT_LINK = ("role", "link", {"name": "Logout"})