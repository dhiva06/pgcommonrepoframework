class NegativeCardLocators:

    USERNAME = "#instuserId"
    PASSWORD = "#instpassword"

    CARD_NUMBER = "#cardNumber1"