class DKKTransactionLocators:

    # Product
    BODY_SOAPS = ("role", "link", {"name": "Body Soaps"})
    CHOCOLATES = ("role", "link", {"name": "Chocolates"})

    # Buttons
    PURCHASE_BTN = ("role", "button", {"name": "Purchase"})
    BUY_BTN = ("role", "button", {"name": "Buy"})

    # Credentials
    TRANPORTAL_ID = 'input[name="tranportalID"]'
    TRANPORTAL_PWD = 'input[name="tranportalPwd"]'
    RESOURCE_KEY = 'input[name="ResourceKey"]'

    # Card Details
    CARD_NUMBER = ("label", "Card Number")
    EXPIRY = ("label", "Expiry Date")
    CARD_NAME = ("label", "Card Holders Name")
    CVV = ("label", "CVV")

    CURRENCY_DROPDOWN = "#currencyConversionList"

    # 3DS
    STEPUP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'
    OTP_FIELD = ("role", "textbox", {})
    SUBMIT_BTN = ("role", "button", {"name": "submit"})

    # Alerts / Messages
    APPROVED_TEXT = "APPROVED"
    CAPTURED_TEXT = "CAPTURED"
    VOIDED_TEXT = "VOIDED"

    PAYMENT_ID = "//td[normalize-space()='Payment ID']/following-sibling::td"

    # Supporting Txn
    ACTION_DROPDOWN = 'select[name="action"]'
    UDF5_DROPDOWN = 'select[name="udf5"]'
    COMMENT_FIELD = 'input[name="comment"]'

    SEND_ANYWAY_BTN = ("role", "button", {"name": "send anyway"})