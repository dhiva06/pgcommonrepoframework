class UserRoleLocators:

    ADMIN_USER = "#adminuserId"
    ADMIN_PASSWORD = "#adminpassword"

    ROLE_NAME = ("role", "textbox", {"name": "Minimum Length : 5 , Maximum Length : 25 , Type : Alphanumeric"})
    DISPLAY_NAME = ("role", "textbox", {"name": "Minimum Length : 5 , Maximum Length : 25 , Type : Alphabetic"})