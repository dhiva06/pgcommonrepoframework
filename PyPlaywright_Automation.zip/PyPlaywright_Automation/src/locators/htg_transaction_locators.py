class HTGTransactionLocators:

    # Credentials
    TRANPORTAL_ID = 'input[name="tranportalID"]'
    TRANPORTAL_PWD = 'input[name="tranportalPwd"]'
    RESOURCE_KEY = 'input[name="ResourceKey"]'

    # Supporting txn
    ACTION_DROPDOWN = 'select[name="action"]'
    UDF5_DROPDOWN = 'select[name="udf5"]'
    COMMENT_FIELD = 'input[name="comment"]'

    # Payment ID
    PAYMENT_ID = "//td[normalize-space()='Payment ID']/following-sibling::td"

    # Currency
    CURRENCY = "#currencyConversionList"

    # OTP
    OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'