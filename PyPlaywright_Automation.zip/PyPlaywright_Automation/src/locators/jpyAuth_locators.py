class JpyAuthLocators:

    # 🔹 Navigation / Product
    PRODUCT_LINK = lambda product: ("role", "link", product)
    PURCHASE_BTN = ("role", "button", "Purchase")

    # 🔹 Dropdowns
    ACTION_DROPDOWN = "select[name='action']"
    UDF_DROPDOWN = "select[name='udf5']"

    # 🔹 Inputs
    COMMENT = "input[name='comment']"
    TRANPORTAL_ID = "input[name='tranportalID']"
    TRANPORTAL_PWD = "input[name='tranportalPwd']"
    RESOURCE_KEY = "input[name='ResourceKey']"
    Amount= "input[name='amount']"

    # 🔹 Buttons
    BUY_BTN = ("role", "button", "Buy")
    PAY_BTN = ("role", "button", "Pay")

    # 🔹 Card Fields
    CARD_NUMBER = ("role", "textbox", "Card Number")
    EXPIRY = ("role", "textbox", "Expiry Date")
    CARD_NAME = ("role", "textbox", "Card Holders Name")
    CVV = ("role", "textbox", "CVV")

    # 🔹 Currency
    CURRENCY = "#currencyConversionList"

    # 🔹 Status / Text
    STATUS_TEXT = lambda text: ("text", text)

    # 🔹 Payment ID
    PAYMENT_ID = "//td[normalize-space()='Payment ID']/following-sibling::td"

    # 🔹 3DS
    THREE_DS_IFRAME = "iframe[name^='cardinal-stepUpIframe']"
    
    OTP_IFRAME = 'iframe[name^="cardinal-stepUpIframe"]'