class MerchantEditLocators:

    USERNAME = "#instuserId"
    PASSWORD = "#instpassword"

    SEARCH_VALUE = "#columnValue"

    TRAN_ROUTE = "select[name='tranRoute']"
    MPGS_MERCHANT_ID = "#mpgsmerchantid"
    MPGS_PASSWORD = "#mpgspassword"