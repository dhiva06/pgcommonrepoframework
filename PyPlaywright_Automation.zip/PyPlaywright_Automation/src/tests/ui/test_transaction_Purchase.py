import pytest
import allure
from pages.transaction.transaction_page import TransactionPage
from utils.excel_utils import ExcelUtil


@allure.feature("Transaction Flow")
class TestTransaction:

    # Load Excel data
    txn_data = ExcelUtil.get_sheet("Datasheet", "Pur_TXN")

    @pytest.mark.regression
    def test_transaction_flow(self, page):

        txn = TransactionPage(page)

        # -------- PURCHASE --------
        purchase_data = self.txn_data[0]

        txn.open_merchant_demo(purchase_data["url"])

        txn.start_purchase(purchase_data["product_name"])

        txn.fill_credentials(
            purchase_data["tranportal_id"],
            purchase_data["tranportal_pwd"],
            purchase_data["resource_key"]
        )

        txn.submit_buy()

        txn.complete_card_payment(
            purchase_data["card_number"],
            purchase_data["expiry"],
            purchase_data["card_holder"],
            purchase_data["cvv"],
            purchase_data["currency"]
        )

        txn.handle_otp(purchase_data["otp"])

        payment_id = txn.verify_approved_and_get_pid()

        print("Payment ID:", payment_id)

        # -------- SUPPORTING TRANSACTIONS --------
        for data in self.txn_data:

            txn.open_merchant_demo(data["url"])

            txn.start_purchase(data["supporting_product"])

            txn.perform_supporting_transaction(
                data["action_code"],
                payment_id,
                data["expected_status"],
                data
            )