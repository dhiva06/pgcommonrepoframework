import pytest
import allure
from pages.bank.terminal_upload_page import TerminalUploadPage
from utils.excel_utils import ExcelUtil


@allure.feature("Terminal Upload")
class TestTerminalUpload:

    upload_data = ExcelUtil.get_sheet("Datasheet", "TerminalUpload")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", upload_data)
    def test_terminal_upload(self, page, data):

        upload = TerminalUploadPage(page)

        upload.open_login(data["url"])

        upload.login(
            data["user_id"],
            data["password"]
        )

        upload.navigate_terminal_upload()

        upload.upload_terminal_file(data["file_path"])

        upload.validate_file()

        upload.logout()