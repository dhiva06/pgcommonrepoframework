import pytest
import allure
from pages.bank.negative_card_page import NegativeCardPage
from utils.excel_utils import ExcelUtil


@allure.feature("Negative Card")
class TestNegativeCard:

    test_data = ExcelUtil.get_sheet("Datasheet", "NegativeCard")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", test_data)
    def test_negative_card(self, page, data):

        nc = NegativeCardPage(page)

        nc.open_login(data["url"])

        nc.login(
            data["username"],
            data["password"]
        )

        nc.navigate_negative_card()

        nc.search_card(data["card_number"])

        nc.validate_result(data["expected_result"])

        nc.logout()