import pytest
import allure
from pages.bank.merchant_upload_page import MerchantUploadPage
from utils.excel_utils import ExcelUtil


@allure.feature("Merchant Upload")
class TestMerchantUpload:

    upload_data = ExcelUtil.get_sheet("Datasheet", "MerchantUpload")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", upload_data)
    def test_merchant_upload(self, page, data):

        upload = MerchantUploadPage(page)

        upload.open_login(data["url"])

        upload.login(
            data["user_id"],
            data["password"]
        )

        upload.navigate_to_upload()

        upload.upload_file(data["file_path"])

        upload.validate_file()

        upload.logout()