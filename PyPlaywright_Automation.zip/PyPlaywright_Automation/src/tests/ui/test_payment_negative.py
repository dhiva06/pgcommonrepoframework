import pytest
import allure
from pages.transaction.payment_negative import Payment_negative
from utils.excel_utils import ExcelUtil


class TestPaymentNegative:

    payment_data = ExcelUtil.get_sheet("Datasheet", "PaymentNegative")

    @pytest.mark.regression
    @pytest.mark.negative
    @pytest.mark.flaky(reruns=2, reruns_delay=2)  
    @pytest.mark.parametrize("data", payment_data)
    @allure.feature("Payment Negative Scenarios")
    def test_payment_negative(self, page, data):

        txn = Payment_negative(page)

        # Step 1: Navigate
        txn.navigate(data["url"])

        # Step 2: Product selection
        txn.select_product_and_purchase(data["product"])

        # Step 3: Merchant details
        txn.enter_merchant_details(
            data["tranportal_id"],
            data["resource_key"]
        )

        txn.click_buy()

        # Step 4: Card details
        txn.enter_card_details(
            data["card"],
            data["expiry"],
            data["name"],
            data["cvv"]
        )

        txn.click_pay()

        # Step 5: Validation
        # txn.verify_error(data["expected_error"])