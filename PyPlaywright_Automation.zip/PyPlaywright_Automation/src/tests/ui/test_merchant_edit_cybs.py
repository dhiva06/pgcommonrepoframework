import pytest
import allure
from pages.bank.merchant_edit_cybs_page import MerchantEditCYBSPage
from utils.excel_utils import ExcelUtil


@allure.feature("Merchant Edit CYBS")
class TestMerchantEditCYBS:

    test_data = ExcelUtil.get_sheet("Datasheet", "MerchantEditCYBS")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", test_data)
    def test_edit_merchant_cybs(self, page, data):

        merchant = MerchantEditCYBSPage(page)

        merchant.open_login(data["url"])

        merchant.login(
            data["username"],
            data["password"]
        )

        merchant.navigate_to_merchant()

        merchant.search_merchant(data["merchant_id"])

        merchant.open_edit()

        merchant.update_cybs_details(data)

        merchant.save()

        merchant.validate_update(data["expected_result"])

        merchant.logout()