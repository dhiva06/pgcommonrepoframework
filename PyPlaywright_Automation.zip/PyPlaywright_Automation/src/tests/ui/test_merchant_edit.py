import pytest
import allure
from pages.bank.merchant_edit_page import MerchantEditPage
from utils.excel_utils import ExcelUtil


@allure.feature("Merchant Edit")
class TestMerchantEdit:

    test_data = ExcelUtil.get_sheet("Datasheet", "MerchantEdit")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", test_data)
    def test_edit_merchant(self, page, data):

        merchant = MerchantEditPage(page)

        merchant.open_login(data["url"])

        merchant.login(
            data["username"],
            data["password"]
        )

        merchant.navigate_to_merchant()

        merchant.search_merchant(data["merchant_id"])

        merchant.edit_merchant(data)

        merchant.save_merchant()

        merchant.validate_update(data["expected_result"])

        merchant.logout()