import pytest
import allure
from pages.bank.update_user_page import UpdateUserPage
from utils.excel_utils import ExcelUtil


@allure.feature("Update User")
class TestUpdateUser:

    update_user_data = ExcelUtil.get_sheet("Datasheet", "UpdateUser")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", update_user_data)
    def test_update_user(self, page, data):

        user = UpdateUserPage(page)

        user.open_login(data["url"])

        user.login(
            data["inst_user"],
            data["inst_password"]
        )

        user.navigate_create_user()

        user.search_user(data["search_user"])

        user.update_user(data["new_username"])

        user.save_user()

        user.logout()