import pytest
import allure
from pages.bank.declined_cards_page import DeclinedCardsPage
from utils.excel_utils import ExcelUtil


@allure.feature("Declined Cards Search")
class TestDeclinedCards:

    declined_data = ExcelUtil.get_sheet("Datasheet", "DeclinedCards")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", declined_data)
    def test_declined_card_search(self, page, data):

        declined = DeclinedCardsPage(page)

        declined.open_login(data["url"])

        declined.login(
            data["user_id"],
            data["password"]
        )

        declined.navigate_declined_cards()

        declined.search_card(data["card_number"])

        declined.validate_no_records()

        declined.logout()