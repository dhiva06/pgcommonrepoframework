import pytest
import allure
from pages.bank.merchant_page import MerchantPage
from utils.excel_utils import ExcelUtil


class TestMerchant:

    merchant_data = ExcelUtil.get_sheet("Datasheet", "merchant")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", merchant_data)
    @allure.feature("Merchant")
    def test_add_merchant(self, page, data):

        merchant = MerchantPage(page)

        merchant.login(
            data["Bank_url"],
            data["Bank_userId"],
            data["Bank_password"]
        )

        merchant.navigate_to_merchant()

        merchant.click_add()

        merchant.fill_merchant_details(data)

        merchant.fill_address(data)

        merchant.fill_contact(data)

        merchant.save_merchant()

        merchant.logout()