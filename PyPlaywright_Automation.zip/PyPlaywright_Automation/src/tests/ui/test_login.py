import pytest
import allure
from pages.login.login_page import LoginPage
from utils.excel_utils import ExcelUtil

class TestLogin:
    # Load test data from Excel 
    login_data = ExcelUtil.get_sheet("Datasheet", "login")
    print("Loaded login_data:", login_data)

    @pytest.mark.regression_sanity
    @pytest.mark.sanity
    @pytest.mark.parametrize("data", login_data)
    @allure.feature("Login")
    def test_adminLogin(self, page, data):
        login = LoginPage(page)
        login.navigate(data["Admin_url"])
        login.enter_LoginDetails(data["Admin_userId"],data["Admin_password"])
        # login.click_login_button()
        # login.enter_adminuser_id(data["Admin_userId"])
        # login.enter_adminpassword(data["Admin_password"])
        # login.click_submit()
        # login.assert_login_result(data["expected_result"])
        # login.click_logout_button()
    
    # #@pytest.mark.skip(reason="Skipping this test for now")
    # @pytest.mark.regression
    # @pytest.mark.sanity 
    # @pytest.mark.parametrize("data", login_data)
    # @allure.feature("Login")
    # def test_bankLogin(self, page, data):
    #     login = LoginPage(page)
    #     login.navigate(data["Bank_url"])
    #     login.click_login_button()
    #     login.enter_bankuser_id(data["Bank_userId"])
    #     login.enter_bankpassword(data["Bank_password"])
    #     login.click_submit()
    #     login.assert_login_result(data["expected_result"])
    #     login.click_logout_button()    
    
        
    
