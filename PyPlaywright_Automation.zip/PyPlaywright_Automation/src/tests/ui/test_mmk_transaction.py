import pytest
import allure
from pages.transaction.htg_transaction_page import HTG_TransactionPage
from utils.excel_utils import ExcelUtil
from utils.OracleSQL import execute_oracle_query


@allure.feature("MMK Transaction Flow")
class TestMMKTransaction:

    data = ExcelUtil.get_sheet("Datasheet", "MMK_TXN")

    @pytest.fixture(scope="class")
    def payment_id(self, browser):

        context = browser.new_context()
        page = context.new_page()

        txn = HTG_TransactionPage(page)
        d = self.data[0]

        txn.open_url(d["url"])
        txn.start_purchase(d["product"])

        txn.fill_credentials(d)
        txn.click_buy()

        txn.enter_card_details(d)
        # txn.click_pay_button()
        txn.handle_otp(d["otp"])

        pid = txn.get_payment_id()

        # DB Validation
        rows = execute_oracle_query(
            f"SELECT RESPONSE_CODE FROM TRANLOG WHERE PAYMENT_ID = {pid}"
        )

        print("DB Result:", rows)

        context.close()

        return pid

    # -------------------------
    def test_payment_created(self, payment_id):
        assert len(payment_id) >= 10

    # -------------------------
    @pytest.mark.parametrize("data", data)
    def test_supporting_txn(self, page, payment_id, data):

        txn = HTG_TransactionPage(page)

        txn.open_url(data["url"])
        txn.start_purchase(data["supporting_product"])

        txn.supporting_txn(
            data["action_code"],
            payment_id,
            data["expected_status"],
            data
        )