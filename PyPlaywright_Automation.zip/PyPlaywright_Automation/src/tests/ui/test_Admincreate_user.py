import pytest
import allure
from pages.admin.create_user_page import CreateUserPage
from utils.excel_utils import ExcelUtil


@allure.feature("Create User")
class TestCreateUser:

    user_data = ExcelUtil.get_sheet("Datasheet", "CreateUser")

    @pytest.mark.sanity
    @pytest.mark.parametrize("data", user_data)
    def test_create_user(self, page, data):

        user = CreateUserPage(page)

        user.open_login(data["url"])

        user.login(
            data["admin_user"],
            data["admin_password"]
        )

        user.navigate_create_user()

        user.click_add_user()

        user.fill_user_details(data)

        user.save_user()

        user.logout()