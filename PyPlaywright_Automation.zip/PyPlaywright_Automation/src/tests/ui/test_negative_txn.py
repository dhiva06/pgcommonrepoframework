import pytest
import allure
from pages.transaction.negativeDemo_txn_page import negativeDemo_txn
from utils.excel_utils import ExcelUtil


class TestNegativeTxn:

    # 🔹 Load Excel Data
    txn_data = ExcelUtil.get_sheet("Datasheet", "NegativeTxn")

    @pytest.mark.regression
    @pytest.mark.negative
    @pytest.mark.parametrize("data", txn_data)
    @allure.feature("Negative Transactions")
    def test_negative_transactions(self, page, data):

        txn = negativeDemo_txn(page)

        # Step 1: Navigate
        txn.navigate(data["url"])

        # Step 2: Select product
        txn.select_product_and_purchase(data["product"])

        # Step 3: Enter tranportal_id (can be empty)
        txn.enter_tranportal_id(data["tranportal_id"])

        # Step 4: Click Buy
        txn.click_buy()

        # Step 5: Validate Error
        txn.verify_error_message(data["expected_error"])