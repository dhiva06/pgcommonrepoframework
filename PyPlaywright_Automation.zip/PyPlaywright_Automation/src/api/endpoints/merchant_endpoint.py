# api/endpoints/merchant_endpoint.py

from api.client.api_client import APIClient
from api.payloads.merchant_payload import MerchantPayload
from utils.config import MERCHANT_ENDPOINT


class MerchantAPI:

    @staticmethod
    def create_merchant():

        token = APIClient.generate_token()

        payload = MerchantPayload.create_merchant_payload()

        response = APIClient.post(
            url=MERCHANT_ENDPOINT,
            payload=payload,
            token=token
        )

        return response