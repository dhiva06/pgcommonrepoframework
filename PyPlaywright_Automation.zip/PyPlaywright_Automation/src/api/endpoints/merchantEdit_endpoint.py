# api/endpoints/merchant_endpoint.py

from api.client.api_client import APIClient
from api.payloads.merchant_payload import MerchantPayload
from utils.config import MERCHANT_ENDPOINT


class MerchantAPIEdit:

    @staticmethod
    def edit_merchant(merchant_id, updated_data):

        token = APIClient.generate_token()

        payload = MerchantPayload.edit_merchant_payload(updated_data)

        response = APIClient.put(
            url=f"{MERCHANT_ENDPOINT}/{merchant_id}",
            payload=payload,
            token=token
        )

        return response