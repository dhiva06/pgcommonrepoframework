# api/client/api_client.py

import requests
from utils.config import TOKEN_URL, USERNAME, PASSWORD
from core.logger import get_logger

logger = get_logger("APIClient")


class APIClient:

    @staticmethod
    def generate_token():

        payload = {
            "username": USERNAME,
            "password": PASSWORD
        }

        headers = {
            "Content-Type": "application/json"
        }

        response = requests.post(
            TOKEN_URL,
            json=payload,
            headers=headers
        )

        logger.info(f"Token API Status Code: {response.status_code}")
        logger.info(f"Token API Response: {response.text}")

        assert response.status_code == 200

        token = response.json()["access_token"]

        return token

    @staticmethod
    def post(url, payload, token):

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }

        response = requests.post(
            url,
            json=payload,
            headers=headers
        )

        logger.info(f"POST API URL: {url}")
        logger.info(f"POST API Request: {payload}")
        logger.info(f"POST API Response: {response.text}")

        return response