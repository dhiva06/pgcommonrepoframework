# api/tests/test_create_merchant.py

import pytest
import allure

from api.endpoints.merchant_endpoint import MerchantAPI


@allure.feature("Merchant API")
class TestCreateMerchant:

    @pytest.mark.api
    @pytest.mark.sanity
    def test_create_merchant(self):

        response = MerchantAPI.create_merchant()

        assert response.status_code == 200

        response_text = response.text

        assert "Merchant created sucessfully" in response_text

        print("Merchant Created Successfully")