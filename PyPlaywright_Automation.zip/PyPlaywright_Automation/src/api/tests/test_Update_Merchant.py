# api/tests/test_update_merchant.py

import pytest
import allure

from api.endpoints.merchant_endpoint import MerchantAPI


@allure.feature("Merchant API")
class TestUpdateMerchant:

    @pytest.mark.api
    @pytest.mark.sanity
    def test_update_merchant(self):

        response = MerchantAPI.edit_merchant(merchant_id="1234567", updated_data={"merchantBusinessName": "Updated Merchant Name"})

        assert response.status_code == 200

        response_text = response.text

        assert "Merchant updated successfully" in response_text

        print("Merchant Updated Successfully")