import allure
from utils.api_client import APIClient
from utils.config import BASE_URL
from utils.data_loader import load_payload

client = APIClient(BASE_URL)

@allure.feature("User API")
@allure.story("Create User")
def test_create_user():

    payload = load_payload("src/data/payloads.json", "create_user")

    response = client.post("/users", payload)

    assert response.status_code == 201

    json_data = response.json()

    assert json_data["name"] == "Aravindan"