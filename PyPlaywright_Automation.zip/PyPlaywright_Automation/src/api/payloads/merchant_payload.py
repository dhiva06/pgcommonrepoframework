# api/payloads/merchant_payload.py

class MerchantPayload:

    @staticmethod
    def create_merchant_payload():

        payload = {
            "merchantId": "1234567",
            "merchantBusinessName": "WIO merchant",
            "merchantCategory": "1234",
            "currencyCode": "784",
            "websiteName": "WIO merch",
            "websiteAddress": "https://www.wio.com",
            "transactionRouting": "MPGS",
            "mpgsMerchantId": "gc52uf52hk34v6",
            "mpgsPassword": "d7st79tdgsd8tga08s",
            "frmFlag": "no",
            "currencyConversionFlag": "yes",
            "currencyConversion": "MCP",
            "aftFlag": "no",
            "method": "POST",
            "status": "Active",
            "city": "chennai",
            "state": "TamilNadu",
            "country": "India",
            "isoCountryCode": "123",
            "zipcode": "600001",
            "contactName": "WIO",
            "contactEmail": "wio@gmail.com",
            "mobileNumber": "12345678901",
            "ipAddress": "10.10.101.10",
            "userId": "MADMAX",
            "faxNo": "12345"
        }

        return payload
    
    @staticmethod
    def edit_merchant_payload(updated_data):

        payload = {
            "merchantId": "1234567",
            "merchantBusinessName": "WIO merchant",
            "merchantCategory": "1234",
            "currencyCode": "784",
            "websiteName": "WIO merch",
            "websiteAddress": "https://www.wio.com",
            "transactionRouting": "MPGS",
            "mpgsMerchantId": "gc52uf52hk34v6",
            "mpgsPassword": "d7st79tdgsd8tga08s",
            "frmFlag": "no",
            "currencyConversionFlag": "yes",
            "currencyConversion": "MCP",
            "aftFlag": "no",
            "method": "POST",
            "status": "Active",
            "city": "chennai",
            "state": "TamilNadu",
            "country": "India",
            "isoCountryCode": "123",
            "zipcode": "600001",
            "contactName": "WIO",
            "contactEmail": "wio@gmail.com",
            "mobileNumber": "12345678901",
            "ipAddress": "10.10.101.10",
            "userId": "MADMAX",
            "faxNo": "12345"
        }

        return payload