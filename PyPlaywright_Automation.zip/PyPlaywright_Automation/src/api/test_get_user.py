import pytest
import allure
from utils.api_client import APIClient
from utils.config import BASE_URL

client = APIClient(BASE_URL)


@allure.feature("User API")
@allure.story("Get User")
@allure.title("Verify GET user API")
def test_get_user():

    response = client.get("/users/2")

    assert response.status_code == 200

    json_data = response.json()

    assert json_data["data"]["id"] == 2
    assert "email" in json_data["data"]