import oracledb
import os

# Initialize thick mode FIRST (before any connection)
oracledb.init_oracle_client(lib_dir=r"C:\Oracle\instantclient-basic-windows.x64-23.26.1.0.0\instantclient_23_0")

class OracleDB:
    def __init__(self, user, password, dsn):
        self.user = user
        self.password = password
        self.dsn = dsn
        self.connection = None

    def connect(self):
        self.connection = oracledb.connect(
            user=self.user,
            password=self.password,
            dsn=self.dsn
        )
        return self.connection

    def execute_query(self, query):
        with self.connection.cursor() as cursor:
            cursor.execute(query)
            return cursor.fetchall()

    def close(self):
        if self.connection:
            self.connection.close()


def execute_oracle_query(query):
    db = OracleDB(
        "PG_PINELABS_BANK_NEW",
        "PG_PineLabs_Bank123#",
        "10.136.4.176:1521/SITDB1_pdb1.data.dntvcn.oraclevcn.com"
    )
    db.connect()
    print("Connected to Oracle Database")
    #rows = db.execute_query("SELECT RESPONSE_CODE FROM TRANLOG WHERE TRAN_ID = '202425710711031'")
    rows = db.execute_query(query)
    print("Rows fetched:", rows)

    if not rows:
        print("No rows found in DB")
    else:
        print("Response Codes:")
        for r in rows:
            print("RESPONSE_CODE =", r[0])

    db.close()
    return rows
