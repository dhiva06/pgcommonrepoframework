# utils/config.py
TESTDATA_DIR = r"D:\\Automation\\Pinelabs_Automation\\New_Pinelabs\\PyPlaywright_Automation\\PyPlaywright_Automation\\src\\data"  # only the file path
EXCEL_FILE_PATH = f"{TESTDATA_DIR}\\Datasheet.xlsx"  # directory for excel files
#BASE_URL = "https://reqres.in/api"

# utils/config.py

BASE_URL = "http://10.136.2.146:8320/FSS_PG_iPay_WIO"

TOKEN_URL = f"{BASE_URL}/paybylink/v1/generateJWTToken"

MERCHANT_ENDPOINT = f"{BASE_URL}/api/v1/merchant"

USERNAME = "PINEUSER123"
PASSWORD = "PINEPASS123"