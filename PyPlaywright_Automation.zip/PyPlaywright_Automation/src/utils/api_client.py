import requests
import allure
import logging

logger = logging.getLogger(__name__)

class APIClient:

    def __init__(self, base_url):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json"
        }

    @allure.step("GET Request to {endpoint}")
    def get(self, endpoint, params=None):
        url = self.base_url + endpoint
        response = requests.get(url, headers=self.headers, params=params)

        logger.info(f"GET {url}")
        logger.info(f"Response: {response.status_code} {response.text}")

        allure.attach(response.text, name="Response", attachment_type=allure.attachment_type.JSON)

        return response

    @allure.step("POST Request to {endpoint}")
    def post(self, endpoint, payload=None):
        url = self.base_url + endpoint
        response = requests.post(url, headers=self.headers, json=payload)

        logger.info(f"POST {url}")
        logger.info(f"Payload: {payload}")
        logger.info(f"Response: {response.status_code} {response.text}")

        allure.attach(response.text, name="Response", attachment_type=allure.attachment_type.JSON)

        return response