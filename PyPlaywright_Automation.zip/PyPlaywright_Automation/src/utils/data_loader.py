import json

def load_payload(file_path, key):
    with open(file_path) as f:
        data = json.load(f)
        return data[key]