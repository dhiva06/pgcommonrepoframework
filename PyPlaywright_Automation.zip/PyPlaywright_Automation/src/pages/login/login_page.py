import allure
from playwright.sync_api import Page
from pytest_playwright.pytest_playwright import page
from pages.base_page import BasePage
from locators.login_locators import LoginLocators


class LoginPage(BasePage):  
    def __init__(self, page: Page):
        super().__init__(page)

    @allure.step("Click Login button")
    def click_login_button(self):
        self.click_by_locator(LoginLocators.Login_Button, description="Login button")

    @allure.step("Enter login Details")
    def enter_LoginDetails(self, user_id: str,password: str):
        self.click_by_locator(LoginLocators.Login_Button, description="Login button")
        self.fill_by_locator(LoginLocators.Admin_User_Id, user_id, description="User ID")
        self.fill_by_locator(LoginLocators.Admin_Password, password, description="Password")
        self.click_by_getbyrole(LoginLocators.Submit_Button, description="Submit button")    
        
    @allure.step("Enter User ID")
    def enter_adminuser_id(self, user_id: str):
        self.fill(LoginLocators.Admin_User_Id, user_id, description="User ID")
        
    @allure.step("Enter Password")
    def enter_adminpassword(self, password: str):
        self.fill(LoginLocators.Admin_Password, password, description="Password")
        
    @allure.step("Enter User ID")
    def enter_bankuser_id(self, user_id: str):
        self.fill(LoginLocators.Bank_User_Id, user_id, description="User ID")
        
    @allure.step("Enter Password")
    def enter_bankpassword(self, password: str):
        self.fill(LoginLocators.Bank_Password, password, description="Password")
        
    @allure.step("Click Submit button")
    def click_submit(self):
        self.click_by_getbyrole(LoginLocators.Submit_Button, description="Submit button")
        
    @allure.step("Home page verification")
    def verify_home_page(self):
        self.assert_visible(LoginLocators.Home_Page, description="Home Page")
        
    @allure.step("Verify login result")
    def assert_login_result(self, expected_result="success"):
        if expected_result.lower() == "success":
            dashboard = self.page.locator(LoginLocators.Home_Page)
            dashboard.wait_for(state="visible", timeout=15000)
            assert dashboard.is_visible(), "Login failed but expected success"
            self.attach_screenshot("Dashboard visible")
        else:
            error_msg = self.page.locator(LoginLocators.Error_Message)
            error_msg.wait_for(state="visible", timeout=10000)
            assert error_msg.is_visible(), "Error message not shown for invalid login"
            self.attach_screenshot("Error message visible")
            
    @allure.step("Click Logout button")
    def click_logout_button(self):
        self.click(LoginLocators.Logout_Button, description="Logout button")
