import allure
from pathlib import Path
from playwright.sync_api import Page, expect
from pages.base_page import BasePage
from locators.merchant_upload_locators import MerchantUploadLocators


class MerchantUploadPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="MerchantUpload")

    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    @allure.step("Login to Bank Portal")
    def login(self, user_id, password):

        self.click_by_getbytext("Login", "Click Login")

        self.fill_by_locator(
            MerchantUploadLocators.USER_ID,
            user_id,
            "Enter User ID"
        )

        self.fill_by_locator(
            MerchantUploadLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_getbytext("Submit", "Click Submit")

    @allure.step("Navigate to Merchant Upload")
    def navigate_to_upload(self):

        self.hover_by_getbytext("Configuration", "Hover Configuration")

        self.click_by_getbytext("Merchant  Upload", "Click Merchant Upload")

    @allure.step("Upload Merchant File")
    def upload_file(self, file_path):

        file_path = str(Path(file_path).resolve())

        with self.page.expect_file_chooser() as fc_info:
            self.click_by_getbytext("Choose File", "Click Choose File")

        file_chooser = fc_info.value

        file_chooser.set_files(file_path)

        self.attach_screenshot("File Uploaded")

    @allure.step("Validate Uploaded File")
    def validate_file(self):

        self.click_by_getbytext("Validate", "Click Validate")

        expect(
            self.page.get_by_text("xClose Validation Failed")
        ).to_be_visible(timeout=10000)

        self.attach_screenshot("Validation Result")

    @allure.step("Logout")
    def logout(self):

        self.click_by_getbytext("Logout", "Click Logout")