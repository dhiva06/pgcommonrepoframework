import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.negative_card_locators import NegativeCardLocators


class NegativeCardPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="NegativeCard")

    # ---------------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Login to Application")
    def login(self, username, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            NegativeCardLocators.USERNAME,
            username,
            "Enter Username"
        )

        self.fill_by_locator(
            NegativeCardLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Login Successful")

    # ---------------------------------
    @allure.step("Navigate to Negative Card (Declined Cards)")
    def navigate_negative_card(self):

        self.hover_by_role("link", re.compile(r"Risk(\s|\xa0)*Configuration"))

        self.click_by_role("link", re.compile(r"Declined(\s|\xa0)*Cards"))

        self.attach_screenshot("Navigated to Negative Card Page")

    # ---------------------------------
    @allure.step("Search Card Number")
    def search_card(self, card_number):

        self.fill_by_locator(
            NegativeCardLocators.CARD_NUMBER,
            card_number,
            "Enter Card Number"
        )

        self.click_by_role("button", "Search")

        self.attach_screenshot("Clicked Search")

    # ---------------------------------
    @allure.step("Validate Search Result")
    def validate_result(self, expected_result):

        expected_result = expected_result.strip().lower()

        # --- IF ELSE ASSERTION ---
        if expected_result == "no records found":

            self.assert_visible(
                self.page.get_by_text("No records found"),
                "No Records Found"
            )

        elif expected_result == "records found":

            self.assert_visible(
                self.page.locator("table"),
                "Records Found Table"
            )

        else:
            raise ValueError(f"Invalid expected result: {expected_result}")

    # ---------------------------------
    @allure.step("Logout")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logout Successful")