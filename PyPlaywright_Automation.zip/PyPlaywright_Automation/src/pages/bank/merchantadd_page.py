from playwright.sync_api import Page

class MerchantPage:
    def __init__(self, page: Page):
        self.page = page
        # Define locators
        self.configuration_link = page.get_by_role("link", name="Configuration", exact=True)
        self.merchant_link = page.get_by_role("link", name="Merchant", exact=True)
        self.add_button = page.get_by_role("button", name="Add")

    # Actions
    def navigate_to_merchantAddpage(self):
        """Hover Configuration → Click Merchant"""
        self.configuration_link.hover()
        self.merchant_link.click()

    def click_add_button(self):
        """Click the Add button"""
        self.add_button.click()
