import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.terminal_locators import TerminalLocators


class TerminalPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="Terminal")

    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    @allure.step("Login to Bank Portal")
    def login(self, user_id, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            TerminalLocators.USER_ID,
            user_id,
            "Enter User ID"
        )

        self.fill_by_locator(
            TerminalLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.page.get_by_role("button", name="Submit").click()

    @allure.step("Navigate to Terminal Page")
    def navigate_terminal(self):

        self.hover_by_role("link", "Configuration")

        self.click_by_role("link", "Terminal")
        self.click_by_role("button", "Add")


        self.attach_screenshot("Opened Create User Page")

        # self.page.get_by_role("link", name="Configuration").hover()

        # self.page.get_by_role("link", name="Terminal").click()

        # self.page.get_by_role("button", name="Add").click()

    @allure.step("Fill Terminal Basic Details")
    def fill_terminal_details(self, bank_code, terminal_id, terminal_name):

        self.page.get_by_role("textbox", name="- Select -").click()

        self.page.wait_for_selector(".select2-results__option")

        self.page.locator(".select2-results__option", has_text=bank_code).click()

        self.page.get_by_role(
            "textbox",
            name="Minimum Length : 2 , Maximum"
        ).fill(terminal_id)

        self.page.get_by_role(
            "textbox",
            name="Minimum Length : 5 , Maximum"
        ).fill(terminal_name)

    @allure.step("Configure Plugin Settings")
    def configure_plugin(self, success_url, error_url):

        self.page.get_by_role("link", name="Instruments & Actions").click()

        self.page.get_by_role("link", name="Plugin").click()

        self.page.get_by_role(
            "textbox",
            name="Maximum Length : 255 , Type:"
        ).fill(success_url)

        self.page.get_by_role(
            "textbox",
            name="Maximum Length : 255 , Type : Alphanumeric, Sample: https://www.enbdmerch.com"
        ).fill(error_url)

        self.page.get_by_role("button", name="Generate Key").click()

        self.attach_screenshot("Plugin Details Filled")

    @allure.step("Configure Processing Options")
    def configure_processing(self):

        self.page.get_by_role("link", name="External Connection").click()

        self.page.get_by_role("link", name="Processing Options & Action").click()

    @allure.step("Save Terminal")
    def save_terminal(self):

        self.page.get_by_role("button", name="Save").click()

        self.attach_screenshot("Terminal Saved")

    @allure.step("Logout")
    def logout(self):

        self.page.get_by_role("link", name="Logout").click()