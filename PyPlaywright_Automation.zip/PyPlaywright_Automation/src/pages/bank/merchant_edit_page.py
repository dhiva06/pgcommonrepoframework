import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.merchant_edit_locators import MerchantEditLocators


class MerchantEditPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="MerchantEdit")

    # ---------------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Login to Bank Portal")
    def login(self, username, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            MerchantEditLocators.USERNAME,
            username,
            "Enter Username"
        )

        self.fill_by_locator(
            MerchantEditLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_role("button", "Submit")
        self.attach_screenshot("Logged in Successfully")

    # ---------------------------------
    @allure.step("Navigate to Merchant Screen")
    def navigate_to_merchant(self):

        self.click_by_role("link", "Configuration")
        self.click_by_role("link", "Merchant")

        self.attach_screenshot("Navigated to Merchant Page")

    # ---------------------------------
    @allure.step("Search Merchant")
    def search_merchant(self, merchant_id):

        self.page.get_by_text("- Select - - Select - ALL").click()
        self.page.get_by_text("Merchant ID").click()

        self.fill_by_locator(
            MerchantEditLocators.SEARCH_VALUE,
            merchant_id,
            "Enter Merchant ID"
        )

        self.click_by_role("button", "Search")
        self.attach_screenshot("Merchant Search Completed")

    # ---------------------------------
    @allure.step("Edit Merchant Details")
    def edit_merchant(self, data):

        self.click_by_role("link", "Edit")

        self.select_dropdown(
            MerchantEditLocators.TRAN_ROUTE,
            data["tran_route"]
        )

        self.fill_by_locator(
            MerchantEditLocators.MPGS_MERCHANT_ID,
            data["mpgs_merchant_id"],
            "Enter MPGS Merchant ID"
        )

        self.fill_by_locator(
            MerchantEditLocators.MPGS_PASSWORD,
            data["mpgs_password"],
            "Enter MPGS Password"
        )

        self.attach_screenshot("Updated Merchant Details")

    # ---------------------------------
    @allure.step("Save Merchant Details")
    def save_merchant(self):

        self.click_by_role("button", "Save")
        self.attach_screenshot("Clicked Save")

    # ---------------------------------
    @allure.step("Validate Merchant Update")
    def validate_update(self, expected_text):

        self.assert_visible(
            self.page.get_by_text(expected_text),
            "Merchant Updated Successfully"
        )

    # ---------------------------------
    @allure.step("Logout")
    def logout(self):

        self.click_by_role("link", "Logout")