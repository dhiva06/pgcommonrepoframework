import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.merchant_locators import MerchantLocators


class MerchantPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="Merchant")

    @allure.step("Login to Bank Portal")
    def login(self, url, user, password):

        self.navigate(url)

        self.click_by_locator(MerchantLocators.LOGIN_LINK, "Login Link")

        self.fill_by_locator(MerchantLocators.USER_ID, user, "User ID")

        self.fill_by_locator(MerchantLocators.PASSWORD, password, "Password")

        self.click_by_locator(MerchantLocators.SUBMIT, "Submit Button")

    @allure.step("Navigate to Merchant")
    def navigate_to_merchant(self):

        self.hover_by_getbytext("Configuration", "Configuration Menu")

        self.click_by_getbytext("Merchant", "Merchant Menu")

    @allure.step("Click Add Merchant")
    def click_add(self):

        self.click_by_locator(MerchantLocators.ADD_BUTTON, "Add Merchant")

    @allure.step("Fill Merchant Details")
    def fill_merchant_details(self, data):

        self.fill_by_locator(MerchantLocators.MERCHANT_ID, data["merchant_id"], "Merchant ID")

        self.fill_by_locator(MerchantLocators.MERCHANT_NAME, data["merchant_name"], "Merchant Name")

        self.click_by_getbytext("- Select -", "Select Dropdown")

        self.page.wait_for_selector(MerchantLocators.SELECT_OPTION)

        self.page.locator(MerchantLocators.SELECT_OPTION, has_text=data["select_value"]).click()

        self.fill_by_locator(MerchantLocators.WEBSITE, data["website"], "Website")

        self.fill_by_locator(MerchantLocators.RETURN_URL, data["return_url"], "Return URL")

        self.fill_by_locator(MerchantLocators.NUMERIC1, data["numeric1"], "Numeric1")

        self.fill_by_locator(MerchantLocators.NUMERIC2, data["numeric2"], "Numeric2")

    @allure.step("Fill Address")
    def fill_address(self, data):

        self.click_by_getbytext("Address", "Address Tab")

        self.fill_by_locator(MerchantLocators.ADDRESS, data["address"], "Address")

        self.fill_by_locator(MerchantLocators.COUNTRY, data["country"], "Country")

        self.fill_by_locator(MerchantLocators.PIN1, data["pin1"], "Pin1")

        self.fill_by_locator(MerchantLocators.PIN2, data["pin2"], "Pin2")

    @allure.step("Fill Contact")
    def fill_contact(self, data):

        self.click_by_getbytext("Contact", "Contact Tab")

        self.fill_by_locator(MerchantLocators.CONTACT_NAME, data["contact_name"], "Contact Name")

        self.fill_by_locator(MerchantLocators.EMAIL, data["email"], "Email")

        self.fill_by_locator(MerchantLocators.PHONE, data["phone"], "Phone")

    @allure.step("Save Merchant")
    def save_merchant(self):

        self.click_by_locator(MerchantLocators.SAVE, "Save Button")

    @allure.step("Logout")
    def logout(self):

        self.click_by_locator(MerchantLocators.LOGOUT, "Logout")