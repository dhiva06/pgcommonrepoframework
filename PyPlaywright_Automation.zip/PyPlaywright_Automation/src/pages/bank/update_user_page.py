import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.update_user_locators import UpdateUserLocators


class UpdateUserPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="UpdateUser")

    # ---------------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):

        self.navigate(url)

    # ---------------------------------
    @allure.step("Login to Bank Portal")
    def login(self, user, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            UpdateUserLocators.INST_USER,
            user,
            "Enter Institution Username"
        )

        self.fill_by_locator(
            UpdateUserLocators.INST_PASSWORD,
            password,
            "Enter Institution Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Logged in Successfully")

    # ---------------------------------
    @allure.step("Navigate to Create User Page")
    def navigate_create_user(self):

        self.page.get_by_role(
            "link",
            name=re.compile(r"My(\s|\xa0)*Accounts")
        ).hover()

        self.page.get_by_role(
            "link",
            name=re.compile(r"Create(\s|\xa0)*User")
        ).click()

        self.attach_screenshot("Navigated to Create User Page")

    # ---------------------------------
    @allure.step("Search User")
    def search_user(self, username):

        self.page.locator(UpdateUserLocators.SEARCH_DROPDOWN).click()

        self.page.get_by_text("User Name").click()

        self.fill_by_locator(
            UpdateUserLocators.SEARCH_VALUE,
            username,
            "Enter Username for Search"
        )

        self.click_by_role("button", "Search")

        self.attach_screenshot("User Search Completed")

    # ---------------------------------
    @allure.step("Update Username")
    def update_user(self, new_name):

        self.click_by_role("link", "Edit")

        self.fill_by_role(
            "textbox",
            "Minimum Length : 5, Maximum",
            new_name
        )

        self.attach_screenshot("Updated User Details")

    # ---------------------------------
    @allure.step("Save Updated User")
    def save_user(self):

        self.click_by_role("button", "Save")

        self.attach_screenshot("Clicked Save Button")

    # ---------------------------------
    @allure.step("Logout from Application")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logout Successful")