import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.merchant_edit_cybs_locators import MerchantEditCYBSLocators


class MerchantEditCYBSPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="MerchantEditCYBS")

    # ---------------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Login to Bank Portal")
    def login(self, username, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            MerchantEditCYBSLocators.USERNAME,
            username,
            "Enter Username"
        )

        self.fill_by_locator(
            MerchantEditCYBSLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_role("button", "Submit")
        self.attach_screenshot("Logged in Successfully")

    # ---------------------------------
    @allure.step("Navigate to Merchant Page")
    def navigate_to_merchant(self):

        self.click_by_role("link", "Configuration")
        self.click_by_role("link", "Merchant")

        self.attach_screenshot("Navigated to Merchant Page")

    # ---------------------------------
    @allure.step("Search Merchant")
    def search_merchant(self, merchant_id):

        self.page.get_by_text("- Select - - Select - ALL").click()
        self.page.get_by_text("Merchant ID").click()

        self.fill_by_locator(
            MerchantEditCYBSLocators.SEARCH_VALUE,
            merchant_id,
            "Enter Merchant ID"
        )

        self.click_by_role("button", "Search")
        self.attach_screenshot("Merchant Search Completed")

    # ---------------------------------
    @allure.step("Open Merchant in Edit Mode")
    def open_edit(self):

        self.page.get_by_role("cell", name="View   Edit").click()
        self.click_by_role("link", "Edit")

    # ---------------------------------
    @allure.step("Update CYBS Details")
    def update_cybs_details(self, data):

        self.select_dropdown(
            MerchantEditCYBSLocators.TRAN_ROUTE,
            data["tran_route"]
        )

        self.fill_by_locator(
            MerchantEditCYBSLocators.CYBS_MERCHANT_ID,
            data["cybs_merchant_id"],
            "Enter CYBS Merchant ID"
        )

        self.fill_by_locator(
            MerchantEditCYBSLocators.CYBS_KEY_ID,
            data["cybs_key_id"],
            "Enter CYBS Key ID"
        )

        self.fill_by_locator(
            MerchantEditCYBSLocators.CYBS_KEY,
            data["cybs_key"],
            "Enter CYBS Key"
        )

        self.attach_screenshot("Filled CYBS Details")

    # ---------------------------------
    @allure.step("Save Merchant Details")
    def save(self):

        self.click_by_role("button", "Save")
        self.attach_screenshot("Clicked Save Button")

    # ---------------------------------
    @allure.step("Validate Update")
    def validate_update(self, expected_text):

        self.assert_visible(
            self.page.get_by_text(expected_text),
            "Merchant Updated Successfully"
        )

    # ---------------------------------
    @allure.step("Logout")
    def logout(self):

        self.click_by_role("link", "Logout")