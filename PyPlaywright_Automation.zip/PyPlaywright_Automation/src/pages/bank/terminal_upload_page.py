import allure
from pathlib import Path
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.terminal_upload_locators import TerminalUploadLocators


class TerminalUploadPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="TerminalUpload")

    # -------------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    # -------------------------------
    @allure.step("Login to Bank Portal")
    def login(self, user_id, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            TerminalUploadLocators.USER_ID,
            user_id,
            "Enter User ID"
        )

        self.fill_by_locator(
            TerminalUploadLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Login Successful")

    # -------------------------------
    @allure.step("Navigate to Terminal Upload Page")
    def navigate_terminal_upload(self):

        self.hover_by_role("link", "Configuration")

        self.click_by_role("link", "Terminal  Upload")

        self.attach_screenshot("Opened Terminal Upload Page")

    # -------------------------------
    @allure.step("Upload Terminal File")
    def upload_terminal_file(self, file_path):

        file_path = str(Path(file_path).resolve())

        with self.page.expect_file_chooser() as fc_info:
            self.click_by_role("button", "Choose File")

        file_chooser = fc_info.value
        file_chooser.set_files(file_path)

        self.attach_screenshot("Terminal File Uploaded")

    # -------------------------------
    @allure.step("Validate Uploaded File")
    def validate_file(self):

        self.click_by_role("button", "Validate")

        self.assert_visible(
            self.page.get_by_text("xClose Validation Failed"),
            "Validation Result"
        )

        self.attach_screenshot("Validation Completed")

    # -------------------------------
    @allure.step("Logout from Application")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logged Out Successfully")