import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.declined_cards_locators import DeclinedCardsLocators


class DeclinedCardsPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="DeclinedCards")

    # -----------------------------
    @allure.step("Open Bank Login Page")
    def open_login(self, url):
        self.navigate(url)

    # -----------------------------
    @allure.step("Login to Application")
    def login(self, user_id, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            DeclinedCardsLocators.USER_ID,
            user_id,
            "Enter User ID"
        )

        self.fill_by_locator(
            DeclinedCardsLocators.PASSWORD,
            password,
            "Enter Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Login Successful")

    # -----------------------------
    @allure.step("Navigate to Declined Cards Page")
    def navigate_declined_cards(self):

        self.hover_by_role("link", "Risk Configuration")

        self.click_by_role("link", "Declined Cards")

        self.attach_screenshot("Opened Declined Cards Page")

    # -----------------------------
    @allure.step("Search Card Number")
    def search_card(self, card_number):

        self.fill_by_locator(
            DeclinedCardsLocators.CARD_NUMBER,
            card_number,
            "Enter Card Number"
        )

        self.click_by_role("button", "Search")

        self.attach_screenshot("Card Search Executed")

    # -----------------------------
    @allure.step("Validate No Records Found")
    def validate_no_records(self):

        self.assert_visible(
            self.page.get_by_text("No records found"),
            "No Records Found Message"
        )

    # -----------------------------
    @allure.step("Logout from Application")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logout Successful")