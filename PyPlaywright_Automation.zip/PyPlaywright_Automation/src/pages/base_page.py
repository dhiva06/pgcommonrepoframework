import os
import re
import allure
from openai import timeout
from core.logger import get_logger
from core.llm_auto_heal import LocatorAutoHeal

class BasePage:
    def __init__(self, page, module_name="General"):
        self.page = page
        self.logger = get_logger(self.__class__.__name__)
        self.auto_healer = LocatorAutoHeal(page)
        self.module_name = module_name
        self.screenshot_dir = os.path.join("screenshots", module_name)
        os.makedirs(self.screenshot_dir, exist_ok=True)
        self.screenshot_count = 1

    @allure.step("Take screenshot: {step_name}")
    def attach_screenshot(self, step_name):
        """Save screenshot in module folder and attach to Allure"""

        # Remove characters that are invalid in Windows filenames
        safe_file_name = re.sub(r'[<>:"/\\|?*]', '_', step_name).strip()

        file_name = f"{self.screenshot_count:03d}_{safe_file_name}.png"
        path = os.path.join(self.screenshot_dir, file_name)

        self.page.screenshot(path=path, full_page=True)

        # Keep the original name in the Allure report
        allure.attach.file(
            path,
            name=step_name,
            attachment_type=allure.attachment_type.PNG
        )

        self.screenshot_count += 1

    @allure.step("Navigate to URL: {url}")
    def navigate(self, url: str, timeout: int = 30000) -> bool:
        """Navigate to a given URL"""
        try:
            self.page.goto(url, timeout=timeout)
            self.logger.info(f"Navigated to URL: {url}")
            self.attach_screenshot("After navigation")
            return True
        except TimeoutError:
            self.logger.error(f"Failed to navigate to URL: {url}")
            return False
    
    

    @allure.step("Hover on element by role: {role} with name: {name}")
    def hover_by_role(self, role: str, name: str, exact: bool = True, timeout: int = 10000):
        """
        Generic method to hover on an element using Playwright get_by_role
        """
        try:
            element = self.page.get_by_role(role, name=name, exact=exact)
            element.wait_for(state="visible", timeout=timeout)
            element.hover()

            self.logger.info(f"Hovered on element with role '{role}' and name '{name}'")

        except Exception as e:
            self.logger.error(f"Failed to hover on role '{role}' with name '{name}': {e}")
            self.take_screenshot(f"hover_failed_{name}")
            raise
        
    @allure.step("Fill '{value}' in {role} with name '{name}'")
    def fill_by_role(self, role: str, name: str, value: str, use_regex: bool = False):
        if use_regex:
            locator = self.page.get_by_role(role, name=re.compile(name, re.I))
        else:
            locator = self.page.get_by_role(role, name=name)

        locator.wait_for(state="visible", timeout=10000)
        locator.fill(value)

    @allure.step("Click element by role: {role} with name: {name}")
    def click_by_role(self, role: str, name: str, exact: bool = True, timeout: int = 10000):
        """
        Generic method to click element using Playwright get_by_role
        """
        try:
            element = self.page.get_by_role(role, name=name, exact=exact)
            element.wait_for(state="visible", timeout=timeout)
            element.click()

            self.logger.info(f"Clicked element with role '{role}' and name '{name}'")

        except Exception as e:
            self.logger.error(f"Failed to click role '{role}' with name '{name}' : {e}")
            raise
        
    @allure.step("Click element")
    def click_by_locator(self, locator, description="Click action", timeout: int = 30000) -> bool:
        """Click with auto-heal fallback"""
        try:
             # If locator is a string, convert to Playwright locator
            if isinstance(locator, str):
                locator = self.page.locator(locator)
                
            locator.wait_for(state="visible", timeout=timeout)
            locator.click()
            self.logger.info(f"Clicked element: {description}")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Click failed for: {description}")
            # 🔧 Auto-heal attempt
            healed_locator = self.auto_healer.locator(str(locator))
            if healed_locator:
                self.logger.info(f"Auto-heal applied for: {description}")
                healed_locator.click()
                self.attach_screenshot(f"After auto-heal {description}")
                return True
            return False
        
    @allure.step("Select value from custom dropdown")
    def select_custom_dropdown(self, dropdown_id: str, value: str):
        try:
            # Click dropdown
            self.page.locator(f"#{dropdown_id}").click()

            # Select option
            option = self.page.locator(f"#{dropdown_id} span", has_text=value)
            option.wait_for(state="visible", timeout=10000)
            option.click()

            self.logger.info(f"Selected '{value}' from dropdown '{dropdown_id}'")

        except Exception as e:
            self.logger.error(f"Dropdown selection failed: {e}")
            # self.take_screenshot("dropdown_failure")
            raise
        
    @allure.step("Fill input field")
    def fill_by_locator(self, locator, text: str, description="Fill action", timeout: int = 30000) -> bool:
        """Fill with auto-heal fallback"""
        try:
            if isinstance(locator, str): 
                locator = self.page.locator(locator)
            
            locator.wait_for(state="visible", timeout=timeout)
            locator.fill(text)
            self.logger.info(f"Filled element ({description}) with text: {text}")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Fill failed for: {description}")
            healed_locator = self.auto_healer.locator(str(locator))
            if healed_locator:
                self.logger.info(f"Auto-heal applied for: {description}")
                healed_locator.fill(text)
                self.attach_screenshot(f"After auto-heal {description}")
                return True
            return False
        
    @allure.step("Assert image is visible")
    def assert_image_visible(self, locator, description="Image validation", timeout=30000):
        try:
            image = self.page.locator(locator)

            # Wait until visible
            image.wait_for(state="visible", timeout=timeout)

            # Check visible
            assert image.is_visible(), f"{description} - Image not visible"

            # Check src exists
            src = image.get_attribute("src")
            assert src is not None and src != "", f"{description} - Image src missing"

            # Check image loaded
            natural_width = image.evaluate("img => img.naturalWidth")
            assert natural_width > 0, f"{description} - Broken image"

            self.logger.info(f"{description} passed successfully")

        except Exception as e:
            self.logger.error(f"{description} failed: {str(e)}")
            raise
        
    # @allure.step("Fill input field")
    # def fill_by_locator(self, locator, text: str, description="Fill action", timeout: int = 30000) -> bool:
    #     """Fill with auto-heal fallback"""
    #     try:

    #         # Handle tuple locator (role based)
    #         if isinstance(locator, tuple):
    #             locator_type, value, options = locator

    #             if locator_type == "role":
    #                 locator = self.page.get_by_role(value, **options)

    #         # Handle string locator
    #         elif isinstance(locator, str):
    #             locator = self.page.locator(locator)

    #         locator.wait_for(state="visible", timeout=timeout)
    #         locator.fill(text)

    #         self.logger.info(f"Filled element ({description}) with text: {text}")
    #         self.attach_screenshot(f"After {description}")
    #         return True

    #     except TimeoutError:
    #         self.logger.error(f"Fill failed for: {description}")

    #         healed_locator = self.auto_healer.locator(str(locator))

    #         if healed_locator:
    #             self.logger.info(f"Auto-heal applied for: {description}")
    #             healed_locator.fill(text)
    #             self.attach_screenshot(f"After auto-heal {description}")
    #             return True

    #         return False
    @allure.step("Click element")
    def click_by_getbyrole(self, locator, description="Click action", timeout: int = 30000) -> bool:
        """Click with auto-heal fallback"""

        try:
            locator.wait_for(state="visible", timeout=timeout)
            locator.click()

            self.logger.info(f"Clicked element: {description}")
            self.attach_screenshot(f"After {description}")
            return True

        except Exception as e:
            self.logger.error(f"Click failed for: {description} | Error: {e}")

        # ❌ REMOVE this completely (wrong implementation)
        # auto-heal with str(locator) is invalid

        return False
    @allure.step("Select dropdown value")
    def select_by_locator(self, locator, value, description="Select dropdown", timeout=30000):

        try:
            locator.wait_for(state="visible", timeout=timeout)
            locator.select_option(value)

            self.logger.info(f"{description}: {value}")
            self.attach_screenshot(f"{description}")
            return True

        except Exception as e:
            self.logger.error(f"{description} failed: {e}")
            return False    

    @allure.step("Click element by XPath: {xpath}")
    def click_by_xpath(self, xpath: str, description: str = "Click by XPath", timeout: int = 30000) -> bool:
        """Wait until element located by XPath is visible, then click"""
        try:
            locator = self.page.locator(f"xpath={xpath}")
            locator.wait_for(state="visible", timeout=timeout)
            locator.click()
            self.logger.info(f"Clicked element by XPath: {xpath}")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Element not visible for XPath click: {xpath}")
            return False
    
    
        
    @allure.step("Get text content")
    def get_text(self, locator, description: str = "Get text", timeout: int = 30000) -> str:
        try:
            locator.wait_for(state="visible", timeout=timeout)
            text = locator.text_content()
            self.logger.info(f"Got text from {description}: {text}")
            allure.attach(text, name=f"Text content - {description}", attachment_type=allure.attachment_type.TEXT)
            return text
        except TimeoutError:
            self.logger.error(f"Get text failed for: {description}")
            return ""
        
    # @allure.step("Click element")
    # def click_by_getbyrole(self, get_by_role, description="Click action", timeout: int = 30000) -> bool:
    #     """Click with auto-heal fallback"""
    #     try:
    #          # If get_by_role is a string, convert to Playwright locator
    #         if isinstance(get_by_role, str):
    #             locator = self.page.get_by_role(get_by_role)
                
    #         locator.wait_for(state="visible", timeout=timeout)
    #         locator.click()
    #         self.logger.info(f"Clicked element: {description}")
    #         self.attach_screenshot(f"After {description}")
    #         return True
    #     except TimeoutError:
    #         self.logger.error(f"Click failed for: {description}")
    #         # 🔧 Auto-heal attempt
    #         healed_locator = self.auto_healer.get_by_role(str(locator))
    #         if healed_locator:
    #             self.logger.info(f"Auto-heal applied for: {description}")
    #             healed_locator.click()
    #             self.attach_screenshot(f"After auto-heal {description}")
    #             return True
    #         return False
        
    # @allure.step("Fill input field")
    # def fill_by_getbyrole(self, get_by_role, text: str, description="Fill action", timeout: int = 30000) -> bool:
    #     """Fill with auto-heal fallback"""
    #     try:
    #         if isinstance(get_by_role, str): 
    #             locator = self.page.get_by_role(get_by_role)
            
    #         locator.wait_for(state="visible", timeout=timeout)
    #         locator.fill(text)
    #         self.logger.info(f"Filled element ({description}) with text: {text}")
    #         self.attach_screenshot(f"After {description}")
    #         return True
    #     except TimeoutError:
    #         self.logger.error(f"Fill failed for: {description}")
    #         healed_locator = self.auto_healer.get_by_role(str(locator))
    #         if healed_locator:
    #             self.logger.info(f"Auto-heal applied for: {description}")
    #             healed_locator.fill(text)
    #             self.attach_screenshot(f"After auto-heal {description}")
    #             return True
    #         return False

    def fill_by_getbyrole(self, get_by_role, text: str, description="Fill action", timeout: int = 30000) -> bool:
        try:
        # ✅ Always assign locator
            if isinstance(get_by_role, str):
                locator = self.page.get_by_role(get_by_role)
            else:
                locator = get_by_role

        # ✅ Handle blank test data
            if text in [None, "", "(blank)"]:
                self.logger.info(f"Skipping fill for {description} (blank value)")
                return True

            locator.wait_for(state="visible", timeout=timeout)
            locator.fill(text)

            self.logger.info(f"Filled element ({description}) with text: {text}")
            self.attach_screenshot(f"After {description}")
            return True

        except Exception as e:
            self.logger.error(f"Fill failed for: {description} | Error: {e}")
            raise
        
    @allure.step("Hover element by role")
    def hover_by_getbyrole(self, get_by_role, description="Hover action", timeout: int = 30000) -> bool:
        """Hover with auto-heal fallback"""
        try:
            if isinstance(get_by_role, str):
                locator = self.page.get_by_role(get_by_role)
            else:
                locator = get_by_role

            locator.wait_for(state="visible", timeout=timeout)
            locator.hover()
            self.logger.info(f"Hovered element ({description}) successfully")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Hover failed for: {description}")
            healed_locator = self.auto_healer.get_by_role(str(locator))
            if healed_locator:
                self.logger.info(f"Auto-heal applied for: {description}")
                healed_locator.hover()
                self.attach_screenshot(f"After auto-heal {description}")
                return True
            return False
        
    @allure.step("Click element by text")
    def click_by_getbytext(self, text: str, description="Click action", exact: bool = False, timeout: int = 30000) -> bool:
        """Click with auto-heal fallback"""
        try:
            locator = self.page.get_by_text(text, exact=exact)
            locator.wait_for(state="visible", timeout=timeout)
            locator.click()
            self.logger.info(f"Clicked element ({description}) successfully")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Click failed for: {description}")
            healed_locator = self.auto_healer.get_by_text(text, exact=exact)
            if healed_locator:
                self.logger.info(f"Auto-heal applied for: {description}")
                healed_locator.click()
                self.attach_screenshot(f"After auto-heal {description}")
                return True
            return False
        
    @allure.step("Hover element by text")
    def hover_by_getbytext(self, text: str, description="Hover action", exact: bool = False, timeout: int = 30000) -> bool:
        """Hover with auto-heal fallback"""
        try:
            locator = self.page.get_by_text(text, exact=exact)
            locator.wait_for(state="visible", timeout=timeout)
            locator.hover()
            self.logger.info(f"Hovered element ({description}) successfully")
            self.attach_screenshot(f"After {description}")
            return True
        except TimeoutError:
            self.logger.error(f"Hover failed for: {description}")
            healed_locator = self.auto_healer.get_by_text(text, exact=exact)
            if healed_locator:
                self.logger.info(f"Auto-heal applied for: {description}")
                healed_locator.hover()
                self.attach_screenshot(f"After auto-heal {description}")
                return True
            return False
    
    
    
    # ---------------------------
    # Assertion helpers
    # ---------------------------
        
    @allure.step("Assert element is visible")
    def assert_visible(self, locator, description: str = "Visibility check", timeout: int = 30000):
        try:
            locator.wait_for(state="visible", timeout=timeout)
            assert locator.is_visible(), f"Expected {description} to be visible, but it was not."
            self.logger.info(f"Assertion passed: {description} is visible")
            self.attach_screenshot(f"{description} visible")
        except TimeoutError:
            self.logger.error(f"Assertion failed: {description} not visible within {timeout}ms")
            raise AssertionError(f"{description} not visible within {timeout}ms")


    @allure.step("Assert element text equals expected")
    def assert_text(self, locator, expected_text: str, description: str = "Text assertion", timeout: int = 30000):
        try:
            locator.wait_for(state="visible", timeout=timeout)

            # Trim leading/trailing whitespace
            actual_text = locator.text_content().strip()
            expected_text = expected_text.strip()

            assert actual_text == expected_text, (
                f"Expected text '{expected_text}' for {description}, but got '{actual_text}'"
            )

            self.logger.info(f"Assertion passed: {description} text matched '{expected_text}'")

            allure.attach(
                actual_text,
                name=f"Text content - {description}",
                attachment_type=allure.attachment_type.TEXT
            )

            self.attach_screenshot(f"{description} text assertion")

        except TimeoutError:
            self.logger.error(f"Assertion failed: {description} not visible within {timeout}ms")
            raise AssertionError(f"{description} not visible within {timeout}ms")
        
    # ---------------------------
    # Locator helpers
    # ---------------------------
    def locator(self, selector: str):
        return self.page.locator(selector)

    def get_by_role(self, role: str, name: str = None, exact: bool = False):
        return self.page.get_by_role(role, name=name, exact=exact)

    def get_by_text(self, text: str, exact: bool = False):
        return self.page.get_by_text(text, exact=exact)

    def get_by_label(self, label: str, exact: bool = False):
        return self.page.get_by_label(label, exact=exact)

    def get_by_placeholder(self, placeholder: str, exact: bool = False):
        return self.page.get_by_placeholder(placeholder, exact=exact)

    def get_by_test_id(self, test_id: str):
        return self.page.get_by_test_id(test_id)

    def locator_by_xpath(self, xpath: str):
        return self.page.locator(f"xpath={xpath}")
    

