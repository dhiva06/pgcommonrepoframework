import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.payment_negative_locators import PaymentNegativeLocators


class Payment_negative(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="PaymentNegative")
        self.locators = PaymentNegativeLocators(page)

    # -------------------------------
    # Product Selection
    # -------------------------------
    @allure.step("Select product and click Purchase")
    def select_product_and_purchase(self, product_name: str):

        self.click_by_getbyrole(
            self.locators.product(product_name),
            description=f"Select product {product_name}"
        )

        self.click_by_locator(
            self.locator(self.locators.PURCHASE_BUTTON),
            description="Click Purchase"
        )

    # -------------------------------
    # Merchant Details
    # -------------------------------
    @allure.step("Enter Merchant Details")
    def enter_merchant_details(self, tranportal_id: str, resource_key: str):

        self.fill_by_locator(
            self.locator(self.locators.TRANPORTAL_ID),
            tranportal_id,
            description="Enter Tranportal ID"
        )

        self.fill_by_locator(
            self.locator(self.locators.RESOURCE_KEY),
            resource_key,
            description="Enter Resource Key"
        )

    @allure.step("Click Buy")
    def click_buy(self):

        self.click_by_locator(
            self.locator(self.locators.BUY_BUTTON),
            description="Click Buy"
        )

    # -------------------------------
    # Card Details
    # -------------------------------
    @allure.step("Enter Card Details")
    def enter_card_details(self, card, expiry, name, cvv):

        self.fill_by_locator(
            self.locator(self.locators.CARD_NUMBER),
            card,
            description="Enter Card Number"
        )

        self.fill_by_locator(
            self.locator(self.locators.EXPIRY_DATE),
            expiry,
            description="Enter Expiry Date"
        )

        self.fill_by_locator(
            self.locator(self.locators.CARD_HOLDER),
            name,
            description="Enter Card Holder Name"
        )

        self.fill_by_locator(
            self.locator(self.locators.CVV),
            cvv,
            description="Enter CVV"
        )

    # -------------------------------
    # Payment
    # -------------------------------
    @allure.step("Click Pay")
    def click_pay(self):

        self.click_by_xpath(
            self.locators.PAY_BUTTON,
            description="Click Pay"
        )

    # -------------------------------
    # Validation
    # -------------------------------
    @allure.step("Verify Error Message")
    def verify_error(self, expected_text: str):

        locator = self.locators.ERROR_LOCATORS.get(expected_text)

        if locator is None:
            raise ValueError(f"No locator configured for: {expected_text}")

        self.assert_text(
            self.page.locator(locator),
            expected_text,
            description=f"Verify Error : {expected_text.strip()}"
        )