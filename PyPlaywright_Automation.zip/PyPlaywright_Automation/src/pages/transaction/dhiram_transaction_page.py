import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.cop_transaction_locators import COPTransactionLocators


class Dhiram_TransactionPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="Dhiram_Transaction")

    # ---------------------------------
    @allure.step("Open Merchant Demo")
    def open_url(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Start Purchase")
    def start_purchase(self, product):

        if product.lower() == "body soaps":
            self.click_by_role("link", "Body Soaps")

        elif product.lower() == "chocolates":
            self.click_by_role("link", "Chocolates")

        else:
            raise ValueError(f"Invalid product: {product}")

        self.click_by_role("button", "Purchase")

    # ---------------------------------
    @allure.step("Fill Credentials")
    def fill_credentials(self, data):

        self.fill_by_locator(
            COPTransactionLocators.TRANPORTAL_ID,
            data["tranportal_id"],
            "Tranportal ID"
        )

        self.fill_by_locator(
            COPTransactionLocators.TRANPORTAL_PWD,
            data["tranportal_pwd"],
            "Tranportal Password"
        )

        self.fill_by_locator(
            COPTransactionLocators.RESOURCE_KEY,
            data["resource_key"],
            "Resource Key"
        )
    
        
    #----------------------------------------
    @allure.step("Fill Credentials")
    def fill_credentialsEPP(self, data):

        self.fill_by_locator(
            COPTransactionLocators.TRANPORTAL_ID,
            data["tranportal_id"],
            "Tranportal ID"
        )

        self.fill_by_locator(
            COPTransactionLocators.TRANPORTAL_PWD,
            data["tranportal_pwd"],
            "Tranportal Password"
        )

        self.fill_by_locator(
            COPTransactionLocators.RESOURCE_KEY,
            data["resource_key"],
            "Resource Key"
        )
        
        self.fill_by_locator(
            COPTransactionLocators.EPP_AMT,
            data["epp_amount"],
            "EPP Amount"
        )
        
        self.fill_by_locator(
            COPTransactionLocators.TERMSANDCONDITIONURL,
            data["TERMSANDCONDITIONURL"],
            "Terms and Conditions URL"
        )    
        
        

    # ---------------------------------
    @allure.step("Click Buy")
    def click_buy(self):
        self.click_by_role("button", "Buy")

    # ---------------------------------
    @allure.step("Enter Card Details")
    def enter_card_details(self, data):

        self.page.get_by_label("Card Number").fill(data["card_number"])
        self.page.get_by_label("Expiry Date").fill(data["expiry"])
        self.fill_by_locator(
        self.locator("#creditCardholderName"),
        data["card_holder"],
        description="Enter Card Holder Name"
)
        self.page.get_by_label("CVV").fill(data["cvv"])

        # self.page.locator(COPTransactionLocators.CURRENCY).select_option(str(data["currency"]))
        # self.page.locator("button:has-text('Pay')").first.click()
        self.assert_image_visible(COPTransactionLocators.Dhiram_Symbol_AR, description="Verify Dhiram symbol")
        self.assert_image_visible(COPTransactionLocators.Dhiram_Symbol_ARAmount, description="Verify Dhiram symbol")

        self.click_by_xpath("//*[@id='proceed_button']", description="Click Pay")
        

        # self.page.get_by_role("button", name=re.compile("Pay")).click()


        self.attach_screenshot("Card Details Entered")
    @allure.step("Click Pay Button")
    def click_pay_button(self):
        locator = self.page.locator("button:has-text('Pay')").locator(":visible")
        locator.first.wait_for(state="visible")
        locator.first.click()
        self.logger.info("Clicked correct Pay button")

    # ---------------------------------
    @allure.step("Handle OTP")
    def handle_otp(self, otp):
 
        self.page.wait_for_selector(COPTransactionLocators.OTP_IFRAME)
 
        frame = self.page.frame_locator(
            COPTransactionLocators.OTP_IFRAME
    )
 
        frame.get_by_role("textbox").fill(otp)
 
        frame.get_by_role(
        "button",
        name=re.compile("submit", re.I)
    ).click()
 
 
        send_anyway = self.page.get_by_role(
        "button",
        name=re.compile(r"send anyway", re.I)
    )
 
        if send_anyway.is_visible(timeout=10000):
            send_anyway.click()
 
        self.page.wait_for_load_state("networkidle")
 
        self.click_by_locator(
        "//*[@id='proceed-button']",
        "Proceed After OTP"
    )
 
        self.attach_screenshot("OTP Submitted")
        
        
        
    # -------------------------------------
    
    @allure.step("Handle OTP")
    def handle_otp_EPP(self, otp):
 
        self.page.wait_for_selector(COPTransactionLocators.OTP_IFRAME_EPP)
 
        frame = self.page.frame_locator(
            COPTransactionLocators.OTP_IFRAME_EPP
    )
 
        frame.get_by_role("textbox").fill(otp)
 
        frame.get_by_role(
        "button",
        name=re.compile("submit", re.I)
    ).click()
 
 
        send_anyway = self.page.get_by_role(
        "button",
        name=re.compile(r"send anyway", re.I)
    )
 
        if send_anyway.is_visible(timeout=10000):
            send_anyway.click()
 
        self.page.wait_for_load_state("networkidle")
 
        self.click_by_locator(
        "//*[@id='proceed-button']",
        "Proceed After OTP"
    )
 
        self.attach_screenshot("OTP Submitted")

    # ---------------------------------
    @allure.step("Verify Approved & Get Payment ID")
    def get_payment_id(self):

        self.assert_visible(
            self.page.get_by_text("CAPTURED"),
            "Payment Approved"
        )

        pid = self.page.locator(
            COPTransactionLocators.PAYMENT_ID
        ).inner_text().strip()

        assert pid.isdigit(), f"Invalid Payment ID: {pid}"

        return pid

    # ---------------------------------
    @allure.step("Perform Supporting Transaction")
    def supporting_txn(self, action, payment_id, expected_status, data):

        self.page.locator(COPTransactionLocators.ACTION_DROPDOWN).select_option(str(action))

        self.page.locator(COPTransactionLocators.UDF5_DROPDOWN).select_option("PaymentID")

        self.page.locator(COPTransactionLocators.COMMENT_FIELD).fill(payment_id)

        self.fill_credentials(data)

        self.click_buy()

         