import allure
from playwright.sync_api import Page
from pages.base_page import BasePage


class negativeDemo_txn(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="NegativeTxn")

    # 🔹 Actions
    @allure.step("Select product and click purchase")
    def select_product_and_purchase(self, product_name: str):
        self.click_by_getbyrole(
            self.get_by_role("link", name=product_name),
            description=f"Click on product {product_name}"
        )
        self.click_by_getbyrole(
            self.get_by_role("button", name="Purchase"),
            description="Click Purchase button"
        )

    @allure.step("Enter Tranportal ID")
    def enter_tranportal_id(self, value: str):
        self.fill_by_locator(
            self.locator("input[name='tranportalID']"),
            value,
            description="Enter Tranportal ID"
        )

    @allure.step("Click Buy button")
    def click_buy(self):
        self.click_by_getbyrole(
            self.get_by_role("button", name="Buy"),
            description="Click Buy button"
        )

    # 🔹 Validations
    @allure.step("Verify error message")
    def verify_error_message(self, expected_text: str):
        locator = self.get_by_text(expected_text)
        self.assert_visible(locator, description=f"Error message: {expected_text}")