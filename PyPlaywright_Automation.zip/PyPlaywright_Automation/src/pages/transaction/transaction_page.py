import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.transaction_locators import TransactionLocators


class TransactionPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="Transaction")

    # ---------------------------------
    @allure.step("Open Merchant Demo URL")
    def open_merchant_demo(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Start Purchase Flow")
    def start_purchase(self, product: str):

        product = product.strip().lower()

        if product == "body soaps":
            _, role, opts = TransactionLocators.BODY_SOAPS_LINK

        elif product == "chocolates":
            _, role, opts = TransactionLocators.CHOCOLATES_LINK

        else:
            raise ValueError(f"Invalid product name: {product}")

        # Click product
        self.click_by_getbyrole(role, f"Click {opts['name']}")

        self.page.wait_for_load_state("networkidle")

        # Click Purchase
        _, role, opts = TransactionLocators.PURCHASE_BUTTON
        self.click_by_getbyrole(role, "Click Purchase Button")

    # ---------------------------------
    @allure.step("Fill Merchant Credentials")
    def fill_credentials(self, tranportal_id, tranportal_pwd, resource_key):

        self.fill_by_locator(
            TransactionLocators.TRANPORTAL_ID,
            tranportal_id,
            "Tranportal ID"
        )

        self.fill_by_locator(
            TransactionLocators.TRANPORTAL_PWD,
            tranportal_pwd,
            "Tranportal Password"
        )

        self.fill_by_locator(
            TransactionLocators.RESOURCE_KEY,
            resource_key,
            "Resource Key"
        )

    # ---------------------------------
    @allure.step("Submit Buy")
    def submit_buy(self):

        _, role, opts = TransactionLocators.BUY_BUTTON
        self.click_by_getbyrole(role, "Buy Button")

    # ---------------------------------
    @allure.step("Complete Card Payment")
    def complete_card_payment(self, card_number, expiry, card_holder, cvv, currency):

        self.fill_by_getbyrole("textbox", card_number, "Card Number")

        self.fill_by_getbyrole("textbox", expiry, "Expiry Date")

        self.fill_by_getbyrole("textbox", card_holder, "Card Holder")

        self.fill_by_getbyrole("textbox", cvv, "CVV")

        self.page.locator(
            TransactionLocators.CURRENCY_LIST
        ).select_option(str(currency))

        self.click_by_locator("#proceed_button", "Proceed Button")

    # ---------------------------------
    @allure.step("Handle OTP")
    def handle_otp(self, otp):

        self.page.wait_for_selector(TransactionLocators.OTP_IFRAME)

        frame = self.page.frame_locator(TransactionLocators.OTP_IFRAME)

        frame.get_by_role("textbox").fill(otp)

        frame.get_by_role("button", name=re.compile("submit", re.I)).click()

        self.click_by_locator("#proceed-button", "Proceed After OTP")

    # ---------------------------------
    @allure.step("Verify Approved Status and Get Payment ID")
    def verify_approved_and_get_pid(self):

        locator = self.get_by_text("CAPTURED", exact=True)

        self.assert_visible(locator, "Approved Message")

        pid = self.page.locator(
            TransactionLocators.PAYMENT_ID
        ).inner_text().strip()

        assert pid.isdigit(), f"Invalid Payment ID: {pid}"

        return pid

    # ---------------------------------
    @allure.step("Perform Supporting Transaction")
    def perform_supporting_transaction(self, action_code, payment_id, expected_status, data):

        # Select Action Code
        self.page.locator(
            TransactionLocators.AUTH_DROPDOWN
        ).select_option(str(action_code))

        # Select PaymentID
        self.page.locator(
            TransactionLocators.UDF5_DROPDOWN
        ).select_option("PaymentID")

        # Enter PaymentID
        self.fill_by_locator(
            TransactionLocators.COMMENT_FIELD,
            payment_id,
            "Payment ID"
        )

        # Fill Credentials
        self.fill_credentials(
            data["tranportal_id"],
            data["tranportal_pwd"],
            data["resource_key"]
        )

        # Click Buy
        self.click_by_getbytext("Buy", "Buy Button")

        # Validate Status
        status_locator = self.get_by_text(expected_status)

        self.assert_visible(
            status_locator,
            f"{expected_status} Status"
        )