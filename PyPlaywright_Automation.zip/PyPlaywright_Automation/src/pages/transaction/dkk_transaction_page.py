import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.htg_transaction_locators import HTGTransactionLocators



class DKK_TransactionPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="HTG_Transaction")

    # ---------------------------------
    @allure.step("Open Merchant Demo")
    def open_url(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Start Purchase")
    def start_purchase(self, product):

        if product.lower() == "body soaps":
            self.click_by_role("link", "Body Soaps")

        elif product.lower() == "chocolates":
            self.click_by_role("link", "Chocolates")

        else:
            raise ValueError(f"Invalid product: {product}")

        self.click_by_role("button", "Purchase")

    # ---------------------------------
    @allure.step("Fill Credentials")
    def fill_credentials(self, data):

        self.fill_by_locator(
            HTGTransactionLocators.TRANPORTAL_ID,
            data["tranportal_id"],
            "Tranportal ID"
        )

        self.fill_by_locator(
            HTGTransactionLocators.TRANPORTAL_PWD,
            data["tranportal_pwd"],
            "Tranportal Password"
        )

        self.fill_by_locator(
            HTGTransactionLocators.RESOURCE_KEY,
            data["resource_key"],
            "Resource Key"
        )

    # ---------------------------------
    @allure.step("Click Buy")
    def click_buy(self):
        self.click_by_role("button", "Buy")

    # ---------------------------------
    @allure.step("Enter Card Details")
    def enter_card_details(self, data):

        self.page.get_by_label("Card Number").fill(data["card_number"])
        self.page.get_by_label("Expiry Date").fill(data["expiry"])
        self.fill_by_locator(
        self.locator("#creditCardholderName"),
        data["card_holder"],
        description="Enter Card Holder Name"
)
        self.page.get_by_label("CVV").fill(data["cvv"])

        # self.page.locator(HTGTransactionLocators.CURRENCY).select_option(str(data["currency"]))
        # self.page.locator("button:has-text('Pay')").first.click()
        # self.page.get_by_role("button", name="Pay 130.90 DKK").click()
        self.click_by_xpath("//*[@id='proceed_button']", description="Click Pay")

        # self.page.get_by_role("button", name=re.compile("Pay")).click()

        self.attach_screenshot("Card Details Entered")
    @allure.step("Click Pay Button")
    def click_pay_button(self):
        locator = self.page.locator("button:has-text('Pay')").locator(":visible")
        locator.first.wait_for(state="visible")
        locator.first.click()
        self.logger.info("Clicked correct Pay button")

    # ---------------------------------
    @allure.step("Handle OTP")
    def handle_otp(self, otp):
 
        self.page.wait_for_selector(HTGTransactionLocators.OTP_IFRAME)
 
        frame = self.page.frame_locator(
            HTGTransactionLocators.OTP_IFRAME
    )
 
        frame.get_by_role("textbox").fill(otp)
 
        frame.get_by_role(
        "button",
        name=re.compile("submit", re.I)
    ).click()
 
 
        send_anyway = self.page.get_by_role(
        "button",
        name=re.compile(r"send anyway", re.I)
    )
 
        if send_anyway.is_visible(timeout=10000):
            send_anyway.click()
 
        self.page.wait_for_load_state("networkidle")
 
        self.click_by_locator(
        "//*[@id='proceed-button']",
        "Proceed After OTP"
    )
 
        self.attach_screenshot("OTP Submitted")
    # ---------------------------------
    @allure.step("Verify Approved & Get Payment ID")
    def get_payment_id(self):

        self.assert_visible(
            self.page.get_by_text("CAPTURED"),
            "Payment Approved"
        )

        pid = self.page.locator(
            HTGTransactionLocators.PAYMENT_ID
        ).inner_text().strip()

        assert pid.isdigit(), f"Invalid Payment ID: {pid}"

        return pid

    # ---------------------------------
    @allure.step("Perform Supporting Transaction")
    def supporting_txn(self, action, payment_id, expected_status, data):

        self.page.locator(HTGTransactionLocators.ACTION_DROPDOWN).select_option(str(action))

        self.page.locator(HTGTransactionLocators.UDF5_DROPDOWN).select_option("PaymentID")

        self.page.locator(HTGTransactionLocators.COMMENT_FIELD).fill(payment_id)

        self.fill_credentials(data)

        self.click_buy()

        # ---- IF ELSE ASSERTION ----
        status = expected_status.lower()

        if status == "approved":
            self.assert_visible(self.page.get_by_text("APPROVED"), "Approved")

        elif status == "captured":
            self.assert_visible(self.page.get_by_text("CAPTURED"), "Captured")

        elif status == "voided":
            self.assert_visible(self.page.get_by_text("VOIDED"), "Voided")

        else:
            raise ValueError(f"Invalid status: {expected_status}")