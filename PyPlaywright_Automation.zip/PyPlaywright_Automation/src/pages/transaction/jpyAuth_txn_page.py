import allure
import re
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.jpyAuth_locators import JpyAuthLocators as loc


class jpyAuth_txn(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="JPYAuthTxn")

    # 🔹 Navigation
    @allure.step("Open Homepage")
    def open_homepage(self, url):
        self.navigate(url)

    # 🔹 Product Selection (🔥 FIXED)
    @allure.step("Select product and click purchase")
    def select_product(self, product):

        # Try LINK first
        try:
            self.click_by_getbyrole(
                self.get_by_role("link", name=product),
                description=f"Click product (link): {product}"
            )
        except Exception:
            # Fallback to CELL (your failure case)
            self.click_by_getbyrole(
                self.get_by_role("cell", name=product),
                description=f"Click product (cell): {product}"
            )

        # Click Purchase
        _, role_name, value = loc.PURCHASE_BTN
        self.click_by_getbyrole(
            self.get_by_role(role_name, name=value),
            description="Click Purchase"
        )

    # 🔹 Action
    @allure.step("Select transaction action")
    def select_action(self, action):
        self.select_by_locator(
            self.locator(loc.ACTION_DROPDOWN),
            action,
            description=f"Select action {action}"
        )

    # 🔹 UDF
    def select_udf(self, value):
        self.select_by_locator(
            self.locator(loc.UDF_DROPDOWN),
            value,
            description="Select UDF"
        )

    def enter_comment(self, payment_id):
        self.fill_by_locator(
            self.locator(loc.COMMENT),
            payment_id,
            description="Enter Payment ID"
        )

    # 🔹 Merchant
    @allure.step("Enter merchant details")
    def enter_merchant_details(self, tid, pwd, key):
        self.fill_by_locator(self.locator(loc.TRANPORTAL_ID), tid, "Tranportal ID")
        self.fill_by_locator(self.locator(loc.TRANPORTAL_PWD), pwd, "Tranportal Password")
        self.fill_by_locator(self.locator(loc.RESOURCE_KEY), key, "Resource Key")
        self.fill_by_locator(self.locator(loc.Amount), "70.00", "Amount")

    # 🔹 Buy
    def click_buy(self):
        _, role_name, value = loc.BUY_BTN
        self.click_by_getbyrole(
            self.get_by_role(role_name, name=value),
            description="Click Buy"
        )
    @allure.step("Enter Card Details")
    def enter_card_details(self, data):

        self.page.get_by_label("Card Number").fill(data["card"])
        self.page.get_by_label("Expiry Date").fill(data["expiry"])
        self.fill_by_locator(
        self.locator("#creditCardholderName"),
        data["name"],
        description="Enter Card Holder Name"
)
        self.page.get_by_label("CVV").fill(data["cvv"])

        # self.page.locator(loc.CURRENCY).select_option(str(data["currency"]))
        # self.page.locator("button:has-text('Pay')").first.click()
        # self.page.get_by_role("button", name="Pay 428.29 CZK").click()

        # self.page.get_by_role("button", name=re.compile("Pay")).click()

        self.attach_screenshot("Card Details Entered")    

    # # 🔹 Card Details
    # def enter_card_details(self, card, expiry, name, cvv):
    #     _, role, value = loc.CARD_NUMBER
    #     self.fill_by_getbyrole(self.get_by_role(role, name=value), card, "Card Number")

    #     _, role, value = loc.EXPIRY
    #     self.fill_by_getbyrole(self.get_by_role(role, name=value), expiry, "Expiry Date")

    #     _, role, value = loc.CARD_NAME
    #     self.fill_by_getbyrole(self.get_by_role(role, name=value), name, "Card Holder Name")

    #     _, role, value = loc.CVV
    #     self.fill_by_getbyrole(self.get_by_role(role, name=value), cvv, "CVV")

    # # 🔹 Currency
    def select_currency(self, currency):
        self.select_by_locator(
            self.locator(loc.CURRENCY),
            currency,
            description=f"Select Currency {currency}"
        )

    # 🔹 Pay (🔥 Improved)
    def click_pay(self):
        self.click_by_xpath("//*[@id='proceed_button']", description="Click Pay")

    # 🔹 3DS (🔥 Safer)
    def handle_3ds(self):
        try:
            self.page.wait_for_selector(loc.THREE_DS_IFRAME, timeout=15000)
 
            frame = self.page.frame_locator(loc.THREE_DS_IFRAME)
 
            frame.get_by_role("textbox").fill("1234")
            frame.get_by_role("button", name=re.compile("submit", re.I)).click()
            # frame.get_by_role("button", name=re.compile("submit", re.I)).click()
            send_anyway = self.page.get_by_role(
            "button",
            name=re.compile(r"send anyway", re.I)
    )
 
            if send_anyway.is_visible(timeout=10000):
                send_anyway.click()
 
            self.page.wait_for_load_state("networkidle")
 
            self.click_by_locator(
            "//*[@id='proceed-button']",
            "Proceed After OTP"
    )
 
            self.attach_screenshot("OTP Submitted")
 
        except Exception:
            # No 3DS → skip
            pass

        

    # 🔹 Validation
    def verify_status(self, status):
        self.assert_visible(
            self.get_by_text(status),
            description=f"{status} displayed"
        )

    # 🔹 Payment ID
    def get_payment_id(self):
        return self.locator(loc.PAYMENT_ID).inner_text().strip()