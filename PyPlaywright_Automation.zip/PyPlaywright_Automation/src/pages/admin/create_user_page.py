import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.create_user_locators import CreateUserLocators


class CreateUserPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="CreateUser")

    # ----------------------------
    @allure.step("Open Admin Login Page")
    def open_login(self, url):
        self.navigate(url)

    # ----------------------------
    @allure.step("Login as Admin")
    def login(self, user, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            CreateUserLocators.ADMIN_USER,
            user,
            "Enter Admin User"
        )

        self.fill_by_locator(
            CreateUserLocators.ADMIN_PASSWORD,
            password,
            "Enter Admin Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Admin Login Successful")

    # ----------------------------
    @allure.step("Navigate to Create User Page")
    def navigate_create_user(self):

        self.hover_by_role("link", "My Accounts")

        self.click_by_role("link", "Create User")

        self.attach_screenshot("Opened Create User Page")

    # ----------------------------
    @allure.step("Click Add User")
    def click_add_user(self):

        self.click_by_role("button", "Add")

    # ----------------------------
    @allure.step("Fill User Details")
    def fill_user_details(self, data):

        self.fill_by_locator(
            CreateUserLocators.USER_NAME,
            data["user_name"],
            "Enter User Name"
        )

        self.fill_by_locator(
            CreateUserLocators.LOGIN_ID,
            data["login_id"],
            "Enter Login ID"
        )

        self.fill_by_locator(
            CreateUserLocators.PASSWORD,
            data["password"],
            "Enter Password"
        )

        # Role Selection
        self.select_custom_dropdown(CreateUserLocators.ROLE_DROPDOWN, data["role"])
        # self.page.locator("div").filter(has_text="- Select -").click()
        # self.page.get_by_text(data["role"]).click()

        self.fill_by_locator(
            CreateUserLocators.EMAIL,
            data["email"],
            "Enter Email"
        )

        self.fill_by_locator(
            CreateUserLocators.MOBILE,
            data["mobile"],
            "Enter Mobile Number"
        )

        self.attach_screenshot("Filled User Details")

    # ----------------------------
    @allure.step("Save User")
    def save_user(self):

        self.click_by_role("button", "Save")

        self.attach_screenshot("Clicked Save Button")

    # ----------------------------
    @allure.step("Logout")
    def logout(self):

        self.click_by_role("link", "Logout")