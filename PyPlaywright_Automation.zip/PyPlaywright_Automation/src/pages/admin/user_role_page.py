import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.user_Adminrole_locators import UserRoleLocators


class UserRolePage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="UserRole")

    # ---------------------------------
    @allure.step("Open Admin Login Page")
    def open_login(self, url):
        self.navigate(url)

    # ---------------------------------
    @allure.step("Login as Admin")
    def login(self, user, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            UserRoleLocators.ADMIN_USER,
            user,
            "Enter Admin Username"
        )

        self.fill_by_locator(
            UserRoleLocators.ADMIN_PASSWORD,
            password,
            "Enter Admin Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Logged in Successfully")

    # ---------------------------------
    @allure.step("Navigate to User Role Page")
    def navigate_user_role(self):

        self.page.get_by_role("link", name=re.compile(r"My(\s|\xa0)*Accounts")).hover()

        self.page.get_by_role("link", name=re.compile(r"User(\s|\xa0)*Role")).click()

        self.page.get_by_text(re.compile(r"Close\s*User\s*Role", re.I)).click()

        self.attach_screenshot("Opened User Role Page")

    # ---------------------------------
    @allure.step("Click Add User Role")
    def click_add_role(self):

        self.click_by_role("button", "Add")

    # ---------------------------------
    @allure.step("Fill User Role Details")
    def fill_user_role_details(self, data):

        self.page.get_by_role(
            "textbox",
            name=re.compile(r"Minimum\s*Length\s*:\s*5.*Maximum\s*Length\s*:\s*25.*Alphanumeric", re.I)
        ).fill(data["role_name"])

        # Select Institution User
        self.page.get_by_text("- Select -", exact=True).first.click()

        self.page.get_by_text(data["role_type"], exact=True).click()

        # Display Name
        self.page.get_by_role(
            "textbox",
            name=re.compile(r"Minimum\s*Length\s*:\s*5.*Maximum\s*Length\s*:\s*25.*Alphabetic", re.I)
        ).fill(data["display_name"])

        self.attach_screenshot("Filled User Role Details")

    # ---------------------------------
    @allure.step("Save User Role")
    def save_role(self):

        self.click_by_role("button", "Save")

        self.attach_screenshot("Clicked Save Button")

    # ---------------------------------
    @allure.step("Validate User Role Creation")
    def validate_role_created(self):

        self.assert_visible(
            self.page.get_by_text(re.compile(r"Created successfully", re.I)),
            "User Role Created Successfully"
        )

    # ---------------------------------
    @allure.step("Logout from Application")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logout Successful")