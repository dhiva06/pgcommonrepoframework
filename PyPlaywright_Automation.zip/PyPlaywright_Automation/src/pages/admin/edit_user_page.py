import re
import allure
from playwright.sync_api import Page
from pages.base_page import BasePage
from locators.edit_user_locators import EditUserLocators


class EditUserPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page, module_name="EditUser")

    # ---------------------------------
    @allure.step("Open Admin Login Page")
    def open_login(self, url):

        self.navigate(url)

    # ---------------------------------
    @allure.step("Login as Admin")
    def login(self, user, password):

        self.click_by_role("link", "Login")

        self.fill_by_locator(
            EditUserLocators.ADMIN_USER,
            user,
            "Enter Admin Username"
        )

        self.fill_by_locator(
            EditUserLocators.ADMIN_PASSWORD,
            password,
            "Enter Admin Password"
        )

        self.click_by_role("button", "Submit")

        self.attach_screenshot("Logged in Successfully")

    # ---------------------------------
    @allure.step("Navigate to Create User Page")
    def navigate_create_user(self):

        self.page.get_by_role(
            "link",
            name=re.compile(r"My(\s|\xa0)*Accounts")
        ).hover()

        self.page.get_by_role(
            "link",
            name=re.compile(r"Create(\s|\xa0)*User")
        ).click()

        self.attach_screenshot("Navigated to Create User Page")

    # ---------------------------------
    @allure.step("Search User")
    def search_user(self, username,data):

        self.select_custom_dropdown(EditUserLocators.SEARCH_DROPDOWN, data)

        self.fill_by_locator(
            EditUserLocators.SEARCH_VALUE,
            username,
            "Enter Username for Search"
        )

        self.click_by_role("button", "Search")

        self.attach_screenshot("User Search Completed")

    # ---------------------------------
    @allure.step("Edit User Name")
    def edit_user(self, new_name):

        self.click_by_role("link", "Edit")

        self.fill_by_role(
            "textbox",
            "Minimum Length : 5, Maximum",
            new_name
        )

        self.attach_screenshot("Navigated to Edit User Page and Updated Username")

    # ---------------------------------
    @allure.step("Save Updated User")
    def save_user(self):

        self.click_by_role("button", "Save")

        self.attach_screenshot("Clicked Save Button")

    # ---------------------------------
    @allure.step("Logout from Application")
    def logout(self):

        self.click_by_role("link", "Logout")

        self.attach_screenshot("Logout Successful")